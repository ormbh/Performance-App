# Performance App v108

Extract the complete ZIP, then open `index.html` in your browser. All fonts,
images and scripts are local; no server or installation is required by the app.
Imported data is processed on your device.

## Report workspace

Primary navigation is separate from page tools. **محفظة المشاريع** opens the portfolio-delivery overview. A compact scope toolbar shows
active selections even when the filters are closed. Open **تصفية** to select
multiple values and search the option list. Values within one filter form a union;
different filters intersect. **مسح التصفية** resets the scope. Empty selection
means all values. Blank source values remain distinct and available for selection.
Filter choices group equivalent spacing, Arabic presentation forms and invisible
formatting characters into one visible option. Selecting it includes every exact
source token required by existing filter rules; records and identifiers are not
merged or rewritten. Genuinely different values sharing a translated label remain
separate and display their source values. Existing partial selections stay intact
until you change them; group chips, counts and summaries do not duplicate aliases.
Filter popups have one scrollable options list. The title, search field and
select-all/clear controls remain visible. Short screens use the available viewport
instead of clipping these controls; focused filters stay open when it shrinks.

The strategy card omits the unmeasured-count line; its measurement population and
averages remain unchanged. The legislation card explains **تجاوز الموعد** at the
bottom right: **أُنجز بعد أحد المواعيد المسجّلة في الملف.** This preserves the mold's
actual-date rule and refers to completed work, separately from current delays.
Native pie reports place counts and percentages in the editable legend so small
slices stay legible. Legend annotations reflect the scope at export time; numeric
chart series and embedded workbooks remain editable.

Monthly report content appears first: executive portfolios on the right and
projects on the left, matching the RTL source mold. Strategy, decisions and
legislation use the same metric typography. Data tables are displayed as sections
rather than closed disclosures; long tables and full notes remain readable.

**طباعة التقرير** prints the currently filtered report directly. The adjacent
**إعدادات الطباعة** opens a native dialog without scrolling away from the filters.
Calculation-date and A4/A3 changes apply immediately; **حفظ الإعدادات** closes the
dialog and returns focus to the same print button. The file name, selected
calculation date and source reference (when different) appear at the screen footer.
Monthly printed pages retain the organizational wording and copyright only.
The source filename and calculation-date footer line are removed; the report
cutoff stays in the header.
Source/reporting/history dates retain separate meanings. Help and source-quality
explanations can still collapse.

No demonstration records, demonstration-file fingerprint, data-purpose selector
or automatic sample classification are included. Retired purpose metadata and
explicitly marked sample caches are cleared during upgrade. Files you import
normally retain the existing local-session behavior. The browser can keep the
imported file in session storage for reload/new-tab workflows; nothing is sent to
an external service. Source files and full notes remain unchanged.

## Portfolio delivery

The Projects page opens with portfolio totals and visible sector/unit comparison
tables. Individual project records open when you select a total; the return
button restores the overview. The parent organization is shown as context rather
than a sector. The legacy strategic-budget Projects population and imported
organizational hierarchy are preserved. No illustrative unit names or records
are included. The supplied mold contains five sector labels; a three-sector
reclassification requires an agreed mapping rather than a guessed one.

Group tables show status counts, planned-date exceptions, completion rate,
validated snapshot movement and paired spending/budget coverage. The deadline
table separates 1–30,31–60 and61–90-day windows; the current-month column is an
independent view of open projects and must not be added to those windows.
Overdue projects overlap open status counts. All views and drilldowns use the
selected filters and calculation date.

Spending and allocated budget retain their source labels and separate coverage.
Financial utilization uses projects with both a positive approved budget and a
nonnegative recorded expenditure. Spending is not delivery achievement.
An available balance, on-time completion, approved changes and required decisions
remain unavailable when the corresponding source fields are absent. Missing
history stays unavailable; movement requires two confirmed, dated snapshots with
exact, unambiguous project identities. Observed revisions are not approvals.

**عرض جميع البنود** opens the filtered follow-up list in the same tab, including
when browser popup opening is blocked. Council report defaults use
**مستجدات قرارات المجالس** plus the selected calculation year and
**حتى تاريخ** plus the selected cutoff. Custom titles and periods remain intact
until you reset them.

## Measurement and comparison definitions

Annual KPI zeros count as measured only with an explicit measurement-state field:
`حالة القياس`, `Measurement State` or `Measurement Status`. Supported values:
`مقاس`/`Measured`, `غير مقاس`/`Unmeasured`, `لا ينطبق`/`Not applicable`.
Absent or blank state retains the existing nonzero measurement rule. Invalid,
missing, not-applicable and conflicting states are distinguished. Incompatible
measurement definitions withhold comparisons and show the reason. Result and
target averages use their separate source populations; thresholds and weighting
are not invented. Zero metric readings display an ASCII dash (-); unavailable values use an em dash.
Their numeric values and measurement states remain distinct and unchanged;
unchanged comparison indicators stay blank.

The application reads cached Excel formula results. It does not recalculate all
Excel formulas or refresh Power Query. Named tables and valid renamed sheets are
supported. Ambiguous identifiers are retained for review and excluded from
resolved historical matches rather than merged by title or row number.

## Upgrade and verification

Keep the prior app and browser data until you have checked your notes/settings.
Use the same browser/profile and location where possible. Full note text and
existing storage keys are preserved. File-origin storage behavior varies between
browsers; back up notes before moving folders or changing profiles.

Browser execution over local HTTP, responsive RTL layouts, keyboard interactions,
scoped imports/filters/CSV and generated monthly PDFs were tested in the delivery
review. Default detailed-report titles derive their year from the selected cutoff; the displayed period
defaults to the selected calculation cutoff. User-entered titles/periods are preserved.
Native file-opening is blocked by the managed test browser, so Windows
Edge double-click startup, Microsoft PowerPoint interactive editing, physical
printing and full screen-reader certification remain not run. This is not a claim
of unconditional production readiness.

Readable source modules are bundled locally by `python tools/build-bundles.py`.
`python tools/build-bundles.py --check` checks bundle consistency.
