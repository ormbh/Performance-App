/* Portfolio delivery readings from the selected Projects source population.
 * Status, due-date and finance populations are separate. No RAG policy, actual
 * completion dates, approvals, decisions or historical observations are inferred. */
(function(S){
 'use strict';
 var U=S.util,R=S.rules,PARENT='الأمانة العامة للمجلس التنفيذي';
 var STATUS=[['completed','منجز'],['active','قيد العمل'],['notStarted','لم يبدأ'],['suspended','معلق'],['cancelled','ملغى'],['transferred','منقول'],['delayed','متأخر حسب الحالة'],['unknown','حالة غير محسومة']];
 var FINANCE=[['approved','الموازنة الأصلية'],['revised','الموازنة المعتمدة'],['committed','المخصص'],['spent','المنفق حسب الفواتير'],['nonCommitted','غير المخصص']];
 function key(v){return U.key(v==null?'':String(v));}
 function status(it){var v=key(it.t.status),canonical={done:'completed',progress:'active',notStarted:'notStarted',hold:'suspended',cancelled:'cancelled',transferred:'transferred',delayed:'delayed'};return {completed:'completed',active:'active','not started':'notStarted',frozen:'suspended',cancelled:'cancelled',transferred:'transferred'}[v]||canonical[it.statusCat]||'unknown';}
 function serial(c){return c&&c.t==='n'&&Number.isFinite(c.v)&&c.v>0&&c.v<2958466?Math.floor(c.v):null;}
 function due(it){var v=it.calc&&it.calc.due;return typeof v==='number'&&Number.isFinite(v)&&v>0&&v<2958466?Math.floor(v):null;}
 function money(it,field){return S.projectsReport.money(it.c[field]);}
 function statusCounts(items){var out={};STATUS.forEach(function(p){out[p[0]]=items.filter(function(it){return status(it)===p[0];}).length;});return out;}
 function open(it){return ['active','notStarted'].includes(status(it));}
 function model(state,baseModel){
  var data=state.data,base=baseModel||S.projects.model(state),items=base.items.slice(),cutoff=data&&U.validDateSerial(data.today)?Math.floor(data.today):null;
  var selections=new Map(),labels=new Map();
  function collection(id,label,rows,extra){selections.set(id,rows.slice());labels.set(id,label);return Object.assign({id:id,label:label,total:rows.length,items:rows.slice()},extra||{});}
  var all=collection('overview:all','جميع المشاريع ضمن النطاق',items),completed=collection('overview:completed','منجز حسب الحالة',items.filter(function(it){return status(it)==='completed';}));
  var overall=Object.assign({},all,{completed:completed.total,completedId:completed.id,completionRate:items.length?completed.total/items.length*100:null,statusCounts:statusCounts(items),overdue:0});
  var statuses=STATUS.map(function(p){return collection('status:'+p[0],p[1],items.filter(function(it){return status(it)===p[0];}),{key:p[0]});});
  // Source LOV hierarchy is authoritative. Parent organisation is context, never
  // one of the sector rows. Unknown and conflicting source classifications remain.
  var sectorNames=(data.lovs.lists.Sectors||[]).filter(function(v){return key(v)!==key(PARENT);}),sectorSet=new Set(sectorNames.map(key));
  var unitParents=data.lovs.departmentSector||new Map(),groupsMap=new Map(),unresolvedRows=[];
  items.forEach(function(it){var sector=it.sector||'',unit=it.unit||'',parent=unitParents.get(key(unit)),kind,name,reason='';
   if(key(sector)===key(PARENT)){
    if(unit&&parent&&key(parent)===key(PARENT)){kind='unit';name=unit;}
    else{kind='unresolved';name=unit?'وحدة مستقلة غير محسومة: '+unit:'وحدة مستقلة غير مسجلة';reason='المصدر يحدد الأمانة العامة دون وحدة مستقلة معتمدة قابلة للتعيين';}
   }else if(sectorSet.has(key(sector))&&(!parent||key(parent)===key(sector))){kind='sector';name=sector;}
   else{kind='unresolved';name=sector?'تصنيف يحتاج مراجعة: '+sector:'قطاع / وحدة غير محسومين';reason=parent&&key(parent)!==key(sector)?'القطاع والوحدة لا يتوافقان مع علاقة المصدر':'لم يُحسم التصنيف من حقول المصدر وقائمة الوحدات';}
   var id='group:'+kind+':'+encodeURIComponent(name);if(!groupsMap.has(id))groupsMap.set(id,{id:id,kind:kind,name:name,items:[],reason:reason});groupsMap.get(id).items.push(it);if(kind==='unresolved')unresolvedRows.push(it);
  });
  var groups=Array.from(groupsMap.values()).map(function(g){var rows=g.items,done=rows.filter(function(it){return status(it)==='completed';}),late=rows.filter(function(it){return open(it)&&cutoff!=null&&due(it)!=null&&due(it)<cutoff;});collection(g.id,g.name,rows);collection(g.id+':completed','منجز · '+g.name,done);STATUS.forEach(function(p){collection(g.id+':status:'+p[0],p[1]+' · '+g.name,rows.filter(function(it){return status(it)===p[0];}));});return Object.assign(g,{total:rows.length,completed:done.length,completedId:g.id+':completed',completionRate:rows.length?done.length/rows.length*100:null,statusCounts:statusCounts(rows),overdue:cutoff==null?null:late.length,blankUnits:rows.filter(function(it){return !it.unit;}).length,selection:{id:g.id}});});
  groups.sort(function(a,b){var rank={sector:0,unit:1,unresolved:2};return rank[a.kind]-rank[b.kind]||(a.kind==='sector'?sectorNames.map(key).indexOf(key(a.name))-sectorNames.map(key).indexOf(key(b.name)):S.order.compare(data,'Departments',a.name,b.name));});
  var currentMonth=cutoff!=null?U.ymd(cutoff):null;
  function pending(predicate){return items.filter(function(it){return open(it)&&predicate(it,due(it));});}
  var timeline={
   dueThisMonth:collection('timeline:dueThisMonth','موعد انتهاء مخطط خلال شهر المرجع',pending(function(it,d){if(d==null||!currentMonth)return false;var x=U.ymd(d);return x.y===currentMonth.y&&x.m===currentMonth.m;})),
   next30:collection('timeline:next30','استحقاق خلال 1–30 يوماً',pending(function(it,d){return d!=null&&cutoff!=null&&d-cutoff>=1&&d-cutoff<=30;})),
   next60:collection('timeline:next60','استحقاق خلال 31–60 يوماً',pending(function(it,d){return d!=null&&cutoff!=null&&d-cutoff>=31&&d-cutoff<=60;})),
   next90:collection('timeline:next90','استحقاق خلال 61–90 يوماً',pending(function(it,d){return d!=null&&cutoff!=null&&d-cutoff>=61&&d-cutoff<=90;})),
   overdue:collection('timeline:overdue','تجاوز موعد الانتهاء المخطط',pending(function(it,d){return d!=null&&cutoff!=null&&d<cutoff;})),
   later:collection('timeline:later','استحقاق بعد 90 يوماً',pending(function(it,d){return d!=null&&cutoff!=null&&d-cutoff>90;})),
   dueToday:collection('timeline:dueToday','استحقاق في تاريخ المرجع',pending(function(it,d){return d!=null&&cutoff!=null&&d===cutoff;})),
   undated:collection('timeline:undated','مشاريع مفتوحة دون موعد انتهاء صالح',pending(function(it,d){return d==null;}))
  };
  timeline.openTotal=items.filter(open).length;
  overall.overdue=cutoff==null?null:timeline.overdue.total;
  if(cutoff==null)Object.keys(timeline).forEach(function(k){if(k!=='undated'&&k!=='openTotal'){timeline[k].available=false;timeline[k].value=null;timeline[k].reason='التاريخ المرجعي للحسابات غير متاح';}});
  var actualRows=completed.items.filter(function(it){return serial(it.c.actualCompletion)!=null&&due(it)!=null;}),onTime=actualRows.filter(function(it){return serial(it.c.actualCompletion)<=due(it);});
  timeline.deliveredOnTime=Object.assign(collection('timeline:deliveredOnTime','الإنجاز في الموعد وفق تاريخ الإنجاز الفعلي',onTime),{available:actualRows.length>0,value:actualRows.length?onTime.length:null,known:actualRows.length,total:completed.total,rate:actualRows.length?onTime.length/actualRows.length*100:null,reason:actualRows.length?'':'لا يتوفر تاريخ إنجاز فعلي في حقول المصدر؛ الحالة المنجزة لا تثبت الإنجاز في الموعد'});
  var finance=FINANCE.map(function(f){var rows=items.filter(function(it){return money(it,f[0])!=null;}),value=rows.length?rows.reduce(function(sum,it){return sum+money(it,f[0]);},0):null;collection('finance:'+f[0],f[1]+' · مشاريع بقيم مسجلة',rows);return {id:'finance:'+f[0],key:f[0],name:f[1],label:f[1],value:value,known:rows.length,total:items.length,coverage:items.length?rows.length/items.length:null,available:rows.length>0,note:f[0]==='committed'?'المخصص كما ورد في المصدر؛ لا يُعاد تفسيره تلقائياً كالتزامات تعاقدية':f[0]==='nonCommitted'?'غير المخصص حقل مستقل؛ لا يُعاد تفسيره كرصيد متاح':'قيم المصدر؛ المنفق لا يقيس الإنجاز',reason:rows.length?'':'لا تتوفر قيم رقمية صالحة في النطاق'};});
  finance.push({id:'finance:available',key:'available',label:'الرصيد المتاح',name:'الرصيد المتاح',value:null,known:0,total:items.length,available:false,reason:'المصدر لا يعرّف حقلاً للرصيد المتاح؛ لم يُحسب بطرح المنفق أو المخصص'});
  var paired=items.filter(function(it){return money(it,'revised')!=null&&money(it,'spent')!=null&&money(it,'revised')>0&&money(it,'spent')>=0;}),sumBudget=paired.reduce(function(n,it){return n+money(it,'revised');},0),sumSpent=paired.reduce(function(n,it){return n+money(it,'spent');},0);
  var financeCoverage={id:'finance:spendingRatio',known:paired.length,total:items.length,revised:paired.length?sumBudget:null,spent:paired.length?sumSpent:null,ratio:sumBudget>0?sumSpent/sumBudget*100:null,reason:'نسبة المنفق للموازنة على المشاريع بقيم مزدوجة صالحة؛ لا تعبر عن الإنجاز'};collection(financeCoverage.id,'مشاريع مؤهلة لمقارنة المنفق والموازنة',paired);
  groups.forEach(function(g){
   g.timeline={};g.timelineIds={};
   ['dueThisMonth','next30','next60','next90','overdue','undated','later','dueToday'].forEach(function(k){var wanted=new Set(timeline[k].items),selected=g.items.filter(function(it){return wanted.has(it);}),id=g.id+':timeline:'+k;collection(id,timeline[k].label+' · '+g.name,selected);g.timelineIds[k]=id;g.timeline[k]=cutoff==null&&k!=='undated'?null:selected.length;});
   var pair=g.items.filter(function(it){return money(it,'revised')!=null&&money(it,'spent')!=null&&money(it,'revised')>0&&money(it,'spent')>=0;}),budget=pair.reduce(function(n,it){return n+money(it,'revised');},0),spent=pair.reduce(function(n,it){return n+money(it,'spent');},0),id=g.id+':finance:spendingRatio';collection(id,'مشاريع مؤهلة لمقارنة المنفق والموازنة · '+g.name,pair);
   g.financeUtilisation={id:id,known:pair.length,total:g.total,scopeBudget:pair.length?budget:null,scopeSpent:pair.length?spent:null,ratio:budget>0?spent/budget*100:null,available:pair.length>0,reason:'نسبة المنفق للموازنة على المشاريع بقيم مزدوجة صالحة؛ لا تعبر عن الإنجاز'};
   g.monthlyDelta={available:false,reason:'لا تتوفر لقطتان مؤكدتان بهويات محسومة للمقارنة',previousTotal:null,currentTotal:g.total,totalDelta:null,previousCompleted:null,currentCompleted:g.completed,completedDelta:null,completionRateDelta:null};
  });

  var exceptionRows=[['noOwner','مدير المشروع غير مسجل',items.filter(function(it){return !String(it.t.pm||'').trim();}),'حقل مدير المشروع فارغ'],['undated','موعد الانتهاء غير متاح',timeline.undated.items,'موعد مخطط غير صالح؛ لا يُفترض تأخر'],['invalidProgress','نسبة الإنجاز غير متاحة أو غير صالحة',items.filter(function(it){return !it.c.progress||it.c.progress.t!=='n'||!Number.isFinite(it.progress)||it.progress<0||it.progress>100;}),'النتيجة المفقودة لا تُحول إلى صفر'],['negativeFinance','قيم مالية سالبة مسجلة',items.filter(function(it){return FINANCE.some(function(f){var n=money(it,f[0]);return n!=null&&n<0;});}),'قيم المصدر محفوظة؛ تتطلب تفسير مسؤول البيانات'],['unresolvedClassification','تصنيف تنظيمي يحتاج مراجعة',unresolvedRows,'السجلات محفوظة ضمن الإجمالي وفي صف مستقل']];
  var exceptions=exceptionRows.map(function(x){return collection('exceptions:'+x[0],x[1],x[2],{description:x[3]});});
  var noHistory='لا تتوفر نسختان مختلفتان بتاريخي لقطة مؤكدين وهوية قابلة للمطابقة؛ الملخص السابق وحده لا يثبت حركة مشاريع';
  var history={available:false,reason:noHistory,points:[],unresolved:[],metrics:[]};
  ['added','closed','suspended','changed'].forEach(function(k){history[k]=collection('movement:'+k,{added:'مشاريع مضافة بين اللقطتين',closed:'انتقلت إلى حالة منجزة بين اللقطتين',suspended:'انتقلت إلى حالة معلقة بين اللقطتين',changed:'تغيرت بيانات المصدر بين اللقطتين'}[k],[],{value:null,available:false});});
  var periods=state.comparison||{},err=S.comparison.validate(periods.previous||{},periods.current||{},state.previous,data);
  if(!err){
   var priorState=Object.assign({},state,{data:state.previous}),priorModel=S.projectsReport.model(S.projects.adapter(priorState)),priorItems=priorModel.items,oldSet=new Set(priorItems),newSet=new Set(items),scope=Object.assign({},state.projects||{}),raw=S.comparison.compare(state.previous,data,scope);
   var rows=raw.rows.filter(function(x){return x.pf==='secretariat'&&((x.before&&oldSet.has(x.before))||(x.after&&newSet.has(x.after)));}),unresolved=raw.unresolved.filter(function(x){return x.it.pf==='secretariat'&&((x.role==='previous'&&oldSet.has(x.it))||(x.role==='current'&&newSet.has(x.it)));});
   // Show observed source-field revisions, never label them approved changes.
   rows.forEach(function(x){if(!x.before||!x.after)return;[['approved','الموازنة الأصلية'],['revised','الموازنة المعتمدة'],['committed','المخصص'],['spent','المنفق حسب الفواتير'],['nonCommitted','غير المخصص'],['start','تاريخ البدء المخطط'],['desc','نبذة حول المشروع']].forEach(function(f){var a=x.before.c[f[0]],b=x.after.c[f[0]],av=a?{type:a.t,value:a.v}:null,bv=b?{type:b.t,value:b.v}:null;if(JSON.stringify(av)!==JSON.stringify(bv))x.changes.push({field:f[1],before:x.before.t[f[0]]||null,after:x.after.t[f[0]]||null,category:['start'].includes(f[0])?'dates':f[0]==='desc'?'source':'budget',approved:false});});});
   var available=!unresolved.length,reason=available?'':'توجد هويات مفقودة أو مكررة أو غير محسومة؛ حركة المشاريع غير مكتملة ولم تُعرض كحركة مؤكدة';
   history.available=available;history.reason=reason;history.unresolved=unresolved;
   if(available){
    var movement={added:rows.filter(function(x){return x.kind==='added'&&x.after&&newSet.has(x.after);}),closed:rows.filter(function(x){return x.before&&x.after&&newSet.has(x.after)&&status(x.before)!=='completed'&&status(x.after)==='completed';}),suspended:rows.filter(function(x){return x.before&&x.after&&newSet.has(x.after)&&status(x.before)!=='suspended'&&status(x.after)==='suspended';}),changed:rows.filter(function(x){return x.before&&x.after&&newSet.has(x.after)&&x.changes.length;})};
    Object.keys(movement).forEach(function(k){var refs=movement[k].map(function(x){return x.after||x.before;});history[k]=collection('movement:'+k,history[k].label,refs,{available:true,value:refs.length,records:movement[k]});});
    history.points=[{date:periods.previous.date,total:priorItems.length,completed:priorItems.filter(function(it){return status(it)==='completed';}).length},{date:periods.current.date,total:items.length,completed:completed.total}];
    var priorDelivery=model(Object.assign({},priorState,{previous:null,comparison:{previous:{},current:{}}}),priorModel),priorGroups=new Map(priorDelivery.groups.map(function(g){return [g.id,g];}));
    groups.forEach(function(g){var before=priorGroups.get(g.id),prevTotal=before?before.total:0,prevDone=before?before.completed:0,prevRate=prevTotal?prevDone/prevTotal*100:null;g.monthlyDelta={available:true,reason:'صافي تغير عدد المشاريع ضمن التصنيف بين اللقطتين؛ لا يثبت إضافة عمل أو اعتماد تغيير',previousTotal:prevTotal,currentTotal:g.total,totalDelta:g.total-prevTotal,previousCompleted:prevDone,currentCompleted:g.completed,completedDelta:g.completed-prevDone,completionRateDelta:g.completionRate!=null&&prevRate!=null?g.completionRate-prevRate:null};});
    history.priorOnlyGroups=priorDelivery.groups.filter(function(g){return !groups.some(function(currentGroup){return currentGroup.id===g.id;});}).map(function(g){return {id:g.id,kind:g.kind,name:g.name,previousTotal:g.total,currentTotal:0,totalDelta:-g.total,reason:'التصنيف غير موجود ضمن نطاق اللقطة الحالية؛ لا يثبت إلغاء المشاريع'};});

    history.metrics=['added','closed','suspended','changed'].map(function(k){return history[k];});
   }
  }else history.reason=err;
  var groupItems=groups.flatMap(function(g){return g.items;}),unique=new Set(groupItems),reconciliation={total:items.length,groupTotal:groupItems.length,uniqueKeys:unique.size,passed:groupItems.length===items.length&&unique.size===items.length};
  return {scopePortfolio:'secretariat',items:items,total:items.length,cutoff:cutoff,overall:overall,statuses:statuses,groups:groups,parentContext:{name:PARENT,total:items.length,directUnitsTotal:groups.filter(function(g){return g.kind==='unit';}).reduce(function(n,g){return n+g.total;},0),units:groups.filter(function(g){return g.kind==='unit';})},reconciliation:reconciliation,timeline:timeline,finance:finance,financeCoverage:financeCoverage,history:history,exceptions:exceptions,decisions:{available:false,reason:'المصدر لا يحدد قرارات مطلوبة أو جهة اعتماد؛ ملاحظات المتابعة لا تُحوّل تلقائياً إلى طلب قرار',items:[]},changes:{available:false,reason:'لا تتوفر حقول اعتماد تغييرات النطاق أو الموازنة أو الجدول؛ فروق المصدر ليست اعتمادات',items:[]},selections:selections,labels:labels,definitions:{completion:'المنجز حسب الحالة ÷ جميع المشاريع ضمن النطاق؛ تشمل جميع الحالات',deadline:'نهاية شهر الانتهاء وفق قاعدة المصدر وتاريخ الحساب المختار؛ الاستحقاقات تخص Active وNot Started فقط',history:'لقطتان مؤكدتان ومطابقة هوية دقيقة؛ نقطتان ليستا سلسلة اتجاه شهرية'}};
 }
 function select(m,id){return m&&m.selections&&m.selections.has(id)?m.selections.get(id).slice():[];}
 function label(m,id){return m&&m.labels&&m.labels.has(id)?m.labels.get(id):'اختيار غير متاح';}
 S.portfolioDelivery={model:model,select:select,label:label,status:status};
})(window.Saytara=window.Saytara||{});
