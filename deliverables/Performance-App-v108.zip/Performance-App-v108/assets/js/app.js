/*
 * Performance reporting · application controller
 * Holds the state, switches screens (the address hash keeps the browser's Back
 * button working), reads the chosen file and routes every click and key press.
 */
(function (S) {
  'use strict';

  var U = S.util, SC = S.schema;
  var SESSION_KEY = 'saytara.file', RECENT_KEY = 'saytara.recent';
  // Remove retired source-purpose metadata only. User notes and settings remain.
  // An opaque imported workbook is never guessed to be a sample by name/hash.
  (function retireSourcePurpose() {
    try {
      var storage = window.localStorage, retired = [];
      for (var n = 0; n < storage.length; n++) {
        var key = storage.key(n);
        if (key && key.indexOf('performance.source-purpose.v1:') === 0) retired.push(key);
      }
      retired.forEach(function(key) { storage.removeItem(key); });
    } catch (ignore) {}
    function explicitlyMarked(value) {
      return value && (value.sourcePurpose === 'sample' || value.purpose === 'sample' || value.sample === true);
    }
    ['saytara.file','saytara.comparison.v1'].forEach(function(key) {
      try {
        var raw = U.store.get('sessionStorage',key); if (!raw) return;
        var value = JSON.parse(raw);
        if (explicitlyMarked(value)) { U.store.del('sessionStorage',key); return; }
        if (!value || !value.files) return;
        var changed = false;
        ['current','previous'].forEach(function(role) {
          if (explicitlyMarked(value.files[role])) { delete value.files[role]; changed = true; }
        });
        if (changed) {
          if (!value.files.current && !value.files.previous) U.store.del('sessionStorage',key);
          else U.store.set('sessionStorage',key,JSON.stringify(value));
        }
      } catch (ignore) {}
    });
  })();

  var TITLES = { projects:'محفظة المشاريع', entities:'تقرير الجهات', upload: 'رفع الملف', home: 'البحث في الأداء / Performance Search', results: 'نتائج البحث', dashboard: 'التقرير الشهري للأداء والتنفيذ', checks: 'ملاحظات البيانات', comparison:'المقارنة الشهرية', reports: 'التقارير' };

  function newSearch() {
    return { q: '', tab: 'all', f: S.search.emptyF(), drill: null, sort: null, page: 1, columns: S.views.results.loadColumns(), browse: false, force: false };
  }
  function loadRecent() {
    try { var r = JSON.parse(U.store.get('localStorage', RECENT_KEY) || '[]'); return Array.isArray(r) ? r.filter(function(x){return typeof x==='string'&&x.length<=20000;}).slice(0, 4) : []; } catch (e) { return []; }
  }

  var state = {
    projects:S.projects.defaults(), monthly:{layout:U.store.get('localStorage','saytara.monthly-layout')==='a3'?'a3':'a4'},
    entity:{entity:'',role:'primary'}, previous:null, comparison:{previous:{},current:{},scope:{sector:'',unit:'',entity:''},busy:false,error:''}, data: null, screen: 'upload', upload: { status: 'idle', error: null, fileName: '' },
    report: { kind: 'agenda', lead: '', type: '', followup:'', projectType:'', priority:'', quarter:'', projectStatus:'' }, search: newSearch(), dash: { sector: '', unit: '', entity: '', entityMode: 'concerned' }, checks: { sheet: '', severity: '' },
    openKey: null, menu: null, navOpen: false, filterPanels: {}, sugOpen: false, fuOpen: {}, recent: loadRecent(), lastRes: null, lastDash: null, reporting: false
  };

  var root = document.getElementById('app');
  var overlay = document.getElementById('overlay');
  var tipEl = document.getElementById('tip');
  var toastEl = document.getElementById('toast');
  var lastFocus = null, toastTimer = 0, raf = 0;

  var printPending = false, printSession = null, printDisclosures = null, printRestore = null;
  function finishPrintRestore() {
    if(!printRestore||(window.matchMedia&&window.matchMedia('print').matches))return;
    var saved=printRestore;printRestore=null;
    if(state.screen===saved.screen){
      if(saved.focus&&document.contains(saved.focus)&&saved.focus.focus)saved.focus.focus({preventScroll:true});
      window.scrollTo(saved.scroll.x,saved.scroll.y);
    }
  }
  function screenTitle() {
    return state.screen === 'reports' ? S.reportDisplay.fileTitle(S.reportDisplay.get(state).fileTitle) : TITLES[state.screen];
  }
  function beginPrint() {
    hideTip();
    if(state.screen==='results')S.views.results.preparePrint(state);
    if(state.screen==='dashboard'&&state.data&&S.monthlyPrint){
      var monthlyRoot=document.getElementById('monthly-print-root');
      var monthlyHistory=S.comparison&&S.comparison.dashboardHistory?S.comparison.dashboardHistory(state):null;
      var monthlyDash=S.rules.dashboard(state.data,state.dash,monthlyHistory);
      state.lastDash=monthlyDash;
      if(monthlyRoot)monthlyRoot.innerHTML=S.monthlyPrint.render(state,monthlyDash);
      document.body.setAttribute('data-monthly-layout',S.monthlyTools?S.monthlyTools.layout(state):state.monthly.layout);
    }else document.body.removeAttribute('data-monthly-layout');
    if(state.screen==='entities'&&!printSession){var entityPrint=document.getElementById('entity-print-report');if(entityPrint)entityPrint.innerHTML=S.views.entities.printReport(state);}
    if (!printSession) {
      // The same complete source selection is present on screen and in print.
      // Preserve existing DOM and focus rather than rebuilding the record list.
      printSession = { title: document.title, screen: state.screen, kind: state.report.kind,
        focus:document.activeElement,scroll:{x:window.scrollX,y:window.scrollY} };
    }
    if (printDisclosures === null) {
      var disclosureSelector='details.pmo-disclosure, details.pmo-progress-details, details.pmo-notes-details, details.pmo-note-details'+(state.screen==='dashboard'?'':', details.fu-disclosure');
      printDisclosures = Array.from(root.querySelectorAll(disclosureSelector)).filter(function(el){return !el.open;});
      printDisclosures.forEach(function(el){el.open=true;});
    }
    document.title = screenTitle();
  }
  function endPrint() {
    S.views.results.clearPrint();
    if (printDisclosures !== null) { printDisclosures.forEach(function(el){el.open=false;}); printDisclosures=null; }
    if (!printSession) { finishPrintRestore(); return; }
    var session = printSession; printSession = null; printPending = false;
    if(state.screen===session.screen){
      // Some browsers fire afterprint before print media exits. Controls hidden
      // by print styles receive focus only when screen styles are active again.
      printRestore={screen:session.screen,focus:session.focus,scroll:session.scroll};
      finishPrintRestore();requestAnimationFrame(finishPrintRestore);
    }
    document.title = state.screen === session.screen && state.report.kind === session.kind
      ? session.title : screenTitle();
  }
  async function printReport() {
    if (printPending || printSession) return;
    printPending = true; state.menu = null; hideTip();
    try {
      if (document.fonts && document.fonts.ready) await document.fonts.ready;
      beginPrint(); window.print();
    } catch (e) { endPrint(); printPending = false; throw e; }
  }

  /* ---------- rendering ---------- */
  function refreshPersistenceNotice(){
    var messages=Object.values(state.persistenceWarnings||{}),main=root.querySelector('main'),notice=document.getElementById('local-save-warning');
    if(!main||!messages.length){if(notice)notice.remove();return;}
    if(!notice){notice=document.createElement('aside');notice.id='local-save-warning';notice.className='app-session-warning app-screen-only';notice.setAttribute('role','status');notice.setAttribute('aria-live','polite');main.insertBefore(notice,main.firstChild);}
    notice.textContent=messages.join(' ');
  }
  function render(menuAnchor) {
    if(state.screen==='home')state.search.tab='all';
    hideTip();
    S.ui.resetTips();
    root.innerHTML = S.views[state.screen].render(state);
    refreshPersistenceNotice();
    var main = root.querySelector('main');
    if (main) { if (!main.id) main.id = 'app-main'; main.setAttribute('tabindex', '-1'); if(S.ui.sourceFooter)main.insertAdjacentHTML('afterend',S.ui.sourceFooter(state)); }
    if (state.screen === 'results') S.views.results.update(state);
    var newTabActions = state.screen === 'dashboard' ? '[data-act="drill"], [data-act="compare-metric"]' : state.screen === 'entities' ? '[data-act="entity-focus"]' : '';
    if (newTabActions) Array.from(root.querySelectorAll(newTabActions)).forEach(function(el) {
      var label = el.getAttribute('aria-label') || el.getAttribute('title') || el.textContent;
      if (label.indexOf('علامة تبويب جديدة') < 0) label += ' · يفتح في علامة تبويب جديدة';
      el.setAttribute('aria-label', label);
      el.setAttribute('title', label);
    });
    updateTables();
    renderOverlay();
    document.title = screenTitle();
    document.body.setAttribute('data-screen', state.screen);
    positionMultiMenu(menuAnchor);
  }

  // Use the same viewport placement for every multi-select, including menus
  // opened near the bottom of a filter panel or beside a scrolled table.
  function multiMenuAnchor(id) {
    var trigger=root.querySelector('[data-menu="'+id+'"]');
    if(!trigger||id==='reports')return null;
    var wrap=trigger.closest('.multi-wrap'),menu=wrap&&wrap.querySelector('.multi-menu'),options=menu&&menu.querySelector('.multi-options');
    return {id:id,top:trigger.getBoundingClientRect().top,optionsScroll:options?options.scrollTop:0,focused:!!(menu&&menu.contains(document.activeElement))};
  }
  function focusMultiControl(control) {
    control.focus({preventScroll:true});
    var scroller=control.closest('.multi-options');
    if(scroller){
      var rect=(control.closest('.opt')||control).getBoundingClientRect();
      if(rect.height>scroller.clientHeight)rect=control.getBoundingClientRect();
      var top=scroller.getBoundingClientRect().top+scroller.clientTop,bottom=top+scroller.clientHeight;
      if(rect.top<top)scroller.scrollTop+=rect.top-top;else if(rect.bottom>bottom)scroller.scrollTop+=rect.bottom-bottom;
    }
  }
  function positionMultiMenu(anchor) {
    if(!state.menu)return;
    var trigger=root.querySelector('[data-menu="'+state.menu+'"]');
    var wrap=trigger&&trigger.closest('.multi-wrap'),menu=wrap&&wrap.querySelector('.multi-menu');
    if(!menu||!trigger||!trigger.getBoundingClientRect)return;
    Array.from(menu.querySelectorAll('[data-multi-partial]')).forEach(function(input){input.indeterminate=true;});
    var previousWidth=menu.style.width,previousHeight=menu.style.height;
    var viewport=window.visualViewport,vl=viewport?viewport.offsetLeft:0,vt=viewport?viewport.offsetTop:0;
    var vw=viewport?viewport.width:window.innerWidth,vh=viewport?viewport.height:window.innerHeight;
    var vr=vl+vw,vb=vt+vh,rect=trigger.getBoundingClientRect();
    // Filter summaries and result heights can change during a redraw. Restore
    // the active control's viewport position before deciding menu placement.
    if(anchor&&anchor.id===state.menu){window.scrollTo(window.scrollX,window.scrollY+rect.top-anchor.top);rect=trigger.getBoundingClientRect();}
    // A selection redraw temporarily removes the focused input. Keep the active
    // popup through that redraw even if a smaller viewport hides its trigger.
    var focused=menu.contains(document.activeElement)||(anchor&&anchor.id===state.menu&&anchor.focused);
    if((rect.bottom<vt+12||rect.top>vb-12||rect.right<vl+12||rect.left>vr-12)&&!focused){dismissMenu();return;}
    var width=Math.min(410,Math.max(1,vw-24)),below=Math.max(0,vb-rect.bottom-18),above=Math.max(0,rect.top-vt-18);
    menu.style.width=width+'px';
    var options=menu.querySelector('.multi-options'),style=getComputedStyle(menu);
    function pixels(v){return parseFloat(v)||0;}
    var controlsHeight=pixels(style.paddingTop)+pixels(style.paddingBottom)+pixels(style.borderTopWidth)+pixels(style.borderBottomWidth);
    Array.from(menu.children).forEach(function(child){
      if(child===options||!child.getClientRects().length)return;
      var childStyle=getComputedStyle(child);
      controlsHeight+=child.getBoundingClientRect().height+pixels(childStyle.marginTop)+pixels(childStyle.marginBottom);
    });
    var optionsHeight=options?Math.min(260,options.scrollHeight):0,wanted=Math.min(420,controlsHeight+optionsHeight);
    var down=below>=wanted||(above<wanted&&below>=above),space=down?below:above;
    // When neither side can fit the controls plus two rows, use the viewport
    // instead of clipping search/actions inside a tiny anchored popup.
    var minimum=Math.min(wanted,controlsHeight+Math.min(88,optionsHeight));
    var height=Math.max(1,Math.min(wanted,vh-24,space>=minimum?space:vh-24));
    var top=down?rect.bottom+6:rect.top-height-6;top=Math.max(vt+12,Math.min(top,vb-height-12));
    menu.style.left=Math.max(vl+12,Math.min(rect.right-width,vr-width-12))+'px';menu.style.top=top+'px';menu.style.height=height+'px';menu.style.maxHeight=height+'px';
    if(anchor&&anchor.id===state.menu&&options)options.scrollTop=anchor.optionsScroll;
    if((previousWidth!==menu.style.width||previousHeight!==menu.style.height)&&options&&options.contains(document.activeElement))focusMultiControl(document.activeElement);
  }
  window.addEventListener('resize',positionMultiMenu);
  if(window.visualViewport){window.visualViewport.addEventListener('resize',positionMultiMenu);window.visualViewport.addEventListener('scroll',positionMultiMenu);}
  document.addEventListener('scroll',positionMultiMenu,true);

  // Keep the original table and its source cells. Narrow layouts display each
  // row as a labelled record; controls, order, totals and column scope survive.
  var tableObserver=typeof ResizeObserver==='function'?new ResizeObserver(function(entries){entries.forEach(function(entry){adaptTableLayout(entry.target);});}):null;
  function adaptTableLayout(wrap) {
    var table=wrap.querySelector('.ui-stack-table');if(!table)return;
    var columns=Number(table.getAttribute('data-column-count'))||1;
    var stack=window.innerWidth<=900||wrap.clientWidth<Math.max(480,columns*120);
    table.classList.toggle('ui-table-stacked',stack);wrap.classList.toggle('is-stacked',stack);
  }
  function updateTables() {
    if(tableObserver)tableObserver.disconnect();
    Array.from(root.querySelectorAll('.rpt-scroll-hint,.pw-table-hint,.ui-table-scroll-hint,.entity-organization-hint')).forEach(function(hint){
      if(hint.id)Array.from(root.querySelectorAll('[aria-describedby]')).forEach(function(el){var ids=el.getAttribute('aria-describedby').split(/\s+/).filter(function(id){return id!==hint.id;});if(ids.length)el.setAttribute('aria-describedby',ids.join(' '));else el.removeAttribute('aria-describedby');});
      hint.remove();
    });
    Array.from(root.querySelectorAll('table')).forEach(function(table,index){
      if(!table.tHead)return;
      table.classList.add('ui-stack-table');table.setAttribute('role','table');
      var columns=[];
      Array.from(table.tHead.rows).forEach(function(row){
        row.setAttribute('role','row');
        Array.from(row.cells).forEach(function(cell){
          cell.setAttribute('role','columnheader');
          if(!cell.id)cell.id='ui-table-'+index+'-col-'+columns.length;
          var clone=cell.cloneNode(true);
          Array.from(clone.querySelectorAll('.sort-ind,.visually-hidden,[aria-hidden="true"]')).forEach(function(el){el.remove();});
          var label=clone.textContent.replace(/\s+/g,' ').trim();
          for(var n=0;n<cell.colSpan;n++)columns.push({label:label,id:cell.id});
        });
      });
      var groups=Array.from(table.tBodies);if(table.tFoot)groups.push(table.tFoot);
      table.setAttribute('data-column-count',columns.length);
      table.tHead.setAttribute('role','rowgroup');
      groups.forEach(function(group,groupIndex){
        group.setAttribute('role','rowgroup');
        Array.from(group.rows).forEach(function(row,rowIndex){
          row.setAttribute('role','row');var at=0;
          var rowHeaders=Array.from(row.cells).filter(function(cell){return cell.tagName==='TH';});
          rowHeaders.forEach(function(cell,headerIndex){if(!cell.id)cell.id='ui-table-'+index+'-group-'+groupIndex+'-row-'+rowIndex+'-head-'+headerIndex;});
          Array.from(row.cells).forEach(function(cell){
            var cols=columns.slice(at,at+cell.colSpan);at+=cell.colSpan;
            if(cols.length){
              if(!cell.hasAttribute('data-label'))cell.setAttribute('data-label',cols.map(function(c){return c.label;}).join(' / '));
              cell.classList.toggle('ui-record-title-cell',cols.some(function(c){return ['الموضوع','التشريع','المشروع','القرار','المؤشر','العنوان'].includes(c.label);}));
              var headers=cols.map(function(c){return c.id;});
              if(cell.tagName!=='TH')headers=headers.concat(rowHeaders.map(function(h){return h.id;}));
              cell.setAttribute('headers',headers.join(' '));
            }
            cell.setAttribute('role',cell.tagName==='TH'?'rowheader':'cell');
          });
        });
      });
      var wrap=table.parentElement;
      if(wrap&&wrap.matches('.table-wrap,.rpt-table-scroll,.ag-table-scroll,.pw-table-scroll,.cmp-table,.pr-table-scroll,.entity-organization-scroll')){
        wrap.classList.add('ui-table-container');
        // It no longer has its own scrolling interaction or tab stop.
        wrap.removeAttribute('tabindex');
        adaptTableLayout(wrap);if(tableObserver)tableObserver.observe(wrap);
      }
    });
  }
  window.addEventListener('resize',function(){Array.from(root.querySelectorAll('.ui-table-container')).forEach(adaptTableLayout);});
  document.addEventListener('toggle',function(e){if(root.contains(e.target)){if(e.target.matches('details.entity-comparison-setup'))state.entity.comparisonSetup=e.target.open;updateTables();}},true);

  function renderOverlay() {
    var settingsOpen=state.screen==='dashboard'&&state.monthly&&state.monthly.settingsOpen;
    var html = settingsOpen ? S.monthlyTools.settings(state,state.lastDash) : state.openKey ? S.views.detail.render(state) : '';
    overlay.innerHTML = html;
    if(settingsOpen){var dialog=document.getElementById('monthly-report-settings');if(dialog&&!dialog.open)dialog.showModal();}
    document.body.classList.toggle('has-detail', !!html);
  }

  function updateResults(menuAnchor) {
    if (state.screen !== 'results') return;
    S.views.results.update(state);
    updateTables();
    positionMultiMenu(menuAnchor);
    replaceHash();
  }
  function scheduleUpdate() {
    if (raf) return;
    raf = requestAnimationFrame(function () { raf = 0; updateResults(); renderSug(); });
  }

  function renderSug() {
    var box = document.getElementById('sug');
    if (!box) return;
    var html = S.views.home.suggestions(state);
    box.innerHTML = html;
    box.hidden = !html;
    var input = document.getElementById('q');
    if (input) input.setAttribute('aria-expanded', String(!!html));
  }

  function syncSearchBox() {
    var q = state.search.q;
    var c = document.querySelector('.sclear'), k = document.querySelector('.skbd');
    if (c) c.classList.toggle('is-hidden', !q);
    if (k) k.classList.toggle('is-hidden', !!q);
  }

  function focusQuery() {
    var q = document.getElementById('q');
    if (q) { q.focus(); try { q.setSelectionRange(q.value.length, q.value.length); } catch (e) { /* search inputs in some browsers */ } }
  }

  /* ---------- navigation ---------- */
  function hashFor(screen, routeState) {
    var route = routeState || state;
    var p = new URLSearchParams();
    if (screen === 'results') {
      if(route.search.page>1)p.set('page',String(route.search.page));
      if (route.search.q) p.set('q', route.search.q);
      if (route.search.tab !== 'all') p.set('tab', route.search.tab);
      S.search.FILTERS.forEach(function(F){U.selectionParam(p,'f.'+F.k,route.search.f[F.k]);});
      if(route.search.drill){p.set('metric',route.search.drill.id);U.selectionParam(p,'drillSector',route.search.drill.scope.sector);U.selectionParam(p,'drillUnit',route.search.drill.scope.unit);U.selectionParam(p,'drillEntity',route.search.drill.scope.entity);if(route.search.drill.scope.entityMode==='concerned')p.set('entityMode','concerned');}
    }
    if (screen === 'dashboard' || screen === 'reports') {
      U.selectionParam(p,'sector',route.dash.sector);
      U.selectionParam(p,'unit',route.dash.unit);
      U.selectionParam(p,'entity',route.dash.entity);
    }
    if(screen==='projects'){S.projects.keys.forEach(function(k){U.selectionParam(p,k,route.projects[k]);});if(route.projects.view==='records'){p.set('pview','records');p.set('pfocus',route.projects.focus||'all');if(route.projects.value)p.set('pvalue',route.projects.value);}}
    if (screen === 'reports') { p.set('kind',route.report.kind); U.selectionParam(p,'lead',route.report.lead); U.selectionParam(p,'type',route.report.type); if(route.report.kind==='council')U.selectionParam(p,'followup',route.report.followup); if(route.report.kind==='projects')['projectType','priority','quarter','projectStatus'].forEach(function(k){U.selectionParam(p,k,route.report[k]);}); S.reportDisplay.params(route,p); }
    if(screen==='entities'){U.selectionParam(p,'eareas',route.entity.areas);U.selectionParam(p,'entity',route.entity.entity);if(route.entity.role!=='primary')U.selectionParam(p,'role',route.entity.role);['mode','area','q','kind'].forEach(function(k){if(route.entity[k])p.set('e'+k,route.entity[k]);});U.selectionParam(p,'estatus',route.entity.status);}
    if(screen==='comparison'){if(route.comparison.scope.entityMode==='concerned')p.set('entityMode','concerned');['sector','unit','entity'].forEach(function(k){U.selectionParam(p,k,route.comparison.scope[k]);});var cv=route.comparison.view||{};if(cv.metric)p.set('metric',cv.metric);if(cv.type)p.set('change',cv.type);if(cv.q)p.set('cq',cv.q);}
    if(screen==='checks'){if(route.checks.sheet)p.set('sheet',route.checks.sheet);if(route.checks.severity)p.set('severity',route.checks.severity);}
    var qs = p.toString();
    return '#/' + screen + (qs ? '?' + qs : '');
  }
  /* The actual app URL opens synchronously while the user gesture is active.
     A one-use message handshake transfers the workbook without touching the
     child document, including file:// documents with opaque origins. */
  var TAB_TRANSFER = 'saytara.drill-tab.v1:', TAB_MESSAGE = 'saytara.drill-tab.v2';
  var pendingTabs = Object.create(null);
  function tabOrigin() { return location.protocol === 'file:' ? '*' : location.origin; }
  function tabToken() {
    var bytes = new Uint8Array(16);
    if (window.crypto && window.crypto.getRandomValues) window.crypto.getRandomValues(bytes);
    else for (var i = 0; i < bytes.length; i++) bytes[i] = Math.floor(Math.random() * 256);
    return Array.from(bytes).map(function (n) { return n.toString(16).padStart(2, '0'); }).join('');
  }
  async function transferPayload(route) {
    var files = {current:cmpFiles.current,previous:cmpFiles.previous};
    var payload = {periods:JSON.parse(JSON.stringify({previous:state.comparison.previous,current:state.comparison.current})),scope:route.comparison.scope,files:{}};
    for (var role of ['current','previous']) {
      var file = files[role];
      if (file) payload.files[role] = {name:file.name,lastModified:file.lastModified||0,b64:toB64(await file.arrayBuffer())};
    }
    return JSON.stringify(payload);
  }
  function finishTab(token) {
    var pending = pendingTabs[token];
    if (pending) { clearTimeout(pending.timer); delete pendingTabs[token]; }
  }
  window.addEventListener('message', function (event) {
    var message = event.data, pending = message && pendingTabs[message.token];
    if (!pending || event.source !== pending.child || message.type !== TAB_MESSAGE) return;
    if (event.origin !== (location.protocol === 'file:' ? 'null' : location.origin)) return;
    if (message.status === 'received') { finishTab(message.token); return; }
    if (message.status !== 'ready' || message.url !== pending.url || pending.sending) return;
    pending.sending = true;
    pending.payload.then(function (payload) {
      if (!pending.child.closed && pendingTabs[message.token] === pending)
        pending.child.postMessage({type:TAB_MESSAGE,token:message.token,status:'data',payload:payload}, tabOrigin());
    }).catch(function () { finishTab(message.token); toast('تعذّر نقل بيانات الملف؛ أعد فتح التفاصيل وحاول مجدداً'); });
  });
  function screenLinkPatch(el) {
    var screen = el.getAttribute('data-screen-link');
    if (screen === 'entities' && el.getAttribute('data-act') === 'entity-focus') return entityDrillPatch(el);
    if (screen === 'reports' && el.hasAttribute('data-report')) return {report:Object.assign({},state.report,{kind:el.getAttribute('data-report')})};
    if (screen === 'comparison') return {comparison:Object.assign({},state.comparison,{scope:{sector:state.dash.sector||'',unit:state.dash.unit||'',entity:state.dash.entity||'',entityMode:'concerned'},view:{}})};
    if (screen === 'projects') return {projects:Object.assign({},state.projects,{view:'dashboard',focus:'all',value:''})};
    return {};
  }
  function openDrillTab(screen, patch) {
    if (!state.data) return;
    if (!cmpFiles.current) { toast('تعذّر نقل بيانات الملف؛ أعد تحميل الملف ثم حاول مجدداً'); return; }
    var route = Object.assign({}, state, patch || {}), token = tabToken();
    var hash = hashFor(screen, route), url = location.href.split('#')[0] + hash + (hash.indexOf('?') < 0 ? '?' : '&') + '__tab=' + token;
    var child = window.open(url, '_blank');
    if (!child) { toast('اسمح بفتح علامات التبويب لهذا التطبيق ثم حاول مجدداً'); return; }
    var payload = transferPayload(route);
    // Handle serialization failures immediately even if the receiving page fails to boot.
    payload.catch(function () {});
    pendingTabs[token] = {child:child,url:url,payload:payload,sending:false,timer:setTimeout(function () {
      finishTab(token);
    }, 30000)};
  }
  function receiveDrillTab(token) {
    var parent;
    try { parent = window.opener; } catch (e) { return false; }
    if (!parent) return false;
    state.screen = 'upload';
    state.upload = {status:'loading',error:null,fileName:'تحميل بيانات التفاصيل…'};
    render();
    var timeout = setTimeout(function () {
      window.removeEventListener('message', receive);
      state.upload = {status:'error',error:'تعذّر استلام بيانات الملف. أغلق هذه العلامة وأعد فتح التفاصيل من التطبيق.',fileName:''};
      render();
      try { window.opener = null; } catch (e) {}
    }, 30000);
    function receive(event) {
      var message = event.data;
      if (event.source !== parent || !message || message.type !== TAB_MESSAGE || message.token !== token || message.status !== 'data') return;
      if (event.origin !== (location.protocol === 'file:' ? 'null' : location.origin)) return;
      if (typeof message.payload !== 'string') return;
      clearTimeout(timeout); window.removeEventListener('message', receive);
      parent.postMessage({type:TAB_MESSAGE,token:token,status:'received'}, tabOrigin());
      try { window.opener = null; } catch (e) {}
      U.store.set('sessionStorage', CMP_KEY, message.payload);
      if (!restoreSession(message.payload)) {
        state.upload = {status:'error',error:'تعذّر استلام بيانات الملف. أغلق هذه العلامة وأعد فتح التفاصيل من التطبيق.',fileName:''};
        render();
      }
    }
    window.addEventListener('message', receive);
    parent.postMessage({type:TAB_MESSAGE,token:token,status:'ready',url:location.href}, tabOrigin());
    return true;
  }
  function replaceHash() {
    var h = hashFor(state.screen);
    if (location.hash !== h) { try { history.replaceState(null, '', h); } catch (e) { /* ignore */ } }
  }
  function go(screen, opts) {
    opts = opts || {};
    if(state.data&&!state.data.referenceDateReady&&!state.comparison.current.confirmed&&screen!=='upload'&&screen!=='comparison'){screen='comparison';state.comparison.error='حدد التاريخ المرجعي للنسخة الحالية وأكّده قبل عرض التقرير';}
    if (screen === 'reports' && state.report.kind === 'projects') {
      state.projects = Object.assign(S.projects.defaults(), state.dash, state.report, {view:'dashboard'});
      screen = 'projects';
    }
    state.screen = screen;
    state.monthly.settingsOpen=false;
    state.menu = null;
    state.navOpen = false;
    state.sugOpen = false;
    if (screen === 'upload' || screen === 'home') state.openKey = null;
    var h = hashFor(screen);
    if (location.hash !== h) {
      if (opts.replace) { try { history.replaceState(null, '', h); } catch (e) { /* ignore */ } }
      else location.hash = h;
    }
    render();
    window.scrollTo(0, 0);
    if (opts.focusQuery || screen === 'home') focusQuery();
  }

  function parseHash() {
    var m = /^#\/(\w+)(?:\?(.*))?$/.exec(location.hash || '');
    if (!m || !TITLES[m[1]]) return null;
    var screen = m[1], params = new URLSearchParams(m[2] || '');
    if (screen === 'reports' && params.get('kind') === 'projects') {
      screen = 'projects'; params.delete('kind'); params.delete('pview'); params.delete('pfocus'); params.delete('pvalue');
      var next = '#/projects' + (params.toString() ? '?' + params.toString() : '');
      try { history.replaceState(null, '', next); } catch (e) {}
    }
    return { screen: screen, params: params };
  }

  function applyHash(route) {
    var h = route || parseHash();
    if (!state.data) { state.screen = h && h.screen==='comparison'?'comparison':'upload'; return; }
    if (!h || h.screen === 'upload') { state.screen = h ? 'upload' : 'home'; return; }
    state.screen = h.screen;
    if(h.screen==='checks')state.checks={sheet:h.params.get('sheet')||'',severity:['error','warn','info'].includes(h.params.get('severity'))?h.params.get('severity'):''};
    if(!state.data.referenceDateReady&&!state.comparison.current.confirmed&&state.screen!=='upload'){state.screen='comparison';return;}
    if(h.screen==='projects'){state.projects=S.projects.defaults();S.projects.keys.forEach(function(k){state.projects[k]=U.selectionFromParam(h.params,k);});state.projects.view=h.params.get('pview')==='records'?'records':'dashboard';state.projects.focus=h.params.get('pfocus')||'all';state.projects.value=h.params.get('pvalue')||'';}
    if(h.screen==='entities')state.entity={areas:U.selectionFromParam(h.params,'eareas'),entity:U.selectionFromParam(h.params,'entity'),role:U.selectionFromParam(h.params,'role')||'primary',mode:h.params.get('emode')||'',area:h.params.get('earea')||'',q:h.params.get('eq')||'',kind:h.params.get('ekind')||'',status:U.selectionFromParam(h.params,'estatus')};
    if(h.screen==='comparison'){state.comparison.scope.entityMode=h.params.get('entityMode')==='concerned'?'concerned':'';['sector','unit','entity'].forEach(function(k){state.comparison.scope[k]=U.selectionFromParam(h.params,k);});state.comparison.view={metric:h.params.get('metric')||'',type:h.params.get('change')||'changes',q:h.params.get('cq')||''};}
    if (h.screen === 'results') {
      var q = h.params.get('q') || '', tab = h.params.get('tab') || 'all';
      if (q !== state.search.q || tab !== state.search.tab) {
        state.search.q = q;
        state.search.tab = S.search.TABS.indexOf(tab) >= 0 ? tab : 'all';
        state.search.page = 1;
        state.search.browse = !q.trim();
      }
      S.search.FILTERS.forEach(function(F){state.search.f[F.k]=U.selection(U.selectionFromParam(h.params,'f.'+F.k));});
      var metric=h.params.get('metric');
      state.search.drill=metric&&S.rules.MET[metric]?{id:metric,label:S.rules.MET[metric].label,scope:{sector:U.selectionFromParam(h.params,'drillSector'),unit:U.selectionFromParam(h.params,'drillUnit'),entity:U.selectionFromParam(h.params,'drillEntity'),entityMode:h.params.get('entityMode')==='concerned'?'concerned':''}}:null;
      if (!q.trim() && !state.search.drill) state.search.browse = true;
    }
    if (h.screen === 'reports') { state.report.kind = ['hh','council'].includes(h.params.get('kind')) ? h.params.get('kind') : 'agenda'; state.report.lead = S.ui.reportLeadSelection(U.selectionFromParam(h.params,'lead')); state.report.type = U.selectionFromParam(h.params,'type'); state.report.followup=U.selectionFromParam(h.params,'followup'); ['projectType','priority','quarter','projectStatus'].forEach(function(k){state.report[k]=U.selectionFromParam(h.params,k);}); S.reportDisplay.restore(state,h.params); }
    if (h.screen === 'dashboard' || h.screen === 'reports') {
      state.dash.sector = U.selectionFromParam(h.params,'sector');
      state.dash.unit = U.selectionFromParam(h.params,'unit');
      state.dash.entity = U.selectionFromParam(h.params,'entity');
      state.dash.entityMode = 'concerned';
    }
    if(h.screen==='results'){var requestedPage=Number(h.params.get('page'));state.search.page=Number.isInteger(requestedPage)&&requestedPage>0?requestedPage:1;}
    if(['ppage','epage','cp'].some(function(k){return h.params.has(k);})||(h.screen!=='results'&&h.params.has('page')))replaceHash();
  }

  /* Our own navigation already matches the state; only Back/Forward (or an edited
     address) needs a redraw. */
  window.addEventListener('hashchange', function () {
    if (location.hash === hashFor(state.screen)) return;
    state.menu = null;
    state.navOpen = false;
    state.sugOpen = false;
    state.openKey = null;
    applyHash();
    render();
  });

  /* ---------- file loading ---------- */
  function toB64(buf) {
    var bytes = new Uint8Array(buf), out = '', CH = 0x8000;
    for (var i = 0; i < bytes.length; i += CH) out += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
    return btoa(out);
  }
  function fromB64(s) {
    if(typeof s!=='string'||s.length>Math.ceil(S.zip.limits.fileBytes/3)*4||s.length%4||! /^[A-Za-z0-9+/]*={0,2}$/.test(s))throw new Error('Invalid stored workbook');
    var bin = atob(s), bytes = new Uint8Array(bin.length);
    if(bin.length>S.zip.limits.fileBytes)throw new Error('Stored workbook too large');
    for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes;
  }
  var pendingSearchLanding=false;
  var CMP_KEY='saytara.comparison.v1', cmpFiles={previous:null,current:null}, cmpToken=0, saveToken=0;
  async function saveComparison(){
    var token=++saveToken;
    try{
      var o={periods:{previous:state.comparison.previous,current:state.comparison.current},scope:state.comparison.scope,files:{}};
      for(var role of ['previous','current']){var f=cmpFiles[role];if(f){if(f.size>3.5*1024*1024)throw new Error('size');o.files[role]={name:f.name,lastModified:f.lastModified||0,b64:toB64(await f.arrayBuffer())};}}
      if(token!==saveToken)return;
      U.store.del('sessionStorage',SESSION_KEY);
      var text=JSON.stringify(o);U.store.set('sessionStorage',CMP_KEY,text);
      if(U.store.get('sessionStorage',CMP_KEY)!==text)throw new Error('storage');
      U.persistence(state,'workbooks','');
    }catch(e){if(token!==saveToken)return;U.store.del('sessionStorage',CMP_KEY);U.persistence(state,'workbooks','تعذّر حفظ ملف التقرير للجلسة؛ يبقى متاحاً الآن، وأعد اختياره بعد تحديث الصفحة.');}
  }
  function restoreSession(transferred){
    var raw=transferred || U.store.get('sessionStorage',CMP_KEY);
    if(raw){try{if(typeof raw!=='string'||raw.length>2*Math.ceil(S.zip.limits.fileBytes/3)*4+1048576)throw new Error('Invalid stored state');var o=JSON.parse(raw),savedRoute=parseHash();if(!o||typeof o!=='object'||!o.files||typeof o.files!=='object'||!['current','previous'].some(function(role){return o.files[role];}))throw new Error('Invalid stored state');(async function(){
      for(var role of ['current','previous']){var f=o.files[role];if(f){if(typeof f!=='object'||typeof f.name!=='string'||f.name.length>1024)throw new Error('Invalid stored file');var file=new File([fromB64(f.b64)],f.name,{lastModified:Number.isFinite(f.lastModified)?f.lastModified:0});var loaded=await loadComparisonFile(file,role,true);if(!loaded)throw new Error('Stored workbook failed validation');}}
      ['previous','current'].forEach(function(role){var p=o.periods&&o.periods[role],d=role==='previous'?state.previous:state.data;if(p&&d&&typeof p.date==='string'&&S.comparison.serial(p.date)){state.comparison[role]=Object.assign({},state.comparison[role],{date:p.date,confirmed:p.confirmed===true});if(p.confirmed===true)S.loader.redate(d,S.comparison.serial(p.date));}});
      var rawScope=o.scope&&typeof o.scope==='object'?o.scope:{};var savedScope={sector:U.selectionState(rawScope.sector),unit:U.selectionState(rawScope.unit),entity:U.selectionState(rawScope.entity),entityMode:rawScope.entityMode==='concerned'?'concerned':''};
      state.comparison.scope=Object.assign({},savedScope);
      // Read the requested view before normalizing its URL. Only bare legacy
      // reload routes inherit the stored comparison scope;
      // a transferred drill route is authoritative, including an all scope.
      var legacyScope=!transferred&&savedRoute&&savedRoute.screen==='comparison'&&!Array.from(savedRoute.params.keys()).some(function(k){return k!=='__tab';});
      applyHash(savedRoute);
      if(legacyScope){
        ['sector','unit','entity'].forEach(function(k){state.comparison.scope[k]=savedScope[k]||'';});
        if(!savedRoute.params.has('entityMode'))state.comparison.scope.entityMode=savedScope.entityMode||'';
      }
      if(state.screen==='upload'&&state.data)state.screen=state.data.referenceDateReady||state.comparison.current.confirmed?'dashboard':'comparison';replaceHash();render();
      if(state.screen==='entities'&&state.entity.mode)focusEntityDetails();
    })().catch(function(){
      U.store.del('sessionStorage',CMP_KEY);
      state.comparison.busy=false;
      state.comparison.error='تعذّر استعادة الملف المحفوظ للجلسة؛ أعد اختيار ملف Excel.';
      state.screen=state.data?'comparison':'upload';
      if(!state.data)state.upload={status:'error',fileName:'',error:state.comparison.error};
      replaceHash();render();
    });return true;}catch(e){U.store.del('sessionStorage',CMP_KEY);}}
    var old=U.store.get('sessionStorage',SESSION_KEY);if(!old)return false;
    try{var f=JSON.parse(old);loadFile(new File([fromB64(f.b64)],f.name,{lastModified:f.lastModified}),{restored:true});return true;}catch(e){U.store.del('sessionStorage',SESSION_KEY);return false;}
  }
  async function loadComparisonFile(file,role,restored){
    if(!file||!['current','previous'].includes(role)||state.comparison.busy)return false;
    var entityOrigin=!restored&&state.screen==='entities'&&state.entity.comparisonSetup;
    if(role==='current'&&!restored)pendingSearchLanding=false;
    var token=++cmpToken;state.comparison.busy=true;state.comparison.error='';state.screen=entityOrigin?'entities':'comparison';render();
    try{var data=await S.loader.load(file);if(token!==cmpToken)return false;
      cmpFiles[role]=file;state[role==='previous'?'previous':'data']=data;
      state.comparison[role]=S.comparison.detect(file.name,data.savedReportDate,role,data);state.comparison.view={};
      if(role==='current'){state.projects=S.projects.defaults();state.search=newSearch();state.dash={sector:'',unit:'',entity:'',entityMode:'concerned'};state.lastRes=null;state.openKey=null;state.fuOpen={};}
      if(!restored){await saveComparison();if(role==='current'&&!entityOrigin){pendingSearchLanding=!data.referenceDateReady&&!state.comparison.current.confirmed;go('home');}}return true;
    }catch(e){state.comparison.error=S.views.upload.message(e);return false;}
    finally{if(token===cmpToken){state.comparison.busy=false;if(entityOrigin)state.screen='entities';render();if(entityOrigin)focusEntityComparisonSetup();else if(state.screen==='home')focusQuery();}}
  }

  function loadFile(file, opts) {
    opts = opts || {};
    if (!file || state.comparison.busy || state.upload.status==='loading') return Promise.resolve(false);
    if(!opts.restored)pendingSearchLanding=false;
    state.upload = { status: 'loading', fileName: file.name, error: null };
    state.screen = 'upload';
    state.openKey = null;
    render();
    return S.loader.load(file).then(function (data) {
      state.data = data;
      state.upload = { status: 'idle', error: null, fileName: '' };
      state.search = newSearch();
      state.projects = S.projects.defaults();
      state.dash = { sector: '', unit: '', entity: '', entityMode: 'concerned' };
      state.checks = { sheet: '', severity: '' };
      state.fuOpen = {};
      state.lastRes = null;
      cmpFiles.current=file;state.comparison.current=S.comparison.detect(file.name,data.savedReportDate,'current',data);
      if (!opts.restored) saveComparison();
      if (opts.restored) {
        applyHash();
        if (state.screen === 'upload') state.screen = data.referenceDateReady?'dashboard':'comparison';
        replaceHash();
        render();
        if (state.screen === 'home') focusQuery();
      } else {
        pendingSearchLanding=!data.referenceDateReady&&!state.comparison.current.confirmed;
        go('home', { replace: false });
        var n = SC.ORDER.filter(function (pf) { return pf !== 'kpi'; }).reduce(function (a, pf) { return a + data.byPf[pf].length; }, 0);
        toast('تم تحميل الملف · بنود المتابعة: ' + U.fmtN(n) + ' · المؤشرات: ' + U.fmtN(data.byPf.kpi.length));
      }
      return true;
    }).catch(function (err) {
      if (window.console) console.error('Performance reporting: could not read the file', err);
      if (opts.restored) { U.store.del('sessionStorage', SESSION_KEY); state.upload = { status: 'idle', error: null, fileName: '' }; }
      else state.upload = { status: 'error', error: S.views.upload.message(err), fileName: file.name };
      state.screen = 'upload';
      render();
      return false;
    });
  }

  /* ---------- search actions ---------- */
  function addRecent(q) {
    state.recent = [q].concat(state.recent.filter(function (x) { return x !== q; })).slice(0, 4);
    U.store.set('localStorage', RECENT_KEY, JSON.stringify(state.recent));
  }

  function submit(q) {
    var s = state.search;
    if (q != null) s.q = q;
    var v = s.q.trim();
    state.sugOpen = false;
    renderSug();
    if (!v) s.browse = true;
    if (v) addRecent(v);
    s.force = !!v;
    if (state.screen === 'results') { updateResults(); return; }
    s.page = 1; s.sort = null; s.drill = null; s.f = S.search.emptyF();
    s.browse = !v;
    go('results', { focusQuery: true });
  }

  function drill(metric, inline) {
    var m = S.rules.MET[metric];
    if (!m) return;
    var s = newSearch();
    var pfName = m.pf === '*' ? 'جميع المحافظ' : SC.PF[m.pf].ar;
    var label = m.label === pfName ? pfName : pfName + ' · ' + m.label;
    if (U.hasSelection(state.dash.sector)) label += ' · القطاع: ' + U.selectionText(state.dash.sector);
    if (U.hasSelection(state.dash.unit)) label += ' · الوحدة: ' + U.selectionText(state.dash.unit);
    if (U.hasSelection(state.dash.entity)) label += ' · الجهة المعنية: ' + U.selectionText(state.dash.entity);
    s.drill = { id: metric, label: label, scope: { sector: state.dash.sector, unit: state.dash.unit, entity: state.dash.entity, entityMode:'concerned' } };
    s.tab = m.pf === '*' ? 'all' : m.pf;
    s.browse = true;
    s.columns = state.search.columns;
    if (state.screen === 'dashboard'&&!inline) return openDrillTab('results', {search:s});
    state.search = s;
    go('results');
  }

  function openDetail(key, trigger) {
    if (!state.data || !state.data.byKey[key]) return;
    lastFocus = trigger || document.activeElement;
    state.openKey = key;
    state.sugOpen = false;
    renderSug();
    renderOverlay();
    if (state.screen === 'results') { S.views.results.update(state); updateTables(); }
    var c = overlay.querySelector('.det-close');
    if (c) c.focus();
  }
  function closeDetail() {
    var key = state.openKey;
    state.openKey = null;
    renderOverlay();
    if (state.screen === 'results') { S.views.results.update(state); updateTables(); }
    var back = key ? root.querySelector('[data-act="open"][data-key="' + (window.CSS && CSS.escape ? CSS.escape(key) : key) + '"]') : null;
    if (back) back.focus(); else if (lastFocus && document.contains(lastFocus)) lastFocus.focus();
  }

  function copyText(text) {
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = text; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
      ta.remove();
      return ok;
    }
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text).then(function () { return true; }, function () { return fallback(); });
    }
    return Promise.resolve(fallback());
  }

  function stamp() { var p = U.ymd(U.todaySerial()); return p.y + '-' + String(p.m).padStart(2, '0') + '-' + String(p.d).padStart(2, '0'); }

  /* All filtering controls share one state/action contract. Empty means no
     constraint. Arrays and old scalar links are both accepted. */
  function multiObject(id){return id[0]==='p'?state.projects:id[0]==='d'?state.dash:id[0]==='c'?state.comparison.scope:id[0]==='e'?state.entity:id[0]==='r'?state.report:state.search.f;}
  function multiValue(id){var v=multiObject(id)[id.slice(2)];return id==='e:role'&&v==='all'?['primary','contributor']:U.selection(v);}
  function syncMulti(id,values,focusValue){
    if(state.reporting)return;
    var menuAnchor=state.menu===id?multiMenuAnchor(id):null;
    var k=id.slice(2),obj=multiObject(id),prev=U.selection(obj[k]);
    if(id==='r:lead')values=U.selection(S.ui.reportLeadSelection(values));
    obj[k]=id[0]==='f'?U.selection(values):id==='e:role'&&!values.length?'all':U.selectionState(values);
    if(k==='sector'){
      var records=state.data?state.data.items.slice():[],departments=[];
      if(id[0]==='d'){var h=S.comparison.dashboardHistory(state);if(h.source==='workbook')records=records.concat(h.data.items);if(h.source==='embedded')records=records.concat(state.data.snapshot&&state.data.snapshot.rows||[]);[state.data,h.source==='workbook'?h.data:null].filter(Boolean).forEach(function(d){departments=departments.concat(d.lovs.lists.Departments||[]);});}
      if(id[0]==='c'&&state.previous)records=records.concat(state.previous.items);
      var allowed=records.filter(function(i){return U.selected(i.sector,obj.sector);}).map(function(i){return U.key(i.unit);}).concat(departments.filter(function(p){return U.selected(p.parent,obj.sector);}).map(function(p){return U.key(p.value);}));
      var units=U.selection(obj.unit),kept=units.filter(function(v){return allowed.includes(U.key(v));});
      if(kept.length!==units.length){obj.unit=id[0]==='f'?kept:U.selectionState(kept);toast('أزيلت الوحدات غير التابعة للقطاعات المحددة');}
    }
    if(id[0]==='p'){state.projects.view='dashboard';state.projects.focus='all';state.projects.value='';}
    state.search.page=1;
    if(id[0]==='e'){if(k==='entity'||k==='role'||k==='areas'){state.entity.area='';state.entity.status='';state.entity.q='';state.entity.kind='';}}
    if(state.screen==='results')updateResults(menuAnchor);else render(menuAnchor);
    if(id[0]==='c'){state.comparison.view=Object.assign({},state.comparison.view||{});saveComparison();}replaceHash();
    var inputs=Array.from(root.querySelectorAll('input[data-change="multi"]')),target=focusValue==null?null:inputs.find(function(el){return el.getAttribute('data-multi')===id&&el.getAttribute('data-v')===focusValue;});
    if(target)focusMultiControl(target);else {var trigger=root.querySelector('[data-menu="'+id+'"]');if(trigger)focusMultiControl(trigger);}
  }
  function dismissMenu(){
    var m=state.menu;if(!m)return;state.menu=null;
    var popup=m==='reports'?document.getElementById('report-menu'):root.querySelector('.multi-menu');if(popup)popup.remove();
    var btn=root.querySelector('[data-menu="'+m+'"]');if(btn)btn.setAttribute('aria-expanded','false');
  }

  function focusComparisonDetails(){var el=document.getElementById('cmp-detail');if(el){el.scrollIntoView({behavior:(window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'),block:'start'});el.focus({preventScroll:true});}}
  function changeComparisonView(patch){state.comparison.view=Object.assign({},state.comparison.view||{},patch);render();replaceHash();focusComparisonDetails();}
  function entityUpdate(fields,push,focus){
    Object.assign(state.entity,fields);state.menu=null;render();
    if(push){var h=hashFor('entities');if(location.hash!==h){if(history.pushState)history.pushState(null,'',h);else location.hash=h;}}else replaceHash();
    if(focus)focusEntityDetails();
  }
  function focusEntityDetails(){var el=document.getElementById('entity-detail');if(el){el.focus({preventScroll:true});if(el.scrollIntoView)el.scrollIntoView({block:'start',behavior:'auto'});}}
  function focusEntityComparisonSetup(){var el=document.getElementById('entity-comparison-setup');if(el){el.focus({preventScroll:true});if(el.scrollIntoView)el.scrollIntoView({block:'nearest',behavior:'auto'});}}
  function focusComparisonPeriod(role, action){
    var picker=root.querySelector('[data-act="'+(role==='previous'?'pick-previous':'pick-current')+'"]');
    var target=action?root.querySelector('[data-act="'+action+'"][data-role="'+role+'"]'):picker;
    if(target){var closed=target.closest('details:not([open])');if(closed&&!closed.querySelector('summary').contains(target))target=null;}
    if(!target)target=document.getElementById('entity-comparison-setup')||root.querySelector('.cmp-setup > summary')||picker;
    if(target)target.focus({preventScroll:true});
  }
  function entityDrillPatch(el){return {entity:Object.assign({},state.entity,{mode:el.getAttribute('data-mode')||'records',area:el.getAttribute('data-area')||'',status:el.getAttribute('data-status')||'',kind:el.getAttribute('data-kind')||'',q:''})};}
  function focusScopePanel(id){
    var target=root.querySelector('[data-filter-panel="'+id+'"] .ui-filter-toggle')||root.querySelector('main h1')||root.querySelector('main');
    if(target){if(!target.matches('button,a,input,select,textarea,[tabindex]'))target.setAttribute('tabindex','-1');target.focus({preventScroll:true});}
  }
  function focusMonthlyControl(action){
    var control=document.querySelector('[data-act="'+action+'"]');
    if(control)control.focus({preventScroll:true});
  }
  function monthlyDate(value){
    if(!state.data||state.reporting||state.comparison.busy)return;
    var date=S.comparison.serial(value);
    if(!U.validDateSerial(date)){
      render();focusMonthlyControl('monthly-date');
      toast('أدخل تاريخ حساب صحيحاً؛ لم يتغير التاريخ المرجعي.');return;
    }
    S.loader.redate(state.data,date);
    state.comparison.current=Object.assign({},state.comparison.current,{date:S.comparison.iso(date),confirmed:true,source:'تاريخ الحساب المحدد',issue:''});
    state.comparison.error='';state.lastComparison=null;
    saveComparison();render();focusMonthlyControl('monthly-date');
  }
  function resetMonthlyDate(){
    if(!state.data||state.reporting||state.comparison.busy)return;
    var data=state.data,live=data.sourceDateKind==='live';
    var date=live?U.todaySerial():U.validDateSerial(data.savedReportDate)?data.savedReportDate:data.sourceValidationDate;
    if(!U.validDateSerial(date)){
      toast('لا يتوفر تاريخ مرجعي صالح في الملف؛ حدّد تاريخ الحساب.');
      focusMonthlyControl('monthly-date');return;
    }
    S.loader.redate(data,date);
    data.calculationDateKind=live?'live':data.sourceDateKind||'fixed';
    state.comparison.current=S.comparison.detect(data.file.name,data.savedReportDate,'current',data);
    state.comparison.error='';state.lastComparison=null;
    saveComparison();render();focusMonthlyControl('monthly-date-reset');
  }
  function compareMetric(metric){if(state.screen==='dashboard'){var comparison=Object.assign({},state.comparison,{scope:{sector:U.selectionState(U.selection(state.dash.sector)),unit:U.selectionState(U.selection(state.dash.unit)),entity:U.selectionState(U.selection(state.dash.entity)),entityMode:'concerned'},view:{metric:S.comparison.insights.descriptor(metric)?metric:'',type:'changes',q:''}});return openDrillTab('comparison',{comparison:comparison});}state.comparison.scope={sector:U.selectionState(U.selection(state.dash.sector)),unit:U.selectionState(U.selection(state.dash.unit)),entity:U.selectionState(U.selection(state.dash.entity)),entityMode:'concerned'};state.comparison.view={metric:S.comparison.insights.descriptor(metric)?metric:'',type:'changes',q:''};state.openKey=null;go('comparison');if(state.lastComparison)focusComparisonDetails();}

  /* ---------- actions ---------- */
  var A = {
    'browse-all':function(){var columns=state.search.columns;state.search=newSearch();state.search.columns=columns;state.search.browse=true;go('results');var count=root.querySelector('.r-count');if(count){count.setAttribute('tabindex','-1');count.focus({preventScroll:true});}},
    'search-page':function(el){var requested=Number(el.getAttribute('data-page'));if(!Number.isInteger(requested))return;var paging=S.views.results.paging(state,state.lastRes);state.search.page=Math.max(1,Math.min(paging.pages,requested));updateResults();var range=document.getElementById('search-result-range')||root.querySelector('.r-count');if(range){range.setAttribute('tabindex','-1');range.focus({preventScroll:true});range.scrollIntoView({block:'start',behavior:'auto'});}},
    'skip-content':function(){var main=root.querySelector('main');if(main){main.focus({preventScroll:true});main.scrollIntoView({block:'start'});}},
    'toggle-nav':function(){state.navOpen=!state.navOpen;var header=root.querySelector('.app-header'),button=root.querySelector('[data-act="toggle-nav"]');if(header)header.classList.toggle('is-nav-open',state.navOpen);if(button)button.setAttribute('aria-expanded',String(state.navOpen));},
    'toggle-filters':function(el){
      var id=el.getAttribute('data-filter-panel'),panel=el.closest('.ui-filter-panel'),body=document.getElementById(el.getAttribute('aria-controls'));
      if(!panel||!body)return;
      var open=el.getAttribute('aria-expanded')!=='true';
      state.filterPanels[id]=open;dismissMenu();hideTip();
      panel.classList.toggle('is-open',open);body.hidden=!open;el.setAttribute('aria-expanded',String(open));
      var label=el.querySelector('.ui-filter-toggle-label');if(label)label.textContent=open?'إغلاق التصفية':'تصفية';var icon=el.querySelector('.ic');if(icon)icon.outerHTML=U.icon(open?'up':'down',18);
      el.focus({preventScroll:true});
    },
    'reset-dashboard-filters':function(){state.dash={sector:'',unit:'',entity:'',entityMode:'concerned'};state.menu=null;render();replaceHash();var toggle=root.querySelector('[data-filter-panel="dashboard"] .ui-filter-toggle');if(toggle)toggle.focus({preventScroll:true});},
    'monthly-settings':function(){dismissMenu();state.monthly.settingsOpen=true;renderOverlay();var first=document.getElementById('monthly-date');if(first)first.focus({preventScroll:true});var trigger=root.querySelector('[data-act="monthly-settings"]');if(trigger)trigger.setAttribute('aria-expanded','true');},
    'monthly-settings-close':function(){closeMonthlySettings(false);},
    'monthly-settings-save':function(){closeMonthlySettings(true);},
    'monthly-date-reset':resetMonthlyDate,
    'reset-comparison-scope':function(){state.comparison.scope=Object.assign({},state.comparison.scope,{sector:'',unit:'',entity:''});state.comparison.view=Object.assign({},state.comparison.view||{});state.menu=null;render();replaceHash();saveComparison();focusScopePanel('comparison');},
    'reset-comparison-view':function(){state.comparison.view={metric:'',type:'all',q:''};state.menu=null;render();replaceHash();saveComparison();var toggle=root.querySelector('[data-filter-panel="comparison-records"] .ui-filter-toggle');if(toggle)toggle.focus({preventScroll:true});},
    'compare-metric':function(el){compareMetric(el.getAttribute('data-metric'));},
    'cmp-focus':function(el){var metric=el.getAttribute('data-cmp-metric'),patch={type:el.getAttribute('data-cmp-type')||'changes',q:''};if(metric!=null)patch.metric=metric;changeComparisonView(patch);},
    'cmp-search':function(){var input=document.getElementById('cmp-q');changeComparisonView({q:input?input.value:''});},
    'close-multi':function(el){var id=el.getAttribute('data-multi');dismissMenu();var trigger=root.querySelector('[data-menu="'+id+'"]');if(trigger)trigger.focus({preventScroll:true});},
    'multi-all':function(el){var id=el.getAttribute('data-multi');syncMulti(id,id==='r:lead'?[]:S.filterOptions.all(state.multiOptions[id]||[]));},
    'multi-clear':function(el){syncMulti(el.getAttribute('data-multi'),[]);},
    'multi-remove':function(el){var id=el.getAttribute('data-multi'),v=el.getAttribute('data-v');syncMulti(id,S.filterOptions.remove(multiValue(id),v));},
    'go-entities':function(){go('entities');},
    'reset-entity':function(){state.entity={entity:'',role:'primary'};state.menu=null;render();replaceHash();focusScopePanel('entity-scope');},
    'entity-focus':function(el){return openDrillTab('entities',entityDrillPatch(el));},
    'entity-mode':function(el){entityUpdate({mode:el.getAttribute('data-mode')||'records',kind:''},true,true);},
    'entity-area':function(el){entityUpdate({area:el.getAttribute('data-area')||'',status:'',kind:''},true,true);},
    'entity-clear-filters':function(){entityUpdate({area:'',status:'',kind:'',q:''},false,true);},
    'entity-close-detail':function(){entityUpdate({mode:'',area:'',status:'',kind:'',q:''},true,false);var el=root.querySelector('.entity-overview-card');if(el)el.focus();},
    'entity-changes':function(){entityUpdate({mode:'changes',area:'',status:'',kind:'',q:''},true,true);},
    'entity-comparison':function(){state.entity.comparisonSetup=true;state.menu=null;pendingSearchLanding=false;render();focusEntityComparisonSetup();},
    'entity-close-comparison':function(){state.entity.comparisonSetup=false;state.menu=null;render();focusScopePanel('entity-scope');},
    'pick-file': function () {
      if (state.upload.status === 'loading') return;
      var i = document.getElementById('file-input');
      if (i) { i.value = ''; i.click(); }
    },
     'go-comparison':function(){state.comparison.view={};state.comparison.scope={sector:state.dash.sector||'',unit:state.dash.unit||'',entity:state.dash.entity||'',entityMode:'concerned'};go('comparison');},
    'pick-previous':function(){if(state.comparison.busy)return;var i=document.getElementById('previous-file-input');if(i){i.value='';i.click();}},
    'pick-current':function(){if(state.comparison.busy)return;var i=document.getElementById('comparison-current-input');if(i){i.value='';i.click();}},
    'confirm-period':function(el){var needsCurrentDate=state.data&&!state.data.referenceDateReady&&!state.comparison.current.confirmed&&!state.previous;var role=el.getAttribute('data-role'),p=state.comparison[role],d=role==='previous'?state.previous:state.data,n=S.comparison.serial(p.date);if(!n){state.comparison.error='أدخل تاريخاً صحيحاً';render();focusComparisonPeriod(role,'confirm-period');return;}p.confirmed=true;S.loader.redate(d,n);state.comparison.error='';saveComparison();if(role==='current'&&(pendingSearchLanding||needsCurrentDate)){pendingSearchLanding=false;go('home');}else{render();focusComparisonPeriod(role,'confirm-period');}},
    'clear-comparison-file':function(el){if(state.comparison.busy)return;state.comparison.view={};state.comparison.error='';var role=el.getAttribute('data-role');state[role==='previous'?'previous':'data']=null;state.comparison[role]={};cmpFiles[role]=null;state.lastComparison=null;if(role==='current'&&state.screen==='entities'){state.screen='upload';replaceHash();}saveComparison();render();focusComparisonPeriod(role);},
    'reset-comparison':function(){if(state.comparison.busy)return;state.previous=null;cmpFiles.previous=null;state.comparison.previous={};state.comparison.scope={sector:'',unit:'',entity:''};state.lastComparison=null;saveComparison();render();replaceHash();var reset=root.querySelector('[data-act="reset-comparison"]');if(reset)reset.focus({preventScroll:true});},
    'change-file': function () { state.upload = { status: 'idle', error: null, fileName: '' }; go('upload'); },
    'restore-agenda-legacy':function(){if(state.reporting)return;if(S.views.agendaPage.restoreLegacy(state)){render();toast('أُضيفت النصوص السابقة إلى التقرير الحالي؛ بقيت النسخة الأصلية محفوظة.');}},
    'download-agenda-legacy':function(){S.views.agendaPage.downloadLegacy(state);},
    'go-home': function () { if (state.data) go('home'); },
    'go-projects': function(){if(state.data){state.projects.view='dashboard';go('projects');}},
    'projects-reset':function(){state.projects=S.projects.defaults();state.menu=null;render();replaceHash();focusScopePanel('projects');},
    'projects-overview':function(){state.projects.view='dashboard';state.projects.focus='all';state.projects.value='';go('projects');},
    'projects-drill':function(el){state.projects=Object.assign({},state.projects,{view:'records',focus:el.getAttribute('data-focus')||'all',value:el.getAttribute('data-value')||''});go('projects');var records=document.getElementById('projects-records');if(records)records.focus({preventScroll:true});},
    'projects-report':function(){if(state.data){state.projects.view='dashboard';go('projects');}},
    'go-dash': function () { if (state.data) go('dashboard'); },
    'go-checks': function () { if (state.data) go('checks'); },
    'show-report': async function(el) {
      if(el.getAttribute('data-report')==='projects'){A['go-projects']();return;}
      state.report.kind=['hh','council'].includes(el.getAttribute('data-report'))?el.getAttribute('data-report'):'agenda';
      if(document.fonts&&document.fonts.ready)await document.fonts.ready; go('reports');
    },
    'reset-report-filters':function(){if(state.reporting)return;state.dash={sector:'',unit:'',entity:'',entityMode:'concerned'};state.report.lead='';state.report.type='';state.report.followup='';['projectType','priority','quarter','projectStatus'].forEach(function(k){state.report[k]='';});state.menu=null;render();replaceHash();},
    'reset-report-display':function(){if(state.reporting)return;S.reportDisplay.reset(state);render();replaceHash();},
    'report-jump': function(el,e) {
      e.preventDefault(); var target=document.getElementById(el.getAttribute('data-target'));
      if(target){ target.scrollIntoView({behavior:(window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'),block:'start'}); target.setAttribute('tabindex','-1'); target.focus({preventScroll:true}); }
    },
    'agenda-report': async function () {
      if (!state.data || state.reporting) return;
      var data = state.data, scope = { sector: state.dash.sector, unit: state.dash.unit, entity:state.dash.entity, entityMode:'concerned' };
      state.menu = null; state.reporting = true; render();
      try {
        var result = await S.agendaReport.build(data, scope, state.report.type||'', S.views.agendaPage.options(state));
        U.download(result.name, result.blob);
        toast('تم تنزيل تقرير الأجندة بصيغة PowerPoint · المواضيع: ' + U.fmtN(result.model.total));
      } catch (err) {
        toast(err.message || 'تعذّر إعداد التقرير. حاول مرة أخرى.');
      } finally {
        state.reporting = false; render();
        var trigger = root.querySelector('[data-menu="reports"]');
        if (trigger) trigger.focus();
      }
    },
    'council-report': async function () {
      if (!state.data || state.reporting) return;
      var data=state.data, scope={sector:state.dash.sector,unit:state.dash.unit,entity:state.dash.entity,entityMode:'concerned'}, options=S.views.councilPage.options(state);
      state.menu=null;state.reporting=true;render();
      try {
        var result=await S.councilExport.build(data,scope,options);
        U.download(result.name,result.blob);
        toast('تم تنزيل تقرير قرارات المجالس بصيغة PowerPoint');
      } catch(err) { toast(err.message||'تعذّر إعداد التقرير. حاول مرة أخرى.'); }
      finally {state.reporting=false;render();var trigger=root.querySelector('[data-act="council-report"]');if(trigger)trigger.focus();}
    },
    'hh-report': async function () {
      if (!state.data || state.reporting) return;
      state.menu = null; state.reporting = true; render();
      try {
        var result = await S.hhReport.build(state);
        U.download(result.name, result.blob);
        toast('تم تنزيل تقرير المشاريع الخاصة بصيغة PowerPoint · المشاريع: ' + U.fmtN(result.model.items.length));
      } catch (err) {
        toast(err.message || 'تعذّر إعداد التقرير. حاول مرة أخرى.');
      } finally {
        state.reporting = false; render();
        var trigger = root.querySelector('[data-act="hh-report"]');
        if (trigger) trigger.focus();
      }
    },
    'back': function () { if (history.length > 1) history.back(); else go('home'); },

    'scope': function (el) {
      state.search.tab = el.getAttribute('data-tab');
      var box = root.querySelector('.scope-chips');
      if (box) box.innerHTML = S.views.home.scopeChips(state);
      focusQuery();
    },
    'tab': function (el) {
      var s = state.search;
      s.tab = el.getAttribute('data-tab');
      s.page = 1;
      if (!s.q.trim() && !s.drill) s.browse = true;
      state.menu = null;
      updateResults();
    },
    'recent': function (el) { submit(el.getAttribute('data-q')); },
    'clear-q': function () {
      var s = state.search;
      s.q = ''; s.page = 1;
      if (!s.drill) s.browse = state.screen === 'results' || s.tab !== 'all';
      var q = document.getElementById('q');
      if (q) q.value = '';
      state.sugOpen = false;
      syncSearchBox(); renderSug(); updateResults(); focusQuery();
    },
    'menu': function (el) {
      var m = el.getAttribute('data-menu');
      var menuAnchor=multiMenuAnchor(m);
      state.menu = state.menu === m ? null : m;
      if (state.screen === 'results' && m !== 'reports') updateResults(menuAnchor); else render(menuAnchor);
      var btn = root.querySelector('[data-menu="' + m + '"]');
      if (btn) btn.focus({preventScroll:true});
    },
    'chip-remove':function(el){var id='f:'+el.getAttribute('data-f'),v=el.getAttribute('data-v');syncMulti(id,S.filterOptions.remove(multiValue(id),v));},
    'clear-filters': function () { state.search.f = S.search.emptyF(); state.search.page = 1; updateResults(); },
    'drill-clear': function () {
      var s = state.search;
      s.drill = null; s.page = 1;
      s.browse = !s.q.trim();
      updateResults();
    },
    'zero-all': function () { state.search.browse = !state.search.q.trim(); state.search.tab = 'all'; state.search.f = S.search.emptyF(); state.search.drill = null; state.search.page = 1; updateResults(); },
    'sort': function (el) {
      var s = state.search, col = el.getAttribute('data-col');
      s.sort = !s.sort || s.sort.col !== col ? { col: col, dir: 'asc' } : s.sort.dir === 'asc' ? { col: col, dir: 'desc' } : null;
      s.page = 1;
      updateResults();
      var b = root.querySelector('[data-act="sort"][data-col="' + col + '"]');
      if (b) b.focus();
    },
    'reset-search-columns': function () { state.search.columns=S.views.results.saveColumns(); updateResults(); var b=root.querySelector('[data-act="reset-search-columns"]');if(b)b.focus(); },
    'export': function () {
      var res = state.lastRes;
      if (!res || !res.rows.length) return;
      U.download('performance-results-' + stamp() + '.csv', S.search.exportCsv(res.rows), 'text/csv;charset=utf-8');
      toast('تم تصدير النتائج بصيغة CSV · العدد: ' + U.fmtN(res.rows.length));
    },
    'print': printReport,
    'open': function (el) { openDetail(el.getAttribute('data-key'), el); },
    'close-detail': function () { closeDetail(); },
    'copy-item': function () {
      var it = state.data && state.data.byKey[state.openKey];
      if (!it) return;
      copyText(S.views.detail.textOf(it, state.data)).then(function (ok) { toast(ok ? 'تم نسخ بيانات ' + S.ui.recordWord(it.pf, 'definite') : 'تعذّر النسخ. حدّد النص وانسخه يدوياً'); });
    },
    'drill': function (el) { drill(el.getAttribute('data-metric')); },
    'follow-items':function(){drill('follow',true);},
    'dash-set':function(el){syncMulti('d:'+el.getAttribute('data-k'),U.selection(el.getAttribute('data-v')));},
    'fu-expand': function (el, e) {
      e.stopPropagation();
      var key = el.getAttribute('data-key');
      state.fuOpen[key] = !state.fuOpen[key];
      var y = window.scrollY;
      render();
      window.scrollTo(0, y);
    },
    'checks-sheet': function (el) {
      var sh = el.getAttribute('data-sheet');
      state.checks.sheet = state.checks.sheet === sh ? '' : sh;
      replaceHash();
      var y = window.scrollY;
      render();
      window.scrollTo(0, y);
      var button=Array.from(root.querySelectorAll('[data-act="checks-sheet"]')).find(function(b){return b.getAttribute('data-sheet')===sh;});if(button)button.focus({preventScroll:true});
    },
    'checks-export': function () {
      if (!state.data.issues.length) return;
      U.download('performance-issues-' + stamp() + '.csv', S.views.checks.exportCsv(state.data,state.checks), 'text/csv;charset=utf-8');
      toast('تم تنزيل الملاحظات ضمن عوامل التصفية الحالية');
    },
    'sug-all': function () { submit(); },
    'sug-item': function (el) {
      var key = el.getAttribute('data-key');
      state.sugOpen = false;
      if (state.screen === 'home') submit();
      openDetail(key);
    },
    'sug-person': function (el) {
      var s = newSearch();
      s.f.coord = [U.key(el.getAttribute('data-name'))];
      s.browse = true;
      s.columns = state.search.columns;
      state.search = s;
      go('results');
    },
    'sug-pf': function (el) {
      var s = newSearch();
      s.tab = el.getAttribute('data-pf');
      s.browse = true;
      s.columns = state.search.columns;
      state.search = s;
      go('results');
    }
  };

  /* ---------- events ---------- */
  document.addEventListener('click', function (e) {
    var picker=root.querySelector('.cmp-metric-picker[open]');if(picker&&!e.target.closest('.cmp-metric-picker'))picker.open=false;
    if (state.menu && !e.target.closest('.menu-wrap')) dismissMenu();
    if (state.sugOpen && !e.target.closest('#sbox')) { state.sugOpen = false; renderSug(); }
    var el = e.target.closest('[data-act]');
    if (!el || el.disabled) return;
    var action = el.getAttribute('data-act'), fn = A[action];
    if (el.tagName === 'A' && fn) {
      e.preventDefault();
      if ((e.ctrlKey || e.metaKey || e.shiftKey) && el.hasAttribute('data-screen-link')) {
        openDrillTab(el.getAttribute('data-screen-link'),screenLinkPatch(el)); return;
      }
    }
    if (fn) {
      var resetPanel=el.classList.contains('ui-filter-reset')?el.closest('.ui-filter-panel').getAttribute('data-filter-panel'):null;
      fn(el, e);
      // Reset commonly redraws the view and removes its button. Return focus
      // to the stable disclosure instead of leaving it on the document body.
      if(resetPanel){var resetToggle=root.querySelector('[data-filter-panel="'+resetPanel+'"] .ui-filter-toggle');if(resetToggle)resetToggle.focus({preventScroll:true});}
    }
  });

  document.addEventListener('auxclick', function (e) {
    if (e.button !== 1) return;
    var el = e.target.closest('[data-act]');
    if (!el || el.disabled) return;
    if (el.hasAttribute('data-screen-link')) { e.preventDefault(); openDrillTab(el.getAttribute('data-screen-link'),screenLinkPatch(el)); return; }
    if (!['dashboard','projects','entities'].includes(state.screen) || !['drill','compare-metric','projects-drill','projects-report','entity-focus'].includes(el.getAttribute('data-act'))) return;
    e.preventDefault(); A[el.getAttribute('data-act')](el, e);
  });

  function closeMonthlySettings(saved){
    var dialog=document.getElementById('monthly-report-settings');state.monthly.settingsOpen=false;
    if(dialog&&dialog.open)dialog.close();renderOverlay();
    var trigger=root.querySelector('[data-act="monthly-settings"]');if(trigger)trigger.setAttribute('aria-expanded','false');
    var target=saved?root.querySelector('.monthly-print-control [data-act="print"]'):trigger;if(target)target.focus({preventScroll:true});
  }
  document.addEventListener('cancel',function(e){if(e.target.id==='monthly-report-settings'){e.preventDefault();closeMonthlySettings(false);}},true);
  document.addEventListener('click',function(e){if(e.target.id==='monthly-report-settings'){var r=e.target.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeMonthlySettings(false);}});

  document.addEventListener('input', function (e) {
    var menuSearch=e.target.getAttribute('data-multi-search');
    if(menuSearch){state.multiSearch=state.multiSearch||{};state.multiSearch[menuSearch]=e.target.value;var menu=e.target.closest('.multi-menu'),needle=U.norm(S.filterOptions.display(e.target.value)),shown=0;Array.from(menu.querySelectorAll('.multi-options .opt')).forEach(function(opt){opt.hidden=!!needle&&!U.norm(opt.querySelector('.opt-l').textContent).includes(needle);if(!opt.hidden)shown++;});var empty=menu.querySelector('.multi-empty');if(empty){empty.hidden=!!shown;empty.textContent='لا توجد خيارات مطابقة للبحث';}positionMultiMenu();return;}

    if(e.target.id==='entity-query'){var pos=e.target.selectionStart;state.entity.q=e.target.value;var panel=document.getElementById('entity-detail');if(panel&&state.lastEntity)panel.outerHTML=S.views.entities.focusPanel(state.lastEntity,state);else render();replaceHash();var input=document.getElementById('entity-query');if(input){input.focus({preventScroll:true});try{input.setSelectionRange(pos,pos);}catch(ignore){}}return;}
    var displayField=e.target.getAttribute('data-report-display');if(displayField){if(state.reporting)return;S.reportDisplay.set(state,displayField,e.target.value);S.reportDisplay.updateVisible(state);document.title=screenTitle();replaceHash();return;}
    var reportText=e.target.getAttribute('data-report-text');if(reportText&&['notes','recommendations'].includes(reportText)){if(state.reporting)return;S.reportEditorial.set(state,reportText,e.target.value);S.reportEditorial.update(state);return;}
    var councilText=e.target.getAttribute('data-council-text');
    if(councilText&&['notes','recommendations'].includes(councilText)){if(state.reporting)return;S.views.councilPage.options(state)[councilText]=e.target.value;S.views.councilPage.save(state);S.views.councilPage.updateEditorial(state);return;}
    var agendaText=e.target.getAttribute('data-agenda-text');
    if(agendaText&&['notes','recommendations'].includes(agendaText)){S.views.agendaPage.options(state)[agendaText]=e.target.value;S.views.agendaPage.save(state);S.views.agendaPage.updateEditorial(state);return;}
    if (e.target.id !== 'q') return;
    var s = state.search;
    s.q = e.target.value;
    s.page = 1;
    s.sort = null;
    s.force = false;
    if (s.q.trim()) { s.browse = false; s.drill = null; }
    else s.browse = !s.drill && (state.screen === 'results' || s.tab !== 'all');
    state.sugOpen = true;
    syncSearchBox();
    scheduleUpdate();
    if (state.screen !== 'results') renderSug();
  });

  document.addEventListener('change', function (e) {
    var t = e.target;
    var monthlyAction=t.getAttribute('data-act');
    if(monthlyAction==='checks-severity'){state.checks.severity=['error','warn','info'].includes(t.value)?t.value:'';replaceHash();render();document.getElementById('checks-severity').focus({preventScroll:true});return;}
    if(monthlyAction==='monthly-layout'){
      if(state.reporting)return;
      state.monthly.layout=t.value==='a3'?'a3':'a4';
      U.store.set('localStorage','saytara.monthly-layout',state.monthly.layout);
      render();focusMonthlyControl('monthly-layout');return;
    }
    if(monthlyAction==='monthly-date'){monthlyDate(t.value);return;}
    if(t.getAttribute('data-change')==='search-sort'){var sort=t.value.split(':');state.search.sort=sort[0]?{col:sort[0],dir:sort[1]}:null;state.search.page=1;updateResults();var sel=root.querySelector('[data-change="search-sort"]');if(sel)sel.focus();return;}
    if(t.getAttribute('data-change')==='search-column'){var id=t.getAttribute('data-column'),cols=S.views.results.cleanColumns(state.search.columns);state.search.columns=S.views.results.saveColumns(t.checked?cols.concat(id):cols.filter(function(x){return x!==id;}));updateResults();var cb=root.querySelector('[data-change="search-column"][data-column="'+id+'"]');if(cb)cb.focus();return;}
    if(t.getAttribute('data-change')==='multi'){var id=t.getAttribute('data-multi'),v=t.getAttribute('data-v'),values=multiValue(id),option=(state.multiOptions[id]||[]).find(function(o){return o.v===v;})||{v:v,variants:[v]};syncMulti(id,S.filterOptions.toggle(values,option,t.checked),v);return;}
    var ef=t.getAttribute('data-entity-field');if(ef&&['entity','role'].includes(ef)){state.entity[ef]=t.value;render();replaceHash();return;}
    var role=t.getAttribute('data-cmp-period');if(role){state.comparison[role].date=t.value;state.comparison[role].confirmed=false;saveComparison();render();var periodInput=root.querySelector('[data-cmp-period="'+role+'"]');if(periodInput)periodInput.focus({preventScroll:true});return;}
    var scope=t.getAttribute('data-cmp-scope');if(scope){syncMulti('c:'+scope,U.selection(t.value));return;}
    if(t.id==='previous-file-input'||t.id==='comparison-current-input'){if(t.files&&t.files[0])loadComparisonFile(t.files[0],t.id==='previous-file-input'?'previous':'current');return;}
    var displayField=t.getAttribute('data-report-display');if(displayField){if(state.reporting)return;S.reportDisplay.set(state,displayField,t.value);S.reportDisplay.updateVisible(state);document.title=screenTitle();replaceHash();return;}
    if (t.id === 'file-input') { if (t.files && t.files[0]) loadFile(t.files[0]); return; }
    if (t.getAttribute('data-change') === 'report-type') { state.report.type=t.value; render(); replaceHash(); return; }
    if (t.getAttribute('data-change') === 'report-lead') { state.report.lead=S.ui.reportLeadSelection(t.value); render(); replaceHash(); return; }
    if (t.getAttribute('data-change') === 'facet') {
      var f = state.search.f, k = t.getAttribute('data-f'), v = t.getAttribute('data-v');
      var list = f[k] || [];
      f[k] = t.checked ? list.concat(list.indexOf(v) < 0 ? [v] : []) : list.filter(function (x) { return x !== v; });
      state.search.page = 1;
      updateResults();
      var again = root.querySelector('input[data-change="facet"][data-f="' + k + '"][data-v="' + (window.CSS && CSS.escape ? CSS.escape(v) : v) + '"]');
      if (again) again.focus();
    }
  });

  document.addEventListener('focusin', function (e) {
    if(state.menu==='reports'&&e.target.closest&&!e.target.closest('.report-wrap'))dismissMenu();
    if(state.menu&&state.menu!=='reports'&&e.target.closest){
      var wrap=root.querySelector('[data-multi-wrap="'+state.menu+'"]');
      // Activating a label can first focus its focusable page ancestor. Keep
      // the option alive until the browser activates its native checkbox.
      if(!wrap||(!wrap.contains(e.target)&&!e.target.contains(wrap)))dismissMenu();
    }
    var el = e.target.closest && e.target.closest('[data-tip]');
    if (el) showTip(el); else hideTip();
  });

  document.addEventListener('keydown', function (e) {
    var t = e.target, typing = /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName) || t.isContentEditable;
    if(t.getAttribute&&t.getAttribute('role')==='tab'&&t.getAttribute('data-act')==='tab'&&['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){
      e.preventDefault();var tabs=Array.from(root.querySelectorAll('[role="tab"][data-act="tab"]')),index=tabs.indexOf(t),next=e.key==='Home'?0:e.key==='End'?tabs.length-1:(index+(e.key==='ArrowLeft'?1:-1)+tabs.length)%tabs.length;
      if(tabs[next]){var value=tabs[next].getAttribute('data-tab');A.tab(tabs[next]);var active=root.querySelector('[role="tab"][data-act="tab"][data-tab="'+value+'"]');if(active)active.focus();}return;
    }

    var multi=t.closest&&t.closest('.multi-wrap');
    if(multi&&['ArrowDown','ArrowUp','Home','End','Escape'].includes(e.key)&&(!t.hasAttribute('data-multi-search')||['ArrowDown','Escape'].includes(e.key))){
      var id=multi.getAttribute('data-multi-wrap');e.preventDefault();
      if(e.key==='Escape'){dismissMenu();var trigger=root.querySelector('[data-menu="'+id+'"]');if(trigger)trigger.focus();return;}
      if(state.menu!==id){var menuAnchor=multiMenuAnchor(id);state.menu=id;if(state.screen==='results')updateResults(menuAnchor);else render(menuAnchor);}
      var wrap=root.querySelector('[data-multi-wrap="'+id+'"]'),controls=wrap?Array.from(wrap.querySelectorAll('.multi-menu button, .multi-menu input')).filter(function(control){return !control.disabled&&!control.closest('[hidden]');}):[],at=controls.indexOf(t),next=e.key==='Home'?0:e.key==='End'?controls.length-1:e.key==='ArrowDown'?(at+1)%controls.length:at<0?controls.length-1:(at-1+controls.length)%controls.length;
      if(controls[next])focusMultiControl(controls[next]);return;
    }

    if (t.closest('.report-wrap')) {
      if (e.key === 'Escape' && state.menu === 'reports') {
        e.preventDefault(); state.menu = null; render(); root.querySelector('[data-menu="reports"]').focus(); return;
      }
      if (['ArrowDown', 'ArrowUp', 'Home', 'End'].indexOf(e.key) >= 0) {
        e.preventDefault();
        if (state.menu !== 'reports') { state.menu = 'reports'; render(); }
        var options=Array.from(root.querySelectorAll('#report-menu [role="menuitem"]:not(:disabled)')), at=options.indexOf(t);
        var next=e.key==='Home'?0:e.key==='End'?options.length-1:e.key==='ArrowDown'?(at+1)%options.length:at<0?options.length-1:(at-1+options.length)%options.length;
        if(options[next])options[next].focus();
        return;
      }
    }

    if(t.id==='cmp-q'&&e.key==='Enter'){e.preventDefault();A['cmp-search']();return;}
    if (t.id === 'q') {
      if (e.key === 'Enter') { e.preventDefault(); submit(); return; }
      if (e.key === 'Escape') { if (state.sugOpen) { e.preventDefault(); state.sugOpen = false; renderSug(); return; } }
      if (e.key === 'ArrowDown') {
        var first = document.querySelector('#sug:not([hidden]) button');
        if (first) { e.preventDefault(); first.focus(); return; }
      }
    }
    if (t.closest && t.closest('#sug') && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
      e.preventDefault();
      var btns = Array.prototype.slice.call(document.querySelectorAll('#sug button')), i = btns.indexOf(t);
      var next = e.key === 'ArrowDown' ? btns[i + 1] : btns[i - 1];
      if (next) next.focus(); else if (e.key === 'ArrowUp') focusQuery();
      return;
    }

    /* Esc closes the top-most thing; the key is then used up, so the browser doesn't also act on it
       (for example by clearing the search box). */
    if (e.key === 'Escape') {
      if(state.navOpen&&!state.menu){e.preventDefault();A['toggle-nav']();var navToggle=root.querySelector('[data-act="toggle-nav"]');if(navToggle)navToggle.focus();return;}
      var picker=root.querySelector('.cmp-metric-picker[open]');if(picker){e.preventDefault();picker.open=false;var ps=picker.querySelector('summary');if(ps)ps.focus();return;}
      if (!tipEl.hidden) { e.preventDefault(); hideTip(); return; }
      if (state.menu) { e.preventDefault(); var m = state.menu; state.menu = null; if (state.screen === 'results' && m !== 'reports') updateResults(); else render(); var b = root.querySelector('[data-menu="' + m + '"]'); if (b) b.focus(); return; }
      if (state.sugOpen) { e.preventDefault(); state.sugOpen = false; renderSug(); focusQuery(); return; }
      if (state.openKey) { e.preventDefault(); closeDetail(); return; }
    }

    if (e.key === '/' && !typing && state.data && !state.openKey) {
      e.preventDefault();
      if (state.screen !== 'home' && state.screen !== 'results') go('home');
      else focusQuery();
      return;
    }

    if ((e.key === 'Enter' || e.key === ' ') && !typing && t.matches && t.matches('tr[data-act], [role="button"][data-act]')) {
      e.preventDefault();
      t.click();
      return;
    }
    if ((e.key === 'ArrowDown' || e.key === 'ArrowUp') && t.matches && t.matches('tr[tabindex]')) {
      e.preventDefault();
      var sib = e.key === 'ArrowDown' ? t.nextElementSibling : t.previousElementSibling;
      if (sib) sib.focus();
      return;
    }
    if (e.key === 'Tab' && state.openKey) {
      var panel = overlay.querySelector('.detail');
      if (!panel) return;
      var focusables = panel.querySelectorAll('button, [href], input, [tabindex]:not([tabindex="-1"])');
      if (!focusables.length) return;
      var firstEl = focusables[0], lastEl = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === firstEl) { e.preventDefault(); lastEl.focus(); }
      else if (!e.shiftKey && document.activeElement === lastEl) { e.preventDefault(); firstEl.focus(); }
    }
  });

  /* Dropping a workbook anywhere loads it. */
  function hasFiles(e) { return e.dataTransfer && Array.prototype.indexOf.call(e.dataTransfer.types || [], 'Files') >= 0; }
  ['dragenter', 'dragover'].forEach(function (type) {
    document.addEventListener(type, function (e) {
      if (!hasFiles(e)) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
      document.body.classList.add('is-dragging');
    });
  });
  document.addEventListener('dragleave', function (e) {
    if (!e.relatedTarget || e.relatedTarget === document.documentElement) document.body.classList.remove('is-dragging');
  });
  document.addEventListener('drop', function (e) {
    if (!hasFiles(e)) return;
    e.preventDefault();
    document.body.classList.remove('is-dragging');
    var f = e.dataTransfer.files && e.dataTransfer.files[0];
    if(state.screen==='comparison'){state.comparison.error='اختر زر الملف السابق أو الحالي لتحديد دور الملف بوضوح';render();return;}
    if (f && state.upload.status !== 'loading') loadFile(f);
  });

  /* ---------- tooltip and toast ---------- */
  function showTip(el) {
    var t = S.ui.tips[el.getAttribute('data-tip')];
    if (!t) return;
    tipEl.innerHTML = '<div class="tip-t">' + U.esc(t.title) + '</div>' + (t.def ? '<div class="tip-d">' + U.esc(t.def) + '</div>' : '') +
      (t.now ? '<div class="tip-n">الآن: <b>' + U.esc(t.now) + '</b></div>' : '') + (t.base ? '<div class="tip-d">' + U.esc(t.base) + '</div>' : '');
    tipEl.hidden = false;
    var r = el.getBoundingClientRect(), tw = tipEl.offsetWidth, th = tipEl.offsetHeight;
    var x = Math.max(8, Math.min(window.innerWidth - tw - 8, r.left + r.width / 2 - tw / 2));
    var y = r.top - th - 8;
    if (y < 8) y = r.bottom + 8;
    tipEl.style.left = x + 'px';
    tipEl.style.top = y + 'px';
  }
  function hideTip() { if (tipEl && !tipEl.hidden) tipEl.hidden = true; }
  document.addEventListener('mouseover', function (e) {
    var el = e.target.closest && e.target.closest('[data-tip]');
    if (el) showTip(el);
  });
  document.addEventListener('mouseout', function (e) {
    var el = e.target.closest && e.target.closest('[data-tip]');
    if (el && !el.contains(e.relatedTarget)) hideTip();
  });
  window.addEventListener('scroll', hideTip, true);
  window.addEventListener('resize', hideTip);

  function toast(msg) {
    clearTimeout(toastTimer);
    toastEl.innerHTML = U.icon('check', 18) + '<span>' + U.esc(msg) + '</span>';
    toastEl.hidden = false;
    toastTimer = setTimeout(function () { toastEl.hidden = true; }, 2800);
  }

  window.addEventListener('beforeprint', beginPrint);
  window.addEventListener('afterprint', endPrint);
  // A print-media exit also covers browsers that omit afterprint on Cancel.
  if (window.matchMedia) {
    var printMedia = window.matchMedia('print');
    var printMediaChanged = function (e) { if (e.matches) beginPrint(); else endPrint(); };
    if (printMedia.addEventListener) printMedia.addEventListener('change', printMediaChanged);
    else if (printMedia.addListener) printMedia.addListener(printMediaChanged);
  }

  /* ---------- start ---------- */
  function boot() {
    var route = parseHash(), token = route && route.params.get('__tab');
    if (token && receiveDrillTab(token)) return;
    var transferred = '';
    if (window.name && window.name.indexOf(TAB_TRANSFER) === 0) {
      transferred = window.name.slice(TAB_TRANSFER.length); window.name = '';
      // Persist only within this tab, when storage capacity allows normal reloads.
      U.store.set('sessionStorage', CMP_KEY, transferred);
    }
    if (!S.zip.supported()) {
      state.upload = { status: 'error', error: S.views.upload.message({ code: 'BROWSER' }), fileName: '' };
    }
    if (!restoreSession(transferred)) {
      state.screen = 'upload';
      if (location.hash && location.hash !== '#/upload') { try { history.replaceState(null, '', '#/upload'); } catch (e) { /* ignore */ } }
      render();
    }
  }

  S.app = { state: state, href:hashFor, loadComparisonFile:loadComparisonFile, saveComparison:saveComparison, loadFile: loadFile, go: go, drill: drill, submit: submit, openDetail: openDetail, closeDetail: closeDetail, render: render, updateResults: updateResults,refreshPersistenceNotice:refreshPersistenceNotice };
  boot();
})(window.Saytara = window.Saytara || {});
