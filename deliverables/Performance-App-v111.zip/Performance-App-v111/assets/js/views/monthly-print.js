/* Paper report: consume the same scoped dashboard model as the screen.
 * Keep all source notes as text. Page limits are preferences, never clipping. */
(function (S) {
  'use strict';
  var U = S.util, R = S.rules;
  function text(v) { return U.esc(v == null ? '' : String(v)); }
  function value(v, percent) {
    return '<bdi dir="ltr">' + U.metricText(v, percent) + '</bdi>';
  }
  function available(state, key) { return R.metricAvailable(state.data, key, state.dash || {}); }
  function delta(D, key, tone) {
    var c = D.change(key);
    if (c.state === 'same' || c.state === 'none') return '';
    var up = c.d > 0, color = tone === 'good' ? (up ? 'good' : 'bad') : tone === 'bad' ? (up ? 'bad' : 'good') : 'neutral';
    var unit = key === 'kpiAvg' ? ' ن.م.' : '';
    return '<span class="mp-change ' + color + '" data-print-change="' + key + '"><bdi dir="ltr">' + (up ? '↑ +' : '↓ −') + text(c.text) + '</bdi>' + unit + '</span>';
  }
  function metric(state, D, key, label, tone, raw, percent, compare, changeTone) {
    var v = available(state, key) ? (raw === undefined ? D.n[key] : raw) : null;
    return '<div class="mp-metric ' + (tone || '') + (key === 'legLate' ? ' mp-overdue' : '') + '"><span>' + text(label) + '</span><strong data-print-metric="' + key + '">' + value(v, percent) + '</strong>' + (compare === false ? '' : delta(D,key,changeTone===undefined?tone:changeTone)) + '</div>';
  }
  function row(state, D, cells, extraClass) {
    return '<div class="mp-metrics' + (extraClass ? ' ' + extraClass : '') + '" style="--mp-cols:' + cells.length + '">' + cells.map(function(c){return metric(state,D,c[0],c[1],c[2],c[3],c[4],c[5],c[6]);}).join('') + '</div>';
  }
  function supplementary(state, D, cells) {
    // Omit empty supplementary categories while keeping source gaps visible
    // as numeric cells. A missing metric is never treated as a zero.
    return cells.filter(function(c){return !available(state,c[0]) || D.n[c[0]] !== 0;});
  }
  function card(state,D,key,title,body) {
    return '<section class="mp-card"><header class="mp-card-head"><h3>' + text(title) + '</h3><div class="mp-total"><span>المجموع</span><strong data-print-metric="' + key + '">' + value(available(state,key)?D.n[key]:null) + '</strong>' + delta(D,key) + '</div></header>' + S.monthlyRag.render(state,D,(R.MET[key]||{}).pf) + body + '</section>';
  }
  function note(s, warn) { return '<p class="mp-note' + (warn ? ' mp-warning' : '') + '">' + s + '</p>'; }
  function historyQuality(D) {
    var issues=D.historyIssues||[];
    if(!issues.length)return '';
    return note('مراجعة المصدر للمقارنة: '+Array.from(new Set(issues.map(function(issue){return issue.reason;}))).map(text).join(' · '),true);
  }
  function header(state, withScope) {
    var d=state.data, fields=S.monthlyTools.scope(state).filter(function(field){return field.key==='sector'||field.key==='unit';});
    return '<header class="mp-header' + (withScope===false?' mp-header-compact':'') + '"><div class="mp-title"><h1>التقرير الشهري للأداء والتنفيذ - حتى تاريخ <bdi dir="ltr">' + text(U.fmtDate(d.today)) + '</bdi></h1>' + '</div></header>' +
      (withScope===false?'':'<dl class="mp-scope">' + fields.map(function(field){return '<div class="mp-scope-field" data-print-scope="' + field.key + '"><dt class="mp-scope-label">' + text(field.label) + '</dt><dd class="mp-scope-value"><bdi dir="auto">' + text(field.text) + '</bdi></dd></div>';}).join('') + '</dl>');
  }
  function footer(state) {
    var organization=S.ui.copyrightText();
    return '<style>:root{--mp-footer-context:"'+organization+'";}</style><footer class="mp-footer">'+text(organization)+'</footer>';
  }
  function strategy(state,D) {
    var k=D.kpi;
    return '<section class="mp-card mp-strategy"><header class="mp-card-head"><h3>استراتيجية الأمانة العامة</h3><div class="mp-total"><span>المجموع</span><strong data-print-metric="kpiTotal">' + value(available(state,'kpiTotal')?k.total:null) + '</strong>' + (D.change('kpiTotal').state==='none'?'':delta(D,'kpiTotal')) + '</div></header>' + S.monthlyRag.render(state,D,'kpi') + '<div class="mp-strategy-grid"><div class="mp-metric"><span>المؤشرات المقاسة / الإجمالي</span><strong data-print-ratio="kpi"><bdi dir="ltr">' + U.metricText(available(state,'kpiMeasured')?k.measured:null) + ' / ' + U.metricText(available(state,'kpiTotal')?k.total:null) + '</bdi></strong>' + delta(D,'kpiMeasured','good') + '</div>' +
      metric(state,D,'kpiAvg','متوسط النتائج المقاسة','',k.avgResult,true) + metric(state,D,'kpiTargeted','متوسط المستهدفات المعتمدة','',k.avgTarget,true,false) + '</div>' + (k.explicitState ? '<p class="mp-note">خارج إحصاءات القياس: غير مقاس '+text(U.metricText(k.notMeasured))+' · غير منطبق '+text(U.metricText(k.notApplicable))+' · غير متاح '+text(U.metricText(k.unavailable))+' · حالة غير معروفة '+text(U.metricText(k.unknown))+' · تعارض '+text(U.metricText(k.conflict))+'</p>' : '') + '</section>';
  }
  function special(state,D,area) {
    var groups=[['specialLead','للقيادة','specialLeadProgress','specialLeadDone','specialLeadLate'],['specialGs','للأمانة العامة','specialGsProgress','specialGsDone','specialGsLate']];
    var extras=supplementary(state,D,[['specialNoRequester','جهة طلب غير مسجلة','',undefined,false,false]]);
    groups=groups.filter(function(g){return !area || !area.groups || area.groups[g[0]];});
    return card(state,D,'specialTotal','المشاريع الخاصة',groups.map(function(g){return '<div class="mp-requester'+(groups.length===1?' mp-requester-single':'')+'"><h4>'+text(g[1])+' · '+value(available(state,g[0])?D.n[g[0]]:null)+delta(D,g[0])+'</h4>'+row(state,D,[[g[4],'متأخر','bad'],[g[3],'منجز','good'],[g[2],'قيد العمل']])+'</div>';}).join('') + (extras.length?row(state,D,extras,'mp-secondary-metrics'):''));
  }
  function secretariat(state,D,area) {
    var b=D.budget;
    return card(state,D,'secTotal','مشاريع بموازنة استراتيجية',row(state,D,[['secLate','متأخر','bad'],['secDone','منجز','good'],['secActive','قيد العمل'],['secHeld','ملغى / معلق']]) +
      '<div class="mp-subheading">توزيع المشاريع حسب ربع موعد الانتهاء · '+state.data.year+'</div>'+row(state,D,[1,2,3,4].map(function(q){return ['secQ'+q,'ربع '+q];}),'mp-quarters') +
      (D.n.secNoQuarter ? '<p class="mp-note mp-quarter-exception">خارج أرباع سنة التقرير أو بدون تاريخ: <span data-print-metric="secNoQuarter">'+value(available(state,'secNoQuarter')?D.n.secNoQuarter:null)+'</span></p>' : '') +
      (area && area.budget===false ? '' : '<section class="mp-budget"><div class="mp-budget-head"><div class="mp-budget-title"><h4>الموازنة</h4><small class="mp-budget-unit">(درهم إماراتي)</small></div><div class="mp-total mp-budget-total" data-print-money="budApproved"><span class="mp-budget-label">الموازنة المعتمدة</span><strong data-print-metric="budApproved">'+value(available(state,'budApproved')?b.approved:null)+'</strong><span class="mp-budget-change">'+delta(D,'budApproved','neutral')+'</span></div></div>'+[['budAllocated','المخصص',b.allocated],['budSpent','المنفق حسب الفواتير',b.spent],['budUnallocated','غير المخصص',b.unallocated]].map(function(c){return '<div class="mp-budget-row" data-print-money="'+c[0]+'"><span class="mp-budget-label">'+text(c[1])+'</span><strong data-print-metric="'+c[0]+'">'+value(available(state,c[0])?c[2]:null)+'</strong><span class="mp-budget-change">'+delta(D,c[0],'neutral')+'</span></div>';}).join('')+'</section>'));
  }
  function agenda(state,D) {
    var extras=supplementary(state,D,[['agendaNoStatus','غير مصنف','',undefined,false,false]]);
    return card(state,D,'agendaTotal','الأجندة السنوية','<div class="mp-agenda-types">'+row(state,D,[['agendaPlanned','الأجندة المعتمدة'],['agendaEmerging','مستجدات الأجندة']])+'</div>'+row(state,D,[['agendaLate','متأخر','bad'],['agendaDone','منجز','good'],['agendaReady','جاهز للعرض'],['agendaProgress','قيد العمل']].concat(extras)));
  }
  function council(state,D) {
    var extras=supplementary(state,D,[['councilNoStatus','بدون حالة معتمدة','',undefined,false,false]]);
    return card(state,D,'councilTotal','قرارات المجالس',row(state,D,[['councilLate','متأخر','bad'],['councilDone','منجز','good'],['councilProgress','قيد العمل']]) +
      '<div class="mp-council-footer">'+(extras.length?'<p class="mp-note mp-council-unclassified">بدون حالة معتمدة: <span data-print-metric="councilNoStatus">'+value(available(state,'councilNoStatus')?D.n.councilNoStatus:null)+'</span></p>':'')+'<p class="mp-note mp-population-note">القرارات التي تتطلب متابعة</p></div>');
  }
  function legislation(state,D) {
    return card(state,D,'legTotal','التشريعات','<div class="mp-legislation-statuses"><h4 class="mp-completed-heading">منجز</h4>'+row(state,D,[['legLate','متأخر','bad'],['legOnTime','على الموعد','good'],['legOverrun','تجاوز الموعد','good',undefined,false,undefined,'neutral'],['legProgress','قيد العمل']])+'</div><p class="mp-note mp-deadline-definition" title="وفق معادلة القالب، يُقارن الإنجاز الفعلي بكل موعد متاح، ويُحتسب التجاوز إذا كان بعد أحدها؛ التمديد لا يلغي المواعيد الأخرى.">تجاوز الموعد: تاريخ الإنجاز الفعلي بعد أحد مواعيد SLC أو التمديد أو إدارة التشريعات.</p>');
  }
  function followups(state,D) {
    var list=D.follow.slice().sort(function(a,b){return S.order.items(state.data,a.it,b.it)||S.order.status(state.data,a.status,b.status,a.it.pf===b.it.pf?a.it.pf:null);});
    if(!list.length) return '';
    var headings=['المحفظة',S.ui.contentHeader(list.map(function(x){return x.it;})),'مستوى الإنجاز','الوحدة التنظيمية / القطاع','الملاحظات'];
    return '<section class="mp-followups">'+(S.monthlyTools.layout(state)==='a4'?header(state,false):'')+'<h2>بنود المتابعة · '+U.fmtN(list.length)+'</h2><table class="mp-notes-table"><colgroup>'+[12,22,10,20,36].map(function(width){return '<col style="width:'+width+'%">';}).join('')+'</colgroup><thead><tr>'+headings.map(function(label){return '<th scope="col">'+text(label)+'</th>';}).join('')+'</tr></thead><tbody>'+list.map(function(x){
      var it=x.it, pf=U.tableCellText(S.ui.pfName(it.pf)), title=U.tableCellText(it.title), statusLabel=U.tableCellText(x.status);
      var unit=U.tableCellText(it.unit), sector=U.tableCellText(it.sector), noteText=U.tableCellText(x.note);
      var status={statusLabel:statusLabel,statusCat:R.catOf(statusLabel)};
      return '<tr data-print-key="'+text(it.key)+'"><td class="mp-followup-pf">'+text(pf)+'</td><td class="mp-followup-title">'+(title?'<strong dir="'+text(it.dir||'auto')+'">'+text(title)+'</strong>':'')+'</td><td class="mp-followup-status">'+(statusLabel?S.ui.statusChip(status):'')+'</td><td class="mp-followup-unit">'+(unit?'<span dir="auto">'+text(unit)+'</span>':'')+(sector?'<small dir="auto">'+text(sector)+'</small>':'')+'</td><td class="mp-followup-note">'+(noteText?'<p dir="auto">'+text(noteText)+'</p>':'')+'</td></tr>';
    }).join('')+'</tbody></table></section>';
  }
  function render(state,D) {
    var areas=S.views.dashboard.contribution(state,D), projects=(areas.special.visible?special(state,D,areas.special):'')+(areas.secretariat.visible?secretariat(state,D,areas.secretariat):''), executive=(areas.agenda.visible?agenda(state,D):'')+(areas.council.visible?council(state,D):'')+(areas.legislation.visible?legislation(state,D):'')+(areas.kpi.visible?strategy(state,D):'');
    return '<article class="mp-report mp-'+S.monthlyTools.layout(state)+'" dir="rtl"><section class="mp-summary">'+header(state)+'<div class="mp-portfolios'+(!projects||!executive?' mp-single':'')+'">'+(executive?'<div><h2 class="mp-portfolio-heading">محافظ المتابعة التنفيذية</h2>'+executive+'</div>':'')+(projects?'<div><h2 class="mp-portfolio-heading">محفظة المشاريع</h2>'+projects+'</div>':'')+'</div>'+(projects||executive?'':note('لا توجد بيانات ضمن النطاق المحدد.'))+historyQuality(D)+'</section>'+followups(state,D)+footer(state)+'</article>';
  }
  S.monthlyPrint={render:render};
})(window.Saytara=window.Saytara||{});
