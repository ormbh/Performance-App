/* تقرير الأداء والتنفيذ · presentation aligned with Bank_Statement_2026_HTML / تقرير الأداء والتنفيذ. */
(function (S) {
  'use strict';
  var U = S.util, UI = S.ui, R = S.rules;
  /* One visible placeholder, with source zero/missing kept distinct in names. */
  function valueText(v, percent) { return U.metricText(v, percent); }
  function semanticText(v, percent) {
    if (v == null || !Number.isFinite(v)) return 'غير متاح';
    if (v === 0) return percent ? 'صفر بالمئة' : 'صفر';
    return percent ? U.fmtNum(v * 100) + '%' : U.fmtNum(v);
  }
  function valueHtml(v, percent) {
    var text = valueText(v, percent);
    if (text === '—' || text === '-') {
      var state = v == null || !Number.isFinite(v) ? 'missing' : v === 0 ? 'zero' : 'rounded-zero';
      var name = semanticText(v, percent);
      return '<span data-value-state="' + state + '" title="' + U.esc(name) + '" aria-label="' + U.esc(name) + '">' + text + '</span>';
    }
    return percent ? U.esc(text.slice(0, -1)) + '<small>%</small>' : U.esc(text);
  }
  function metricValue(D, key, value) {
    return D.available && !D.available(key) ? null : value === undefined ? D.n[key] : value;
  }
  /* Current eligible records control all scopes; history never creates a card. */
  function contribution(state, D) {
    var scope = state.dash || {}, previous = D.prev, out = {};
    var totals = { kpi:'kpiTotal', special:'specialTotal', secretariat:'secTotal', agenda:'agendaTotal', council:'councilTotal', legislation:'legTotal' };
    var records = state.data.items.filter(function(it) { return R.inScope(it, scope); });
    function eligible(it, pf) {
      if (it.pf !== pf || !(it.hasTitle === true || (it.hasTitle == null && U.key(it.title))) || !R.test(totals[pf], it)) return false;
      return true; // Registered KPIs remain visible before any results or targets are recorded.
    }
    ['kpi','special','secretariat','agenda','council','legislation'].forEach(function(pf) {
      var current = records.some(function(it) { return eligible(it, pf); });
      var keys = Object.keys(R.MET).filter(function(k) { return R.MET[k].pf === pf; });
      if (pf === 'kpi') keys.push('kpiAvg');
      if (pf === 'secretariat') keys = keys.concat(['budApproved','budAllocated','budSpent','budUnallocated']);
      var historical = D.priorData ? D.priorData.items.some(function(it) { return eligible(it, pf) && R.inScope(it, scope); }) : !!previous && keys.some(function(k) { return typeof previous[k] === 'number' && Number.isFinite(previous[k]) && previous[k] > 0; });
      out[pf] = { visible: current, current: current, historical: historical, historicalOnly: !current && historical };
    });
    out.special.groups = {};
    ['specialLead','specialGs'].forEach(function(metric) {
      out.special.groups[metric] = records.some(function(it) { return eligible(it, 'special') && R.test(metric, it); });
    });
    out.secretariat.budget = records.some(function(it) {
      return eligible(it, 'secretariat') && ['secRevised','secCommitted','secSpent','secNonCommitted'].some(function(metric) { return R.test(metric, it); });
    });
    return out;
  }
  function historyNote(area, pf) {
    return area && area.historicalOnly ? '<p class="wb-history-only">لا توجد ' + S.terms.words(pf).plural + ' حالية؛ تتوافر بيانات للفترة السابقة.</p>' : '';
  }
  function drill(metric) { var pf=(R.MET[metric]||{}).pf; return ' data-act="drill" data-metric="' + metric + '" aria-description="يفتح ' + S.terms.words(pf).definitePlural + ' المطابقة في علامة تبويب جديدة"'; }
  function delta(D, key, tone) {
    if (!key) return '';
    var c = D.change(key), info = D.comparison || {};
    // No change is blank; unavailable history keeps its distinct display below.
    if (c.state === 'same') return '';
    var source = info.source === 'workbook' ? 'مقارنة بالفترة السابقة (' + info.previousDate + ')' : 'مقارنة ببيانات الشهر السابق المحفوظة داخل الملف';
    var metric = (R.MET[key] || (S.comparison && S.comparison.insights && S.comparison.insights.descriptor(key)) || {}).label || key;
    var attr = ' data-comparison-metric="' + U.esc(key) + '" data-change-state="' + c.state + '" data-act="compare-metric" data-metric="' + U.esc(key) + '" aria-description="يفتح تفاصيل المقارنة في علامة تبويب جديدة"';
    if (c.state === 'none') return '<span class="wb-delta wb-delta-unavailable" data-comparison-metric="' + U.esc(key) + '" data-change-state="none" title="' + U.esc(c.reason || 'لا تتوافر قيمتان قابلتان للمقارنة لهذا المقياس ضمن النطاق') + '">المقارنة غير متاحة</span>';
    var up = c.d > 0;
    // Volume, finance, average KPI results without polarity, and ambiguous overrun
    // semantics carry direction only. No source-defined amber threshold exists.
    var cl = tone === 'neutral' || key === 'kpiAvg' || key === 'legOverrun' ? 'neutral' : ((tone === 'good') === up ? 'good' : 'bad');
    var movement = up ? 'زيادة' : 'انخفاض';
    var amount = (up ? '+' : '−') + c.text;
    var unit = key === 'kpiAvg' ? ' نقطة مئوية' : /^bud/.test(key) ? ' درهم' : '';
    var label = metric + ': ' + movement + ' ' + amount + unit + '، ' + source;
    return '<button type="button" class="wb-delta ' + cl + '"' + attr + ' data-direction="' + (up ? 'up' : 'down') + '" aria-label="' + U.esc(label) + '" title="' + U.esc(source) + '"><span class="wb-delta-arrow" aria-hidden="true">' + (up ? '↑' : '↓') + '</span><bdi dir="ltr">' + amount + '</bdi><span class="wb-delta-label">' + unit.trim() + '</span>' + UI.drillCue() + '</button>';
  }
  function number(D, key, label, tone, compare, value, accessibleLabel) {
    var n=metricValue(D,key,value),tip={title:accessibleLabel||label,def:R.MET[key]?R.MET[key].def:'',now:semanticText(n)};
    return '<div class="wb-stat '+(tone||'')+'"><button type="button" class="wb-stat-main"'+drill(key)+UI.tip(tip)+' aria-label="'+U.esc(accessibleLabel||label)+': '+U.esc(semanticText(n))+'"><span class="wb-stat-label">'+label+'</span><strong>'+valueHtml(n)+UI.drillCue()+'</strong></button>'+delta(D,compare===false?null:compare||key,tone==='good'?'good':tone==='bad'?'bad':'neutral')+'</div>';
  }
  function heading(state,D,title,metric,total,area,id,totalCompare){total=metricValue(D,metric,total);return '<header class="wb-card-head"><div><h3'+(id?' id="'+U.esc(id)+'"':'')+'><button type="button"'+drill(metric)+'>'+title+UI.drillCue()+'</button></h3><button class="cmp-card-link" data-act="compare-metric" data-metric="'+metric+'" aria-label="'+U.esc('تفاصيل مقارنة '+title)+'" aria-description="يفتح تفاصيل المقارنة في علامة تبويب جديدة">تفاصيل المقارنة '+UI.drillCue()+'</button></div><div class="wb-total"><button type="button" class="wb-total-main"'+drill(metric)+' aria-label="'+U.esc(title+' · المجموع '+semanticText(total))+'"><span>المجموع</span><strong>'+valueHtml(total)+UI.drillCue()+'</strong></button>'+(totalCompare===false?'':delta(D,metric,'neutral'))+'</div></header>'+historyNote(area,(R.MET[metric]||{}).pf)+S.monthlyRag.render(state,D,(R.MET[metric]||{}).pf);}
  function metrics(D, arr) {
    /* A shared display order keeps matching status columns in the same RTL
     * positions. Source status labels, counts and drill definitions stay intact. */
    function rank(k) {
      if (/Late$/.test(k)) return 0;
      if (/Done$/.test(k)) return 1;
      if (k === 'agendaReady') return 2;
      if (/Progress$/.test(k) || k === 'secActive') return 3;
      return 4;
    }
    arr=arr.slice().sort(function(a,b){return rank(a[0])-rank(b[0]);});
    return '<div class="wb-stats" style="--cols:' + arr.length + '">' + arr.map(function(a){return number(D,a[0],a[1],a[2],a[3]);}).join('') + '</div>'; }
  function kpis(state,D, area) {
    var k = D.kpi, measured=metricValue(D,'kpiMeasured',k.measured), total=metricValue(D,'kpiTotal',k.total), avgResult=metricValue(D,'kpiAvg',k.avgResult), avgTarget=metricValue(D,'kpiTargeted',k.avgTarget);
    function tile(label, value, metric, note, change, accessibleLabel) {
      return '<div class="wb-stat wb-strategy-metric"><button type="button" class="wb-stat-main"' + drill(metric) + ' aria-label="' + U.esc(accessibleLabel || label) + '"><span class="wb-stat-label">' + label + '</span><strong>' + value + UI.drillCue() + '</strong></button>' + ((note || change) ? '<div class="wb-kpi-note">' + (note ? '<span>' + note + '</span>' : '') + (change || '') + '</div>' : '') + '</div>';
    }
    var pct = function(v) { return valueHtml(v, true); };
    var breakdown = k.explicitState ? '<p class="wb-measurement-breakdown">' +
      [['notMeasured','غير مقاس'],['notApplicable','لا ينطبق'],['unavailable','النتيجة غير متاحة'],['unknown','حالة غير معتمدة'],['conflict','تعارض']].map(function(x) {
        return U.esc(x[1]) + ': ' + U.metricText(k[x[0]]);
      }).join(' · ') + '</p>' : '';
    return '<article class="wb-card wb-strategy" aria-labelledby="strategy-heading">' + heading(state,D,'استراتيجية الأمانة العامة','kpiTotal',k.total,area,'strategy-heading',D.change('kpiTotal').state!=='none') + '<div class="wb-strategy-metrics">' +
      tile('المؤشرات المقاسة / الإجمالي', '<bdi dir="ltr">' + valueHtml(measured) + '<span class="wb-strategy-denominator"> / ' + valueHtml(total) + '</span></bdi>', 'kpiTotal', '', delta(D,'kpiMeasured','good'), 'المؤشرات المقاسة: '+semanticText(measured)+'، الإجمالي: '+semanticText(total)) +
      tile('متوسط النتائج المقاسة', pct(avgResult), 'kpiMeasured', avgResult == null ? 'لم تُقَس بعد' : '', delta(D,'kpiAvg','good'), 'متوسط النتائج المقاسة: '+semanticText(avgResult,true)) +
      tile('متوسط المستهدفات المعتمدة', pct(avgTarget), 'kpiTargeted', avgTarget == null ? 'لا توجد مستهدفات مسجلة' : '', '', 'متوسط المستهدفات المعتمدة: '+semanticText(avgTarget,true)) + '</div>' + breakdown + '</article>';
  }
  function special(state,D, area) {
    var groups = [['specialLead','للقيادة','specialLeadProgress','specialLeadDone','specialLeadLate'],['specialGs','للأمانة العامة','specialGsProgress','specialGsDone','specialGsLate']];
    return '<article class="wb-card wb-special">' + heading(state,D,'المشاريع الخاصة','specialTotal',D.cur.specialTotal, area) + groups.filter(function(g){ return area.groups[g[0]]; }).map(function(g){
      return '<section class="wb-subgroup"><h4><button type="button"' + drill(g[0]) + '>' + g[1] + '<span>' + valueHtml(metricValue(D,g[0])) + UI.drillCue() + '</span></button>' + delta(D,g[0],'neutral') + '</h4>' + metrics(D,[[g[2],'قيد العمل'],[g[3],'منجز','good',g[3]],[g[4],'متأخر','bad',g[4]]]) + '</section>';
    }).join('') + (D.n.specialNoRequester ? '<button class="wb-alert" type="button"' + drill('specialNoRequester') + '>مشاريع غير مصنفة: ' + valueHtml(metricValue(D,'specialNoRequester')) + UI.drillCue() + '</button>' : '') + '</article>';
  }
  function secretariat(state,D,area) {
    var b=D.budget, approved=metricValue(D,'budApproved',b.approved);
    var cash=[['المخصص',b.allocated,'budAllocated','','secCommitted'],['المنفق حسب الفواتير',b.spent,'budSpent','good','secSpent'],['غير المخصص',b.unallocated,'budUnallocated','bad','secNonCommitted']];
    return '<article class="wb-card wb-secretariat">' + heading(state,D,'مشاريع بموازنة استراتيجية','secTotal',D.cur.secTotal,area) +
      metrics(D,[['secActive','قيد العمل'],['secHeld','ملغى/معلق'],['secDone','منجز','good','secDone'],['secLate','متأخر','bad','secLate']]) +
      '<section class="wb-quarter-section"><div class="wb-section-caption">توزيع المشاريع حسب ربع موعد الانتهاء <span>' + state.data.year + '</span></div><div class="wb-quarters wb-quarter-boxes">' +
      [1,2,3,4].map(function(q){return number(D,'secQ'+q,'ربع '+q);}).join('') + '</div>' +
      S.monthlyCoverage.render(state,D,false) +
      (D.n.secNoQuarter ? '<button class="wb-outside" type="button"' + drill('secNoQuarter') + '>خارج أرباع سنة التقرير أو بدون تاريخ: ' + valueHtml(metricValue(D,'secNoQuarter')) + UI.drillCue() + '</button>' : '') + '</section>' +
      (area.budget ? '<section class="wb-budget wb-budget-ledger" aria-labelledby="monthly-budget-heading"><div class="wb-section-caption"><div class="wb-budget-title"><h4 id="monthly-budget-heading">الموازنة</h4><small>(درهم إماراتي)</small></div><div class="wb-budget-total wb-total" data-money="budApproved"><button type="button" class="wb-total-main"'+drill('secRevised')+' aria-label="'+U.esc('الموازنة المعتمدة: '+semanticText(approved)+' درهم إماراتي')+'"><span>الموازنة المعتمدة</span><strong dir="ltr">'+valueHtml(approved)+UI.drillCue()+'</strong></button>'+delta(D,'budApproved','neutral')+'</div></div><div class="wb-budget-grid">' + cash.map(function(c){
        var amount=metricValue(D,c[2],c[1]);
        return '<div class="wb-money '+c[3]+'"><button type="button" class="wb-money-main"'+drill(c[4])+' aria-label="'+U.esc(c[0]+': '+semanticText(amount)+' درهم إماراتي')+'"><span>'+c[0]+'</span><strong dir="ltr">'+valueHtml(amount)+UI.drillCue()+'</strong></button>'+delta(D,c[2],'neutral')+'</div>';
      }).join('') + '</div></section>' : '') + '</article>';
  }
  function agenda(state,D,area) {
    var planned=metricValue(D,'agendaPlanned'), emerging=metricValue(D,'agendaEmerging');
    return '<article class="wb-card">' + heading(state,D,'الأجندة السنوية','agendaTotal',D.cur.agendaTotal,area) +
      '<div class="wb-agenda-types"><div class="wb-agenda-type"><button type="button" class="wb-agenda-type-main"'+drill('agendaPlanned')+'><span>الأجندة المعتمدة</span><b>'+valueHtml(planned)+UI.drillCue()+'</b></button>'+delta(D,'agendaPlanned','neutral')+'</div><div class="wb-agenda-type"><button type="button" class="wb-agenda-type-main"'+drill('agendaEmerging')+'><span>مستجدات الأجندة</span><b>'+valueHtml(emerging)+UI.drillCue()+'</b></button>'+delta(D,'agendaEmerging','neutral')+'</div></div>' +
      metrics(D,[['agendaProgress','قيد العمل'],['agendaReady','جاهز للعرض'],['agendaDone','منجز','good','agendaDone'],['agendaLate','متأخر','bad','agendaLate']]) + '</article>';
  }
  function council(state,D,area) {
    return '<article class="wb-card wb-council">' + heading(state,D,'قرارات المجالس','councilTotal',D.cur.councilTotal,area) +
      metrics(D,[['councilProgress','قيد العمل'],['councilDone','منجز','good','councilDone'],['councilLate','متأخر','bad','councilLate']]) +
      '<div class="wb-council-footer">' + (D.n.councilNoStatus ? '<button class="wb-outside" type="button"'+drill('councilNoStatus')+'>بدون حالة معتمدة: '+valueHtml(metricValue(D,'councilNoStatus'))+UI.drillCue()+'</button>' : '') +
      '<p class="wb-population-note">القرارات التي تتطلب متابعة</p></div></article>';
  }
  function legislation(state,D,area) {
    return '<article class="wb-card wb-legislation">' + heading(state,D,'التشريعات','legTotal',D.cur.legTotal,area) +
      '<div class="wb-legislation-stats"><h4 class="wb-legislation-completed" id="legislation-completed-heading">منجز</h4>' + number(D,'legLate','متأخر','bad','legLate',undefined,'متأخر عن الموعد') +
      number(D,'legOnTime','على الموعد','good','legOnTime',undefined,'ضمن الموعد بحسب المؤشر') +
      number(D,'legOverrun','تجاوز الموعد','good','legOverrun',undefined,'منجز تجاوز الموعد بحسب التواريخ') +
      number(D,'legProgress','قيد العمل') + '</div><p class="wb-deadline-definition" title="وفق معادلة القالب، يُقارن الإنجاز الفعلي بكل موعد متاح، ويُحتسب التجاوز إذا كان بعد أحدها؛ التمديد لا يلغي المواعيد الأخرى.">تجاوز الموعد: تاريخ الإنجاز الفعلي بعد أحد مواعيد SLC أو التمديد أو إدارة التشريعات.</p></article>';
  }
  var FU_ORDER = { 'متأخر': 0, 'معلق': 1, 'ملغى': 2, 'منقول': 3 };
  function followSection(state, D) {
    var list = D.follow.slice().sort(function(a,b){return S.order.items(state.data,a.it,b.it)||S.order.status(state.data,a.status,b.status,a.it.pf===b.it.pf?a.it.pf:null);});
    var head = '<header class="fu-visible-heading"><h2>بنود المتابعة <span>(' + valueHtml(list.length) + ')</span></h2></header>';
    var all = list.length ? '<button type="button" class="more fu-all" data-act="follow-items" aria-label="عرض جميع بنود المتابعة: ' + U.fmtN(list.length) + '">عرض جميع البنود' + UI.drillCue() + '</button>' : '';
    if (!list.length) return '<section class="fu">' + head + '<div class="fu-disclosure-body fu-empty">لا توجد بنود تتطلب المتابعة</div></section>';
    var rows = list.map(function (x) {
      var it = x.it;
      var pf = U.tableCellText(UI.pfName(it.pf)), title = U.tableCellText(it.title), status = U.tableCellText(x.status);
      var unit = U.tableCellText(it.unit), sector = U.tableCellText(it.sector);
      var stItem = { statusLabel: status, statusCat: R.catOf(status) };
      var note = U.tableCellText(x.note);
      return '<tr tabindex="0" data-act="open" data-key="' + U.esc(it.key) + '">' +
        '<td class="nowrap muted">' + U.esc(pf) + '</td>' +
        '<td class="fu-title" data-label="' + U.esc(UI.contentLabel(it)) + '" data-content-label="' + U.esc(UI.contentLabel(it)) + '">' + (title ? '<span dir="' + U.esc(it.dir || 'auto') + '" title="' + U.esc(title) + '">' + U.esc(title) + '</span>' : '') + '</td>' +
        '<td class="nowrap">' + (status ? UI.statusChip(stItem) : '') + '</td>' +
        '<td class="fu-unit">' + (unit ? '<span dir="auto">' + U.esc(unit) + '</span>' : '') + (sector ? '<small dir="auto">' + U.esc(sector) + '</small>' : '') + '</td>' +
        '<td class="fu-note">' + (note ? '<div class="fu-note-in"><span dir="auto">' + U.esc(note) + '</span></div>' : '') + '</td></tr>';
    }).join('');
    return '<section class="fu fu-visible" aria-label="بنود المتابعة">' + head + '<div class="fu-disclosure-body">' +
      '<div class="table-wrap fu-table" role="region" tabindex="0" aria-label="جدول البنود التي تستدعي المتابعة"><table class="ftable"><thead><tr><th>المحفظة</th><th>' + U.esc(UI.contentHeader(list.map(function(x){return x.it;}))) + '</th><th>مستوى الإنجاز</th><th>الوحدة التنظيمية / القطاع</th><th>الملاحظات</th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
      '</div>' + all + '</section>';
  }

  /* ---------- filters ---------- */
  function uniq(a) { var s = new Set(); return a.filter(function(x){var k=String(x);if(s.has(k))return false;s.add(k);return true;}); }

  function filterBar(state, D, controlsOnly, extra) {
    var d = state.data, f = state.dash;
    // Report options come from this report's concerned entity, never contributors
    // or another portfolio. Reuse the existing exact multi-select scope.
    var reportPf = state.screen === 'reports' ? (state.report.kind === 'hh' ? 'special' : state.report.kind === 'agenda' ? 'agenda' : state.report.kind === 'council' ? 'council' : '') : '';
    var prior=D.priorData, snapshots=D.comparison.source==='embedded' ? (d.snapshot&&d.snapshot.rows||[]) : [];
    var records=d.items.concat(prior?prior.items:[],snapshots), units=(d.lovs.lists.Departments||[]).concat(prior&&prior.lovs?prior.lovs.lists.Departments||[]:[]);
    var sectors = S.order.sort(d,uniq((d.lovs.lists.Sectors || []).concat(prior&&prior.lovs?prior.lovs.lists.Sectors||[]:[],records.map(function(it){return it.sector||'';}))),'Sectors');
    var unitOpts = S.order.sort(d,uniq(units.filter(function(p){return S.filterOptions.selected(p.parent,f.sector,'sector');}).map(function(p){return p.value;}).concat(records.filter(function(it){return S.filterOptions.selected(it.sector,f.sector,'sector');}).map(function(it){return it.unit||'';}))),'Departments');
    var entityRows = reportPf ? d.byPf[reportPf].filter(function(it){return it.hasTitle;}) : d.items.concat(prior ? prior.items : []);
    var entityOpts = S.order.sort(d,uniq(entityRows.filter(function(it){return R.concernedEntity(it) !== null && R.inScope(it,{sector:f.sector,unit:f.unit});}).map(function(it){return R.concernedEntity(it);})),'Entities');
    var chips = ['sector','unit','entity'].map(function(k){return S.filterOptions.selectionGroups(f[k],(state.multiOptions||{})['d:'+k],'d:'+k).map(function(o){return '<span class="fchip">'+(k==='sector'?'القطاع':k==='unit'?'الوحدة التنظيمية':'الجهة المعنية')+': <span dir="auto">'+U.esc(o.label)+'</span><button type="button" data-act="multi-remove" data-multi="d:'+k+'" data-v="'+U.esc(o.v)+'" aria-label="إزالة '+U.esc(o.label)+'">'+U.icon('x',13)+'</button></span>';}).join('');}).join('');
    return '<div class="dfilters">' + UI.multiSelect(state,'d:sector','القطاع',f.sector,sectors) + UI.multiSelect(state,'d:unit','الوحدة التنظيمية',f.unit,unitOpts) + (state.screen === 'reports' && !reportPf ? '' : UI.multiSelect(state,'d:entity','الجهة المعنية',f.entity,entityOpts)) +
      (!reportPf && U.hasSelection(f.entity) ? '<button type="button" class="icon-btn entity-scope-info" aria-label="التشريعات لا تتوفر حسب الجهة المعنية" title="التشريعات لا تتوفر حسب الجهة المعنية"'+UI.tip({title:'الجهة المعنية',def:'التشريعات لا تتوفر حسب الجهة المعنية.'})+'>'+U.icon('info',16)+'</button>' : '') +
      (extra || '') + chips + '</div>' +
      (controlsOnly ? '' : filterNote(state,D));
  }


  function missingHistoryNote(state,D) {
    if (state.data.snapshot && state.data.snapshot.issue) return U.esc(state.data.snapshot.issue);
    if (!state.data.snapshot || !state.data.snapshot.found || !state.data.snapshot.hasData) return 'لا توجد قيم للشهر السابق محفوظة في الملف. تظهر الزيادة والانخفاض عند توفرها أو عند اختيار نسخة سابقة للمقارنة.';
    return 'لا تتوافر قيم سابقة مكتملة للمقارنة ضمن النطاق المحدد.';
  }
  function filterNote(state,D) {
    // Ordinary comparison details live on each metric and in its drilldown.
    // Keep only a material data-availability issue visible here.
    var info=D.comparison||{};
    return info.source==='unavailable'&&info.reason ? '<div class="dnote">'+U.icon('info',16)+'المقارنة غير متاحة</div>' : '';
  }

  function filterSummary(state) { return [['sector','القطاع'],['unit','الوحدة التنظيمية'],['entity','الجهة المعنية']].filter(function(f){return U.hasSelection(state.dash[f[0]]);}).map(function(f){var selected=S.filterOptions.selectionGroups(state.dash[f[0]],(state.multiOptions||{})['d:'+f[0]],'d:'+f[0]);return f[1]+': '+selected.slice(0,2).map(function(o){return o.label;}).join('، ')+(selected.length>2?' +'+(selected.length-2):'');}).join(' · ') || 'جميع القطاعات والوحدات والجهات'; }

  function render(state) {
    UI.resetTips();
    state.dash.entityMode = 'concerned';
    var d=state.data, history=S.comparison&&S.comparison.dashboardHistory ? S.comparison.dashboardHistory(state) : null, D=R.dashboard(d,state.dash,history);
    D.available=function(key){return R.metricAvailable(d,key,D.scope);};
    state.lastDash=D;
    var areas=contribution(state,D), projectCards=(areas.special.visible ? special(state,D,areas.special) : '')+(areas.secretariat.visible ? secretariat(state,D,areas.secretariat) : '');
    var followCards=(areas.agenda.visible ? agenda(state,D,areas.agenda) : '')+(areas.council.visible ? council(state,D,areas.council) : '')+(areas.legislation.visible ? legislation(state,D,areas.legislation) : '')+(areas.kpi.visible ? kpis(state,D,areas.kpi) : '');
    var portfolios=(projectCards || followCards) ? '<div class="portfolios'+(!projectCards || !followCards ? ' portfolios-single' : '')+'">'+(followCards ? '<section class="pcol"><h2 class="pcol-h">محافظ المتابعة التنفيذية</h2>'+followCards+'</section>' : '')+(projectCards ? '<section class="pcol"><h2 class="pcol-h">محفظة المشاريع</h2>'+projectCards+'</section>' : '')+'</div>' : '';
    var noContribution=!Object.keys(areas).some(function(pf){return areas[pf].visible;});
    var issues=d.issues.filter(function(x){return x.sev!=='info';}).length;
    return '<div class="screen dash workbook-report" data-screen="dashboard">' +
      UI.appHeader(state,'dashboard') +
      '<main class="dwrap"><section class="wb-report-heading app-page-heading"><div><h1>التقرير الشهري للأداء والتنفيذ</h1></div><div class="monthly-print-control"><button type="button" class="btn btn-primary monthly-print-action" data-act="print">' + U.icon('print',18) + 'طباعة التقرير</button><button type="button" class="btn monthly-settings-trigger" data-act="monthly-settings" aria-haspopup="dialog" aria-controls="monthly-report-settings" aria-expanded="' + !!(state.monthly&&state.monthly.settingsOpen) + '">إعدادات الطباعة' + U.icon('down',16) + '</button></div></section>' +
      UI.filterPanel(state,{id:'dashboard',resetAction:'reset-dashboard-filters',title:'تصفية التقرير الشهري',body:filterBar(state,D,true),summary:filterSummary(state),activeCount:['sector','unit','entity'].filter(function(k){return U.hasSelection(state.dash[k]);}).length}) + filterNote(state,D) +
      (!d.items.length ? '<div class="wb-empty-notice">'+U.icon('info',18)+'القالب غير معبأ. اختر ملف بيانات لعرض التقرير.</div>' : '') +
      (noContribution ? '<div class="wb-empty-notice">'+U.icon('info',18)+'لا توجد مساهمات مسجلة ضمن النطاق المحدد.</div>' : '') +
      portfolios + followSection(state,D) +
      ((D.historyIssues || []).length ? '<details class="wb-history-quality app-help"><summary>مراجعة بيانات المقارنة المحفوظة</summary>' + D.historyIssues.map(function(x){return '<p>' + U.esc(x.reason) + '</p>';}).join('') + '</details>' : '') +
      '</main><div id="monthly-print-root">'+S.monthlyPrint.render(state,D)+'</div></div>';
  }
  S.views.dashboard={render:render,filterBar:filterBar,filterNote:filterNote,delta:delta,contribution:contribution,valueHtml:valueHtml,valueText:valueText,semanticText:semanticText};
})(window.Saytara=window.Saytara||{});
