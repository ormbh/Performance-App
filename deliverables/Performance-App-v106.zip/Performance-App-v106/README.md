# Performance App v106

Extract the complete ZIP, then open `index.html` in your browser. All fonts,
images and scripts are local; no server or installation is required by the app.
Imported data is processed on your device.

## Report workspace

Primary navigation is separate from page tools. A compact scope toolbar shows
active selections even when the filters are closed. Open **تصفية** to select
multiple values and search the option list. Values within one filter form a union;
different filters intersect. **مسح التصفية** resets the scope. Empty selection
means all values. Blank source values remain distinct and available for selection.
Filter popups have one scrollable options list. The title, search field and
select-all/clear controls remain visible. Short screens use the available viewport
instead of clipping these controls; focused filters stay open when it shrinks.

Monthly report content appears first: executive portfolios on the right and
projects on the left, matching the RTL source mold. Strategy, decisions and
legislation use the same metric typography. Data tables are displayed as sections
rather than closed disclosures; long tables and full notes remain readable.

**طباعة التقرير** prints the currently filtered report directly. The adjacent
**إعدادات الطباعة** opens a native dialog without scrolling away from the filters.
Calculation-date and A4/A3 changes apply immediately; **حفظ الإعدادات** closes the
dialog and returns focus to the same print button. The file name, selected
calculation date and source reference (when different) appear at the screen footer.
Monthly printed pages repeat the full source file name and selected calculation
date in the footer, with the existing organizational wording and copyright.
Source/reporting/history dates retain separate meanings. Help and source-quality
explanations can still collapse.

No demonstration records, demonstration-file fingerprint, data-purpose selector
or automatic sample classification are included. Retired purpose metadata and
explicitly marked sample caches are cleared during upgrade. Files you import
normally retain the existing local-session behavior. The browser can keep the
imported file in session storage for reload/new-tab workflows; nothing is sent to
an external service. Source files and full notes remain unchanged.

## Measurement and comparison definitions

Annual KPI zeros count as measured only with an explicit measurement-state field:
`حالة القياس`, `Measurement State` or `Measurement Status`. Supported values:
`مقاس`/`Measured`, `غير مقاس`/`Unmeasured`, `لا ينطبق`/`Not applicable`.
Absent or blank state retains the existing nonzero measurement rule. Invalid,
missing, not-applicable and conflicting states are distinguished. Incompatible
measurement definitions withhold comparisons and show the reason. Result and
target averages use their separate source populations; thresholds and weighting
are not invented. Recorded zero is displayed as0; unavailable values as an em dash;
unchanged comparison indicators stay blank.

The application reads cached Excel formula results. It does not recalculate all
Excel formulas or refresh Power Query. Named tables and valid renamed sheets are
supported. Ambiguous identifiers are retained for review and excluded from
resolved historical matches rather than merged by title or row number.

## Upgrade and verification

Keep the prior app and browser data until you have checked your notes/settings.
Use the same browser/profile and location where possible. Full note text and
existing storage keys are preserved. File-origin storage behavior varies between
browsers; back up notes before moving folders or changing profiles.

Browser execution over local HTTP, responsive RTL layouts, keyboard interactions,
scoped imports/filters/CSV and generated monthly PDFs were tested in the delivery
review. Default detailed-report titles have no fixed sample year; the displayed period
defaults to the selected calculation cutoff. User-entered titles/periods are preserved.
Native file-opening is blocked by the managed test browser, so Windows
Edge double-click startup, Microsoft PowerPoint interactive editing, physical
printing and full screen-reader certification remain not run. This is not a claim
of unconditional production readiness.

Readable source modules are bundled locally by `python tools/build-bundles.py`.
`python tools/build-bundles.py --check` checks bundle consistency.
