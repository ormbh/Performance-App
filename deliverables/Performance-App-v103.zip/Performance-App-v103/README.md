# Performance Reporting App v103

Extract the entire ZIP and open `index.html` in Chrome or Edge, keeping `assets` beside it. Import `.xlsx` or `.xlsm`. The application remains an offline HTML reporting tool: no backend, account, tracking or imported-data transmission. Imported workbooks and macros are not modified or executed.

## Changes verified in this release

- Entity lists are mapped by unique column headings. The supplied mold has sector and entity columns; v102 incorrectly read sector values as entities. v103 reads all 52 actual entities and removes 306 false validation warnings without changing portfolio figures.
- Known test data is identified by the supplied workbook's SHA-256 fingerprint, regardless of its filename. A persistent Arabic sample-data label appears on screens, monthly PDFs and editable PowerPoint exports. Other files are unclassified until the user selects their local source purpose; a filename alone never proves sample or production status. This classification does not certify source quality.
- Actual metric zero displays as `0` or `0%`; unavailable values display as `—`. Blank source-table cells stay blank. Unchanged comparison indicators stay empty.
- An optional annual KPI measurement-state column identifies genuine measured zero. Existing molds without it preserve their definitions and averages. Incompatible measurement populations do not produce historical measurement comparisons.
- Data review separates unread sources from imported data with errors, uses native selectable sheet buttons, and combines sheet and severity filters with scoped counts. The review CSV exports complete note text for the selected sheet and severity; clear these filters to export all notes.
- Search suggestions expose their expanded state and return focus to search on Escape. The approved bilingual title remains **البحث في الأداء / Performance Search**.
- Monthly continuation headings have safe top spacing. Complete source notes, report columns and editable notes appendices remain. The monthly print report has no logo. The space beside the screen TEC logo remains empty.
- Agenda PowerPoint executive summaries use explicit editable line breaks to prevent text overflow in the tested renderer. Sample provenance is native text in the unused top strip of every exported slide.

## Explicit measurement-state contract

An optional single column named **حالة القياس**, **Measurement State**, or **Measurement Status** may be added by the source owner to the KPI table. This release does not rewrite the supplied mold or add that column automatically.

| Source value | Interpretation |
|---|---|
| مقاس / Measured | A finite numeric annual result, including 0, is measured. A missing/non-numeric result is unavailable and flagged. |
| غير مقاس / Unmeasured | Excluded from measured results. A nonzero recorded result creates a visible source conflict. |
| لا ينطبق / Not applicable | Excluded and identified separately. A nonzero recorded result creates a visible source conflict. |
| Blank / absent column | Legacy mold rule: numeric nonzero annual results are measured; recorded zero alone does not establish measurement. |
| Unknown value / ambiguous headings | Quarantined from measured statistics and flagged; never guessed. |

These are application input values, not a claim of institutional policy. The independent nonzero target-average population is unchanged. Explicit-state breakdowns distinguish unmeasured, not applicable, unavailable, unknown and conflicting records. Embedded history lacks measurement-state information and cannot certify a compatible explicit-state comparison; uploaded files must have compatible, resolved contracts.

## Dates, scope and data quality

The selected calculation date continues to drive the existing timing rules. Saved source reference, report label, snapshot dates and file-modification date remain separate. The supplied test mold uses 30 September 2026 as its fixed reference. Saved Excel formula results are read; arbitrary formulas, Power Query and macros are not refreshed.

Multi-select means union within a field and intersection between fields. Search paging never limits full-scope print or CSV. Dashboard drilldowns carry the selected scope. All source records, blank departments, unresolved classifications and complete meaningful notes are preserved. Exact unique identifiers are used for matching; duplicates/ambiguous records remain for review. Missing history never becomes zero.

The six monthly indicators retain the source mold's rules. No new amber thresholds or unrelated proportional bars were introduced. Strategy still compares the separate result and target averages; unavailable averages do not create a performance flag.

The sample workbook contains blank departments, duplicate decision identities, date/year conflicts and incomplete saved historical status coverage. Review the remaining source warnings before reporting organizational performance. The app does not repair those source facts or treat the sample as real performance.

## Printing and PowerPoint

Use the monthly A4/A3 landscape controls, 100% print scale, background graphics and browser headers/footers disabled. One or two monthly summary pages is a preference where content fits; long details continue without dropping notes. Short tables share pages and long tables repeat headers. PowerPoint uses editable text, tables and native charts with embedded workbooks rather than flattened slide images.

Current test evidence is in the separate v103 audit pack and `qa/QA-v103.md`. Local HTTP browser execution and generated PDF inspection were tested. Managed Chromium blocks direct `file://` navigation, so actual extract-and-double-click startup in Windows/Edge remains not run here. Windows PowerPoint interactive editing, physical printing and full screen-reader testing also require the target equipment. Do not treat native-object inspection or LibreOffice rendering as Windows acceptance.

## Upgrade safely

Keep the old app and browser data until notes/settings are checked. Use the same browser/profile and location where possible. Do not clear storage during upgrade. Full source-specific annotations retain existing storage keys; a same-origin baseline-to-v103 regression preserved a long Arabic note. Local-file storage behaviour varies by browser and location. The app continues to show storage failure warnings; export/copy notes before changing browser profiles or moving folders.

## Development

Edit readable modules, then run:

```sh
python3 tools/build-bundles.py
python3 tools/build-bundles.py --check
python3 -m http.server 8000 --bind 127.0.0.1
```

The server is for development validation; it is not an end-user requirement. Bundled assets use their original execution/cascade order and local asset paths. No repository/site publication was performed. Source originals are supplied separately and are not bundled into the application ZIP.
