/* Source purpose is local metadata, never an approval or a performance value.
 * Recognize the supplied test mold by its bytes, not by its filename. */
(function (S) {
  'use strict';
  var U = S.util;
  var MOLD = 'da0d7331f460a8e4b29ef368912c52cc6d4cbab42d696da42eb3507c327a563b';
  var PURPOSES = ['unknown', 'sample', 'operational'];
  function knownSample(data) { return !!data && data.fingerprint === MOLD; }
  function storageKey(data) { return data && data.fingerprint ? 'performance.source-purpose.v1:' + data.fingerprint : ''; }
  function purpose(data) {
    if (!data) return 'unknown';
    if (knownSample(data)) return 'sample';
    if (PURPOSES.indexOf(data.sourcePurpose) >= 0) return data.sourcePurpose;
    var key = storageKey(data), saved = key && U.store.get('localStorage', key);
    return PURPOSES.indexOf(saved) >= 0 ? saved : 'unknown';
  }
  function isSample(data) { return purpose(data) === 'sample'; }
  function reportText(data) {
    var p = purpose(data);
    return p === 'sample' ? 'بيانات تجريبية — لا تمثل الأداء الفعلي للجهات' :
      p === 'operational' ? 'بيانات تشغيلية — تصنيف المستخدم' : 'نوع البيانات غير محدد';
  }
  function set(state, value) {
    var data = state.data;
    if (!data || knownSample(data) || PURPOSES.indexOf(value) < 0) return;
    data.sourcePurpose = value;
    var key = storageKey(data), ok = !!key && U.store.set('localStorage', key, value);
    U.persistence(state, 'source-purpose', ok ? '' : 'نوع البيانات محفوظ لهذه الجلسة فقط؛ أعد تحديده بعد فتح الملف إذا تعذّر الاحتفاظ به.');
  }
  function print(data) {
    return data ? '<p class="report-provenance' + (isSample(data) ? ' is-sample' : '') + '">' + U.esc(reportText(data)) + '</p>' : '';
  }
  function bar(state) {
    var data = state.data;
    if (!data) return '';
    var p = purpose(data), source = U.validDateSerial(data.sourceValidationDate) ? data.sourceValidationDate : data.savedReportDate;
    var changed = U.validDateSerial(source) && source !== data.today;
    var date = U.validDateSerial(source) ? 'مرجع المصدر: ' + U.fmtDate(source) : 'مرجع المصدر غير متاح';
    if (changed) date += ' · تاريخ الحساب المحدد: ' + U.fmtDate(data.today);
    var previousNote = state.previous && isSample(state.previous) ? '<span class="provenance-prior-sample">النسخة السابقة: بيانات تجريبية</span>' : '';
    var controls = knownSample(data) ? '' : '<details class="provenance-purpose-control"><summary>تحديد نوع البيانات</summary><label for="source-purpose">نوع البيانات</label><select id="source-purpose" data-act="source-purpose"' + (state.reporting ? ' disabled' : '') + '>' +
      [['unknown', 'غير محدد'], ['sample', 'بيانات تجريبية'], ['operational', 'بيانات تشغيلية']].map(function(o) { return '<option value="' + o[0] + '"' + (p === o[0] ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select></details>';
    return '<aside class="app-provenance' + (p === 'sample' ? ' is-sample' : '') + '" aria-label="سياق مصدر البيانات"><div><strong>' + U.esc(reportText(data)) + '</strong><span>' + U.esc(date) + '</span>' + previousNote + '</div>' + controls + '</aside>';
  }
  S.provenance = { purpose: purpose, isSample: isSample, knownSample: knownSample, reportText: reportText, set: set, print: print, bar: bar };
})(window.Saytara = window.Saytara || {});
