/*
 * Performance reporting · search home (S2) and the shared search box with suggestions.
 */
(function (S) {
  'use strict';

  var U = S.util, SC = S.schema, UI = S.ui;
  var PLACEHOLDER = 'ابحث بأي جزء من النص';

  function searchBox(state, size) {
    var q = state.search.q;
    return '' +
      '<div class="sbox sbox-' + size + '" id="sbox">' +
      '  <div class="sfield">' + U.icon('search', size === 'lg' ? 22 : 20, 'sfield-ic') +
      '    <input id="q" type="search" role="combobox" aria-expanded="false" aria-haspopup="listbox" dir="rtl" autocomplete="off" spellcheck="false" value="' + U.esc(q) + '" placeholder="' + PLACEHOLDER + '" aria-label="البحث في الأداء" aria-controls="sug" aria-autocomplete="list">' +
      '    <button type="button" class="sclear' + (q ? '' : ' is-hidden') + '" data-act="clear-q" aria-label="مسح">' + U.icon('x', 16) + '</button>' +
      (size === 'lg' ? '<kbd class="skbd' + (q ? ' is-hidden' : '') + '" aria-hidden="true">/</kbd>' : '') +
      '  </div>' +
      '  <div id="sug" class="sug" role="listbox" aria-label="اقتراحات" hidden></div>' +
      '</div>';
  }

  /* Suggestions while typing (two characters or a number). */
  function suggestions(state) {
    var q = state.search.q, data = state.data;
    var toks = S.search.tokens(q), joined = toks.join('');
    if (!state.sugOpen || !data || !(joined.length >= 2 || /^\d+$/.test(joined))) return '';
    var sg = S.search.suggest(data, q);
    var html = '';
    if (state.screen === 'home') {
      html += '<button type="button" class="sug-all" data-act="sug-all" role="option">' + U.icon('search', 16) +
        'عرض كل النتائج لـ «<span dir="auto">' + U.esc(q.trim()) + '</span>»<span class="sug-count">النتائج: ' + U.fmtN(sg.total) + '</span></button>';
    }
    if (sg.items.length) {
      html += '<div class="sug-h">النتائج</div>' + sg.items.map(function (h) {
        var it = h.it;
        return '<button type="button" class="sug-item" data-act="sug-item" data-key="' + U.esc(it.key) + '" role="option">' +
          '<span class="sug-title" dir="' + it.dir + '">' + S.search.highlight(it.title, sg.toks) + '</span>' +
          '<span class="sug-meta">#' + U.esc(it.ref) + ' · ' + UI.pfName(it.pf) + '</span></button>';
      }).join('');
    }
    if (sg.people.length) {
      html += '<div class="sug-h">الأشخاص</div>' + sg.people.map(function (p) {
        return '<button type="button" class="sug-person" data-act="sug-person" data-name="' + U.esc(p.name) + '" role="option">' +
          '<span dir="auto">' + S.search.highlight(p.name, sg.toks) + '</span><span class="sug-count">المنسق · النتائج: ' + U.fmtN(p.n) + '</span></button>';
      }).join('');
    }
    if (sg.pfs.length) {
      html += '<div class="sug-h">المحافظ</div>' + sg.pfs.map(function (pf) {
        return '<button type="button" class="sug-pf" data-act="sug-pf" data-pf="' + pf + '" role="option">' + UI.pfName(pf) + '</button>';
      }).join('');
    }
    if (!sg.items.length && !sg.people.length && !sg.pfs.length) {
      html += '<div class="sug-none">لا توجد اقتراحات. اضغط Enter لعرض النتائج.</div>';
    }
    return html;
  }

  function scopeChips(state) {
    return S.search.TABS.map(function (t) {
      var on = state.search.tab === t;
      return '<button type="button" class="scope-chip' + (on ? ' is-on' : '') + '" data-act="scope" data-tab="' + t + '" aria-pressed="' + on + '">' +
        (t === 'all' ? 'الكل' : UI.pfName(t)) + '</button>';
    }).join('');
  }

  function fileBar(state) {
    var d = state.data, issues = d.issues.filter(function (x) { return x.sev !== 'info'; }).length;
    return '<div class="filebar">' +
      '<button type="button" class="linkbtn" data-act="go-checks">ملاحظات البيانات: ' + U.fmtN(issues) + '</button>' +
      '<button type="button" class="linkbtn" data-act="change-file">' + U.icon('upload', 15) + 'تغيير الملف</button></div>';
  }

  function render(state) {
    var d = state.data;
    var recent = state.recent.length ?
      '<div class="recent"><span>عمليات البحث الأخيرة:</span>' + state.recent.map(function (r) {
        return '<button type="button" class="recent-q" dir="auto" data-act="recent" data-q="' + U.esc(r) + '">' + U.esc(r) + '</button>';
      }).join('') + '</div>' : '';

    return '' +
      '<div class="screen home" data-screen="home">' +
      '  <div class="mash-bg" aria-hidden="true"></div>' +
      UI.appHeader(state,'search') +
      '  <main class="home-center">' +
      '    <h1 class="wordmark performance-search-title"><span class="wm-ar" lang="ar" dir="rtl">البحث في الأداء</span><span class="wm-en" lang="en" dir="ltr">Performance Search</span></h1>' +
      
      searchBox(state, 'lg') +
      recent +
      '    <button type="button" class="btn search-browse-all" data-act="browse-all">عرض جميع النتائج</button>' +
      '  </main>' +
      '</div>';
  }

  S.views.home = { render: render, searchBox: searchBox, suggestions: suggestions, scopeChips: scopeChips, fileBar: fileBar };
})(window.Saytara = window.Saytara || {});
