/* One PMO dashboard, built from the existing scoped Projects source records.
   Counts, financial coverage and matched comparisons keep their own denominators. */
(function (S) {
  'use strict';
  var U = S.util;

  function render(state, m, h) {
    var p = m.pmo, E = h.esc, N = h.n;
    if (!p || !m.items.length) return '<div class="pw-empty"><h2>لا توجد مشاريع ضمن هذا النطاق</h2><button type="button" class="dbtn" data-act="projects-reset">إعادة ضبط عوامل التصفية</button></div>';
    function count(v) { return N(v); }
    function countName(v) { return v == null || !Number.isFinite(v) ? 'غير متاح' : v === 0 ? 'صفر' : U.fmtN(v); }
    function moneyName(v) { return v == null || !Number.isFinite(v) ? 'غير متاح' : v === 0 ? 'صفر' : U.fmtNum(v, 2); }
    function pct(v) { return v == null || !Number.isFinite(v) ? '—' : U.fmtNum(v, 1) + '%'; }
    function money(v) { return v == null || !Number.isFinite(v) ? '—' : U.fmtNum(v, 2); }
    function coverageText(f) { return 'قيم متاحة: ' + count(f.known) + ' من أصل ' + count(f.total) + (f.known < f.total ? ' · تغطية جزئية' : ''); }
    function coverageNote(f) { return f.known < f.total ? '<small>عدد المشاريع بقيم متاحة: <bdi dir="auto">' + count(f.known) + ' من أصل ' + count(f.total) + '</bdi></small>' : ''; }
    function missingLink(f) { return f.known < f.total ? h.link('غير مسجل: ' + count(f.total - f.known), 'missing', f.key, 'pmo-missing-link') : ''; }
    function cue() { return ''; }
    function opening(text) { return E(text + ' · يفتح المشاريع المطابقة في علامة تبويب جديدة'); }
    function width(v) { return Math.max(0, Math.min(100, Number(v) || 0)) + '%'; }
    function track(v, tone) { return '<span class="pmo-track' + (tone ? ' ' + tone : '') + '" aria-hidden="true"><i style="--pmo-fill:' + width(v) + '"></i></span>'; }
    function finance(rows, key) { return rows.find(function (f) { return f.key === key; }); }
    function header(title, note, action) { return '<div class="pmo-panel-head"><div><h2>' + E(title) + '</h2>' + (note ? '<p>' + E(note) + '</p>' : '') + '</div>' + (action || '') + '</div>'; }
    function disclosure(title, meta, body, cls) {
      return '<details class="pmo-disclosure ' + (cls || '') + '"><summary><h2>' + E(title) + '</h2>' + (meta ? '<span class="pmo-disclosure-meta">' + E(meta) + '</span>' : '') + U.icon('down', 18) + '</summary><div class="pmo-disclosure-body">' + body + '</div></details>';
    }
    function sourceAttr(name, value) { return value == null ? '' : ' data-' + name + '="' + E(value) + '"'; }
    function kpi(title, value, note, focus, id, key, extra) {
      return '<button type="button" class="pmo-kpi' + (key === 'revised' ? ' is-money' : '') + '"' + h.attrs(focus, id) + ' data-pmo-metric="' + key + '"' + (extra || '') + ' aria-label="' + opening(title + ': ' + (key === 'revised' ? moneyName(budget.value) : countName(key === 'overdue' ? due.n : key === 'done' ? m.done.length : p.total)) + (note ? '، ' + note : '')) + '"><span>' + E(title) + '</span><strong><bdi>' + E(value) + '</bdi></strong>' + (note ? '<small>' + E(note) + '</small>' : '') + '</button>';
    }
    var budget = finance(p.finance, 'revised'), due = p.timeline.find(function (g) { return g.key === 'overdue'; });
    var kpis = '<section class="pmo-kpis" aria-label="المؤشرات الرئيسية للمحفظة">' +
      kpi('تجاوز موعد الانتهاء', count(due.n), 'مشاريع مفتوحة', 'pmo', due.id, 'overdue', sourceAttr('count', due.n)) +
      kpi('إجمالي المشاريع', count(p.total), '', 'all', '', 'total', sourceAttr('count', p.total)) +
      kpi('منجز حسب الحالة', count(m.done.length), pct(m.done.length / p.total * 100), 'done', '', 'done', sourceAttr('count', m.done.length)) +
      kpi('الموازنة المعتمدة', money(budget.value), 'درهم' + (budget.known < budget.total ? ' · قيم متاحة: ' + count(budget.known) + ' من ' + count(budget.total) : ''), 'known', 'revised', 'revised', sourceAttr('amount', budget.value) + sourceAttr('known', budget.known)) + '</section>';

    function statusTone(g) { return g.done === g.n ? 'is-done' : ({'قيد العمل':'is-active','ملغى':'is-cancelled','معلق':'is-held','لم يبدأ':'is-not-started'}[g.key] || 'is-neutral'); }
    function statusPanel() {
      var rows = m.groups.projectStatus;
      var stack = '<div class="pmo-status-stack" aria-hidden="true">' + rows.map(function (g) { return '<span class="pmo-status-segment ' + statusTone(g) + '" style="--pmo-fill:' + width(g.n / p.total * 100) + '"></span>'; }).join('') + '</div>';
      var list = '<ul class="pmo-status-list">' + rows.map(function (g) {
        return '<li><button type="button" class="pmo-status-item ' + statusTone(g) + '"' + h.attrs('group', JSON.stringify(['projectStatus', g.key])) + ' data-pmo-group="status" data-key="' + E(g.key) + '" data-count="' + g.n + '" aria-label="' + opening(g.name + '، عدد المشاريع: ' + countName(g.n)) + '"><span class="pmo-status-dot" aria-hidden="true"></span><span class="pmo-status-label">' + E(g.name) + '</span><strong><bdi>' + count(g.n) + '</bdi>' + cue() + '</strong><small><bdi>' + pct(g.n / p.total * 100) + '</bdi></small></button></li>';
      }).join('') + '</ul>';
      return '<section class="pmo-panel pmo-status">' + header('حالة المحفظة') + stack + list + '</section>';
    }
    function deadlinesPanel() {
      var names = { overdue: 'تجاوز الموعد', next30: 'خلال 30 يوماً', later: 'موعد لاحق' };
      var horizon = p.timeline.filter(function (g) { return Object.prototype.hasOwnProperty.call(names, g.key); });
      var chips = p.timeline.filter(function (g) { return !Object.prototype.hasOwnProperty.call(names, g.key) && g.n; });
      var monthYear = p.timeline.some(function (g) { return g.monthDateKnown > 0; }) && state.data.year;
      return '<section class="pmo-panel pmo-deadlines">' + header('مواعيد المشاريع المفتوحة', 'نهاية شهر الانتهاء' + (monthYear ? ' · الأشهر دون سنة: ' + monthYear : '')) +
        '<div class="pmo-timeline">' + horizon.map(function (g) {
          return '<button type="button" class="pmo-chart-row pmo-timeline-item' + (g.key === 'overdue' ? ' is-overdue' : '') + '"' + h.attrs('pmo', g.id) + ' data-timeline="' + E(g.key) + '" data-count="' + g.n + '" aria-label="' + opening(g.label + '، عدد المشاريع: ' + countName(g.n)) + '"><span class="pmo-chart-label">' + E(names[g.key]) + '</span><strong class="pmo-chart-value"><bdi>' + count(g.n) + '</bdi>' + cue() + '</strong>' + track(g.n / p.total * 100) + '</button>';
        }).join('') + '</div>' +
        (chips.length ? '<div class="pmo-deadline-other">' + chips.map(function (g) { return '<button type="button" class="pmo-scope-chip pmo-timeline-item"' + h.attrs('pmo', g.id) + ' data-timeline="' + E(g.key) + '" data-count="' + g.n + '" aria-label="' + opening(g.label + '، عدد المشاريع: ' + countName(g.n)) + '">' + E(g.label.replace(/^مشاريع /, '')) + ' <bdi>' + count(g.n) + '</bdi>' + cue() + '</button>'; }).join('') + '</div>' : '') +
        '<details class="pmo-progress-details"><summary>نسبة الإنجاز المسجلة'+U.icon('down',18)+'</summary><div class="pmo-progress-bands">' + p.progress.map(function (g) {
          var label = g.label.replace(/^إنجاز مسجل /, '');
          return '<button type="button" class="pmo-progress-chip' + (g.n ? '' : ' is-empty') + '"' + h.attrs('pmo', g.id) + ' data-progress="' + E(g.key) + '" data-count="' + g.n + '" aria-label="' + opening(g.label + '، عدد المشاريع: ' + countName(g.n)) + '"><span>' + E(label) + '</span><strong><bdi>' + count(g.n) + '</bdi>' + cue() + '</strong></button>';
        }).join('') + '</div></details></section>';
    }
    function financialComparison(c, title) {
      if (c.known === 0) return '<article class="pmo-comparison pmo-comparison-unavailable" data-comparison="' + E(c.key) + '" data-known="0" data-total="' + c.total + '"' + sourceAttr('left-value', c.leftValue) + sourceAttr('right-value', c.rightValue) + sourceAttr('ratio', c.ratio) + sourceAttr('ratio-known', c.ratioKnown) + '><h3>' + E(title) + '</h3><p class="pmo-coverage-note">لا توجد مشاريع بقيم مالية مزدوجة مسجلة ضمن هذا النطاق.</p></article>';
      var max = Math.max(1, c.leftValue || 0, c.rightValue || 0);
      function bar(label, v, tone) { return '<span class="pmo-pair-bar ' + tone + '"><span class="pmo-chart-label">' + E(label) + '</span><strong class="pmo-chart-value"><bdi>' + E(money(v)) + '</bdi>' + cue() + '</strong>' + track(v == null ? 0 : v / max * 100) + '</span>'; }
      var ratio = c.ratio == null ? '<p class="pmo-coverage-note">النسبة غير متاحة</p>' : '<div class="pmo-ratio">' + h.link(pct(c.ratio), 'pmo', c.ratioId) + '<span>' + E(c.rightLabel + ' / ' + c.leftLabel) + '</span><small>مشاريع مؤهلة للنسبة: <bdi dir="ltr">' + count(c.ratioKnown) + ' / ' + count(c.ratioTotal) + '</bdi></small></div>';
      return '<article class="pmo-comparison" data-comparison="' + E(c.key) + '" data-known="' + c.known + '" data-total="' + c.total + '"' + sourceAttr('left-value', c.leftValue) + sourceAttr('right-value', c.rightValue) + sourceAttr('ratio', c.ratio) + sourceAttr('ratio-known', c.ratioKnown) + '><h3>' + E(title) + '</h3>' + (c.known < c.total ? '<p class="pmo-coverage-note">بيانات مقارنة متاحة: ' + h.link('عدد المشاريع: ' + count(c.known) + ' من أصل ' + count(c.total), 'pmo', c.id) + '</p>' : '') + '<button type="button" class="pmo-comparison-bars"' + h.attrs('pmo', c.id) + ' aria-label="' + opening(title + '، ' + c.leftLabel + ': ' + money(c.leftValue) + '، ' + c.rightLabel + ': ' + money(c.rightValue) + ' درهم، عدد المشاريع بقيمتين مسجلتين: ' + count(c.known)) + '">' + bar(c.leftLabel, c.leftValue, 'is-budget') + bar(c.rightLabel, c.rightValue, 'is-actual') + '</button>' + ratio + ((c.leftValue < 0 || c.rightValue < 0) ? '<p class="pmo-footnote">القيم السالبة لا تمثل بأعمدة.</p>' : '') + '</article>';
    }
    function financePanel() {
      var totals = '<div class="pmo-finance-totals">' + p.finance.map(function (f) {
        return '<div class="pmo-money-cell" data-finance="' + E(f.key) + '" data-known="' + f.known + '" data-total="' + f.total + '"' + sourceAttr('value', f.value) + '><button type="button" class="pmo-money"' + h.attrs('known', f.key) + ' aria-label="' + opening(f.name + ': ' + moneyName(f.value) + ' درهم إماراتي، ' + coverageText(f)) + '"><span>' + E(f.name) + '</span><strong><bdi>' + E(money(f.value)) + '</bdi></strong>' + coverageNote(f) + '</button>' + missingLink(f) + '</div>';
      }).join('') + '</div>';
      return '<section class="pmo-panel pmo-finance-wide" aria-label="التفصيل المالي والمقارنات"><p class="pmo-unit-note">درهم إماراتي</p>' + totals + '<div class="pmo-finance-comparisons">' + financialComparison(p.comparisons.budgetWork, 'قيمة الأعمال مقابل الموازنة') + financialComparison(p.comparisons.budgetSpent, 'المنفق حسب الفواتير مقابل الموازنة') + '</div></section>';
    }
    function financeSummary() {
      var keys = ['revised', 'workDone', 'spent'];
      return '<section class="pmo-panel pmo-finance-overview">' + header('الموازنة والتنفيذ المالي', 'درهم إماراتي') + '<div class="pmo-finance-summary">' + keys.map(function (key) {
        var f = finance(p.finance, key);
        return '<div class="pmo-summary-money-cell" data-finance-summary="' + E(f.key) + '" data-known="' + f.known + '" data-total="' + f.total + '"' + sourceAttr('value', f.value) + '><button type="button" class="pmo-money"' + h.attrs('known', f.key) + ' aria-label="' + opening(f.name + ': ' + moneyName(f.value) + ' درهم إماراتي، ' + coverageText(f)) + '"><span>' + E(f.name) + '</span><strong><bdi>' + E(money(f.value)) + '</bdi></strong>' + coverageNote(f) + '</button>' + missingLink(f) + '</div>';
      }).join('') + '</div></section>';
    }
    function matrixPanel() {
      var x = p.typePriority, max = Math.max(1, ...x.cells.map(function (c) { return c.n; }));
      var columns = x.priorities.map(function (g) { return '<th scope="col">' + E(g.name) + (['H', 'M', 'L'].includes(g.key) ? ' <bdi>(' + E(g.key) + ')</bdi>' : '') + '</th>'; }).join('');
      var rows = x.rows.map(function (r) {
        var total = p.groups.projectType.find(function (g) { return g.key === r.key; }) || { n: 0, id: 'type:' + encodeURIComponent(r.key), budgetId: 'type-budget:' + encodeURIComponent(r.key), finance: [] };
        var revised = finance(total.finance, 'revised') || { value: null, known: 0, total: 0 };
        return '<tr data-type="' + E(r.key) + '"' + sourceAttr('budget', revised.value) + sourceAttr('budget-known', revised.known) + '><th scope="row">' + E(r.name) + '</th>' + r.cells.map(function (c) {
          var priority = x.priorities.find(function (g) { return g.key === c.priority; });
          return '<td data-type="' + E(c.type) + '" data-priority="' + E(c.priority) + '" data-count="' + c.n + '"><button type="button" class="pmo-matrix-count' + (c.n ? '' : ' is-empty') + '" style="--pmo-fill:' + width(c.n / max * 100) + '"' + h.attrs('pmo', c.id) + ' aria-label="' + opening(r.name + '، أولوية ' + priority.name + '، عدد المشاريع: ' + countName(c.n)) + '"><bdi>' + count(c.n) + '</bdi>' + cue() + '</button></td>';
        }).join('') + '<td>' + h.link(count(total.n), 'pmo', total.id) + '</td><td>' + h.link(money(revised.value), 'pmo', total.budgetId) + coverageNote(revised) + '</td></tr>';
      }).join('');
      var foot = '<tfoot><tr><th scope="row">المجموع</th>' + x.priorities.map(function (g) { var total = p.groups.priority.find(function (r) { return r.key === g.key; }) || { n: 0, id: 'priority:' + encodeURIComponent(g.key) }; return '<td>' + h.link(count(total.n), 'pmo', total.id) + '</td>'; }).join('') + '<td>' + h.link(count(p.total), 'all') + '</td><td>' + h.link(money(budget.value), 'known', 'revised') + coverageNote(budget) + '</td></tr></tfoot>';
      return '<section class="pmo-panel pmo-matrix">' + header('نوع المشروع والأولوية', 'الموازنة بالدرهم') + '<div class="pw-table-scroll pmo-matrix-scroll" role="region" tabindex="0" aria-label="توزيع نوع المشروع والأولوية"><table class="pw-finance-table pmo-matrix-table"><caption class="visually-hidden">نوع المشروع والأولوية والموازنة</caption><thead><tr><th scope="col">نوع المشروع</th>' + columns + '<th scope="col">المجموع</th><th scope="col">الموازنة المعتمدة</th></tr></thead><tbody>' + rows + '</tbody>' + foot + '</table></div></section>';
    }
    function unitPanel() {
      var rows = p.groups.unit.map(function (g) {
        var f = finance(g.finance, 'revised');
        return '<tr data-unit="' + E(g.key) + '" data-count="' + g.n + '" data-done="' + g.done + '" data-overdue="' + g.overdue + '"' + sourceAttr('budget', f.value) + sourceAttr('budget-known', f.known) + '><th scope="row">' + E(g.name) + '</th><td>' + h.link(count(g.n), 'pmo', g.id) + '</td><td>' + h.link(count(g.done), 'pmo', g.doneId) + '</td><td>' + h.link(count(g.overdue), 'pmo', g.overdueId) + '</td><td>' + h.link(money(f.value), 'pmo', g.budgetId) + coverageNote(f) + '</td></tr>';
      }).join('');
      return '<section class="pmo-panel pmo-unit-exposure" aria-label="المشاريع بحسب الوحدة"><p class="pmo-unit-note">الموازنة بالدرهم</p><div class="pw-table-scroll pmo-unit-scroll" role="region" tabindex="0" aria-label="المشاريع والموازنة حسب الوحدة"><table class="pw-finance-table pmo-unit-table"><caption class="visually-hidden">المشاريع بحسب الوحدة</caption><thead><tr><th scope="col">الوحدة</th><th scope="col">المشاريع</th><th scope="col">منجز</th><th scope="col">تجاوز الموعد</th><th scope="col">الموازنة المعتمدة</th></tr></thead><tbody>' + rows + '</tbody></table></div></section>';
    }
    function schedulePanel() {
      var s = p.schedule;
      var action = h.link('مشاريع المقارنة (' + count(s.known) + ')', 'pmo', s.id);
      var rows = s.rows.map(function (r) {
        function row(name, value, tone) { return '<span class="pmo-pair-bar ' + tone + '"><span class="pmo-chart-label">' + E(name) + '</span><strong class="pmo-chart-value"><bdi>' + E(pct(value)) + '</bdi>' + cue() + '</strong>' + track(value) + '</span>'; }
        return '<article class="pmo-schedule-item" data-record="' + E(r.key) + '" data-progress="' + r.progress + '" data-elapsed="' + r.elapsedPct + '"><div class="pmo-schedule-head"><h3>' + h.link(r.title, 'record', r.key) + '</h3></div><p class="pmo-schedule-dates"><span>البداية: <bdi>' + E(r.startLabel) + '</bdi></span><span>الانتهاء: <bdi>' + E(r.endLabel) + '</bdi></span></p><button type="button" class="pmo-comparison-bars pmo-schedule-chart"' + h.attrs('record', r.key) + ' aria-label="' + opening(r.title + '، نسبة الإنجاز المسجلة ' + pct(r.progress) + '، الزمن المنقضي ' + pct(r.elapsedPct)) + '">' + row('نسبة الإنجاز المسجلة', r.progress, 'is-actual') + row('الزمن المنقضي', r.elapsedPct, 'is-budget') + '</button></article>';
      }).join('');
      if (!s.known) return '<section class="pmo-panel pmo-schedule pmo-schedule-unavailable" data-known="0" data-total="' + s.total + '"><p class="pmo-empty-note">مقارنة الإنجاز والزمن غير متاحة. ' + h.link('عرض المشاريع (' + count(s.total) + ')', 'pmo', 'schedule:unavailable') + '</p></section>';
      return '<section class="pmo-panel pmo-schedule" aria-label="نسبة الإنجاز والزمن المنقضي" data-known="' + s.known + '" data-total="' + s.total + '"><div class="pmo-schedule-actions">' + action + (s.known < s.total ? h.link('عدد المشاريع غير القابلة للمقارنة: ' + count(s.total - s.known), 'pmo', 'schedule:unavailable') : '') + '</div>' + rows + '</section>';
    }
    function attentionPanel() {
      var labels = [
        ['overdueHigh', 'أولوية عالية تجاوزت الموعد'],
        ['overBudget', 'فواتير تتجاوز الموازنة المسجلة'],
        ['negativeFinance', 'مشاريع بقيم مالية سالبة'],
        ['noDate', 'موعد الانتهاء غير متاح'],
        ['noProgress', 'نسبة إنجاز مفقودة أو غير صالحة']
      ];
      var conditions = labels.map(function (pair) {
        var n = p.attention[pair[0]].length;
        return '<button type="button" class="pmo-attention-count' + (n ? '' : ' is-empty') + '"' + h.attrs('pmo', 'attention:' + pair[0]) + ' data-attention="' + pair[0] + '" data-count="' + n + '" aria-label="' + opening(pair[1] + '، عدد المشاريع: ' + countName(n)) + '"><span>' + E(pair[1]) + '</span>' + (pair[0] === 'overBudget' ? '<small>المشاريع القابلة للفحص: ' + count(p.overBudgetEligible) + ' من أصل ' + count(p.total) + '</small>' : '') + '<strong><bdi>' + count(n) + '</bdi>' + cue() + '</strong></button>';
      }).join('') + '<button type="button" class="pmo-attention-count' + (m.noOwner.length ? '' : ' is-empty') + '"' + h.attrs('noOwner') + ' data-attention="noOwner" data-count="' + m.noOwner.length + '" aria-label="' + opening('مدير المشروع غير مسجل، عدد المشاريع: ' + countName(m.noOwner.length)) + '"><span>مدير المشروع غير مسجل</span><strong><bdi>' + count(m.noOwner.length) + '</bdi>' + cue() + '</strong></button>';
      var notes = m.notes.map(function (it) {
        var ownerNote = String(it.t.ownerRemarks || '').trim(), financeNote = String(it.t.financeRemarks || '').trim();
        function note(label, text) { return text ? '<p class="pmo-note-body"><span>' + E(label) + '</span><bdi dir="auto">' + E(text) + '</bdi></p>' : ''; }
        return '<li class="pmo-note"><div class="pmo-note-head"><h3>' + h.link(it.title, 'record', it.key) + '</h3>' + h.badge(it) + '</div><p class="pmo-note-meta">' + E(h.val(it.unit)) + ' · مدير المشروع: <bdi dir="auto">' + E(h.val(h.owner(it))) + '</bdi></p><details class="pmo-note-details"><summary>عرض الملاحظات المسجلة</summary>' + note('ملاحظات مدير المشروع', ownerNote) + note('ملاحظات المالية', financeNote) + '</details></li>';
      }).join('');
      return '<section class="pmo-panel pmo-attention">' + header('ما يحتاج متابعة', '', m.notes.length ? h.link('الملاحظات (' + count(m.notes.length) + ')', 'notes') : '') + '<div class="pmo-attention-counts">' + conditions + '</div>' + (notes ? '<details class="pmo-notes-details"><summary>ملاحظات المتابعة' + U.icon('down',18) + '</summary><ul class="pmo-attention-list">' + notes + '</ul></details>' : '') + '</section>';
    }
    return '<div class="pmo-dashboard" data-source-total="' + p.total + '">' + kpis + '<div class="pmo-overview-grid">' + statusPanel() + deadlinesPanel() + '</div>' + financeSummary() + '<div class="pmo-portfolio-grid">' + matrixPanel() + attentionPanel() + '</div><div class="pmo-analysis-list">' + disclosure('التفصيل المالي والمقارنات', '', financePanel(), 'pmo-finance-details') + (p.schedule.known ? disclosure('نسبة الإنجاز والزمن المنقضي', 'عدد المشاريع: ' + count(p.schedule.known) + ' من أصل ' + count(p.schedule.total), schedulePanel(), 'pmo-schedule-details') : schedulePanel()) + disclosure('المشاريع بحسب الوحدة', 'عدد الوحدات: ' + count(p.groups.unit.length), unitPanel(), 'pmo-unit-details') + '</div></div>';

  }
  S.views = S.views || {};
  S.views.projectsPMO = { render: render };
})(window.Saytara = window.Saytara || {});
