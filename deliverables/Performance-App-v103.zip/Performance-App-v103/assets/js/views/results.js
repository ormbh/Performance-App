/*
 * Performance reporting · search results (S3)
 * The header with the search box stays in place while typing; tabs, filters and
 * the table are redrawn as the query or filters change.
 */
(function (S) {
  'use strict';

  var U = S.util, UI = S.ui, SR = S.search;
  var SCREEN_PAGE_SIZE = 50;

  function shell(state) {
    return '' +
      '<div class="screen results" data-screen="results">' +
      UI.appHeader(state,'search') +
      '  <div class="r-head" role="search" aria-label="البحث والمحافظ">' +
      '    <div class="r-head-in">' +
      S.views.home.searchBox(state, 'md') +
      '    </div>' +
      '    <div class="tabs" id="r-tabs" role="tablist" aria-label="المحافظ"></div>' +
      '  </div>' +
      '  <main class="r-body"><h1 class="results-title">نتائج البحث</h1><section id="r-body" role="tabpanel" aria-label="نتائج البحث"></section></main>' +
      '</div>';
  }

  function tabs(state, res) {
    return SR.TABS.map(function (t) {
      var on = state.search.tab === t, n = res.counts[t] || 0;
      return '<button type="button" role="tab" class="tab' + (on ? ' is-on' : '') + (n ? '' : ' is-empty') + '" id="search-tab-' + t + '" aria-controls="r-body" tabindex="' + (on ? '0' : '-1') + '" aria-selected="' + on + '" data-act="tab" data-tab="' + t + '">' +
        (t === 'all' ? 'الكل' : UI.pfName(t)) + '<span class="tab-n">' + U.fmtN(n) + '</span></button>';
    }).join('');
  }

  function filterMenus(state, res) {
    var s = state.search;
    var visibleFilters = SR.FILTERS.filter(function (F) { return !F.pf || F.pf === s.tab; });
    var menus = visibleFilters.map(function(F){return UI.multiSelect(state,'f:'+F.k,F.ar,s.f[F.k]||[],res.facets[F.k]||[]);}).join('');

    var chips = [];
    visibleFilters.forEach(function (F) {
      (s.f[F.k] || []).forEach(function (v) {
        var o = (res.facets[F.k] || []).find(function (x) { return x.v === v; });
        chips.push('<span class="fchip">' + F.ar + ': <span dir="auto">' + U.esc(o ? o.label : v) + '</span>' +
          '<button type="button" data-act="chip-remove" data-f="' + F.k + '" data-v="' + U.esc(v) + '" aria-label="إزالة عامل التصفية ' + U.esc(F.ar + ': ' + (o ? o.label : v)) + '">' + U.icon('x', 13) + '</button></span>');
      });
    });
    var active = visibleFilters.filter(function(F){return U.hasSelection(s.f[F.k]);});
    var summary = active.map(function(F){var values=U.selection(s.f[F.k]);return F.ar+': '+values.slice(0,2).map(function(v){var o=(res.facets[F.k]||[]).find(function(x){return x.v===v;});return o?o.label:v||'غير مسجل';}).join('، ')+(values.length>2?' +'+(values.length-2):'');}).join(' · ') || 'الكل';
    return UI.filterPanel(state,{id:'search',resetAction:'clear-filters',title:'تصفية نتائج البحث',body:'<div class="filters">'+menus+chips.join('')+'</div>',summary:summary,activeCount:active.length});
  }

  var COLUMNS = [
    {id:'title', label:'العنوان', sort:'title'},
    {id:'status', label:'الحالة / التقدم', sort:'status'},
    {id:'date', label:'التوقيت', sort:'date'},
    {id:'contact', label:'المتابعة', sort:'coord'},
    {id:'place', label:'الجهة / الوحدة التنظيمية', sort:'place'},
    {id:'context', label:'المستجدات / الخطوة المقبلة'}
  ];
  var COL_KEY = 'saytara.search.columns.v58';
  function cleanColumns(value) {
    var ids = Array.isArray(value) ? value : COLUMNS.map(function(c){return c.id;});
    return COLUMNS.filter(function(c){return c.id==='title'||ids.indexOf(c.id)>=0;}).map(function(c){return c.id;});
  }
  function loadColumns() { try { return cleanColumns(JSON.parse(U.store.get('localStorage',COL_KEY)||'null')); } catch(e) { return cleanColumns(); } }
  function saveColumns(ids) { var clean=cleanColumns(ids); U.store.set('localStorage',COL_KEY,JSON.stringify(clean)); return clean; }
  function columns(state) { return cleanColumns(state.search.columns || loadColumns()); }
  function columnMenu(state) {
    var selected=columns(state), on=state.menu==='search-columns';
    return '<div class="menu-wrap multi-wrap search-columns" data-multi-wrap="search-columns"><button type="button" class="btn btn-sm" data-act="menu" data-menu="search-columns" aria-expanded="'+on+'" aria-controls="search-column-menu">'+U.icon('rows',16)+'تخصيص الأعمدة</button>'+
      (on ? '<div class="multi-menu" id="search-column-menu">'+COLUMNS.map(function(c){return '<label class="search-column-option"><input type="checkbox" data-change="search-column" data-column="'+c.id+'"'+(selected.indexOf(c.id)>=0?' checked':'')+(c.id==='title'?' disabled':'')+'><span>'+c.label+(c.id==='title'?' (أساسي)':'')+'</span></label>';}).join('')+'<button type="button" class="linkbtn" data-act="reset-search-columns">استعادة الافتراضي</button><small>الطباعة: الأعمدة الظاهرة · CSV: الحقول الأساسية</small></div>' : '')+'</div>';
  }
  function sortMenu(state) {
    var current=state.search.sort,value=current?current.col+':'+current.dir:'';
    var options=[['','الحالة ثم التاريخ (الافتراضي)'],['no:asc','الرقم: تصاعدي'],['no:desc','الرقم: تنازلي'],['title:asc','العنوان: أ–ي'],['title:desc','العنوان: ي–أ'],['status:asc','الحالة: ترتيب القائمة'],['status:desc','الحالة: عكس ترتيب القائمة'],['progress:asc','النسبة / نتيجة المؤشر: تصاعدي'],['progress:desc','النسبة / نتيجة المؤشر: تنازلي'],['coord:asc','مسؤول المتابعة: أ–ي'],['coord:desc','مسؤول المتابعة: ي–أ'],['date:asc','التاريخ المعروض: الأقدم'],['date:desc','التاريخ المعروض: الأحدث'],['place:asc','القطاع / الوحدة: ترتيب القائمة'],['place:desc','القطاع / الوحدة: عكس ترتيب القائمة']];
    return '<label class="search-sort-control"><span>ترتيب النتائج</span><select data-change="search-sort" aria-label="ترتيب النتائج">'+options.map(function(o){return '<option value="'+o[0]+'"'+(value===o[0]?' selected':'')+'>'+o[1]+'</option>';}).join('')+'</select></label>';
  }
  function line(label,value,toks,cls) {
    value=U.tableCellText(value);
    if(!value)return '';
    return '<div class="result-line '+(cls||'')+'"><span class="result-label">'+U.esc(label)+': </span><span class="result-value" dir="auto">'+SR.highlight(String(value),toks)+'</span></div>';
  }
  function reference(it) {
    var t=it.t;
    if(it.pf==='council'&&t.no)return ['رقم القرار',t.no];
    if(it.pf==='legislation'&&t.mcms)return ['MCMS',t.mcms];
    if(it.pf==='legislation'&&t.seq)return ['رقم التشريع في المصدر',t.seq];
    if(it.pf==='secretariat'&&t.no)return ['رقم المشروع في المصدر',t.no];
    return ['رقم ' + UI.contentLabel(it) + ' في المصدر',it.seq];
  }
  function matchedIn(h,toks) {
    if(!toks||!toks.length)return '';
    var f=h.m.fields.find(function(x){return typeof x==='object'&&x.field!=='pf';});
    if(!f)return '';
    var it=h.it,value=it.t[f.field]|| (f.field==='date'?it.dateLabel:f.field==='status'?it.statusLabel:f.field==='sector'?it.sector:f.field==='legislationMonth'?it.calc.legislationMonth&&it.calc.legislationMonth.label:'');
    if(!value)return '';
    value=String(value);var norm=U.normMap(value),at=-1;
    toks.some(function(t){var i=norm.text.indexOf(t);if(/[*?]/.test(t)){var ranges=SR.wildcardRanges(norm.text,t,true);i=ranges.length?ranges[0].start:-1;}if(i>=0){at=norm.map[i];return true;}return false;});
    var start=Math.max(0,at-45),excerpt=(start?'…':'')+value.slice(start,start+190)+(value.length>start+190?'…':'');
    return '<div class="t-matched">'+line('تطابق في '+f.label,excerpt,toks)+'</div>';
  }
  function timing(it) {
    var t=it.t,out='';
    if(it.pf==='agenda')return line('شهر الإنجاز',it.dateLabel)+line('الشهر المعدل',t.newMonth);
    if(it.pf==='council')return line('تاريخ الاجتماع',t.meetingDate)+line('تاريخ الرد',t.replyDate);
    if(it.pf==='legislation') {
      out=line(t.ext?'تمديد حتى':'موعد SLC',t.ext||t.slc)+line('موعد إدارة التشريعات',t.deptDate)+line('الإنجاز الفعلي',t.actual);
      return out||line('تاريخ الاستلام',t.received);
    }
    if(it.pf==='special'||it.pf==='secretariat')return line('انتهاء المشروع',it.dateLabel);
    if(it.pf==='kpi')return line('دورية القياس',t.freq)+line('فترة النتيجة','نتيجة العام');
    return '';
  }
  function contact(it,toks) {
    var role=it.pf==='special'||it.pf==='secretariat'?'مدير المشروع':it.pf==='kpi'?'ملاك الهدف':'منسق الأمانة العامة';
    return line(role,it.coord,toks);
  }
  function context(it,toks) {
    var t=it.t, out='';
    function add(k,v,narrative){out+=line(k,v,toks,narrative?'result-narrative':'');}
    if(it.pf==='agenda'){add('ملاحظات الأمانة',t.notes,true);add('ملاحظات المقرر',t.rapporteur,true);if(!out){add('العرض على مجلس الشؤون',t.dateSac);add('العرض على المجلس التنفيذي',t.dateEc);}}
    if(it.pf==='council'){add('متطلبات المتابعة',t.followup,true);add('القرار الأخير',t.latest,true);add('ملاحظات',t.notes,true);}
    if(it.pf==='legislation'){add('مرحلة التشريع',t.stage);add('مستجدات',t.updates,true);}
    if(it.pf==='special'){add('المنجز للآن',t.achieved,true);add('المرحلة المقبلة',t.next,true);add('ملاحظات مدير المشروع',t.notes,true);add('التوصيات',t.recs,true);}
    if(it.pf==='secretariat'){
      add('الأولوية',S.schema.value('priority',t.priority));
      add('الموازنة المعتمدة الجديدة',t.revised);add('المنفق حسب الفواتير',t.spent);
      add('غير المخصص',t.nonCommitted);
      add('ملاحظات مدير المشروع',t.ownerRemarks,true);add('ملاحظات المالية',t.financeRemarks,true);
    }
    if(it.pf==='kpi'){add('نتيجة العام',t.result);add('المستهدف للعام',t.target);add('الهدف الاستراتيجي',t.strategic,true);add('ملاحظات',t.notes,true);}
    return out;
  }
  function status(it,toks) {
    var chips=U.tableCellText(it.statusLabel)?UI.chips(it):(it.health?UI.healthChip(it.health):'');
    var out=chips?'<div class="chips-col">'+chips+'</div>':'';
    if(['special','secretariat','council'].indexOf(it.pf)>=0&&it.progress!=null)out+='<div class="result-progress">'+line('نسبة الإنجاز',Math.round(it.progress)+'%')+'</div>';
    // KPI performance is shown with its source period/target, without assuming polarity.
    return out;
  }
  function cell(id,h,toks,printing) {
    var it=h.it,ref=reference(it);
    if(id==='title')return '<div class="t-title" dir="'+it.dir+'">'+SR.highlight(it.title,toks)+'</div><div class="t-pf">'+UI.pfName(it.pf)+' · '+U.esc(ref[0])+': <bdi>'+U.esc(ref[1])+'</bdi></div>'+(printing?'':matchedIn(h,toks));
    if(id==='status')return status(it,toks);
    if(id==='date')return timing(it);
    if(id==='contact')return contact(it,toks);
    if(id==='place')return line(it.pf==='legislation'?'الجهة المرسلة':'الجهة المعنية',it.entity,toks)+line('الوحدة التنظيمية',it.unit,toks)+line('القطاع',it.sector,toks,'result-secondary');
    return context(it,toks);
  }
  function sortHead(state,c) {
    var s=state.search.sort,on=s&&s.col===c.sort;
    return '<th scope="col"'+(on?' aria-sort="'+(s.dir==='asc'?'ascending':'descending')+'"':'')+'>'+(c.sort?'<button type="button" class="th-btn" data-act="sort" data-col="'+c.sort+'">'+c.label+'<span class="sort-ind">'+(on?(s.dir==='asc'?'▲':'▼'):'')+'</span></button>':c.label)+'</th>';
  }
  function table(state,res,rows,printing) {
    var visible=columns(state),cols=COLUMNS.filter(function(c){return visible.indexOf(c.id)>=0;});
    var titleLabel=UI.contentHeader(res.rows.map(function(h){return h.it;}),state.search.tab==='all'?[]:[state.search.tab]);
    return '<div class="table-wrap search-result-wrap'+(printing?' search-print-table':' search-screen-table')+'" role="region" aria-label="جدول نتائج البحث"><table class="rtable search-result-table"><thead><tr>'+cols.map(function(c){var col=c.id==='title'?Object.assign({},c,{label:titleLabel}):c;return printing?'<th scope="col">'+col.label+'</th>':sortHead(state,col);}).join('')+'</tr></thead><tbody>'+(rows||res.rows).map(function(h){return '<tr'+(printing?'':' tabindex="0" data-act="open" aria-label="عرض تفاصيل '+U.esc(h.it.title)+'"')+' class="'+(state.openKey===h.it.key?'is-sel':'')+'" data-key="'+U.esc(h.it.key)+'">'+cols.map(function(c){var markup=cell(c.id,h,res.toks,printing),label=c.id==='title'?UI.contentLabel(h.it):c.label;return '<td class="result-'+c.id+'" data-label="'+U.esc(label)+'"'+(markup?'':' aria-label="'+U.esc(label+': غير مسجل')+'"')+'>'+markup+'</td>';}).join('')+'</tr>';}).join('')+'</tbody></table></div>';
  }

  /* Screen pagination never slices the protected model, counts, facets or CSV. */
  function paging(state,res) {
    res=res||state.lastRes;
    var total=res&&res.rows?res.rows.length:0,pages=Math.max(1,Math.ceil(total/SCREEN_PAGE_SIZE));
    var wanted=Number(state.search.page),page=Math.min(pages,Math.max(1,Number.isInteger(wanted)?wanted:1));
    return {size:SCREEN_PAGE_SIZE,total:total,pages:pages,page:page,start:total?(page-1)*SCREEN_PAGE_SIZE+1:0,end:Math.min(page*SCREEN_PAGE_SIZE,total)};
  }
  function pageNav(p,bottom) {
    if(p.pages<=1)return '';
    var range='عرض <bdi dir="ltr">'+U.fmtN(p.start)+'–'+U.fmtN(p.end)+'</bdi> من '+U.fmtN(p.total);
    return '<nav class="search-pagination" aria-label="'+(bottom?'صفحات نتائج البحث في نهاية الجدول':'صفحات نتائج البحث')+'"><p'+(bottom?'':' id="search-result-range" tabindex="-1" role="status" aria-live="polite" aria-atomic="true"')+'><strong>'+range+'</strong><span> · الصفحة '+U.fmtN(p.page)+' من '+U.fmtN(p.pages)+'</span></p><div>'+['prev','next'].map(function(dir){var previous=dir==='prev';return '<button type="button" class="btn btn-sm" data-act="search-page" data-page="'+(p.page+(previous?-1:1))+'" aria-label="'+(previous?'الصفحة السابقة من نتائج البحث':'الصفحة التالية من نتائج البحث')+'"'+((previous?p.page<=1:p.page>=p.pages)?' disabled':'')+'>'+U.icon(previous?'right':'left',16)+(previous?'السابق':'التالي')+'</button>';}).join('')+'</div></nav>';
  }

  function body(state, res) {
    var s = state.search, out = '';
    if (s.drill) {
      out += '<div class="drill">' + U.icon('grid', 16) + '<span>من التقرير:</span><b>' + U.esc(s.drill.label) + '</b>' +
        '<button type="button" class="linkbtn" data-act="drill-clear">إزالة</button>' +
        '<button type="button" class="linkbtn" data-act="go-dash">' + U.icon('right', 15) + 'العودة إلى التقرير الشهري</button></div>';
    }
    out += filterMenus(state, res);
    out += '<div class="r-meta"><div class="r-count" role="status" aria-live="polite" aria-atomic="true"><b>' + S.terms.count(res.rows.length, s.tab === 'all' ? res.rows.map(function(h){return h.it;}) : s.tab) + '</b></div>' +
      '<div class="r-tools">' +
      sortMenu(state) + columnMenu(state) +
      '<button type="button" class="btn btn-sm" data-act="export" aria-label="تصدير كل النتائج المطابقة ضمن عوامل التصفية الحالية بصيغة CSV"' + (res.rows.length ? '' : ' disabled') + '>' + U.icon('download', 16) + 'تصدير كل النتائج (CSV)</button>' +
      '<button type="button" class="btn btn-sm" data-act="print" aria-label="طباعة كل النتائج المطابقة ضمن عوامل التصفية الحالية">' + U.icon('print', 16) + 'طباعة كل النتائج</button></div></div>';

    if (!res.active) {
      out += '<div class="state-idle"><p>اكتب كلمة للبحث.</p><button type="button" class="btn" data-act="browse-all">عرض جميع النتائج</button></div>';
    } else if (!res.rows.length) {
      var scoped = s.tab !== 'all' || SR.FILTERS.some(function (F) { return (s.f[F.k] || []).length; });
      out += '<div class="state-zero"><span class="zero-ic">' + U.icon('search', 26) + '</span>' +
        '<h2>' + (s.q.trim() ? 'لا توجد نتائج لـ «<span dir="auto">' + U.esc(s.q.trim()) + '</span>»' : 'لا توجد نتائج مطابقة') + '</h2>' +
        '<p>جرّب جزءاً من الاسم أو أزل عوامل التصفية.</p>' +
        (scoped ? '<button type="button" class="btn btn-outline" data-act="zero-all">ابحث في جميع المحافظ</button>' : '') + '</div>';
    } else {
      var p=paging(state,res);
      out += pageNav(p,false)+table(state,res,res.rows.slice(p.start-1,p.end),false)+pageNav(p,true);
      out += '<div id="search-print-results" class="search-print-results"></div>';
    }
    return out;
  }

  function update(state) {
    // Full ordered matches stay available for counts, facets, CSV and printing.
    var res = SR.run(state.data, state.search);
    state.search.page=paging(state,res).page;
    state.lastRes = res;
    var t = document.getElementById('r-tabs'), b = document.getElementById('r-body');
    if (t) t.innerHTML = tabs(state, res);
    if (b) { b.innerHTML = body(state, res); b.setAttribute('aria-labelledby', 'search-tab-' + state.search.tab); }
    var clear = document.querySelector('.sclear');
    if (clear) clear.classList.toggle('is-hidden', !state.search.q);
    return res;
  }

  function preparePrint(state) {
    var root=document.getElementById('search-print-results'),res=state.lastRes;
    if(root&&res&&res.rows.length)root.innerHTML=(S.provenance?S.provenance.print(state.data):'')+table(state,res,res.rows,true);
  }
  function clearPrint() {
    var root=document.getElementById('search-print-results');
    if(root)root.innerHTML='';
  }

  S.views.results = { render: shell, update: update, paging:paging, preparePrint:preparePrint, clearPrint:clearPrint, loadColumns:loadColumns, saveColumns:saveColumns, cleanColumns:cleanColumns, columns:COLUMNS, reference:reference, timing:timing, context:context };
})(window.Saytara = window.Saytara || {});
