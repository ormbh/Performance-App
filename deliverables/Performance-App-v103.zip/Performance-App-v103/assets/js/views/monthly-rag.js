/* The Excel mold uses a red/green vertical source indicator per portfolio.
   Performance conditional formatting changes its default green fill to red
   when the corresponding flag cell equals 1. There is no stacked status bar,
   amber threshold, or completed-overrun ribbon. Strategy compares the source
   average result with the independently calculated average target. */
(function (S) {
  'use strict';

  var U = S.util, R = S.rules;
  var SOURCE = {
    special: {
      sheet: 'Performance', range: 'C12:C18', flagCell: 'C12',
      flagFormula: '=IF(SUM(U14,AM14)>0,1,"")', conditionalFormula: '$C$12=1',
      countCells: ['U14', 'AM14'], logicCells: ['AA3', 'AE3'],
      metrics: ['specialLeadLate', 'specialGsLate']
    },
    secretariat: {
      sheet: 'Performance', range: 'C21:C30', flagCell: 'C21',
      flagFormula: '=IF(U23=0,"",1)', conditionalFormula: '$C$21=1',
      countCells: ['U23'], logicCells: ['AK3'], metrics: ['secLate']
    },
    agenda: {
      sheet: 'Performance', range: 'AT11:AT16', flagCell: 'AT11',
      flagFormula: '=IF(Performance!CC13=0,"",1)', conditionalFormula: '$AT$11=1',
      countCells: ['CC13'], logicCells: ['J3'], metrics: ['agendaLate']
    },
    council: {
      sheet: 'Performance', range: 'AT18:AT23', flagCell: 'AT18',
      flagFormula: '=IF(Performance!BZ20=0,"",1)', conditionalFormula: '$AT$18=1',
      countCells: ['BZ20'], logicCells: ['O3'], metrics: ['councilLate']
    },
    kpi: {
      sheet: 'Performance', range: 'AY2:AY6', flagCell: 'AY2',
      flagFormula: '=IF(BO4>BY4,"",1)', conditionalFormula: '$AY$2=1',
      countCells: [], valueCells: ['BO4','BY4'], logicCells: ['AR3','AS3'],
      metrics: ['kpiAvg','kpiTargeted'], kind: 'strategy'
    },
    legislation: {
      sheet: 'Performance', range: 'AT25:AT30', flagCell: 'AT25',
      flagFormula: '=IF(CB27=0,"",1)', conditionalFormula: '$AT$25=1',
      countCells: ['CB27'], logicCells: ['W3'], metrics: ['legLate']
    }
  };

  function finite(value) { return typeof value === 'number' && Number.isFinite(value); }
  function unavailable(pf, reason, source) {
    return { available: false, pf: pf, reason: reason, count: null, flag: null,
      color: 'grey', members: [], metrics: [], source: source || null, reconciled: false };
  }
  function summary(D, pf, data) {
    var source = SOURCE[pf];
    if (!source) return unavailable(pf, 'لا يوجد مؤشر في القالب لهذه المحفظة');
    if (!D || !Array.isArray(D.items) || !D.n)
      return unavailable(pf, 'بيانات النطاق غير متاحة', source);
    if (data && !source.metrics.every(function (metric) { return R.metricAvailable(data, metric, D.scope || {}); }))
      return unavailable(pf, 'أعمدة المصدر غير مكتملة', source);
    if (['secretariat', 'legislation'].indexOf(pf) >= 0 && data && data.referenceDateReady === false)
      return unavailable(pf, 'التاريخ المرجعي غير متاح', source);
    if (source.kind === 'strategy') {
      var result = D.kpi && D.kpi.avgResult, target = D.kpi && D.kpi.avgTarget;
      // Never compare the Excel display placeholder "-" with a number. No
      // performance flag can be inferred until both source averages exist.
      if (!finite(result) || !finite(target)) return unavailable(pf, 'لا يتوافر متوسط نتيجة ومستهدف قابلان للمقارنة', source);
      var red = result <= target;
      return { available: true, pf: pf, kind: 'strategy', reason: '', count: null,
        flag: red ? 1 : '', color: red ? 'red' : 'green', members: [],
        metrics: [{ metric: 'kpiAvg', value: result }, { metric: 'kpiTargeted', value: target }],
        populations: { result: D.n.kpiMeasured, target: D.n.kpiTargeted },
        source: source, reconciled: true };
    }
    var metrics = source.metrics.map(function (metric) { return { metric: metric, count: D.n[metric] }; });
    if (metrics.some(function (metric) { return !finite(metric.count) || metric.count < 0; }))
      return unavailable(pf, 'عدد البنود المتأخرة غير متاح', source);
    var count = metrics.reduce(function (sum, metric) { return sum + metric.count; }, 0);
    // Use exactly the same filtered source predicates as the flag's counts.
    // In particular, special excludes an unclassified requester, council
    // excludes decisions outside its follow-up population, and legislation
    // uses legLate only: the separate completed-overrun count is not added.
    var members = D.items.filter(function (it) {
      return it.pf === pf && source.metrics.some(function (metric) { return R.test(metric, it); });
    }).map(function (it) { return { key: it.key || '', row: it.row, sheet: it.sheet || '' }; });
    if (members.length !== count) return unavailable(pf, 'عدد البنود لا يطابق نطاق التقرير', source);
    return {
      available: true, pf: pf, reason: '', count: count, flag: count > 0 ? 1 : '',
      color: count > 0 ? 'red' : 'green', members: members, metrics: metrics,
      source: source, reconciled: true
    };
  }
  function render(state, D, pf) {
    if (!SOURCE[pf]) return '';
    var result = summary(D, pf, state && state.data);
    var message = result.kind === 'strategy' ? 'متوسط النتائج المقاسة ' + U.fmtNum(result.metrics[0].value * 100,2) + '% ' +
      (result.color === 'green' ? 'أعلى من' : 'لا يتجاوز') + ' متوسط المستهدفات ' + U.fmtNum(result.metrics[1].value * 100,2) + '%؛ متوسطان لمجموعتين مستقلتين' :
      !result.available ? 'المؤشر غير متاح: ' + result.reason :
      result.count > 0 ? 'متأخر: ' + U.fmtN(result.count) : 'لا توجد بنود متأخرة';
    var label = S.schema.PF[pf].ar + ' · ' + message;
    return '<div class="monthly-rag monthly-rag-' + result.color + '" data-rag-pf="' + U.esc(pf) +
      '" data-rag-available="' + result.available + '"' + (result.available && result.count != null ? ' data-rag-count="' + result.count + '"' : '') +
      ' data-rag-source="' + U.esc(result.source.sheet + '!' + result.source.range) +
      '" tabindex="0" role="img" aria-label="' + U.esc(label) + '"></div>' +
      '<span class="monthly-rag-tooltip" dir="rtl" aria-hidden="true">' + U.esc(label) + '</span>';
  }

  S.monthlyRag = { render: render, summary: summary };
})(window.Saytara = window.Saytara || {});
