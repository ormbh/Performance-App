/* Monthly report context and preparation controls. Calculations stay in the
 * existing loader/controller; this view never changes the workbook or scope. */
(function (S) {
  'use strict';
  var U = S.util;

  function layout(state) { return state.monthly && state.monthly.layout === 'a3' ? 'a3' : 'a4'; }

  function iso(serial) {
    if (!U.validDateSerial(serial)) return '';
    var date = U.ymd(serial);
    return String(date.y).padStart(4, '0') + '-' + String(date.m).padStart(2, '0') + '-' + String(date.d).padStart(2, '0');
  }

  function scope(state) {
    var filters = state.dash || {};
    return [
      { key: 'sector', label: 'القطاع', text: U.selectionText(filters.sector, 'جميع القطاعات') },
      { key: 'unit', label: 'الوحدة التنظيمية', text: U.selectionText(filters.unit, 'جميع الوحدات التنظيمية') },
      { key: 'entity', label: 'الجهة المعنية', text: U.selectionText(filters.entity, 'جميع الجهات المعنية') }
    ];
  }

  function printHint(value) {
    return value === 'a3'
      ? 'A3: الملخص وبنود المتابعة في صفحة واحدة عند كفاية المساحة. تُعرض الملاحظات كاملة وقد تمتد التفاصيل إلى صفحات إضافية.'
      : 'A4: ملخص المؤشرات في الصفحة الأولى، وبنود المتابعة والملاحظات كاملة من الصفحة الثانية. قد تمتد التفاصيل إلى صفحات إضافية.';
  }

  function sourceNote(data) {
    var cached = U.validDateSerial(data.sourceValidationDate) ? data.sourceValidationDate : data.savedReportDate;
    if (data.sourceDateKind === 'live') {
      return 'الملف يستخدم TODAY؛ ' + (data.calculationDateKind === 'live' ? 'الحسابات بحسب تاريخ اليوم.' : 'الحسابات بحسب التاريخ المرجعي المحدد.') +
        ' قيمة TODAY المحفوظة في الملف: ' + (U.validDateSerial(cached) ? U.fmtDate(cached) : 'غير متاحة') + '.';
    }
    if (U.validDateSerial(cached)) return 'التاريخ المرجعي المحفوظ في الملف: ' + U.fmtDate(cached) + '.';
    return 'لا يتوفر تاريخ مرجعي محفوظ في الملف؛ يُستخدم تاريخ الحساب المحدد.';
  }

  function render(state, D) {
    var data = state.data;
    if (!data) return '';
    var selectedLayout = layout(state), disabled = state.reporting ? ' disabled' : '';
    var filename = data.file && data.file.name ? data.file.name : 'ملف غير مسمى';
    var currentScope = scope(state);
    return '<section class="monthly-tools" aria-label="بيانات التقرير وإعداد الطباعة">' +
      '<div class="monthly-context"><dl class="monthly-source"><div><dt>ملف البيانات</dt><dd><bdi dir="auto">' + U.esc(filename) + '</bdi></dd></div></dl>' +
      '<dl class="monthly-scope" aria-label="النطاق الحالي للتقرير">' + currentScope.map(function (field) {
        return '<div data-monthly-scope="' + field.key + '"><dt>' + field.label + '</dt><dd><bdi dir="auto">' + U.esc(field.text) + '</bdi></dd></div>';
      }).join('') + '</dl></div>' +
      '<div class="monthly-controls"><div class="monthly-date-control"><label for="monthly-date">تاريخ الحساب</label>' +
      '<div class="monthly-date-actions"><input id="monthly-date" name="monthly-date" type="date" data-act="monthly-date" value="' + iso(data.today) + '"' + disabled + '>' +
      '<button type="button" class="dbtn monthly-date-reset" data-act="monthly-date-reset"' + disabled + '>استعادة مرجع الملف</button></div></div>' +
      '<div class="monthly-layout-control"><label for="monthly-layout">تخطيط الطباعة</label><select id="monthly-layout" name="monthly-layout" data-act="monthly-layout"' + disabled + '>' +
      '<option value="a4"' + (selectedLayout === 'a4' ? ' selected' : '') + '>A4 أفقي</option>' +
      '<option value="a3"' + (selectedLayout === 'a3' ? ' selected' : '') + '>A3 أفقي</option></select></div></div></section>';
  }

  S.monthlyTools = { render: render, layout: layout, iso: iso, scope: scope, printHint: printHint, sourceNote: sourceNote };
})(window.Saytara = window.Saytara || {});
