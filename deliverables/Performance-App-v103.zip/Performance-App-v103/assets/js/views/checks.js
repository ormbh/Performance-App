/*
 * Performance reporting · data checks (based on the design's import review, S10)
 * A summary per sheet, then every issue with its row, field and suggested fix.
 */
(function (S) {
  'use strict';

  var U = S.util, SC = S.schema, UI = S.ui;
  var SEV = { error: { ar: 'خطأ', icon: 'x', cls: 'bad' }, warn: { ar: 'تحذير', icon: 'warn', cls: 'warn' }, info: { ar: 'ملاحظة', icon: 'info', cls: 'info' } };

  function issueField(x, data) {
    var it = x.key && data.byKey && data.byKey[x.key];
    var pf = x.pf || it && it.pf;
    var spec = SC.PF[pf], title = spec && spec.fields.title;
    return title && (x.field === 'title' || U.key(x.field) === U.key(title.h)) ? UI.contentLabel(pf) : x.field;
  }

  function render(state) {
    var d = state.data, sel = state.checks.sheet, severity = state.checks.severity || ''; 
    var summary = SC.ORDER.map(function (pf) {
      var m = d.meta[pf], sheet = m.sheet;
      var mine = d.issues.filter(function (x) { return x.sheet === sheet; });
      var e = mine.filter(function (x) { return x.sev === 'error'; }).length, w = mine.filter(function (x) { return x.sev === 'warn'; }).length;
      var res = !m.found ? ['تعذّرت القراءة', 'bad', 'x'] : e ? ['تمت القراءة مع أخطاء في البيانات', 'bad', 'warn'] : w ? ['تمت القراءة مع تحذيرات', 'warn', 'warn'] : ['تمت القراءة', 'ok', 'check'];
      var on = sel === sheet;
      return '<tr class="' + (on ? 'is-sel' : '') + '">' +
        '<td dir="auto"><button type="button" class="checks-sheet-button" data-act="checks-sheet" data-sheet="' + U.esc(sheet) + '" aria-pressed="' + on + '">' + U.esc(sheet) + '</button></td><td>' + UI.pfName(pf) + '</td><td class="num">' + U.metricText(m.rows) + '</td>' +
        '<td class="num">' + U.metricText(e) + '</td><td class="num">' + U.metricText(w) + '</td>' +
        '<td><span class="res res-' + res[1] + '">' + U.icon(res[2], 14) + res[0] + '</span></td></tr>';
    }).join('');

    var scoped = d.issues.filter(function (x) { return !sel || x.sheet === sel; });
    var list = scoped.filter(function (x) { return !severity || x.sev === severity; });
    var counts = { error: 0, warn: 0, info: 0 };
    scoped.forEach(function (x) { counts[x.sev]++; });
    var rows = list.map(function (x) {
      var s = SEV[x.sev];
      return '<tr><td class="nowrap"><span class="sev sev-' + s.cls + '">' + U.icon(s.icon, 15) + s.ar + '</span></td>' +
        '<td dir="auto" class="nowrap muted">' + U.esc(x.sheet) + '</td><td class="nowrap num">' + U.esc(U.tableCellText(x.row)) + '</td>' +
        '<td dir="auto" data-source-label="' + U.esc(x.field) + '">' + U.esc(SC.label(issueField(x, d))) + '</td><td>' + U.esc(x.problem) + '</td>' +
        '<td dir="auto" class="val">' + U.esc(U.tableCellText(x.value)) + '</td>' +
        '<td>' + U.esc(x.fix) + (x.key ? ' <button type="button" class="linkbtn" data-act="open" data-key="' + U.esc(x.key) + '">عرض التفاصيل</button>' : '') + '</td></tr>';
    }).join('');

    return '' +
      '<div class="screen checks" data-screen="checks">' +
      UI.appHeader(state,'checks') +
      '  <div class="chead" role="region" aria-labelledby="checks-title"><div class="chead-in app-page-heading">' +
      '    <button type="button" class="icon-btn" data-act="back" aria-label="رجوع">' + U.icon('right', 18) + '</button>' +
      '    <div class="ctitle"><h1 id="checks-title">ملاحظات البيانات</h1><div class="dsub">التاريخ المرجعي للحسابات ' + U.fmtDate(d.today) + '</div></div>' +
      '    <button type="button" class="btn" data-act="checks-export"' + (list.length ? '' : ' disabled') + '>' + U.icon('download', 17) + 'تنزيل الملاحظات المعروضة</button>' +
      '  </div></div>' +
      '  <main class="cwrap">' +
      '    <section class="panel"><div class="panel-h"><h2>الأوراق المقروءة</h2></div>' +
      '      <div class="table-wrap" role="region" tabindex="0" aria-label="جاهزية أوراق البيانات"><table class="ctable"><caption>جاهزية أوراق البيانات</caption><thead><tr><th scope="col">الورقة</th><th scope="col">المحفظة</th><th scope="col">الصفوف</th><th scope="col">الأخطاء</th><th scope="col">التحذيرات</th><th scope="col">النتيجة</th></tr></thead><tbody>' + summary + '</tbody></table></div></section>' +
      '    <section class="panel"><div class="panel-h"><h2>الملاحظات <span class="muted">(أخطاء: ' + U.metricText(counts.error) + ' · تحذيرات: ' + U.metricText(counts.warn) + ' · ملاحظات: ' + U.metricText(counts.info) + ')</span></h2>' +
      (sel ? '<span class="fchip"><span dir="auto">' + U.esc(sel) + '</span><button type="button" data-act="checks-sheet" data-sheet="" aria-label="إزالة">' + U.icon('x', 13) + '</button></span>' : '') + '</div>' +
      '<div class="checks-triage"><label for="checks-severity">تصفية حسب النوع</label><select id="checks-severity" data-act="checks-severity">' + [['', 'جميع الأنواع'], ['error', 'الأخطاء'], ['warn', 'التحذيرات'], ['info', 'الملاحظات']].map(function (option) { return '<option value="' + option[0] + '"' + (severity === option[0] ? ' selected' : '') + '>' + option[1] + '</option>'; }).join('') + '</select><p role="status" aria-live="polite">المعروض: ' + U.fmtN(list.length) + ' من ' + U.fmtN(scoped.length) + (sel ? ' في الورقة المحددة' : ' في جميع الأوراق') + '</p></div>' +
      (list.length ? '<div class="table-wrap"  role="region" tabindex="0" aria-label="ملاحظات البيانات والإصلاحات المقترحة"><table class="ctable issues"><caption>ملاحظات البيانات'+(sel?' · '+U.esc(sel):' · جميع الأوراق')+'</caption><thead><tr><th scope="col">النوع</th><th scope="col">الورقة</th><th scope="col">الصف</th><th scope="col">الحقل</th><th scope="col">المشكلة</th><th scope="col">القيمة</th><th scope="col">الإصلاح المقترح</th></tr></thead><tbody>' + rows + '</tbody></table></div>' :
        '<div class="state-ok">' + U.icon('check-circle', 22) + 'لا توجد ملاحظات ضمن عوامل التصفية الحالية' + (sel ? ' على هذه الورقة' : '') + '</div>') +
      '    </section>' +
      
      '  </main>' +
      '</div>';
  }

  function exportCsv(data, filters) {
    filters = filters || {};
    var selected = data.issues.filter(function(x) {
      return (!filters.sheet || x.sheet === filters.sheet) && (!filters.severity || x.sev === filters.severity);
    });
    var head = ['النوع', 'الورقة', 'الصف', 'الحقل', 'المشكلة', 'القيمة', 'الإصلاح المقترح'];
    return U.csv([head].concat(selected.map(function (x) { return [SEV[x.sev].ar, x.sheet, x.row, issueField(x, data), x.problem, x.value, x.fix]; })));
  }

  S.views.checks = { render: render, exportCsv: exportCsv };
})(window.Saytara = window.Saytara || {});
