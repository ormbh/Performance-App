/* Council decisions · native editable TEC PowerPoint export. Generated locally from the council report model. */
(function(S){
 'use strict';
 var U=S.util,A='http://schemas.openxmlformats.org/drawingml/2006/main',P='http://schemas.openxmlformats.org/presentationml/2006/main',C='http://schemas.openxmlformats.org/drawingml/2006/chart',R='http://schemas.openxmlformats.org/officeDocument/2006/relationships',PK='http://schemas.openxmlformats.org/package/2006/relationships',CT='http://schemas.openxmlformats.org/package/2006/content-types';
 var encoder=new TextEncoder(),decoder=new TextDecoder(),templatePromise;
 function xml(s){var d=new DOMParser().parseFromString(s,'application/xml');if(d.getElementsByTagName('parsererror').length)throw new Error('تعذّر قراءة قالب التقرير');return d;}
 // Darken neutral text only. Chart fills, approved status accents and logo artwork stay intact.
 function readableText(d){
  ['rPr','defRPr','endParaRPr'].forEach(function(tag){all(d,A,tag).forEach(function(pr){
   var fill=first(pr,A,'solidFill'),c=fill&&first(fill,A,'srgbClr');if(!c)return;
   var v=c.getAttribute('val').toUpperCase();
   if(['756B5F','ABA394','808080','C8C7C7'].includes(v))c.setAttribute('val',Number(pr.getAttribute('sz')||0)>=1800?'333333':'4F4E4E');
   if(v==='00ACA0')c.setAttribute('val','115E67');
  });});
 }
 function serial(d){readableText(d);return new XMLSerializer().serializeToString(d);}
 function all(e,ns,name){return Array.from(e.getElementsByTagNameNS(ns,name));}
 function first(e,ns,name){return e.getElementsByTagNameNS(ns,name)[0];}
 function node(d,ns,name,attrs){var n=d.createElementNS(ns,name);Object.keys(attrs||{}).forEach(function(k){if(k==='xmlns'||k.indexOf('xmlns:')===0)n.setAttributeNS('http://www.w3.org/2000/xmlns/',k,String(attrs[k]));else n.setAttribute(k,String(attrs[k]));});return n;}
 // The generated deck replaces every template slide ID. PowerPoint sections use
 // the Office 2010 namespace, not PML. Schema validation does not resolve these
 // IDs, so stale section references can survive a schema-clean export.
 function clearTemplateSlideLists(presentation){
  all(presentation,'http://schemas.microsoft.com/office/powerpoint/2010/main','sectionLst').forEach(function(list){
   var ext=list.parentNode;list.remove();
   if(ext&&ext.namespaceURI===P&&ext.localName==='ext'&&!ext.children.length){var extensions=ext.parentNode;ext.remove();if(extensions&&!extensions.children.length)extensions.remove();}
  });
  all(presentation,P,'custShowLst').forEach(function(n){n.remove();});
 }
 function clean(s){return String(s==null?'':s).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'');}
 function esc(s){return U.esc(clean(s));}
 function fmt(n){return String(n);}
 function pct(n,total){return total?(100*n/total).toFixed(1).replace(/\.0$/,'')+'%':'0%';}
 function loadTemplate(){
  if(S.agendaTemplateBase64)return Promise.resolve();
  if(!templatePromise)templatePromise=new Promise(function(resolve,reject){var s=document.createElement('script');s.src='assets/js/reports/agenda-template.js';s.onload=resolve;s.onerror=function(){s.remove();templatePromise=null;reject(new Error('ملف قالب PowerPoint غير موجود. فك ضغط مجلد التطبيق كاملاً.'));};document.head.appendChild(s);});
  return templatePromise;
 }
 // ZIP writer for PPTX and its small chart workbooks. Stored entries work offline in Edge/Chrome.
 var crcTable;
 function crc32(bytes){if(!crcTable){crcTable=new Uint32Array(256);for(var i=0;i<256;i++){var c=i;for(var j=0;j<8;j++)c=c&1?0xedb88320^(c>>>1):c>>>1;crcTable[i]=c;}}var crc=0xffffffff;for(var k=0;k<bytes.length;k++)crc=crcTable[(crc^bytes[k])&255]^(crc>>>8);return (crc^0xffffffff)>>>0;}
 function zip(parts,type){
  var body=[],central=[],offset=0;
  parts.forEach(function(value,name){var bytes=typeof value==='string'?encoder.encode(value):value,n=encoder.encode(name),crc=crc32(bytes),l=new Uint8Array(30+n.length),v=new DataView(l.buffer);v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint32(14,crc,true);v.setUint32(18,bytes.length,true);v.setUint32(22,bytes.length,true);v.setUint16(26,n.length,true);l.set(n,30);body.push(l,bytes);var ch=new Uint8Array(46+n.length),cv=new DataView(ch.buffer);cv.setUint32(0,0x02014b50,true);cv.setUint16(4,20,true);cv.setUint16(6,20,true);cv.setUint16(8,0x800,true);cv.setUint32(16,crc,true);cv.setUint32(20,bytes.length,true);cv.setUint32(24,bytes.length,true);cv.setUint16(28,n.length,true);cv.setUint32(42,offset,true);ch.set(n,46);central.push(ch);offset+=l.length+bytes.length;});
  var size=central.reduce(function(n,b){return n+b.length;},0),end=new Uint8Array(22),ev=new DataView(end.buffer);ev.setUint32(0,0x06054b50,true);ev.setUint16(8,parts.size,true);ev.setUint16(10,parts.size,true);ev.setUint32(12,size,true);ev.setUint32(16,offset,true);return new Blob(body.concat(central,[end]),{type:type||'application/zip'});
 }
 function shape(doc,id){return all(doc,P,'sp').find(function(s){var p=first(s,P,'cNvPr');return p&&p.getAttribute('id')===String(id);});}
 function position(el,x,y,w,h){var xf=first(el,A,'xfrm')||first(el,P,'xfrm');if(!xf)return;var off=first(xf,A,'off'),ext=first(xf,A,'ext');if(x!=null)off.setAttribute('x',Math.round(x*9525));if(y!=null)off.setAttribute('y',Math.round(y*9525));if(w!=null)ext.setAttribute('cx',Math.round(w*9525));if(h!=null)ext.setAttribute('cy',Math.round(h*9525));}
 function textProperties(doc,tag,size,font,color,rtl){
  var pr=node(doc,A,'a:'+tag,{lang:rtl?'ar-AE':'en-US',altLang:rtl?'en-US':'ar-AE',sz:Math.round(size*100),b:'0',i:'0',dirty:'0'}),fill=node(doc,A,'a:solidFill');fill.appendChild(node(doc,A,'a:srgbClr',{val:color||'4F4E4E'}));pr.appendChild(fill);
  ['latin','ea','cs'].forEach(function(n){pr.appendChild(node(doc,A,'a:'+n,{typeface:n==='latin'&&/^DIN /.test(font||'')?'Ample':font||'Dubai'}));});pr.appendChild(node(doc,A,'a:rtl',{val:rtl?'1':'0'}));return pr;
 }
 function paragraphs(doc,text,size,font,color,align){
  return clean(text).split('\n').map(function(line){
   var p=node(doc,A,'a:p'),pr=node(doc,A,'a:pPr',{algn:align||'r',rtl:'1',marL:'0',marR:'0',indent:'0'});pr.appendChild(node(doc,A,'a:lnSpc'));pr.lastChild.appendChild(node(doc,A,'a:spcPct',{val:110000}));['spcBef','spcAft'].forEach(function(n){var space=node(doc,A,'a:'+n);space.appendChild(node(doc,A,'a:spcPts',{val:0}));pr.appendChild(space);});pr.appendChild(node(doc,A,'a:buNone'));pr.appendChild(textProperties(doc,'defRPr',size,font,color,true));p.appendChild(pr);
   // Separate Latin identifiers and numbers from Arabic runs without changing source text.
   var spans=[],at=0,re=/[A-Za-z][A-Za-z0-9]*(?:[ \t]+[A-Za-z][A-Za-z0-9]*)*|[0-9]+(?:[.,:/+–-][0-9]+)*(?:[ \t]?%)?/g,m;
   while((m=re.exec(line))){if(m.index>at)spans.push({text:line.slice(at,m.index),rtl:true});spans.push({text:m[0],rtl:false});at=re.lastIndex;}if(at<line.length)spans.push({text:line.slice(at),rtl:true});if(!spans.length)spans.push({text:line,rtl:true});
   spans.forEach(function(span){var run=node(doc,A,'a:r');run.appendChild(textProperties(doc,'rPr',size,font,color,span.rtl));var t=node(doc,A,'a:t');t.textContent=span.text;run.appendChild(t);p.appendChild(run);});p.appendChild(textProperties(doc,'endParaRPr',size,font,color,true));return p;
  });
 }
 function cleanBody(doc,bp){
  ['spAutoFit','normAutofit','noAutofit'].forEach(function(n){all(bp,A,n).forEach(function(x){x.remove();});});bp.setAttribute('wrap','square');bp.setAttribute('vert','horz');bp.setAttribute('rtlCol','1');bp.setAttribute('anchorCtr','0');bp.appendChild(node(doc,A,'a:noAutofit'));
 }
 function applyBaseTextDefaults(doc){
  all(doc,A,'pPr').concat(['defPPr','lvl1pPr','lvl2pPr','lvl3pPr','lvl4pPr','lvl5pPr','lvl6pPr','lvl7pPr','lvl8pPr','lvl9pPr'].flatMap(function(n){return all(doc,A,n);})).forEach(function(pr){pr.setAttribute('rtl','1');pr.setAttribute('algn','r');});
  ['rPr','defRPr','endParaRPr'].forEach(function(tag){all(doc,A,tag).forEach(function(pr){pr.setAttribute('lang','ar-AE');pr.setAttribute('altLang','en-US');var isTitle=false,n=pr;while(n&&n!==doc){if(n.localName==='titleStyle')isTitle=true;n=n.parentNode;}var font=isTitle?'DIN Next LT Arabic':'Dubai';['latin','ea','cs'].forEach(function(tag){var f=first(pr,A,tag);if(f)f.setAttribute('typeface',font);else pr.appendChild(node(doc,A,'a:'+tag,{typeface:font}));});var rtl=first(pr,A,'rtl');if(rtl)rtl.setAttribute('val','1');else pr.appendChild(node(doc,A,'a:rtl',{val:'1'}));});});
 }
 function normalizeTemplateFonts(parts){
  parts.forEach(function(value,name){if(!/^ppt\/(theme|slideMasters|slideLayouts)\/[^/]+\.xml$/.test(name))return;var doc=xml(decoder.decode(value));
   if(name.indexOf('/theme/')>=0){['majorFont','minorFont'].forEach(function(tag){all(doc,A,tag).forEach(function(group){var font=tag==='majorFont'?'DIN Next LT Arabic':'Dubai';['latin','ea','cs'].forEach(function(n){var f=first(group,A,n);if(f)f.setAttribute('typeface',font);});all(group,A,'font').filter(function(f){return ['Arab','Latn'].includes(f.getAttribute('script'));}).forEach(function(f){f.setAttribute('typeface',font);});});});}
   else applyBaseTextDefaults(doc);parts.set(name,serial(doc));
  });
 }
 var fontPromise;
 function loadFonts(){if(S.agendaFonts)return Promise.resolve();if(!fontPromise)fontPromise=new Promise(function(resolve,reject){var s=document.createElement('script');s.src='assets/js/reports/agenda-fonts.js';s.onload=resolve;s.onerror=function(){s.remove();fontPromise=null;reject(new Error('ملفات خطوط PowerPoint غير موجودة. فك ضغط مجلد التطبيق كاملاً.'));};document.head.appendChild(s);});return fontPromise;}
 function embedReportFonts(parts,presentation,rels){
  all(presentation,P,'embeddedFontLst').forEach(function(n){n.remove();});Array.from(rels.documentElement.children).filter(function(n){return n.getAttribute('Type')===R+'/font';}).forEach(function(n){n.remove();});
  var list=node(presentation,P,'p:embeddedFontLst'),entry=node(presentation,P,'p:embeddedFont');entry.appendChild(node(presentation,P,'p:font',{typeface:S.agendaFonts.family}));
  S.agendaFonts.faces.forEach(function(face){parts.set(face.partName,S.agendaFonts.bytes(face));rels.documentElement.appendChild(node(rels,PK,'Relationship',{Id:face.relationshipId,Type:S.agendaFonts.relationshipType,Target:face.partName.replace(/^ppt\//,'')}));var font=node(presentation,P,'p:'+face.style);font.setAttributeNS(R,'r:id',face.relationshipId);entry.appendChild(font);});list.appendChild(entry);
  var root=presentation.documentElement,before=Array.from(root.children).find(function(n){return ['custShowLst','photoAlbum','custDataLst','kinsoku','defaultTextStyle','modifyVerifier','extLst'].includes(n.localName);});root.insertBefore(list,before||null);root.setAttribute('embedTrueTypeFonts','1');root.setAttribute('saveSubsetFonts','0');
 }
 function textShape(doc,id,text,opts){
  opts=opts||{};var s=shape(doc,id);if(!s)return;
  var tb=first(s,P,'txBody');if(!tb)return;
  var bp=first(tb,A,'bodyPr');bp.setAttribute('wrap','square');bp.setAttribute('lIns','0');bp.setAttribute('rIns','0');bp.setAttribute('tIns','0');bp.setAttribute('bIns','0');bp.setAttribute('anchor',opts.anchor||'t');
  all(tb,A,'p').forEach(function(p){p.remove();});cleanBody(doc,bp);
  paragraphs(doc,text,opts.size||16,opts.font||'Dubai',opts.color||'4F4E4E',opts.align).forEach(function(p){tb.appendChild(p);});
  if(opts.box)position.apply(null,[s].concat(opts.box));return s;
 }
 function slide(source){return xml(source);}
 function footer(doc,id){var el=shape(doc,id);if(el)el.remove();}
 function title(doc,id,text,box){textShape(doc,id,text,{size:21,font:'DIN Next LT Arabic',box:box||[70,35,1130,75]});}
 var canvas;
 function wrap(text,width,size){
  canvas=canvas||document.createElement('canvas');var ctx=canvas.getContext('2d');ctx.font=(size||16)+'px "TEC Dubai"';var lines=[];
  clean(text).split('\n').forEach(function(p){var line='';p.split(/\s+/).forEach(function(word){if(!word)return;var next=line?line+' '+word:word;if(ctx.measureText(next).width>width&&line){lines.push(line);line='';}if(ctx.measureText(word).width>width){for(var ch of word){if(ctx.measureText(line+ch).width>width){lines.push(line);line='';}line+=ch;}}else line=line?line+' '+word:word;});lines.push(line);});
  return lines;
 }
 async function workbook(categories,series){
  var rows=[['الفئة'].concat(series.map(function(s){return s.name;}))].concat(categories.map(function(c,i){return [c].concat(series.map(function(s){return s.values[i];}));}));
  var sheet='<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+rows.map(function(row,r){return '<row r="'+(r+1)+'">'+row.map(function(v,c){var ref=String.fromCharCode(65+c)+(r+1);return typeof v==='number'?'<c r="'+ref+'"><v>'+v+'</v></c>':'<c r="'+ref+'" t="inlineStr"><is><t>'+esc(v)+'</t></is></c>';}).join('')+'</row>';}).join('')+'</sheetData></worksheet>';
  var parts=new Map([
   ['[Content_Types].xml','<Types xmlns="'+CT+'"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>'],
   ['_rels/.rels','<Relationships xmlns="'+PK+'"><Relationship Id="rId1" Type="'+R+'/officeDocument" Target="xl/workbook.xml"/></Relationships>'],
   ['xl/workbook.xml','<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="'+R+'"><sheets><sheet name="Data" sheetId="1" r:id="rId1"/></sheets></workbook>'],
   ['xl/_rels/workbook.xml.rels','<Relationships xmlns="'+PK+'"><Relationship Id="rId1" Type="'+R+'/worksheet" Target="worksheets/sheet1.xml"/></Relationships>'],['xl/worksheets/sheet1.xml',sheet]]);
  return new Uint8Array(await zip(parts).arrayBuffer());
 }
 function fresh(source,keep){
  var doc=slide(source),tree=first(doc,P,'spTree');
  Array.from(tree.children).forEach(function(el){if(['sp','graphicFrame','pic','grpSp','cxnSp'].includes(el.localName)){var id=first(el,P,'cNvPr');if(!id||!keep.includes(Number(id.getAttribute('id'))))el.remove();}});
  return doc;
 }
 function addText(doc,text,box,size,font,color,align){
  var tree=first(doc,P,'spTree'),id=Math.max(100,...all(doc,P,'cNvPr').map(function(n){return Number(n.getAttribute('id'));}))+1;
  var sp=node(doc,P,'p:sp'),nv=node(doc,P,'p:nvSpPr');nv.appendChild(node(doc,P,'p:cNvPr',{id:id,name:'Report text '+id}));nv.appendChild(node(doc,P,'p:cNvSpPr',{txBox:1}));nv.appendChild(node(doc,P,'p:nvPr'));sp.appendChild(nv);
  var pr=node(doc,P,'p:spPr'),xf=node(doc,A,'a:xfrm');xf.appendChild(node(doc,A,'a:off',{x:Math.round(box[0]*9525),y:Math.round(box[1]*9525)}));xf.appendChild(node(doc,A,'a:ext',{cx:Math.round(box[2]*9525),cy:Math.round(box[3]*9525)}));pr.appendChild(xf);pr.appendChild(node(doc,A,'a:noFill'));sp.appendChild(pr);
  var tb=node(doc,P,'p:txBody');tb.appendChild(node(doc,A,'a:bodyPr',{wrap:'square',lIns:0,rIns:0,tIns:0,bIns:0}));tb.appendChild(node(doc,A,'a:lstStyle'));sp.appendChild(tb);tree.appendChild(sp);textShape(doc,id,text,{box:box,size:size||16,font:font||'Dubai',color:color||'4F4E4E',align:align||'r'});return sp;
 }
 function cleanRels(source){var rel=xml(source);Array.from(rel.documentElement.children).filter(function(n){return !n.getAttribute('Type').endsWith('/slideLayout')&&!n.getAttribute('Type').endsWith('/image');}).forEach(function(n){n.remove();});return rel;}
 var CHART_COLORS={'متأخر':'651D32','جاهز للعرض':'00ACA0','قيد المراجعة':'ABA394','قيد التطوير':'756B5F','منجز':'115E67','حالات أخرى':'808080','غير مسجل':'808080','بدون حالة':'808080'};
 async function nativeBars(parts,doc,rel,index,values,box,max,fontSize,kind){
  values=values.filter(function(x){return x.n>0;});if(!values.length)return;
  var pie=kind==='pie',horizontal=kind==='horizontal',chart=xml(pie?S.reportPieTemplate:S.reportChartTemplate),ser=first(chart,C,'ser'),labels=values.map(function(x){return pie||horizontal?x.name:x.name.replace('جاهز للعرض','جاهز\nللعرض').replace('قيد ','قيد\n');});
  chart.documentElement.setAttribute('xmlns:a',A);chart.documentElement.setAttribute('xmlns:c',C);chart.documentElement.setAttribute('xmlns:r',R);
  function ref(holder,type,formula,vals){while(holder.firstChild)holder.firstChild.remove();var r=node(chart,C,'c:'+type+'Ref'),f=node(chart,C,'c:f');f.textContent=formula;r.appendChild(f);var cache=node(chart,C,'c:'+type+'Cache');if(type==='num'){var code=node(chart,C,'c:formatCode');code.textContent='0';cache.appendChild(code);}cache.appendChild(node(chart,C,'c:ptCount',{val:vals.length}));vals.forEach(function(v,i){var pt=node(chart,C,'c:pt',{idx:i}),value=node(chart,C,'c:v');value.textContent=String(v);pt.appendChild(value);cache.appendChild(pt);});r.appendChild(cache);holder.appendChild(r);}
  ref(first(ser,C,'tx'),'str','Data!$B$1',['عدد القرارات']);ref(first(ser,C,'cat'),'str','Data!$A$2:$A$'+(values.length+1),labels);ref(first(ser,C,'val'),'num','Data!$B$2:$B$'+(values.length+1),values.map(function(x){return x.n;}));
  all(chart,C,'showVal').forEach(function(n){n.setAttribute('val',pie?'0':'1');});
  first(chart,C,'lang').setAttribute('val','ar-AE');if(!pie)first(chart,C,'barDir').setAttribute('val',horizontal?'bar':'col');
  if(pie){var dl=first(chart,C,'dLbls');dl.insertBefore(node(chart,C,'c:numFmt',{formatCode:'0.0%',sourceLinked:'0'}),dl.firstChild);}
  all(chart,A,'defRPr').forEach(function(n){n.setAttribute('sz',Math.round((fontSize||11)*100));n.setAttribute('b','0');n.setAttribute('i','0');n.setAttribute('lang','ar-AE');n.setAttribute('altLang','en-US');['latin','ea','cs'].forEach(function(tag){var f=first(n,A,tag);if(f)f.setAttribute('typeface','Dubai');else n.appendChild(node(chart,A,'a:'+tag,{typeface:'Dubai'}));});all(n,A,'rtl').forEach(function(r){r.remove();});n.appendChild(node(chart,A,'a:rtl',{val:'1'}));});
  all(chart,A,'pPr').forEach(function(n){n.setAttribute('rtl','1');n.setAttribute('algn','ctr');});all(chart,C,'legend').forEach(function(legend){all(legend,A,'pPr').forEach(function(n){n.setAttribute('algn','r');});});all(chart,C,'dLbls').forEach(function(dl){all(dl,A,'pPr').forEach(function(n){n.setAttribute('rtl','0');});all(dl,A,'rtl').forEach(function(n){n.setAttribute('val','0');});});
  all(ser,C,'dPt').forEach(function(n){n.remove();});values.forEach(function(x,i){var pt=node(chart,C,'c:dPt');pt.appendChild(node(chart,C,'c:idx',{val:i}));var sp=node(chart,C,'c:spPr'),fill=node(chart,A,'a:solidFill');fill.appendChild(node(chart,A,'a:srgbClr',{val:CHART_COLORS[x.name]||'756B5F'}));sp.appendChild(fill);pt.appendChild(sp);ser.insertBefore(pt,first(ser,C,'cat'));});
  if(!pie)all(chart,C,'legend').forEach(function(n){n.remove();});all(chart,C,'catAx').forEach(function(ax){first(ax,C,'tickLblPos').setAttribute('val',horizontal?'none':'low');first(ax,C,'axPos').setAttribute('val',horizontal?'r':'b');first(ax,C,'orientation').setAttribute('val','maxMin');all(ax,C,'tickLblSkip').concat(all(ax,C,'tickMarkSkip')).forEach(function(n){n.remove();});ax.appendChild(node(chart,C,'c:tickLblSkip',{val:1}));ax.appendChild(node(chart,C,'c:tickMarkSkip',{val:1}));});
  all(chart,C,'valAx').forEach(function(ax){first(ax,C,'tickLblPos').setAttribute('val','none');first(ax,C,'axPos').setAttribute('val',horizontal?'b':'l');var sc=first(ax,C,'scaling');first(sc,C,'orientation').setAttribute('val',horizontal?'maxMin':'minMax');all(sc,C,'max').concat(all(sc,C,'min')).forEach(function(n){n.remove();});sc.appendChild(node(chart,C,'c:max',{val:Math.max(max||0,...values.map(function(x){return x.n;}))*1.18}));sc.appendChild(node(chart,C,'c:min',{val:0}));});
  all(chart,A,'ln').forEach(function(ln){while(ln.firstChild)ln.firstChild.remove();ln.appendChild(node(chart,A,'a:noFill'));});all(chart,A,'srgbClr').forEach(function(c){if(['D4D4D4','FFFFFF','000000'].includes(c.getAttribute('val')))c.setAttribute('val',c.getAttribute('val')==='FFFFFF'?'FCFBFB':'4F4E4E');});
  all(chart,C,'externalData').forEach(function(n){n.remove();});var external=node(chart,C,'c:externalData');external.setAttributeNS(R,'r:id','rIdData');external.appendChild(node(chart,C,'c:autoUpdate',{val:0}));chart.documentElement.appendChild(external);
  parts.set('ppt/charts/chart'+index+'.xml',serial(chart));parts.set('ppt/charts/_rels/chart'+index+'.xml.rels','<Relationships xmlns="'+PK+'"><Relationship Id="rIdData" Type="'+R+'/package" Target="../embeddings/report-chart'+index+'.xlsx"/></Relationships>');parts.set('ppt/embeddings/report-chart'+index+'.xlsx',await workbook(labels,[{name:'عدد القرارات',values:values.map(function(x){return x.n;})}]));
  var id='rIdReportChart'+index;rel.documentElement.appendChild(node(rel,PK,'Relationship',{Id:id,Type:R+'/chart',Target:'../charts/chart'+index+'.xml'}));
  var tree=first(doc,P,'spTree'),frame=node(doc,P,'p:graphicFrame'),nv=node(doc,P,'p:nvGraphicFramePr');nv.appendChild(node(doc,P,'p:cNvPr',{id:Math.max(100,...all(doc,P,'cNvPr').map(function(n){return Number(n.getAttribute('id'));}))+1,name:'Report chart '+index}));nv.appendChild(node(doc,P,'p:cNvGraphicFramePr'));nv.appendChild(node(doc,P,'p:nvPr'));frame.appendChild(nv);var xf=node(doc,P,'p:xfrm');xf.appendChild(node(doc,A,'a:off',{x:Math.round(box[0]*9525),y:Math.round(box[1]*9525)}));xf.appendChild(node(doc,A,'a:ext',{cx:Math.round(box[2]*9525),cy:Math.round(box[3]*9525)}));frame.appendChild(xf);var graphic=node(doc,A,'a:graphic'),gd=node(doc,A,'a:graphicData',{uri:C}),c=node(doc,C,'c:chart',{'xmlns:c':C});c.setAttributeNS(R,'r:id',id);gd.appendChild(c);graphic.appendChild(gd);frame.appendChild(graphic);tree.appendChild(frame);
 }
 // Every decision remains in a native table. Oversized cells continue on the
 // next slide with the same source reference; no source text is truncated.
 var TABLE_WIDTHS=[168,289,169,122,295,107], TABLE_FONT=11.5;
 function sourceValue(value){return U.tableCellText(clean(value));}
 function sourceField(data,it,field,value){
  var meta=data.meta&&data.meta.council,definition=S.schema.PF.council.fields[field];
  if(meta&&(!meta.found||(meta.missing||[]).includes(definition.h)))return '';
  return sourceValue(value===undefined?(it.t||{})[field]:value);
 }
 function itemValues(it,data){
  var t=it.t||{};
  return [sourceField(data,it,'no')+'\n'+sourceField(data,it,'issuer'),sourceField(data,it,'title',t.title||it.title),sourceField(data,it,'entity',t.entity||it.entity),sourceField(data,it,'meetingDate'),sourceField(data,it,'latest'),sourceField(data,it,'status',t.status?S.councilReport.status(it,data):'')];
 }
 function tablePages(items,data){
  var pages=[],current=[],used=0,lineHeight=18,capacity=520,maxLines=Math.floor((capacity-16)/lineHeight)-2;
  items.forEach(function(it){
   var values=itemValues(it,data),lines=values.map(function(value,i){return wrap(value,TABLE_WIDTHS[i]-15,TABLE_FONT*4/3);}),n=Math.max.apply(null,lines.map(function(x){return x.length;}));
   for(var at=0;at<n;at+=maxLines){
    var cells=lines.map(function(v){return v.slice(at,at+maxLines).join('\n');});
    // Internal sequence identifies continuation rows only and stays distinct
    // from the recorded decision number. Normal rows contain source fields.
    if(at)cells[0]=(cells[0]?cells[0]+'\n':'')+'السجل '+it.seq+'\n(تابع)';
    var lineCount=Math.max.apply(null,cells.map(function(cell){return cell.split('\n').length;})),height=Math.max(48,lineCount*lineHeight+16);
    if(current.length&&used+height>capacity){pages.push(current);current=[];used=0;}
    current.push({values:cells,height:height,seq:it.seq,continuation:at>0});used+=height;
   }
  });
  if(current.length)pages.push(current);return pages;
 }
 function populateTable(doc,rows){
  var frame=first(doc,P,'graphicFrame'),old=first(frame,A,'tbl'),tbl=node(doc,A,'a:tbl'),pr=node(doc,A,'a:tblPr',{rtl:'0',firstRow:'0',bandRow:'0'}),grid=node(doc,A,'a:tblGrid');
  tbl.appendChild(pr);tbl.appendChild(grid);TABLE_WIDTHS.slice().reverse().forEach(function(w){grid.appendChild(node(doc,A,'a:gridCol',{w:Math.round(w*9525)}));});
  function row(values,height,header,index){
   var tr=node(doc,A,'a:tr',{h:Math.round(height*9525)});
   values.map(function(value,i){return {value:value,index:i};}).reverse().forEach(function(item){
    var tc=node(doc,A,'a:tc'),body=node(doc,A,'a:txBody'),bp=node(doc,A,'a:bodyPr',{vert:'horz',wrap:'square',anchor:'t',rtlCol:'1'});
    bp.appendChild(node(doc,A,'a:noAutofit'));body.appendChild(bp);body.appendChild(node(doc,A,'a:lstStyle'));
    paragraphs(doc,item.value,TABLE_FONT,header?'DIN Next LT Arabic':'Dubai',header?'4F4E4E':item.index===5?(S.councilReport.colors[item.value]||'4F4E4E').replace(/^#/,''):'4F4E4E',item.index===0?'ctr':'r').forEach(function(p){body.appendChild(p);});tc.appendChild(body);
    var props=node(doc,A,'a:tcPr',{marL:60000,marR:60000,marT:38000,marB:38000,anchor:'t'});
    ['lnL','lnR','lnT','lnB'].forEach(function(edge){var ln=node(doc,A,'a:'+edge,{w:6350}),fill=node(doc,A,'a:solidFill');fill.appendChild(node(doc,A,'a:srgbClr',{val:'E7E0D3'}));ln.appendChild(fill);ln.appendChild(node(doc,A,'a:prstDash',{val:'solid'}));props.appendChild(ln);});
    var fill=node(doc,A,'a:solidFill');fill.appendChild(node(doc,A,'a:srgbClr',{val:header?'E7E0D3':index%2?'EFEBE7':'FCFBFB'}));props.appendChild(fill);tc.appendChild(props);tr.appendChild(tc);
   });return tr;
  }
  tbl.appendChild(row(['رقم القرار / صادر عن','الموضوع','الجهة المعنية','تاريخ الاجتماع','القرار الأخير','مستوى الإنجاز'],42,true,0));
  rows.forEach(function(r,i){tbl.appendChild(row(r.values,r.height,false,i));});old.parentNode.replaceChild(tbl,old);position(frame,52,116,1150,42+rows.reduce(function(n,r){return n+r.height;},0));
 }
 function metadata(m){
  var fields=[['القطاع',m.scope.sector],['الوحدة التنظيمية',m.scope.unit],['الجهة المعنية',m.scope.entity]],scope=fields.map(function(x){return x[0]+': '+U.selectionText(x[1],'الكل');});
  return ['الملف: '+m.source,'الفترة المعروضة: '+m.period,'التاريخ المرجعي للحسابات: '+m.date].concat(scope,['متطلبات المتابعة: '+U.selectionText(m.followupSelection,'الكل')]).join('\n');
 }
 function slideLink(doc,rels,textShape,target,id){
  var rp=first(textShape,A,'rPr'),link=node(doc,A,'a:hlinkClick',{action:'ppaction://hlinksldjump'});link.setAttributeNS(R,'r:id',id);rp.insertBefore(link,first(rp,A,'rtl'));rels.documentElement.appendChild(node(rels,PK,'Relationship',{Id:id,Type:R+'/slide',Target:'slide'+target+'.xml'}));
 }
 async function build(data,scope,options){
  options=Object.assign({},options||{});
  var m=S.councilReport.model(data,scope||{},options);
  if(!m.eligibilityAvailable)throw new Error('تعذّر إنشاء التقرير: أعمدة المصدر المطلوبة لتحديد نطاق المتابعة غير متاحة.');
  if(!m.allTotal)throw new Error('لا توجد قرارات ضمن النطاق المحدد.');
  await loadTemplate();await loadFonts();await document.fonts.ready;
  var bin=atob(S.agendaTemplateBase64),bytes=new Uint8Array(bin.length);for(var i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);
  var archive=await S.zip.open(bytes.buffer),parts=new Map();await Promise.all(archive.names().map(async function(name){parts.set(name,await archive.read(name));}));
  normalizeTemplateFonts(parts);
  var sources={},rels={};[1,4,5].forEach(function(i){sources[i]=decoder.decode(parts.get('ppt/slides/slide'+i+'.xml'));rels[i]=decoder.decode(parts.get('ppt/slides/_rels/slide'+i+'.xml.rels'));});
  Array.from(parts.keys()).forEach(function(n){if(/^ppt\/(slides\/(slide\d+\.xml|_rels\/slide\d+\.xml\.rels)|charts\/|embeddings\/|notesSlides\/)/.test(n))parts.delete(n);});
  var slides=[],chartCount=0,contentsEntries=[],manifest=[];
  function add(doc,index){var rel=cleanRels(rels[index]);slides.push({doc:doc,rels:rel});return rel;}
  function sectionEntry(label,doc,count){contentsEntries.push({label:label,doc:doc,count:count});}
  function textPages(label,text,size){
   var lines=wrap(text,1110,(size||16)*4/3),perPage=20;
   for(var at=0;at<lines.length;at+=perPage){var d=fresh(sources[5],[2,4]);title(d,2,label+(at?' (تابع)':''),[65,35,1150,65]);footer(d,4);addText(d,lines.slice(at,at+perPage).join('\n'),[70,135,1135,510],size||16);add(d,5);if(at===0)sectionEntry(label,d,null);}
  }
  var cv=S.reportDisplay.cover(options),cover=slide(sources[1]);
  textShape(cover,4,S.reportDisplay.clean(options.reportTitle,140)||'تقرير قرارات المجالس',{size:cv.titleSize,font:'DIN Next LT Arabic',align:'ctr',box:cv.titleBox});addText(cover,m.period,cv.periodBox,cv.periodSize,'Dubai','4F4E4E','ctr');add(cover,1);
  var contents=fresh(sources[5],[2,4]);title(contents,2,'محتويات التقرير',[65,35,1150,65]);footer(contents,4);var contentsRels=add(contents,5);
  textPages('نطاق التقرير ومصدر البيانات',metadata(m),16);
  var summary=fresh(sources[5],[2,4]);title(summary,2,'الملخص التنفيذي',[65,35,1150,65]);footer(summary,4);var sr=add(summary,5);sectionEntry('الملخص التنفيذي',summary,m.total);
  var summaryLines=wrap(S.councilReport.summaryText(m),1130,23);
  addText(summary,summaryLines.join('\n'),[70,120,1135,Math.min(175,summaryLines.length*26)],17,'Dubai');
  var counters=[['القرارات في المصدر',m.allTotal],['تتطلب متابعة',m.total],['في الملحق',m.excludedTotal],['منجز',m.done],['قيد العمل',m.progress],['متأخر',m.late],['بدون حالة معتمدة',m.unknownStatus]];
  counters.forEach(function(c,i){var x=70+(counters.length-1-i)*(1135/counters.length);addText(summary,c[0],[x,290,1135/counters.length-10,56],13,'DIN Next LT Arabic','4F4E4E','ctr');addText(summary,U.metricText(c[1]),[x,350,1135/counters.length-10,56],c[1]==null?18:29,'Dubai','115E67','ctr');});
  addText(summary,'توزيع قرارات المتابعة بحسب مستوى الإنجاز',[70,430,1135,32],17,'DIN Next LT Arabic','4F4E4E');
  if(m.statuses.some(function(v){return v.n>0;}))await nativeBars(parts,summary,sr,++chartCount,m.statuses,[120,474,1080,165],0,13,'pie');
  else addText(summary,m.statusAvailable?'لا توجد قرارات تتطلب متابعة ضمن النطاق المحدد.':'بيانات مستوى الإنجاز غير متاحة في المصدر.',[120,490,1080,80],18,'Dubai','4F4E4E','ctr');
  addText(summary,'مؤشرات الإنجاز تشمل القرارات التي تتطلب متابعة فقط ('+m.total+'). الملحق '+m.excludedTotal+' قراراً.',[70,650,1135,32],13,'Dubai','4F4E4E');
  async function categoricalCharts(label,values){
   values=values.filter(function(v){return v.n>0;});
   for(var at=0;at<values.length;at+=8){var entries=values.slice(at,at+8),d=fresh(sources[5],[2,4]);title(d,2,label+(at?' (تابع)':''),[65,35,1150,65]);footer(d,4);var rel=add(d,5);if(at===0)sectionEntry(label,d,null);await nativeBars(parts,d,rel,++chartCount,entries,[70,140,815,480],0,13,'horizontal');entries.forEach(function(v,i){addText(d,v.name,[910,140+(i+.5)*480/entries.length-23,285,47],15,'Dubai','4F4E4E');});}
  }
  if(m.issuers.length)await categoricalCharts('قرارات المتابعة بحسب الجهة المصدرة',m.issuers);
  if(m.followup.length)await categoricalCharts('جميع القرارات بحسب متطلبات المتابعة',m.followup);
  [{groups:m.groups,label:'قرارات تتطلب متابعة',count:m.total},{groups:m.excludedGroups,label:'ملحق القرارات خارج نطاق المتابعة',count:m.excludedTotal}].forEach(function(section){
   var firstPage=true;
   section.groups.forEach(function(group){
    tablePages(group.items,data).forEach(function(rows,pageIndex){var d=fresh(sources[4],[9,4,2]);title(d,9,section.label+' — '+group.name+(pageIndex?' (تابع)':''),[62,32,1155,68]);footer(d,2);populateTable(d,rows);add(d,4);manifest.push({slide:slides.length,section:section.label,group:group.key,rows:rows.map(function(r){return {seq:r.seq,continuation:r.continuation};})});if(firstPage){sectionEntry(section.label,d,section.count);firstPage=false;}});
   });
  });
  var sourceNotes=S.sourceNotes.rows(data,'council',m.all),sourceNoteManifest=[];
  S.sourceNotes.pages(sourceNotes,function(value){return wrap(value,1120,14*4/3);},22).forEach(function(page,index){var d=fresh(sources[5],[2,4]);title(d,2,'ملحق ملاحظات المصدر'+(index?' (تابع)':''),[65,35,1150,65]);footer(d,4);addText(d,page.lines.join('\n'),[70,135,1135,510],14,'Dubai','4F4E4E');add(d,5);sourceNoteManifest.push({slide:slides.length,records:page.records});if(!index)sectionEntry('ملحق ملاحظات المصدر',d,sourceNotes.length);});
  [{key:'notes',label:'ملاحظات'},{key:'recommendations',label:'توصيات'}].forEach(function(x){if(String(options[x.key]||'').trim())textPages(x.label,options[x.key],16);});
  // Contents is itself a native table of linked text shapes. Keep its number of
  // entries bounded by report sections, independent of the number of records.
  contentsEntries.forEach(function(entry,i){var y=130+i*58,target=slides.findIndex(function(s){return s.doc===entry.doc;})+1;addText(contents,String(i+1).padStart(2,'0'),[1130,y,80,38],18,'Dubai','756B5F','r');var link=addText(contents,entry.label,[240,y,850,40],19,'DIN Next LT Arabic','115E67','r');if(entry.count!=null)addText(contents,String(entry.count),[70,y,135,38],17,'Dubai','756B5F','l');slideLink(contents,contentsRels,link,target,'rIdCouncilContents'+i);});
  slides.forEach(function(entry,i){
   if(S.provenance && S.provenance.reportText) addText(entry.doc,S.provenance.reportText(data),[350,3,850,20],8.5,'Dubai','756B5F','r');
   if(i)addText(entry.doc,String(i+1),[25,690,40,18],9,'Dubai','756B5F','l');
   if(entry.doc!==cover)addText(entry.doc,'المصدر: '+m.source+' · التاريخ المرجعي: '+m.date,[350,688,850,22],8.5,'Dubai','4F4E4E','r');
   if(entry.doc!==contents&&entry.doc!==cover){var nav=addText(entry.doc,'العودة إلى محتويات التقرير',[50,3,290,20],10,'DIN Next LT Arabic','756B5F','r');slideLink(entry.doc,entry.rels,nav,2,'rIdCouncilContents');}
   parts.set('ppt/slides/slide'+(i+1)+'.xml',serial(entry.doc));parts.set('ppt/slides/_rels/slide'+(i+1)+'.xml.rels',serial(entry.rels));
  });
  var presentation=xml(decoder.decode(parts.get('ppt/presentation.xml'))),ids=first(presentation,P,'sldIdLst');while(ids.firstChild)ids.firstChild.remove();var presRels=xml(decoder.decode(parts.get('ppt/_rels/presentation.xml.rels')));Array.from(presRels.documentElement.children).filter(function(r){return r.getAttribute('Type').endsWith('/slide');}).forEach(function(r){r.remove();});
  slides.forEach(function(s,i){var id=node(presentation,P,'p:sldId',{id:256+i});id.setAttributeNS(R,'r:id','rIdCouncilSlide'+i);ids.appendChild(id);presRels.documentElement.appendChild(node(presRels,PK,'Relationship',{Id:'rIdCouncilSlide'+i,Type:R+'/slide',Target:'slides/slide'+(i+1)+'.xml'}));});clearTemplateSlideLists(presentation);applyBaseTextDefaults(presentation);embedReportFonts(parts,presentation,presRels);parts.set('ppt/presentation.xml',serial(presentation));parts.set('ppt/_rels/presentation.xml.rels',serial(presRels));
  var types=xml(decoder.decode(parts.get('[Content_Types].xml')));Array.from(types.documentElement.children).filter(function(t){return /^\/ppt\/(slides\/slide\d+\.xml|charts\/|notesSlides\/|embeddings\/)/.test(t.getAttribute('PartName')||'');}).forEach(function(t){t.remove();});slides.forEach(function(s,i){types.documentElement.appendChild(node(types,CT,'Override',{PartName:'/ppt/slides/slide'+(i+1)+'.xml',ContentType:'application/vnd.openxmlformats-officedocument.presentationml.slide+xml'}));});for(var ci=1;ci<=chartCount;ci++)types.documentElement.appendChild(node(types,CT,'Override',{PartName:'/ppt/charts/chart'+ci+'.xml',ContentType:'application/vnd.openxmlformats-officedocument.drawingml.chart+xml'}));if(!Array.from(types.documentElement.children).some(function(n){return n.getAttribute('Extension')==='xlsx';}))types.documentElement.appendChild(node(types,CT,'Default',{Extension:'xlsx',ContentType:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}));if(!Array.from(types.documentElement.children).some(function(n){return n.getAttribute('Extension')==='fntdata';}))types.documentElement.appendChild(node(types,CT,'Default',{Extension:'fntdata',ContentType:S.agendaFonts.contentType}));parts.set('[Content_Types].xml',serial(types));
  var app=xml(decoder.decode(parts.get('docProps/app.xml'))),slideCount=app.getElementsByTagName('Slides')[0];if(slideCount)slideCount.textContent=slides.length;['TitlesOfParts','HeadingPairs'].forEach(function(tag){Array.from(app.getElementsByTagName(tag)).forEach(function(n){n.remove();});});parts.set('docProps/app.xml',serial(app));
  return {blob:zip(parts,'application/vnd.openxmlformats-officedocument.presentationml.presentation'),name:S.reportDisplay.fileTitle(options.reportFileTitle||'تقرير قرارات المجالس')+'.pptx',model:m,slides:slides.length,manifest:manifest,sourceNotes:sourceNotes,sourceNoteManifest:sourceNoteManifest};
 }
 S.councilExport={build:build};
})(window.Saytara=window.Saytara||{});
