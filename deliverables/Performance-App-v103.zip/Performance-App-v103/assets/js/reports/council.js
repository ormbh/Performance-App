/* Council decisions: source-defined follow-up eligibility and year/quarter groups.
 * Every scoped source decision stays in the main report or its exclusion annex. */
(function (S) {
  'use strict';
  var U = S.util, R = S.rules, O = S.order;
  var COLORS = {'متأخر':'651D32','قيد المراجعة':'ABA394','قيد التطوير':'756B5F','منجز':'115E67','بدون حالة':'808080'};

  function sourceYear(it) {
    var cell = it.c && it.c.year, text = it.t && it.t.year;
    if (cell && cell.t === 'n' && Number.isInteger(cell.v) && cell.v >= 1900 && cell.v <= 9999) return cell.v;
    if (cell && cell.t === 's' && /^\d{4}$/.test(String(text || '').trim())) {
      var year = Number(text);
      if (year >= 1900 && year <= 9999) return year;
    }
    return null;
  }
  function period(it) {
    var cell = it.c && it.c.meetingDate, year = sourceYear(it);
    if (cell && cell.t === 'n' && U.validDateSerial(cell.v)) {
      var date = U.ymd(cell.v), quarter = Math.ceil(date.m/3);
      return {key:'quarter-'+date.y+'-'+quarter,name:U.quarterLabel(date.y+' Q'+quarter),
        year:date.y,quarter:quarter,month:date.m,basis:'meetingDate',sourceYear:year,mismatch:year != null && year !== date.y};
    }
    if (year != null) return {key:'year-'+year,name:'سنة الاجتماع '+year+' · الربع غير مسجل',year:year,quarter:null,month:null,basis:'year',sourceYear:year,mismatch:false};
    return {key:'undated',name:'تاريخ اجتماع غير محدد',year:null,quarter:null,month:null,basis:'undated',sourceYear:null,mismatch:false};
  }
  function status(it, data) {
    var cell = it.c && it.c.status;
    if (!cell || cell.t === 'e') return 'بدون حالة';
    var raw = U.xlTrim(cell.t === 's' ? cell.v : String(cell.v),true);
    if (!raw) return 'بدون حالة';
    var known = O.statuses(data,'council').find(function(value){return U.xlTrim(value,true).toLowerCase()===raw.toLowerCase();});
    return known || raw;
  }
  function compare(data, a, b) {
    var ap = period(a), bp = period(b);
    return (ap.year == null ? 1e6 : ap.year)-(bp.year == null ? 1e6 : bp.year) ||
      (ap.month == null ? 13 : ap.month)-(bp.month == null ? 13 : bp.month) ||
      O.status(data,status(a,data),status(b,data),'council') ||
      O.compare(data,'Issuers',a.t.issuer || '',b.t.issuer || '') ||
      O.compare(data,'Departments',a.unit || '',b.unit || '') ||
      O.compare(data,'Entities',a.entity || '',b.entity || '') ||
      String(a.t.no || '').localeCompare(String(b.t.no || ''),'ar',{numeric:true}) || a.seq-b.seq;
  }
  function groups(data, items) {
    var map = new Map();
    items.forEach(function(it){
      var p = period(it);
      if (!map.has(p.key)) map.set(p.key,{key:p.key,name:p.name,year:p.year,quarter:p.quarter,basis:p.basis,items:[]});
      map.get(p.key).items.push(it);
    });
    return Array.from(map.values()).sort(function(a,b){return (a.year == null ? 1e6 : a.year)-(b.year == null ? 1e6 : b.year) || (a.quarter == null ? 5 : a.quarter)-(b.quarter == null ? 5 : b.quarter);})
      .map(function(g){g.items.sort(function(a,b){return compare(data,a,b);});return g;});
  }
  function distribution(data, items, name, read) {
    var map = new Map();
    items.forEach(function(it){var label=read(it),key=U.key(label);if(!map.has(key))map.set(key,{name:label || 'غير مسجل',value:label || '',n:0});map.get(key).n++;});
    return Array.from(map.values()).sort(function(a,b){return name==='status'?O.status(data,a.value,b.value,'council'):O.compare(data,name,a.value,b.value);});
  }
  function stats(data, items) { return distribution(data,items,'status',function(it){var label=status(it,data);return label==='بدون حالة'?'':label;}).map(function(x){if(!x.value)x.name='بدون حالة';return x;}); }
  function followupValue(it) {
    var cell=it.c && it.c.followup;
    return cell && cell.v!=null?String(cell.v):String(it.t && it.t.followup || '');
  }
  function fieldAvailable(data,field) {
    var metadata=data.meta && data.meta.council;
    return !!(metadata && metadata.found && !(metadata.missing || []).includes(S.schema.PF.council.fields[field].h));
  }
  function scopeRows(data,scope) {
    var source=data.byPf && data.byPf.council || (data.items || []).filter(function(it){return it.pf==='council';});
    var titleAvailable=fieldAvailable(data,'title');
    return source.filter(function(it){return (!titleAvailable || R.present(it,'title')) && R.inScope(it,scope);});
  }
  function followupList(data,rows,includeLov) {
    var order=O.list(data,'FollowUp'),rank=new Map(),values=new Map();
    order.forEach(function(value,index){rank.set(value,index);if(includeLov)values.set(value,{v:value,label:value,n:0});});
    rows.forEach(function(it){var value=followupValue(it);if(!values.has(value))values.set(value,{v:value,label:value.trim()?value:'غير مسجل',n:0});values.get(value).n++;});
    return Array.from(values.values()).sort(function(a,b){
      if(a.v===b.v)return 0;if(a.v==='')return 1;if(b.v==='')return -1;
      var ai=rank.has(a.v)?rank.get(a.v):1e6,bi=rank.has(b.v)?rank.get(b.v):1e6;
      return ai-bi || a.v.localeCompare(b.v,'ar',{numeric:true});
    });
  }
  function followupOptions(data,scope) {
    scope=Object.assign({entityMode:'concerned'},scope || {});
    return fieldAvailable(data,'followup')?followupList(data,scopeRows(data,scope),true):[];
  }
  function replyDate(it) { return it.t.replyDate || 'غير مسجل'; }
  function noteFields(it) { return ['latest','notes','plan','entities','letterRef','letterDate','hasReport'].filter(function(field){return String(it.t[field] || '').trim();}); }
  function model(data, scope, options) {
    scope = Object.assign({entityMode:'concerned'},scope || {}); options = options || {};
    var metadata=data.meta && data.meta.council, available=!!(metadata && metadata.found);
    var titleAvailable=available && !(metadata.missing || []).includes(S.schema.PF.council.fields.title.h);
    var eligibilityAvailable=R.metricAvailable(data,'councilTotal',scope),statusAvailable=R.metricAvailable(data,'councilDone',scope);
    var followupAvailable=fieldAvailable(data,'followup'),followupSelection=U.selection(options.followup),base=scopeRows(data,scope);
    var all = base.filter(function(it){return !followupAvailable || !followupSelection.length || followupSelection.includes(followupValue(it));}).slice().sort(function(a,b){return compare(data,a,b);});
    var items=eligibilityAvailable?all.filter(function(it){return R.test('councilTotal',it);}):[],excluded=eligibilityAvailable?all.filter(function(it){return !R.test('councilTotal',it);}):[],undetermined=eligibilityAvailable?[]:all;
    var count=function(metric){return R.metricAvailable(data,metric,scope)?items.filter(function(it){return R.test(metric,it);}).length:null;};
    var blank=function(rows){return rows.filter(function(it){return !U.key(it.unit);}).length;};
    var missingDate=items.filter(function(it){var c=it.c.meetingDate;return !c || c.t!=='n' || !U.validDateSerial(c.v);});
    var out={all:all,items:items,eligible:items,excluded:excluded,undetermined:undetermined,allTotal:all.length,total:eligibilityAvailable?items.length:null,excludedTotal:eligibilityAvailable?excluded.length:null,
      done:count('councilDone'),progress:count('councilProgress'),late:count('councilLate'),unknownStatus:count('councilNoStatus'),
      statuses:statusAvailable?stats(data,items):[],groups:groups(data,items),excludedGroups:groups(data,excluded),undeterminedGroups:groups(data,undetermined),
      followup:followupAvailable?followupList(data,all,false).map(function(value){return {name:value.label,value:value.v,n:value.n};}):[],
      followupSelection:followupSelection,followupOptions:followupAvailable?followupList(data,base,true):[],followupAvailable:followupAvailable,
      issuers:distribution(data,items,'Issuers',function(it){return it.t.issuer || '';}),
      blankUnitCount:blank(all),eligibleBlankUnitCount:blank(items),excludedBlankUnitCount:blank(excluded),
      missingDateCount:missingDate.length,undated:items.filter(function(it){return period(it).basis==='undated';}),
      dateMismatchCount:all.filter(function(it){return period(it).mismatch;}).length,
      notes:all.filter(function(it){return noteFields(it).length;}),
      available:available,titleAvailable:titleAvailable,eligibilityAvailable:eligibilityAvailable,statusAvailable:statusAvailable,missingColumns:metadata && metadata.missing || [],
      year:data.year,date:U.fmtDate(data.today),period:(S.reportDisplay?S.reportDisplay.clean(options.reportPeriodText,100):options.reportPeriodText) || 'حتى تاريخ '+U.fmtDate(data.today),
      source:data.file && data.file.name || '',scope:{sector:scope.sector || '',unit:scope.unit || '',entity:scope.entity || '',entityMode:'concerned'}};
    out.reconciled=statusAvailable?out.done+out.progress+out.late+out.unknownStatus===out.total:null;
    return out;
  }
  function summaryText(m) {
    if (!m.available) return 'جدول قرارات المجالس غير متاح في الملف.';
    if (!m.allTotal) return 'لا توجد قرارات ضمن النطاق المحدد.';
    if (!m.eligibilityAvailable) return 'القرارات المسجلة '+U.fmtN(m.allTotal)+'؛ تصنيف متطلبات المتابعة غير متاح بسبب نقص أعمدة المصدر.';
    if (!m.statusAvailable) return 'تتطلب المتابعة '+U.fmtN(m.total)+' من أصل '+U.fmtN(m.allTotal)+' قراراً؛ مستويات الإنجاز غير متاحة بسبب نقص أعمدة المصدر.';
    return 'تتطلب المتابعة '+U.fmtN(m.total)+' من أصل '+U.fmtN(m.allTotal)+' قراراً؛ المنجز '+U.fmtN(m.done)+
      (m.total?' ('+(m.done/m.total*100).toFixed(1).replace(/\.0$/,'')+'%)':'')+'، وقيد العمل '+U.fmtN(m.progress)+'، والمتأخر '+U.fmtN(m.late)+'.';
  }
  S.councilReport={model:model,period:period,sourceYear:sourceYear,status:status,compare:compare,groups:groups,stats:stats,
    replyDate:replyDate,noteFields:noteFields,followupValue:followupValue,followupOptions:followupOptions,summaryText:summaryText,colors:COLORS};
})(window.Saytara=window.Saytara || {});
