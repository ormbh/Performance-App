# Performance App v116

Extract the complete ZIP, then open `index.html` in your browser. All fonts,
images and scripts are local; no server or installation is required by the app.
Imported data is processed on your device.

## Report workspace

Primary navigation is separate from page tools. **محفظة المشاريع** opens **مستجدات محفظة المشاريع**. A compact scope toolbar shows
active selections even when the filters are closed. Open **تصفية** to select
multiple values and search the option list. Values within one filter form a union;
different filters intersect. **مسح التصفية** resets the scope. Empty selection
means all values. Blank source values remain distinct and available for selection.
Sector/unit filters use the latest user-supplied reference: six sectors and 23
units, in the supplied order. Four known legacy unit names map to approved filter
labels: البحث والرصد → الأبحاث والرصد; الأرشفة → المراسلات والأرشفة; and
الاستراتيجيات → الإستراتيجيات in the economic/social unit names only.
Filter choices group these explicit aliases, equivalent spacing, Arabic presentation
forms and invisible formatting characters into one visible option. Selecting it includes every exact
source token required by existing filter rules; records and identifiers are not
merged or rewritten. Genuinely different values sharing a translated label remain
separate and display their source values. Imported classification, identifiers and exact source values stay unchanged.
Unknown and blank source values remain selectable; no record is reassigned to a
sector. Parent-dependent choices use the supplied relationships alongside actual
source choices. The parent Secretariat remains context in the project sector menu.
Unlisted values are marked **قيمة أخرى من الملف**. A known unit recorded under a
different selected source sector is marked **تبعيتها مختلفة في الملف**; the source
classification remains intact. Option search finds approved and legacy names.
Existing partial selections stay intact until you change them; group chips, counts and summaries do not duplicate aliases.
Filter popups have one scrollable options list. The title, search field and
select-all/clear controls remain visible. Short screens use the available viewport
instead of clipping these controls; focused filters stay open when it shrinks.

The strategy card omits the unmeasured-count line; its measurement population and
averages remain unchanged. The legislation card names the deadline basis at the
bottom right: **تجاوز الموعد: تاريخ الإنجاز الفعلي بعد أحد مواعيد SLC أو التمديد أو إدارة التشريعات.**
For records whose KPI is **في الموعد**, the mold compares completion independently
against each available deadline; completion later than any one qualifies. An extension does not replace earlier
dates in this rule. The selected calculation date is not that comparison date.
This explanation preserves the source rule and refers to completed work,
separately from current delays.
Native pie reports place counts and percentages in the editable legend so small
slices stay legible. Legend annotations reflect the scope at export time; numeric
chart series and embedded workbooks remain editable.

One shared footer appears throughout the app, including upload and error screens:
**الأمانة العامة للمجلس التنفيذي لإمارة دبي حقوق النشر © 2026 · جميع الحقوق محفوظة**.
The legal release year remains separate from the selected calculation year.
It sits at the bottom of short pages and follows all content on long pages;
it does not cover tables or controls. On desktop, the source filename, calculation date and copyright share one row.
Narrow screens wrap the complete text without clipping. Browser-printed pages
repeat the same copyright wording; source metadata remains screen-only.
Derived project overdue labels
use **متأخر** consistently across overview, drilldowns and reports. Legislation
**تجاوز الموعد** remains a separate completed-after-deadline population.
The follow-up summary omits **المسؤول** on screen and print; owner fields remain
in source records, search and full details.

The council card places **القرارات التي تتطلب متابعة** at the bottom left,
alongside the unapproved-status note on the right when present. Each quarter
has its own bordered beige box (#EFEBE7), in RTL order, on screen and monthly print. Projects
outside the reporting-year quarters or without a date remain separately visible.

Monthly report content appears first: executive portfolios on the right and
projects on the left, matching the RTL source mold. Strategy, decisions and
legislation use the same metric typography. Data tables are displayed as sections
rather than closed disclosures; long tables and full notes remain readable.

**طباعة التقرير** prints the currently filtered report directly. The adjacent
**إعدادات الطباعة** opens a native dialog without scrolling away from the filters.
Calculation-date and A4/A3 changes apply immediately; **حفظ الإعدادات** closes the
dialog and returns focus to the same print button. The file name, selected
calculation date and source reference (when different) appear at the screen footer.
Monthly printed pages retain the shared organizational/copyright wording only.
The source filename and calculation-date footer line are removed; the report
cutoff stays in the header.
Source/reporting/history dates retain separate meanings. Help and source-quality
explanations can still collapse.

No demonstration records, demonstration-file fingerprint, data-purpose selector
or automatic sample classification are included. Retired purpose metadata and
explicitly marked sample caches are cleared during upgrade. Files you import
normally retain the existing local-session behavior. The browser can keep the
imported file in session storage for reload/new-tab workflows; nothing is sent to
an external service. Source files and full notes remain unchanged.

## Projects portfolio updates

**مستجدات محفظة المشاريع** implements the approved chart-led concept B, using the
monthly dashboard's cards, right/left layout and visible comparison data:

1. One organizational hierarchy, with sector totals and their included units in
   the same area. Direct units appear once; the parent Secretariat stays context.
   Parent and child rows represent the same projects and must not be added twice.
   Project counts and revised source budgets remain visible together.
2. Source delivery statuses, completed-project percentage, unweighted mean of
   valid recorded progress, planned end quarters and open-project date windows.
   Each quarter retains its own beige box.
3. Six source finance fields and their numeric coverage. The spending ratio uses
   only projects with both a positive revised budget and nonnegative expenditure.
4. Manager workload, showing open projects with registered projects, overdue
   exposure and upcoming dates. Missing managers remain visible. Counts and
   budgets are not competence, staffing-capacity or efficiency ratings.
5. One combined type/priority area. Each joint group comes from the selected
   project records and shows its count and revised-budget coverage; marginal
   type and priority totals are not multiplied to invent intersections.

Organization and classification Count/Budget switches change only the chart
scale. They do not alter the filtered records, calculations or comparison
population. Source values remain visible. Budget charts distinguish positive,
negative, recorded-zero and unavailable amounts. The seven source-status
populations are exclusive; overdue is shown separately because it overlaps open
projects. Full comparison rows and source notes remain visible.

A visible table follows with source notes, date-based delays and data gaps. Each
project appears once in that table; its complete manager and finance notes remain
readable. All cards, tables, drilldowns and print output share the same searchable
multi-select filters, including the native project-manager field. Returning from
records restores the selected scope. No project names, managers, budgets or
issues are invented. The parent Secretariat appears as organizational context.

Completed-project percentage is completed status divided by all selected named
projects. Mean recorded progress uses only numeric percentages from 0 to 100 and
shows its population. Neither percentage is budget-weighted. Unknown or missing
values are retained separately. The approved budget headline uses the revised
budget source field, matching the monthly dashboard; original budget remains a
separate finance field. Partial financial sums show their coverage.

Up/down arrows require two different, confirmed monthly snapshots and the approved
exact project key. Unchanged indicators remain blank. Missing or duplicate keys
withhold arrows; missing prior data is never zero. The same filters are applied to
both snapshots. Financial and mean-progress changes are withheld when numeric
coverage is incomplete. Date-derived changes require each calculation cutoff to
match its confirmed snapshot date; quarter changes also require the same year.
A category present only in the previous scope may show a negative count change,
without describing those projects as cancelled.

Planned end dates follow the existing source rule: the last day of the end month.
The 1–30, 31–60 and 61–90-day windows are disjoint; current-month due projects are
a separate view. Overdue counts overlap open statuses and must not be added to the
status total. No on-time-delivery claim is inferred without actual completion dates.
Spending is separate from achievement; source allocation labels remain unchanged.
Status counts use the same case-insensitive, space-preserving source equality as
the monthly mold. Other status values stay unresolved. The separate overdue rule
retains the mold's trimmed Active/Not Started eligibility; displayed labels do not
change those calculations.

**عرض جميع البنود** opens the filtered follow-up list in the same tab, including
when browser popup opening is blocked. Council report defaults use
**مستجدات قرارات المجالس** plus the selected calculation year and
**حتى تاريخ** plus the selected cutoff. Custom titles and periods remain intact
until you reset them.

## Source validation

The upload screen uses the same compact, top-aligned header as the report screens,
with no empty navigation row before a file is loaded. The space beside the TEC
logo remains empty.

Data validation recognizes the same four approved legacy organization aliases as
the filters, against the workbook's actual lists. It does not rewrite cells or
classifications. Parent checks use unique source relationships; conflicting or
blank parents are not guessed. Unknown values remain reviewable.

The data-note count counts observations, not distinct records; a record can have
more than one note. The review page identifies the number of affected records.
On desktop, long grouped source-row lists wrap within their column so the
problem and proposed fix remain visible. Narrow screens retain the labelled-row
layout. All row references and exported note content remain complete. The
affected-record caption still omits some grouped observations; its counting
definition is pending review and has not been changed in this layout correction.
Rows containing business data with a blank title remain preserved and flagged.
A scoped notice on the monthly and project screens and print explains that the mold's totals
may exclude them. Status and quarter formulas are not silently given a different
denominator. Quarter diagnostics distinguish genuine out-of-year/undated records
from disagreement between date-based distribution and title-based totals.

## Measurement and comparison definitions

The approved record connections use these exact source fields:

| Portfolio | Matching key |
| --- | --- |
| المشاريع الخاصة | `Source.Name` + `اسم المشروع` |
| مشاريع بموازنة استراتيجية | `#` + `اسم المشروع` + `القطاع` |
| الأجندة السنوية | `Source.Name` + `الموضوع` |
| قرارات المجالس | `رقم القرار` + `Source.Name` + `الموضوع` |
| التشريعات | `الرقم MCMS` + `القطاع` + `عنوان التشريع` |
| استراتيجية الأمانة العامة | `Source.Name` + `المؤشر` |

`Source.Name` must be an actual column inside the corresponding Excel table.
It is not substituted with the uploaded workbook filename, sheet, unit or row
number. Records with any missing key part remain loaded, but their incomplete
connections are unavailable for exact monthly matching. Source.Name alone does not turn
an otherwise unused template row into a business record.

All parts must be present and valid. Keys are encoded as typed tuples, keeping
literal text, whitespace, leading zeros and numeric zero intact. Portfolio
namespaces keep unrelated portfolios separate. Existing Record ID columns do
not override these approved connections. Duplicate complete keys are quarantined
in both periods without deleting rows. Data Notes names the missing components
or duplicate connection and gives the source row references.

The full tuple must match across versions. Changing a field used in the key
creates a different connection; the app does not infer a rename or merge it with
another record. One-sided complete keys describe presence in one version only,
not cancellation or completion. Missing tables or incomplete keys in the opposite
portfolio prevent definitive one-sided classification. All report calculations,
selected-date behavior, note/settings storage and filters retain their definitions.

Annual KPI zeros count as measured only with an explicit measurement-state field:
`حالة القياس`, `Measurement State` or `Measurement Status`. Supported values:
`مقاس`/`Measured`, `غير مقاس`/`Unmeasured`, `لا ينطبق`/`Not applicable`.
Absent or blank state retains the existing nonzero measurement rule. Invalid,
missing, not-applicable and conflicting states are distinguished. Incompatible
measurement definitions withhold comparisons and show the reason. Result and
target averages use their separate source populations; thresholds and weighting
are not invented. Zero metric readings display an ASCII dash (-); unavailable values use an em dash.
Their numeric values and measurement states remain distinct and unchanged;
unchanged comparison indicators stay blank.

The application reads cached Excel formula results. It does not recalculate all
Excel formulas or refresh Power Query. Named tables and valid renamed sheets are
supported. Ambiguous identifiers are retained for review and excluded from
resolved historical matches rather than merged by title or row number.

## Upgrade and verification

Keep the prior app and browser data until you have checked your notes/settings.
Use the same browser/profile and location where possible. Full note text and
existing storage keys are preserved. File-origin storage behavior varies between
browsers; back up notes before moving folders or changing profiles.

Independent workbook arithmetic and actual browser imports **passed** for v116.
The organizational hierarchy reconciles actual department membership to its
parent; type/priority cells use exact joint records. Manager assignments, open
work, valid dates and next-30-day subsets agree with the source rules. Existing
status, progress, finance, exact-key, numeric-coverage and historical guards
remain intact. Missing fields, duplicate/incomplete identifiers, renamed sheets,
compound filters, chart scales and contributor drills were challenged privately.

Actual keyboard/focus, manager row/table associations, filter search/reset,
malformed-file recovery, responsive RTL and scope/date preservation **passed**.
Count/Budget controls change the chart scale only; native printing retains the
same selected scope. Complete source notes remain visible in the main issues
table and its drilldown. Actual populated, empty, paired, filtered and long-note
PDF pages **passed** visual review for source text, RTL, chart readings and
pagination; the monthly print regression also **passed**. Short groups stay with
their readings; longer tables repeat headers and full notes may continue across
pages. The accompanying release verification document records exact
clean-extracted ZIP checks and remaining limits.

Default detailed-report titles derive their year from the selected cutoff; the
displayed period defaults to the selected calculation cutoff. User-entered
report titles/periods are preserved. The new portfolio title is
**مستجدات محفظة المشاريع**.

Native file opening was blocked by the managed browser policy, so Windows Edge
or Chrome double-click startup is **not run** in this environment. Physical
printing, full screen-reader certification, Microsoft PowerPoint interactive
editing and Excel/Power Query refresh are also **not run** in this release.
PowerPoint assets are unchanged. Verification uses test/reference molds and
private fictional dated pairs; no real organizational monthly comparison is
asserted. Source completeness, title eligibility and the existing Data Notes
counting/validation review decisions remain unresolved; no missing titles or
measurements are invented. This is not an unconditional production-readiness
verdict.

Readable source modules are bundled locally by `python tools/build-bundles.py`.
`python tools/build-bundles.py --check` checks bundle consistency.
