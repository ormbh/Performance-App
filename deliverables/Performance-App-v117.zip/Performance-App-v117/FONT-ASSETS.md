# Font asset provenance – 8 October 2026 (Asia/Dubai)

The supplied v102 ZIP contains these font assets and embedded Dubai report fonts. This release retains those supplied assets; it does not introduce downloaded fonts or treat a statement in an attached document as a new user instruction. Physical license documents were not supplied or independently verified in this review.

The two supplied DIN Arabic faces have OS/2 fsType 4 (preview/print). The existing PowerPoint exporter excludes DIN from embedded font bytes; it references DIN by family for headings. The two supplied Dubai faces have fsType 8 (editable embedding), and the exporter embeds converted Dubai faces. These technical flags do not substitute for licensing evidence.

`assets/fonts/OFL.txt` identifies Noto Arabic and does not establish rights for the DIN/Dubai files. No Noto font file was found in the supplied ZIP. No new font-license or security review is claimed in this release. Original supplied fonts and original ZIP are unchanged.
