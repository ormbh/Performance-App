/*
 * Performance reporting · workbook schema
 * Describes the uploaded Excel template: which Excel Table holds each portfolio,
 * the header of every column, its type and the list of values (LOV) behind it.
 * Headers are matched after trimming spaces, so "الإدارة " and "الإدارة" are equal.
 *
 * Field types: text · lov · date · month · year · num · progress (0–1 fraction)
 *              pct (KPI percentage, 0–1 fraction) · calc (recomputed by rules.js)
 */
(function (S) {
  'use strict';

  var PF = {
    agenda: {
      ar: 'الأجندة السنوية', src: 'Annual Agenda', table: 'ECSAC', sheet: 'الأجندة_السنوية',
      fields: {
        type: { h: 'تصنيف الموضوع', type: 'lov', lov: 'TopicTypes' },
        coord: { h: 'منسق الأمانة العامة', type: 'text' },
        title: { h: 'الموضوع', type: 'text' },
        entity: { h: 'الجهة المعنية', type: 'lov', lov: 'Entities' },
        entities: { h: 'الجهات المساهمة', type: 'text' },
        sector: { h: 'القطاع', type: 'lov', lov: 'Sectors' },
        unit: { h: 'الإدارة', type: 'lov', lov: 'Departments' },
        status: { h: 'مستوى الإنجاز', type: 'lov', lov: 'AgendaStatus' },
        quarter: { h: 'ربع الإنجاز', type: 'lov', lov: 'Quarters' },
        month: { h: 'شهر الإنجاز', type: 'month', lov: 'Months' },
        year: { h: 'سنة الإنجاز', type: 'year', lov: 'Years' },
        newMonth: { h: 'الموعد الجديد إن وجد (شهر)', type: 'month', lov: 'Months' },
        notes: { h: 'ملاحظات فريق الأمانة العامة', type: 'text' },
        dateSac: { h: 'تاريخ العرض على مجلس الشؤون', type: 'date' },
        dateEc: { h: 'تاريخ العرض على المجلس التنفيذي', type: 'date' },
        rapporteur: { h: 'ملاحظات مقرر المجالس', type: 'text' }
      },
      search: ['type', 'entity', 'sector', 'unit', 'status', 'notes']
    },

    council: {
      ar: 'قرارات المجالس', src: 'Decisions', table: 'Resolutions', sheet: 'القرارات',
      fields: {
        plan: { h: 'ضمن خطة دبي أو أجنداتها', type: 'lov', lov: 'PlanStatus' },
        coord: { h: 'منسق الأمانة العامة', type: 'text' },
        title: { h: 'الموضوع', type: 'text' },
        no: { h: 'رقم القرار', type: 'text' },
        latest: { h: 'القرار الأخير', type: 'text' },
        issuer: { h: 'صادر عن', type: 'lov', lov: 'Issuers' },
        year: { h: 'سنة الاجتماع', type: 'year', lov: 'Years' },
        meetingDate: { h: 'تاريخ الاجتماع', type: 'date' },
        letterRef: { h: 'مرجع الخطاب الصادر بالقرار', type: 'text' },
        entity: { h: 'الجهة المعنية', type: 'lov', lov: 'Entities' },
        entities: { h: 'الجهات المساهمة', type: 'text' },
        sector: { h: 'القطاع', type: 'lov', lov: 'Sectors' },
        unit: { h: 'الإدارة', type: 'lov', lov: 'Departments' },
        followup: { h: 'متطلبات المتابعة', type: 'lov', lov: 'FollowUp' },
        letterDate: { h: 'تاريخ إصدار خطاب المتابعة', type: 'date' },
        replyDate: { h: 'تاريخ الرد', type: 'date' },
        status: { h: 'مستوى الإنجاز', type: 'lov', lov: 'WorkStatus' },
        progress: { h: 'نسبه الإنجاز', type: 'progress', lov: 'CompletionPercent' },
        hasReport: { h: 'يتوفر تقرير بالمستجدات؟', type: 'lov', lov: 'YesNo' },
        notes: { h: 'ملاحظات', type: 'text' }
      },
      search: ['latest', 'issuer', 'entity', 'sector', 'unit', 'followup', 'status', 'notes']
    },

    legislation: {
      ar: 'التشريعات', src: 'Legislation', table: 'Legislations', sheet: 'التشريعات',
      fields: {
        seq: { h: '#', type: 'text' },
        mcms: { h: 'الرقم MCMS', type: 'text' },
        title: { h: 'عنوان التشريع', type: 'text' },
        sector: { h: 'القطاع', type: 'lov', lov: 'Sectors' },
        unit: { h: 'الإدارة', type: 'lov', lov: 'Departments' },
        received: { h: 'تاريخ استلام التشريع', type: 'date' },
        assigned: { h: 'تاريخ التحويل للفريق', type: 'date' },
        slc: { h: 'تاريخ الإنجاز وفق (SLC)', type: 'date' },
        ext: { h: 'تمديد حتى', type: 'date' },
        deptDate: { h: 'التاريخ المحدد من إدارة التشريعات', type: 'date' },
        actual: { h: 'تاريخ الانجاز الفعلي', type: 'date' },
        sent: { h: 'تاريخ الإرسال', type: 'date' },
        kpi: { h: 'مؤشرات الأداء', type: 'text' },
        updates: { h: 'مستجدات', type: 'text' },
        state: { h: 'الحالة', type: 'text' },
        issuance: { h: 'الإصدار', type: 'text' },
        sender: { h: 'الجهة المرسلة', type: 'text' },
        stage: { h: 'مرحلة التشريع', type: 'text' },
        nature: { h: 'طبيعة التشريع', type: 'text' },
        year: { h: 'السنة', aliases: ['Year'], type: 'year', lov: 'Years' },
        late: { h: 'Late KPI', type: 'calc' },
        overrun: { h: 'تجاوز الموعد', type: 'calc' },
        legislationMonth: { h: 'شهر التشريع', type: 'calc' }
      },
      search: ['sector', 'unit', 'kpi', 'updates', 'state', 'sender', 'stage', 'nature']
    },

    special: {
      ar: 'المشاريع الخاصة', src: 'Special Projects', table: 'Special', sheet: 'المشاريع_الخاصة',
      fields: {
        lead: { h: 'مشاريع سموه', type: 'lov', lov: 'YesNo' },
        pm: { h: 'مدير المشروع', type: 'text' },
        title: { h: 'اسم المشروع', type: 'text' },
        desc: { h: 'نبذة حول المشروع', type: 'text' },
        entity: { h: 'الجهة المعنية', type: 'lov', lov: 'Entities' },
        entities: { h: 'الجهات المساهمة', type: 'text' },
        sector: { h: 'القطاع', type: 'lov', lov: 'Sectors' },
        unit: { h: 'الإدارة', type: 'lov', lov: 'Departments' },
        units: { h: 'إدارات مساهمة', type: 'text' },
        startMonth: { h: 'بدء المشروع (الشهر)', type: 'month', lov: 'Months' },
        startYear: { h: 'بدء المشروع (السنة)', type: 'year', lov: 'Years' },
        endMonth: { h: 'انتهاء المشروع (الشهر)', type: 'month', lov: 'Months' },
        endYear: { h: 'انتهاء المشروع (السنة)', type: 'year', lov: 'Years' },
        status: { h: 'مستوى الإنجاز', type: 'lov', lov: 'WorkStatus' },
        progress: { h: 'نسبة الإنجاز', type: 'progress', lov: 'CompletionPercent' },
        budget: { h: 'الميزانية المخصصة إن وجدت', type: 'num' },
        achieved: { h: 'المنجز للآن', type: 'text' },
        next: { h: 'المخطط في المرحلة المقبلة', type: 'text' },
        notes: { h: 'ملاحظات مدير المشروع', type: 'text' },
        recs: { h: 'توصيات إدارة الأداء والتنفيذ', type: 'text' }
      },
      search: ['lead', 'desc', 'entity', 'sector', 'unit', 'status', 'achieved', 'next', 'notes', 'recs']
    },

    secretariat: {
      ar: 'مشاريع بموازنة استراتيجية', src: 'Corporate Projects', table: 'Projects', sheet: 'مشاريع_الأمانة',
      fields: {
        no: { h: '#', type: 'text' },
        sector: { h: 'Sector', aliases: ['القطاع'], type: 'lov', lov: 'Sectors' },
        unit: { h: 'Department / Section', aliases: ['الإدارة', 'الوحدة التنظيمية'], type: 'lov', lov: 'Departments' },
        title: { h: 'Project Name', aliases: ['اسم المشروع'], type: 'text' },
        desc: { h: 'Project Description', aliases: ['نبذة حول المشروع'], type: 'text' },
        priority: { h: 'Priority', aliases: ['أولوية', 'الأولوية'], type: 'lov', lov: 'ProjectPriority' },
        ptype: { h: 'Type', aliases: ['نوع', 'نوع المشروع'], type: 'lov', lov: 'ProjectType' },
        pm: { h: 'PM', aliases: ['مدير المشروع'], type: 'text' },
        start: { h: 'Start Date', aliases: ['بدء المشروع', 'تاريخ بدء المشروع'], type: 'date' },
        end: { h: 'End Date', aliases: ['انتهاء المشروع', 'تاريخ انتهاء المشروع'], type: 'date' },
        approved: { h: 'Approved Budget', aliases: ['الموازنة المعتمدة', 'الموازنة الأصلية'], type: 'num' },
        revised: { h: 'Revised Budget', aliases: ['الموازنة المعتمدة الجديدة'], type: 'num' },
        committed: { h: 'Committed', aliases: ['المخصص'], type: 'num' },
        nonCommitted: { h: 'Non-Committed', aliases: ['غير المخصص'], type: 'num' },
        workDone: { h: 'Work Completed', aliases: ['المنفق الفعلي حسب العمل', 'قيمة الأعمال المنجزة'], type: 'num' },
        spent: { h: 'Actual Spent As per the invoices', aliases: ['المنفق الفعلي'], type: 'num' },
        status: { h: 'Status', aliases: ['مستوى الإنجاز'], type: 'lov', lov: 'ProjectStatus' },
        progress: { h: '% Complete', aliases: ['نسبة الإنجاز'], type: 'progress', lov: 'CompletionPercent' },
        ownerRemarks: { h: 'Project Owner Remarks', aliases: ['ملاحظات مدير المشروع', 'ملاحظات مالك المشروع'], type: 'text' },
        financeRemarks: { h: 'Finance Remarks', aliases: ['ملاحظات المالية'], type: 'text' },
        quarter: { h: 'الربع', aliases: ['Quarter'], type: 'calc' },
        late: { h: 'Late KPI', type: 'calc' }
      },
      search: ['sector', 'unit', 'desc', 'priority', 'ptype', 'status', 'ownerRemarks', 'financeRemarks']
    },

    kpi: {
      ar: 'المؤشرات', src: 'KPIs', table: 'Strategy', sheet: 'استراتيجية_الأمانة',
      fields: {
        sector: { h: 'القطاع', type: 'lov', lov: 'Sectors' },
        unit: { h: 'الإدارة', type: 'lov', lov: 'Departments' },
        title: { h: 'المؤشر', type: 'text' },
        freq: { h: 'دورية القياس', type: 'lov', lov: 'Frequency' },
        num: { h: 'البسط', type: 'num' },
        den: { h: 'المقام', type: 'num' },
        q1n: { h: 'البسط Q1', type: 'num' }, q1d: { h: 'المقام Q1', type: 'num' }, q1: { h: 'نتيجة Q1', type: 'pct' },
        q2n: { h: 'البسط Q2', type: 'num' }, q2d: { h: 'المقام Q2', type: 'num' }, q2: { h: 'نتيجة Q2', type: 'pct' },
        q3n: { h: 'البسط Q3', type: 'num' }, q3d: { h: 'المقام Q3', type: 'num' }, q3: { h: 'نتيجة Q3', type: 'pct' },
        q4n: { h: 'البسط Q4', type: 'num' }, q4d: { h: 'المقام Q4', type: 'num' }, q4: { h: 'نتيجة Q4', type: 'pct' },
        result: { h: 'نتيجة العام', type: 'pct' },
        measurementState: { h: 'حالة القياس', aliases: ['Measurement State', 'Measurement Status'], type: 'text', optional: true },
        target: { h: 'المستهدف للعام', type: 'pct' },
        notes: { h: 'ملاحظات', type: 'text' },
        strategic: { h: 'الهدف الاستراتيجي', type: 'lov', lov: 'StrategicObjectives' },
        operational: { h: 'الأهداف التشغيلية', type: 'lov', lov: 'OperationalObjectives' },
        owners: { h: 'ملاك الهدف', type: 'text' },
        objWeight: { h: 'الوزن النسبي للهدف', type: 'text' },
        share: { h: 'نسبة مساهمة الادارات', type: 'text' },
        weight: { h: 'وزن المؤشر', type: 'text' },
        formula: { h: 'المعادلة', type: 'text' }
      },
      search: ['sector', 'unit', 'freq', 'measurementState', 'strategic', 'operational', 'owners', 'notes', 'formula']
    }
  };

  /* Order used by Search (same as the Excel search sheet) and by the tabs. */
  var ORDER = ['agenda', 'council', 'legislation', 'special', 'secretariat', 'kpi'];

  /* User-approved connections (9 October 2026). Source.Name is a literal
     workbook column, never the uploaded filename or a generated label.
     It is optional for reporting, but required by the four matching keys.
     Original source values remain untouched; aliases only locate headers. */
  ['agenda', 'council', 'special', 'kpi'].forEach(function (pf) {
    PF[pf].fields.sourceName = { h: 'Source.Name', type: 'text', optional: true, matchingOnly: true };
  });
  var MATCHING_VERSION = 'approved-connections-2026-10-09';
  var MATCHING = {
    special: { fields: ['sourceName', 'title'], labels: ['Source.Name', 'اسم المشروع'] },
    secretariat: { fields: ['no', 'title', 'sector'], labels: ['#', 'اسم المشروع', 'القطاع'] },
    agenda: { fields: ['sourceName', 'title'], labels: ['Source.Name', 'الموضوع'] },
    council: { fields: ['no', 'sourceName', 'title'], labels: ['رقم القرار', 'Source.Name', 'الموضوع'] },
    legislation: { fields: ['mcms', 'sector', 'title'], labels: ['الرقم MCMS', 'القطاع', 'عنوان التشريع'] },
    kpi: { fields: ['sourceName', 'title'], labels: ['Source.Name', 'المؤشر'] }
  };

  /* Lists of values on the LOVs sheet. `cols` are the table's column headers;
     the defaults below are the values in the template and are used only when the
     uploaded file has no such table. */
  var LOVS = {
    Entities: { table: 'Entities', cols: ['الجهة المعنية'] },
    Sectors: { table: 'Sectors', cols: ['القطاع'], defaults: ['الأمانة العامة للمجلس التنفيذي', 'الحوكمة', 'التنمية المستدامة', 'الاقتصاد والتنمية الاجتماعية', 'التميز والخدمات الحكومية', 'الاتصال الحكومي وشؤون الأمانة العامة'] },
    Departments: { table: 'Departments', cols: ['القطاع', 'الوحدة التنظيمية'] },
    Quarters: { table: 'Quarters', cols: ['الربع'], defaults: ['الربع الأول', 'الربع الثاني', 'الربع الثالث', 'الربع الرابع'] },
    Months: { table: 'Months', cols: ['الشهر'], defaults: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'] },
    Years: { table: 'Years', cols: ['الأعوام'] },
    TopicTypes: { table: 'TopicTypes', cols: ['تصنيف الموضوع'], defaults: ['الأجندة السنوية', 'مستجد'] },
    Issuers: { table: 'Issuers', cols: ['الجهة المسؤولة / صادر عن'], defaults: ['المجلس التنفيذي', 'مجلس الشؤون الاستراتيجية', 'الأمانة العامة للمجلس التنفيذي'] },
    AgendaStatus: { table: 'AgendaStatus', cols: ['مستوى الإنجاز'], defaults: ['متأخر', 'جاهز للعرض', 'قيد المراجعة', 'قيد التطوير', 'منجز'] },
    WorkStatus: { table: 'WorkStatus', cols: ['مستوى الإنجاز'], defaults: ['متأخر', 'قيد المراجعة', 'قيد التطوير', 'منجز'] },
    CompletionPercent: { table: 'CompletionPercent', cols: ['نسب الإنجاز'] },
    PlanStatus: { table: 'PlanStatus', cols: ['ضمن خطة دبي أو أجنداتها'], defaults: ['ضمن الخطة', 'للإضافة', 'خارج الخطة', 'لا ينطبق'] },
    YesNo: { table: 'YesNo', cols: ['القيمة'], defaults: ['نعم', 'لا'] },
    FollowUp: { table: 'FollowUp', cols: ['متطلبات المتابعة'], defaults: ['مغلق (لا يتطلب متابعة)', 'رسالة رسمية', 'بريد من الوحدة التنظيمية', 'ملغي'] },
    Frequency: { table: 'Frequency', cols: ['دورية القياس'], defaults: ['ربع سنوي', 'نصف سنوي', 'سنوي'] },
    StrategicObjectives: { table: 'StrategicObjectives', cols: ['الهدف الاستراتيجي'] },
    OperationalObjectives: { table: 'OperationalObjectives', cols: ['الهدف الاستراتيجي', 'الهدف التشغيلي'] },
    ProjectStatus: { table: 'Table24', cols: ['مستوى الإنجاز'], defaults: ['Cancelled', 'Frozen', 'Not Started', 'Active', 'Completed', 'Transferred'] },
    ProjectType: { table: 'ProjectType', cols: ['نوع'], defaults: ['Strategic', 'Operational'] },
    ProjectPriority: { table: 'ProjectPriority', cols: ['أولوية'], defaults: ['H', 'M', 'L'] }
  };

  /* User-approved sector → units (2026-10-09), used only when the file has no
     Departments table. Actual workbook relationships retain their authority. */
  var DEFAULT_UNITS = [
    ['الأمانة العامة للمجلس التنفيذي', 'مكتب الأمين العام'], ['الأمانة العامة للمجلس التنفيذي', 'الشراكات والعلاقات الدولية'],
    ['الأمانة العامة للمجلس التنفيذي', 'مكتب التدقيق الداخلي'], ['الأمانة العامة للمجلس التنفيذي', 'مكتب خطة دبي'],
    ['الأمانة العامة للمجلس التنفيذي', 'الأبحاث والرصد'],
    ['الحوكمة', 'الحوكمة'], ['الحوكمة', 'التشريعات الحكومية'], ['الحوكمة', 'التنفيذ والأداء'],
    ['التنمية المستدامة', 'السياسات والاستراتيجيات الصحية والعدل'], ['التنمية المستدامة', 'السياسات والاستراتيجيات البيئية والبنية التحتية'],
    ['الاقتصاد والتنمية الاجتماعية', 'السياسات والإستراتيجيات الاجتماعية'], ['الاقتصاد والتنمية الاجتماعية', 'السياسات والإستراتيجيات الاقتصادية'],
    ['التميز والخدمات الحكومية', 'التقييم والدراسات'], ['التميز والخدمات الحكومية', 'التميز والخدمات الحكومية'],
    ['الاتصال الحكومي وشؤون الأمانة العامة', 'الاتصال الحكومي'], ['الاتصال الحكومي وشؤون الأمانة العامة', 'الاتصال الداخلي'],
    ['الاتصال الحكومي وشؤون الأمانة العامة', 'الخدمات المؤسسية'], ['الاتصال الحكومي وشؤون الأمانة العامة', 'تميز الموارد البشرية'],
    ['الاتصال الحكومي وشؤون الأمانة العامة', 'المشتريات والشؤون الإدارية'], ['الاتصال الحكومي وشؤون الأمانة العامة', 'تقنية المعلومات'],
    ['الاتصال الحكومي وشؤون الأمانة العامة', 'المالية والحسابات'], ['الاتصال الحكومي وشؤون الأمانة العامة', 'المراسلات والأرشفة'],
    ['الاتصال الحكومي وشؤون الأمانة العامة', 'تنفيذ ومتابعة المشاريع الميدانية']
  ];

  /* The "previous month" block on the Dashboards sheet (rows labelled الشهر السابق).
     Header text in the block → metric key used by rules.js. */
  var SNAPSHOT = {
    sheet: 'Dashboards',
    sheets: ['Dashboards', 'Logic'],
    labelHeader: 'الحالة', sectorHeader: 'القطاع', unitHeader: 'الوحدة التنظيمية',
    prevLabel: 'الشهر السابق',
    metrics: {
      'المؤشرات_المقاسة': 'kpiMeasured', 'متوسط_النتائج': 'kpiAvg',
      'الخاصة_المجموع': 'specialTotal', 'سموه_منجز': 'specialLeadDone', 'سموه_متأخر': 'specialLeadLate',
      'الخاصة_منجز': 'specialGsDone', 'الخاصة_متأخر': 'specialGsLate',
      'الأجندة_المجموع': 'agendaTotal', 'الأجندة_منجز': 'agendaDone', 'الأجندة_متأخر': 'agendaLate',
      'القرارات_المجموع': 'councilTotal', 'القرارات_منجز': 'councilDone', 'القرارات_متأخر': 'councilLate',
      'مشاريع_الأمانة_المجموع': 'secTotal', 'مشاريع_الأمانة_منجز': 'secDone', 'مشاريع_الأمانة_متأخر': 'secLate',
      'التشريعات_المجموع': 'legTotal', 'التشريعات_منجز': 'legOnTime', 'التشريعات_تجاوز الموعد': 'legOverrun', 'التشريعات_متأخر': 'legLate',
      'الموازنة المعتمدة': 'budApproved', 'المنفق الفعلي': 'budSpent', 'المخصص': 'budAllocated', 'غير المخصص': 'budUnallocated',
      // Additional previous-month fields introduced by HTML(5); older molds remain valid.
      'سموه_المجموع': 'specialLead', 'الخاصة_المجموع_للأمانة': 'specialGs',
      'سموه_قيد_العمل': 'specialLeadProgress', 'الخاصة_قيد_العمل': 'specialGsProgress',
      'الأجندة_الأصلية': 'agendaPlanned', 'الأجندة_مستجد': 'agendaEmerging',
      'الأجندة_قيد_العمل': 'agendaProgress', 'الأجندة_جاهز_للعرض': 'agendaReady',
      'القرارات_قيد_العمل': 'councilProgress', 'مشاريع_الأمانة_قيد_العمل': 'secActive',
      'مشاريع_الأمانة_ملغي_معلق': 'secHeld', 'مشاريع_الأمانة_Q1': 'secQ1',
      'مشاريع_الأمانة_Q2': 'secQ2', 'مشاريع_الأمانة_Q3': 'secQ3', 'مشاريع_الأمانة_Q4': 'secQ4'
    }
  };

  var DISPLAY = {
    '#': 'الرقم', 'Sector': 'القطاع', 'Department / Section': 'الوحدة التنظيمية',
    'Project Name': 'اسم المشروع', 'Project Description': 'نبذة حول المشروع', 'Priority': 'الأولوية', 'Type': 'نوع المشروع', 'PM': 'مدير المشروع',
    'Start Date': 'تاريخ بدء المشروع', 'End Date': 'تاريخ انتهاء المشروع', 'Approved Budget': 'الموازنة الأصلية', 'Revised Budget': 'الموازنة المعتمدة',
    'Committed': 'المخصص', 'Non-Committed': 'غير المخصص', 'Work Completed': 'قيمة الأعمال المنجزة', 'Actual Spent As per the invoices': 'المنفق الفعلي',
    'Status': 'مستوى الإنجاز', '% Complete': 'نسبة الإنجاز', 'Project Owner Remarks': 'ملاحظات مدير المشروع', 'Finance Remarks': 'ملاحظات المالية',
    'Quarter': 'ربع الإنجاز', 'Late KPI': 'مؤشر التأخر', 'Year': 'السنة', 'نسبه الإنجاز': 'نسبة الإنجاز', 'تاريخ الانجاز الفعلي': 'تاريخ الإنجاز الفعلي',
    'نسبة مساهمة الادارات': 'نسبة مساهمة الإدارات'
  };
  function label(h) { return DISPLAY[h] || String(h).replace(/Q([1-4])/g, 'الربع $1'); }
  function value(field, v) {
    var maps={priority:{H:'عالية',M:'متوسطة',L:'منخفضة'},ptype:{Operational:'تشغيلي',Strategic:'استراتيجي'},status:{Active:'قيد العمل',Completed:'منجز',Cancelled:'ملغى',Frozen:'معلق','Not Started':'لم يبدأ',Transferred:'منقول'}};
    return maps[field] && maps[field][v] || v;
  }
  S.schema = { label: label, value: value, PF: PF, ORDER: ORDER, LOVS: LOVS, DEFAULT_UNITS: DEFAULT_UNITS, SNAPSHOT: SNAPSHOT, MATCHING: MATCHING, MATCHING_VERSION: MATCHING_VERSION };
})(window.Saytara = window.Saytara || {});
