/*
 * Performance reporting · loader
 * Turns an uploaded workbook into the app's dataset: one item per table row in
 * every portfolio, the lists of values, and the "previous month" block used for
 * the change arrows.
 */
(function (S) {
  'use strict';

  var U = S.util, SC = S.schema;

  function fail(code, detail) { var e = new Error(code); e.code = code; e.detail = detail; return e; }

  /* ---------- cell helpers ---------- */
  function cellKey(cell) {
    if (!cell || cell.t === 'e') return '';
    if (cell.t === 'b') return cell.v ? 'true' : 'false';
    return U.key(cell.v);
  }

  function progressValue(cell) {
    if (!cell || cell.t !== 'n') return null;
    return cell.v <= 1 ? cell.v * 100 : cell.v;
  }

  function dateText(cell) {
    if (cell.fmt && cell.fmt.monthYear) return U.fmtMonthYear(cell.v);
    return U.fmtDate(cell.v);
  }

  /* How a cell reads on screen, following its column type and Excel number format. */
  function display(cell, f) {
    if (!cell) return '';
    if (cell.t === 'e') return cell.v;
    if (cell.t === 'b') return cell.v ? 'TRUE' : 'FALSE';
    if (cell.t === 's') {
      var text = String(cell.v).replace(/ /g, ' ').trim();
      return f && (f.type === 'date' || f.type === 'month') && U.monthLabel ? U.monthLabel(text) : text;
    }
    var v = cell.v, type = f ? f.type : '';
    if (type === 'date') return v > 0 && v < 2958466 ? dateText(cell) : U.fmtNum(v);
    if (type === 'progress') return Math.round(progressValue(cell)) + '%';
    if (type === 'pct') return Math.round(v * 100) + '%';
    if (type === 'year') return String(Math.round(v));
    if (type === 'num') return U.fmtNum(v, 2);
    if (cell.fmt && cell.fmt.isDate && v > 0 && v < 2958466) return dateText(cell);
    if (cell.fmt && cell.fmt.isPct) return Math.round(v * 100) + '%';
    return Number.isInteger(v) ? String(v) : U.fmtNum(v, 2);
  }

  /* List values are kept exactly as typed, because the report compares them exactly. */
  function rawText(cell) { return cell.t === 's' ? String(cell.v) : display(cell); }

  function sniff(buffer) {
    var b = new Uint8Array(buffer, 0, Math.min(8, buffer.byteLength));
    if (b[0] === 0x50 && b[1] === 0x4B) return 'zip';
    if (b[0] === 0xD0 && b[1] === 0xCF && b[2] === 0x11 && b[3] === 0xE0) return 'ole';
    return 'unknown';
  }

  /* ---------- tables ---------- */
  async function tableHeaders(wb, table) {
    if (table.columns.length) return table.columns.slice();
    var sheet = await wb.sheet(table.sheetName), out = [];
    if (!sheet) return out;
    for (var c = table.ref.c1; c <= table.ref.c2; c++) { var cell = sheet.get(table.ref.r1,c); out.push(cell ? String(cell.v) : ''); }
    return out;
  }

  /* Rows of an Excel Table, or of a sheet whose first row holds the headers. */
  async function tableBlock(wb, tables, tableName, sheetName, signature) {
    var named = tables.filter(function(t) { return U.key(t.name) === U.key(tableName); });
    if (named.length > 1) return { ambiguous: named.map(function(t) { return t.sheetName + ' · ' + t.name; }) };
    var t = named[0], via = 'table';
    if (!t && signature) {
      var matching = [];
      for (var candidate of tables) {
        var candidateHeaders = await tableHeaders(wb,candidate);
        if (await signature(candidate,candidateHeaders)) matching.push(candidate);
      }
      if (matching.length > 1) return { ambiguous: matching.map(function(x) { return x.sheetName + ' · ' + x.name; }) };
      if (matching.length === 1) { t = matching[0]; via = 'matched-table'; }
    }
    if (t) {
      var sheet = await wb.sheet(t.sheetName);
      if (!sheet) return null;
      var headers = t.columns.slice();
      if (!headers.length) {
        for (var c = t.ref.c1; c <= t.ref.c2; c++) { var hc = sheet.get(t.ref.r1, c); headers.push(hc ? String(hc.v) : ''); }
      }
      return {
        via: via, table: t.name, sheetName: t.sheetName, sheet: sheet, headers: headers,
        c1: t.ref.c1, r1: t.ref.r1 + (t.headerRowCount ? 1 : 0), r2: t.ref.r2 - t.totalsRowCount
      };
    }
    if (!sheetName) return null;
    var sh = wb.sheets.find(function (s) { return U.key(s.name) === U.key(sheetName); });
    if (!sh) return null;
    var cells = await wb.sheet(sh.name);
    if (!cells) return null;
    var hdr = [];
    for (var cc = 1; cc <= cells.maxC; cc++) { var h = cells.get(1, cc); hdr.push(h ? String(h.v) : ''); }
    while (hdr.length && !U.key(hdr[hdr.length - 1])) hdr.pop();
    return { via: 'sheet', table: null, sheetName: sh.name, sheet: cells, headers: hdr, c1: 1, r1: 2, r2: cells.maxR };
  }

  /* ---------- lists of values ---------- */
  async function readLovs(wb, tables, notes) {
    var out = {}, sets = {}, sources = {};
    for (var name in SC.LOVS) {
      var def = SC.LOVS[name];
      function headerColumns(headers) {
        var keys = headers.map(U.key), indices = def.cols.map(function(h) {
          var matches = []; keys.forEach(function(k,i) { if (k === U.key(h)) matches.push(i); });
          return matches.length === 1 ? matches[0] : null;
        });
        return indices.some(function(i) { return i === null; }) ? null : indices;
      }
      var block = await tableBlock(wb, tables, def.table, null, async function(table,headers) {
        var indices = headerColumns(headers);
        if (!indices) return false;
        // The approved Entities table has an additional sector context column.
        // Other unrelated columns cannot establish a renamed list's identity.
        var allowed = def.cols.concat(name === 'Entities' ? ['القطاع'] : []).map(U.key);
        if (!headers.every(function(h) { return allowed.indexOf(U.key(h)) >= 0; }) || new Set(headers.map(U.key)).size !== headers.length) return false;
        // Three approved status LOVs share a heading. Their exact source value
        // sets distinguish them; a custom/ambiguous list is not guessed.
        if (def.cols.length === 1 && U.key(def.cols[0]) === U.key('مستوى الإنجاز')) {
          var sheet = await wb.sheet(table.sheetName), values = new Set();
          if (!sheet || !def.defaults) return false;
          for (var r = table.ref.r1 + table.headerRowCount; r <= table.ref.r2 - table.totalsRowCount; r++) {
            var cell = sheet.get(r,table.ref.c1 + indices[0]); if (cell && cellKey(cell)) values.add(cellKey(cell));
          }
          var expected = new Set(def.defaults.map(U.key));
          return values.size === expected.size && Array.from(values).every(function(v) { return expected.has(v); });
        }
        return true;
      });
      if (block && block.ambiguous) {
        notes.push({ sev: 'error', sheet: block.ambiguous.join(' / '), row: '', field: def.table, problem: 'توجد جداول متعددة تطابق قائمة القالب؛ لم تُختَر قائمة تلقائياً', value: '', fix: 'احتفظ بجدول واحد ذي اسم وهوية واضحين لهذه القائمة' });
        block = null;
      }
      var mappedColumns = block ? headerColumns(block.headers) : null;
      if (block && !mappedColumns) {
        notes.push({ sev: 'error', sheet: block.sheetName, row: String(block.r1 - 1), field: def.table,
          problem: 'عناوين قائمة القيم المطلوبة مفقودة أو مكررة؛ لم تُقرأ قيم من أعمدة بديلة', value: block.headers.join(' / '),
          fix: 'احتفظ بعنوان واحد واضح لكل حقل مطلوب: ' + def.cols.join(' / ') });
        block = null;
      }
      var values = [];
      if (block) {
        sources[name] = { sheet: block.sheetName, table: block.table, firstRow: block.r1, lastRow: block.r2, columns: mappedColumns.map(function(i) { return block.c1 + i; }) };
        for (var r = block.r1; r <= block.r2; r++) {
          if (def.cols.length === 2) {
            var a = block.sheet.get(r, block.c1 + mappedColumns[0]), b = block.sheet.get(r, block.c1 + mappedColumns[1]);
            if (b && cellKey(b)) values.push({ parent: a ? rawText(a) : '', value: rawText(b) });
          } else {
            var v = block.sheet.get(r, block.c1 + mappedColumns[0]);
            if (v && cellKey(v)) values.push(v.t === 'n' && name === 'CompletionPercent' ? v.v : rawText(v));
          }
        }
      } else {
        notes.push({ sev: 'info', sheet: 'LOVs', row: '', field: def.table, problem: 'لم يُعثر على جدول القائمة في الملف، واستُخدمت القيم الافتراضية للقالب', value: '', fix: 'تحقق من ورقة LOVs' });
        if (name === 'Departments') values = SC.DEFAULT_UNITS.map(function (p) { return { parent: p[0], value: p[1] }; });
        else if (def.defaults) values = def.defaults.slice();
      }
      out[name] = values;
      sets[name] = new Set(values.map(function (x) { return U.key(typeof x === 'object' ? x.value : x); }));
    }
    var unitSector = uniqueDepartmentSectors(out.Departments || []);
    return { lists: out, sets: sets, unitSector: unitSector, sources: sources,
      departmentSector: sources.Departments ? unitSector : new Map() };
  }

  /* Only the workbook's actual Departments relationship can fill a blank sector.
     Whitespace/case normalisation follows the exact LOV key, never search/fuzzy
     normalisation. Conflicting or blank parents deliberately have no mapping. */
  function uniqueDepartmentSectors(rows) {
    var groups = new Map(), out = new Map();
    rows.forEach(function(p) {
      var unit = U.key(p.value), sector = U.key(p.parent);
      if (!unit) return;
      if (!groups.has(unit)) groups.set(unit, new Map());
      groups.get(unit).set(sector, p.parent);
    });
    groups.forEach(function(parents, unit) {
      if (parents.size === 1 && !parents.has('')) out.set(unit, Array.from(parents.values())[0]);
    });
    return out;
  }
  function resolveClassification(it, lovs) {
    delete it.classification;
    var sourceSector = it.t.sector || '', sourceUnit = it.t.unit || '';
    it.sector = sourceSector; it.unit = sourceUnit;
    var map = lovs && lovs.departmentSector;
    if (U.key(sourceSector) || !U.key(sourceUnit) || !map || !map.has(U.key(sourceUnit))) return;
    // Invalid cells are errors, not empty data. Preserve their warning and value.
    if (it.c.sector && (it.c.sector.t !== 's' || U.key(it.c.sector.v))) return;
    var sector = map.get(U.key(sourceUnit));
    it.sector = sector;
    it.classification = { sector: sector, sourceSector: sourceSector, sourceUnit: sourceUnit,
      basis: 'Departments', source: lovs.sources.Departments };
  }

  /* ---------- items ---------- */
  function makeItem(pf, spec, block, r, seq, cols) {
    var c = {}, k = {}, x = {}, t = {};
    Object.keys(spec.fields).forEach(function (fk) {
      var cell = cols[fk] != null ? block.sheet.get(r, cols[fk]) : null;
      if (cell) c[fk] = cell;
      k[fk] = cellKey(cell);
      x[fk] = U.xl(cell);
      t[fk] = display(cell, spec.fields[fk]);
    });
    var idCols = block.headers.map(function(h,i){return {h:U.key(h),i:i};}).filter(function(x){return ['record id','record_id','id','معرف السجل','معرّف السجل','المعرف الثابت'].indexOf(x.h)>=0;});
    var idCell=idCols.length===1?block.sheet.get(r,block.c1+idCols[0].i):null;
    var recordId=idCell&&idCell.t!=='e'?String(idCell.v):'';
    var all = block.headers.map(function (h, i) {
      var col = block.c1 + i, fk = null;
      for (var key in cols) if (cols[key] === col) { fk = key; break; }
      var f = fk ? spec.fields[fk] : null;
      return {
        label: SC.label(f && f.aliases ? f.h : String(h).replace(/\s+/g, ' ').trim()), field: fk, calc: !!(f && f.type === 'calc'),
        value: fk ? t[fk] : display(block.sheet.get(r, col), null)
      };
    }).filter(function (x) { return x.label; });
    return {
      recordId: recordId, key: pf + '-' + r, pf: pf, row: r, seq: seq, sheet: block.sheetName,
      c: c, k: k, x: x, t: t, calc: {}, all: all
    };
  }

  function joinText(parts) { return parts.filter(function (p) { return p; }).join(' '); }

  /* Columns shown in search results, filled the way the Excel search sheet fills them. */
  function describe(it, today) {
    var t = it.t, c = it.c, pf = it.pf;
    var title = t.title;
    it.hasTitle = !!(c.title && c.title.t !== 'e' && String(c.title.v).trim());
    it.title = title || 'بدون عنوان';
    it.dir = U.dirOf(title);

    if (pf === 'council') it.ref = t.no || String(it.seq);
    else if (pf === 'legislation') it.ref = t.mcms || t.seq || String(it.seq);
    else if (pf === 'secretariat') it.ref = t.no || String(it.seq);
    else it.ref = String(it.seq);

    it.coord = pf === 'special' || pf === 'secretariat' ? t.pm : pf === 'kpi' ? t.owners : pf === 'legislation' ? '' : t.coord;
    it.entity = pf === 'legislation' ? t.sender : pf === 'secretariat' || pf === 'kpi' ? '' : t.entity;
    it.sector = t.sector || '';
    it.unit = t.unit || '';
    it.notes = pf === 'legislation' ? t.updates : pf === 'secretariat' ? t.ownerRemarks : t.notes;

    var ds = null, label = '';
    if (pf === 'agenda') {
      label = joinText([t.month, t.year]);
      var am = U.monthIndexAr(t.month), ay = parseInt(t.year, 10);
      if (am && ay) ds = U.serial(ay, am, 1);
    } else if (pf === 'special') {
      label = joinText([t.endMonth, t.endYear]);
      var sm = U.monthIndexAr(t.endMonth), sy = parseInt(t.endYear, 10);
      if (sm && sy) ds = U.serial(sy, sm, 1);
    } else if (pf === 'council') {
      label = t.meetingDate;
      if (c.meetingDate && c.meetingDate.t === 'n') ds = c.meetingDate.v;
    } else if (pf === 'legislation') {
      label = t.deptDate;
      if (c.deptDate && c.deptDate.t === 'n') ds = c.deptDate.v;
    } else if (pf === 'secretariat') {
      label = t.end;
      if (c.end && c.end.t === 'n') ds = c.end.v;
      else if (c.end && c.end.t === 's') {
        var mi = U.MONTHS_EN3.indexOf(String(c.end.v).trim().toUpperCase());
        if (mi >= 0) { label = U.MONTHS_AR[mi] + ' ' + U.ymd(today).y; ds = U.serial(U.ymd(today).y, mi + 1, 1); }
      }
    }
    it.dateLabel = label || '';
    it.dateSort = ds;

    var yr = pf === 'agenda' || pf === 'council' || pf === 'legislation' ? t.year : pf === 'special' ? t.endYear : '';
    if (!yr && ds != null) yr = String(U.ymd(ds).y);
    it.year = yr || '';

    var pv = null;
    if (pf === 'special' || pf === 'secretariat' || pf === 'council') pv = progressValue(c.progress);
    it.progress = pv == null ? null : pv;
  }

  function buildSearchIndex(it, spec) {
    var other = [];
    (spec.search || []).forEach(function (fk) {
      if (!it.t[fk]) return;
      other.push({ field: fk, label: SC.label(spec.fields[fk].h), text: U.norm(it.t[fk]) });
    });
    if (it.classification) other.push({ field: 'sector', label: 'القطاع حسب قائمة الوحدات', text: U.norm(it.sector) });
    if (it.dateLabel) other.push({ field: 'date', label: 'التاريخ / الموعد', text: U.norm(it.dateLabel) });
    if (it.statusLabel && U.key(it.statusLabel) !== it.k.status) other.push({ field: 'status', label: 'الحالة', text: U.norm(it.statusLabel) });
    if (it.pf === 'legislation' && it.calc.overrun) other.push({ field: 'overrun', label: 'تجاوز الموعد', text: U.norm('تجاوز الموعد متأخر') });
    if (it.pf === 'legislation' && it.calc.legislationMonth && it.calc.legislationMonth.label) other.push({ field: 'legislationMonth', label: 'شهر التشريع', text: U.norm(it.calc.legislationMonth.label) });
    if (it.pf === 'kpi') other.push({ field: 'status', label: 'الحالة', text: U.norm(it.statusLabel) });
    other.push({ field: 'pf', label: 'المحفظة', text: U.norm(SC.PF[it.pf].ar + ' ' + SC.PF[it.pf].src) });
    it.sx = { ref: U.norm(it.ref), title: U.norm(it.hasTitle ? it.title : ''), coord: U.norm(it.coord), other: other };
  }

  async function readPortfolio(wb, tables, pf, notes) {
    var spec = SC.PF[pf];
    var anchors = {
      agenda: ['type','quarter','month'], council: ['issuer','followup','meetingDate'],
      legislation: ['mcms','kpi','actual'], special: ['lead','endMonth','startMonth'],
      secretariat: ['revised','committed','spent'], kpi: ['freq','q1','result']
    };
    var block = await tableBlock(wb, tables, spec.table, spec.sheet, function(table,headers) {
      var keys = headers.map(U.key);
      function has(field) { var f = spec.fields[field]; return [f.h].concat(f.aliases || []).some(function(h) { return keys.indexOf(U.key(h)) >= 0; }); }
      return has('title') && anchors[pf].filter(has).length >= 2;
    });
    if (block && block.ambiguous) {
      notes.push({ sev: 'error', sheet: block.ambiguous.join(' / '), row: '', field: spec.table, problem: 'توجد جداول متعددة تطابق حقول المحفظة؛ لم تُختَر بيانات تلقائياً', value: '', fix: 'حدد جدول المحفظة بمعرّف واضح وفريد' });
      return { meta: { pf: pf, found: false, via: 'ambiguous', sheet: spec.sheet, table: spec.table, rows: 0, missing: [], ambiguousTables: block.ambiguous }, items: [] };
    }
    var meta = { pf: pf, found: !!block, via: block ? block.via : null, sheet: block ? block.sheetName : spec.sheet, table: spec.table, rows: 0, missing: [] };
    if (!block) {
      notes.push({ sev: 'error', sheet: spec.sheet, row: '', field: spec.table, problem: 'لم يُعثر على جدول «' + spec.table + '» ولا على ورقة «' + spec.sheet + '»', value: '', fix: 'استخدم قالب التقرير نفسه دون إعادة تسمية الجداول أو الأوراق' });
      return { meta: meta, items: [] };
    }
    if (block.via === 'sheet') {
      notes.push({ sev: 'warn', sheet: block.sheetName, row: '', field: spec.table, problem: 'لم يُعثر على جدول Excel باسم «' + spec.table + '»، فقُرئت الورقة من الصف الأول', value: '', fix: 'أعد تحويل البيانات إلى جدول بالاسم نفسه' });
    }
    if (block.via === 'matched-table') notes.push({ sev: 'info', sheet: block.sheetName, row: '', field: block.table,
      problem: 'تم التعرف على جدول المحفظة من حقوله المطابقة بعد تغيير اسمه؛ حُفظ نطاق جدول Excel', value: spec.table, fix: 'لا يلزم تعديل الملف؛ احتفظ بعناوين الحقول واضحة وفريدة' });
    var headerKeys = block.headers.map(function (h) { return U.key(h); });
    var cols = {};
    Object.keys(spec.fields).forEach(function (fk) {
      var field = spec.fields[fk], aliases = [field.h].concat(field.aliases || []).map(U.key);
      // Exact whitespace/case-normalized aliases only. Never select the first of
      // duplicate headings or conflate original/revised and work/invoice amounts.
      var matches = [];
      headerKeys.forEach(function (h, i) { if (aliases.indexOf(h) >= 0) matches.push(i); });
      if (matches.length === 1) cols[fk] = block.c1 + matches[0];
      else if (matches.length > 1) {
        if (field.type !== 'calc') meta.missing.push(field.h);
        if (!meta.ambiguous) meta.ambiguous = [];
        meta.ambiguous.push({ field: fk, headers: matches.map(function(i) { return block.headers[i]; }), columns: matches.map(function(i) { return block.c1 + i; }) });
        notes.push({ sev: 'error', sheet: block.sheetName, row: '1', field: field.h, problem: 'توجد أعمدة متعددة للحقل نفسه؛ لم تُختَر قيمة تلقائياً', value: matches.map(function(i) { return block.headers[i]; }).join(' / '), fix: 'احتفظ بعمود واحد واضح لهذا الحقل' });
      } else if (field.type !== 'calc' && !field.optional) meta.missing.push(field.h);
    });
    meta.missing.forEach(function (h) {
      notes.push({ sev: 'error', sheet: block.sheetName, row: '1', field: h, problem: 'العمود غير موجود في الجدول', value: '', fix: 'أعد العمود بالعنوان نفسه كما في القالب' });
    });
    meta.cols = cols;

    var items = [], seq = 0;
    for (var r = block.r1; r <= block.r2; r++) {
      var any = false;
      for (var fk in cols) {
        if (spec.fields[fk].type === 'calc' || spec.fields[fk].matchingOnly) continue;
        var cell = block.sheet.get(r, cols[fk]);
        if (cell && (cell.t === 'n' || cell.t === 'b' || cell.t === 'e' || String(cell.v).trim() !== '')) { any = true; break; }
      }
      seq++;
      if (!any) continue;
      var item = makeItem(pf, spec, block, r, seq, cols);
      if (meta.ambiguous && meta.ambiguous.some(function(x) { return x.field === 'measurementState'; })) item.measurementStateAmbiguous = true;
      items.push(item);
    }
    meta.rows = items.length;
    meta.capacity = block.r2 - block.r1 + 1;
    return { meta: meta, items: items };
  }

  /* ---------- previous-month block ---------- */
  async function readSnapshot(wb, lovs, notes) {
    var cfg = SC.SNAPSHOT;
    // Sheet names are presentation, not identity. A uniquely vetted historical
    // block can survive an Excel sheet rename; competing blocks are quarantined.
    var sheets = wb.sheets;
    var signature = ['kpiMeasured','specialTotal','agendaTotal','councilTotal','secTotal','legTotal'];
    var out = { found: false, rows: [], hasData: false, sheet: '', issue: '', qualityIssues: [] }, blocks = [];
    var metricByHeader = Object.create(null);
    Object.keys(cfg.metrics).forEach(function (h) { metricByHeader[U.key(h)] = cfg.metrics[h]; });
    for (var sh of sheets) {
      var cells = await wb.sheet(sh.name);
      if (!cells) continue;
      cells.rows.forEach(function (rowMap, r) {
        var labels = [];
        rowMap.forEach(function(cell,c){if (cell.t === 's' && U.key(cell.v) === U.key(cfg.labelHeader)) labels.push(c);});
        labels.forEach(function(label,index) {
          // The mold puts sector/unit immediately before the period label.
          // Earlier current-period tables on the same row reuse those headings;
          // they are not duplicate columns in this historical block.
          if (cellKey(rowMap.get(label-2)) !== U.key(cfg.sectorHeader) || cellKey(rowMap.get(label-1)) !== U.key(cfg.unitHeader)) return;
          var found = { metrics: {}, label: label, sector: label-2, unit: label-1 }, n = 0, ambiguous = false;
          rowMap.forEach(function(cell,c) {
            if (c <= label || (labels[index+1] != null && c >= labels[index+1]-2) || cell.t !== 's') return;
            var metric = metricByHeader[U.key(cell.v)];
            if (!metric) return;
            if (found.metrics[metric] != null) ambiguous = true;
            else { found.metrics[metric] = c; n++; }
          });
          if (n >= 10 && signature.every(function(metric) { return found.metrics[metric] != null; }))
            blocks.push({ sheet: sh.name, cells: cells, cols: found, headerRow: r, ambiguous: ambiguous });
        });
      });
    }
    var prevKey = U.key(cfg.prevLabel);
    // A second header can introduce current-period detail, not a second history.
    // Bound each block at the next header in that column before selecting it.
    blocks.forEach(function(block) {
      var next = blocks.filter(function(b){return b.sheet === block.sheet && b.cols.label === block.cols.label && b.headerRow > block.headerRow;}).sort(function(a,b){return a.headerRow-b.headerRow;})[0];
      block.lastRow = next ? next.headerRow-1 : block.cells.maxR;
    });
    blocks = blocks.filter(function(block) {
      var prior = false;
      block.cells.rows.forEach(function(rowMap,r) { if (r > block.headerRow && r <= block.lastRow && cellKey(rowMap.get(block.cols.label)) === prevKey) prior = true; });
      return prior;
    });
    if (!blocks.length) return out;
    out.found = true;
    if (blocks.length !== 1 || blocks[0].ambiguous) {
      out.issue = 'توجد كتل أو أعمدة متعددة لبيانات الشهر السابق؛ لم تُختَر قيم تلقائياً';
      notes.push({ sev: 'error', sheet: blocks.map(function(b){return b.sheet;}).join(' / '), row: '', field: 'الشهر السابق', problem: out.issue, value: '', fix: 'احتفظ بكتلة واحدة ذات أعمدة واضحة للشهر السابق' });
      return out;
    }
    var block = blocks[0], cols = block.cols;
    out.sheet = block.sheet; out.headerRow = block.headerRow;

    block.cells.rows.forEach(function (rowMap, r) {
      if (r <= block.headerRow || r > block.lastRow) return;
      var lab = rowMap.get(cols.label);
      if (!lab || U.key(lab.v) !== prevKey) return;
      var sec = rowMap.get(cols.sector), unit = rowMap.get(cols.unit);
      var sector = sec ? String(sec.v) : '', unitName = unit ? String(unit.v) : '';
      if (!sector.trim() && !unitName.trim()) return;
      var v = {};
      Object.keys(cols.metrics).forEach(function (m) {
        var cell = rowMap.get(cols.metrics[m]);
        if (cell && cell.t === 'n') { v[m] = cell.v; out.hasData = true; }
      });
      var row = { row: r, sector: sector, unit: unitName, v: v };
      if (!U.key(sector) && U.key(unitName) && lovs.departmentSector.has(U.key(unitName))) {
        row.sourceSector = sector;
        row.sector = lovs.departmentSector.get(U.key(unitName));
        row.classification = { basis: 'Departments', source: lovs.sources.Departments };
      }
      out.rows.push(row);
    });
    // These rows are aggregates at sector/unit grain. Repeated keys cannot be
    // summed safely or resolved by choosing the first row.
    var keys = new Map();
    out.rows.forEach(function(row) {
      var key = JSON.stringify([U.key(row.sector), U.key(row.unit)]);
      if (!keys.has(key)) keys.set(key, []);
      keys.get(key).push(row.row);
    });
    var duplicates = Array.from(keys.values()).filter(function(rows){return rows.length > 1;});
    if (duplicates.length) {
      out.hasData = false;
      out.issue = 'تكررت مفاتيح القطاع والوحدة في بيانات الشهر السابق؛ المقارنة غير متاحة حتى معالجة التكرار';
      notes.push({ sev: 'error', sheet: out.sheet, row: duplicates.map(function(rows){return rows.join(', ');}).join(' / '), field: 'الشهر السابق', problem: out.issue, value: '', fix: 'راجع صفوف الشهر السابق واحتفظ بتجميع واحد لكل قطاع ووحدة' });
    }
    // Preserve the raw historical cells. Missing status categories cannot prove
    // a recorded zero is wrong, so incomplete coverage warns but is not repaired.
    // Only mathematically impossible count data is withheld from comparison.
    var incomplete = [], invalid = [];
    out.rows.forEach(function(row) {
      row.quarantined = {};
      Object.keys(row.v).forEach(function(metric) {
        if (metric === 'kpiAvg' || /^bud/.test(metric)) return;
        var value = row.v[metric];
        if (!Number.isFinite(value) || value < 0 || Math.floor(value) !== value) {
          row.quarantined[metric] = 'قيمة عددية غير صالحة في بيانات الشهر السابق';
          invalid.push({ row: row.row, metric: metric });
        }
      });
      var metrics = ['secActive','secDone','secHeld'], total = row.v.secTotal;
      if (!Number.isFinite(total) || !metrics.every(function(metric) { return Number.isFinite(row.v[metric]); })) return;
      var sum = metrics.reduce(function(n,metric) { return n + row.v[metric]; },0);
      if (sum > total) {
        ['secTotal'].concat(metrics).forEach(function(metric) {
          row.quarantined[metric] = 'مجموع حالات المشاريع المحفوظة يتجاوز إجماليها في الشهر السابق';
        });
        invalid.push({ row: row.row, metric: 'secActive' });
      } else if (sum < total) incomplete.push(row.row);
    });
    if (incomplete.length) {
      var reason = 'حالات المشاريع المحفوظة للشهر السابق لا تغطي إجماليها؛ حالات «لم يبدأ» و«منقول» وغير المصنفة غير محفوظة في هذه الكتلة';
      out.qualityIssues.push({ kind: 'incomplete', metrics: ['secActive','secDone','secHeld','secTotal'], rows: incomplete, reason: reason });
      notes.push({ sev: 'warn', sheet: out.sheet, row: incomplete.join(', '), field: 'حالات المشاريع · الشهر السابق', problem: reason, value: '', fix: 'تحقق من اكتمال الحالة والفترة في المصدر؛ لم تُعدّل القيم المحفوظة' });
    }
    if (invalid.length) {
      var invalidRows = Array.from(new Set(invalid.map(function(x) { return x.row; })));
      var invalidMetrics = Array.from(new Set(invalid.map(function(x) { return x.metric; })));
      var invalidReason = 'توجد أعداد أو مجاميع حالات غير صالحة في بيانات الشهر السابق؛ حُجبت المقارنات المتأثرة دون تعديل المصدر';
      out.qualityIssues.push({ kind: 'invalid', metrics: invalidMetrics, rows: invalidRows, reason: invalidReason });
      notes.push({ sev: 'warn', sheet: out.sheet, row: invalidRows.join(', '), field: 'الشهر السابق', problem: invalidReason, value: '', fix: 'راجع الأعداد في صفوف التاريخ المشار إليها' });
    }
    return out;
  }

  function identityNotes(data) {
    var C = S.comparison;
    if (!C || !C.identity) return;
    var ids = new Map(), missing = new Map();
    data.items.forEach(function(it) {
      var ident = C.identity(it);
      if (!ident.value) {
        var missingKey = JSON.stringify([it.pf, ident.missing]);
        if (!missing.has(missingKey)) missing.set(missingKey, []);
        missing.get(missingKey).push(it);
        return;
      }
      var group = JSON.stringify([it.pf, ident.kind, ident.value]);
      if (!ids.has(group)) ids.set(group, []);
      ids.get(group).push(it);
    });
    ids.forEach(function(rows) {
      if (rows.length < 2) return;
      var it = rows[0], ident = C.identity(it);
      data.notes.push({ sev: 'warn', sheet: it.sheet, row: rows.map(function(x) { return x.row; }).join(', '), field: ident.basis,
        problem: 'مفتاح الربط المعتمد مكرر؛ حُفظت جميع الصفوف وحُجبت المطابقة غير المحسومة', value: ident.label,
        fix: 'راجع حقول مفتاح الربط في الصفوف المشار إليها دون حذف بيانات الأداء أو تغيير الأرقام الرسمية', pf: it.pf, matchingKeys: rows.map(function(x) { return x.key; }) });
    });
    missing.forEach(function(rows) {
      var it = rows[0], ident = C.identity(it);
      data.notes.push({ sev: 'warn', sheet: it.sheet, row: rows.map(function(x) { return x.row; }).join(', '), field: ident.basis,
        problem: 'مفتاح الربط المعتمد غير مكتمل؛ الحقول الناقصة: ' + ident.missing.join('، '), value: String(rows.length) + ' بند',
        fix: 'أكمل حقول مفتاح الربط في المصدر عند توفرها؛ حُفظت الصفوف ولا تُستبدل القيم الناقصة باسم الملف أو رقم الصف', pf: it.pf, matchingKeys: rows.map(function(x) { return x.key; }) });
    });
    var zeroKpis = data.items.filter(function(it) {
      return it.pf === 'kpi' && it.hasTitle && it.c.result && it.c.result.t === 'n' && it.c.result.v === 0 && it.calc.measurementState === 'legacy';
    });
    if (zeroKpis.length) data.notes.push({ sev: 'info', sheet: data.meta.kpi.sheet, row: zeroKpis.map(function(it) { return it.row; }).join(', '), field: 'نتيجة العام',
      problem: 'يستبعد القالب النتيجة السنوية صفر من المقاسة؛ لا يميز المصدر بين نتيجة مقاسة صفر وعدم القياس', value: String(zeroKpis.length),
      fix: 'لم تتغير الأعداد؛ لاحتساب صفر مقاس أضف حالة قياس صريحة إلى المصدر بعد اعتماد التعريف', pf: 'kpi' });
  }

  /* Only an explicit cutoff can drive historical date-sensitive calculations.
     ReportDate is a display label and file modification time is not a cutoff. */
  function cutoffSerial(cell) {
    if (!cell || cell.t === 'e' || cell.t === 'b') return null;
    if (cell.t === 'n') return Number.isFinite(cell.v) && cell.v >= 1 && cell.v < 2958466 ? Math.floor(cell.v) : null;
    var text = U.norm(cell.v).trim(), iso = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
    if (!iso) return null;
    var n = U.serial(+iso[1], +iso[2], +iso[3]), d = U.ymd(n);
    return d.y === +iso[1] && d.m === +iso[2] && d.d === +iso[3] && n >= 1 && n < 2958466 ? n : null;
  }
  function cutoffCell(sheet, row, column, source) {
    var cached = cutoffSerial(sheet && sheet.get(row, column)), formula = sheet && sheet.getFormula ? sheet.getFormula(row, column) : '';
    var live = /^\s*=?\s*(?:_xlfn\.)?TODAY\s*\(\s*\)\s*$/i.test(formula);
    return { value: live ? U.todaySerial() : cached, cached: cached, kind: live ? 'live' : 'fixed', source: source, issue: '' };
  }
  async function cutoff(wb) {
    var named = (wb.definedNames || []).filter(function(n) { return U.key(n.name) === 'validationdate' && n.localSheetId == null; });
    if (named.length) {
      var values = [];
      for (var name of named) {
        var ref = /^(?:'((?:[^']|'')+)'|([^'!\[\]]+))!\$?([A-Z]+)\$?(\d+)$/i.exec(name.ref);
        if (!ref) return { value: null, source: 'ValidationDate', issue: 'مرجع ValidationDate لا يشير إلى خلية تاريخ واحدة' };
        var sheetName = (ref[1] || ref[2]).replace(/''/g, "'"), sheet = await wb.sheet(sheetName);
        var reading = cutoffCell(sheet, +ref[4], S.xlsx.colIndex(ref[3].toUpperCase()), 'ValidationDate · ' + name.ref), value = reading.value;
        if (value == null) return { value: null, source: 'ValidationDate · ' + name.ref, issue: 'قيمة التاريخ المرجعي مفقودة أو غير صالحة؛ أدخل تاريخ قطع البيانات' };
        values.push(reading);
      }
      return values.every(function(x) { return x.value === values[0].value; }) ? values[0] : { value: null, source: 'ValidationDate', issue: 'توجد قيم مرجعية متعارضة؛ حدّد تاريخ قطع البيانات' };
    }
    var dash = wb.sheets.find(function(s) { return U.key(s.name) === 'dashboards'; });
    var ds = dash && await wb.sheet(dash.name), reading = cutoffCell(ds, 1, 2, 'Dashboards!B1');
    if (reading.value == null) { reading.source = ''; reading.issue = 'لم يُعثر على تاريخ قطع بيانات محفوظ؛ أدخل التاريخ المرجعي للتقرير'; }
    return reading;
  }

  /* ---------- entry point ---------- */
  async function load(file, options) {
    options = options || {};
    if (!S.zip.supported()) throw fail('BROWSER');
    if(file.size>S.zip.limits.fileBytes)throw fail('FILE_LIMIT');
    var buffer = await file.arrayBuffer();
    if(buffer.byteLength>S.zip.limits.fileBytes)throw fail('FILE_LIMIT');
    var kind = sniff(buffer);
    if (kind === 'ole') throw fail('OLE');
    if (kind !== 'zip') throw fail('NOT_XLSX');

    var wb;
    try { wb = await S.xlsx.read(buffer); }
    catch (e) { throw fail(e.code === 'ENCRYPTED' ? 'OLE' : ['FILE_LIMIT','WORKBOOK_LIMIT'].includes(e.code)?e.code:['BAD_ZIP','BAD_XML','ZIP_METHOD','ZIP64'].includes(e.code)?'DAMAGED_XLSX':'NOT_XLSX', e.message); }

    var today = options.today != null ? options.today : U.todaySerial();
    var sourceCutoff = await cutoff(wb), savedReportDate = sourceCutoff.kind === 'live' ? null : sourceCutoff.value;
    if (options.today == null && sourceCutoff.value != null) today = sourceCutoff.value;
    var validationDate = sourceCutoff.value != null ? sourceCutoff.value : today;
    var notes = [];
    var tables = await wb.tables();
    var lovs = await readLovs(wb, tables, notes);

    var items = [], byPf = {}, meta = {};
    for (var i = 0; i < SC.ORDER.length; i++) {
      var pf = SC.ORDER[i];
      var res = await readPortfolio(wb, tables, pf, notes);
      meta[pf] = res.meta;
      byPf[pf] = res.items;
      res.items.forEach(function (it) {
        describe(it, today);
        resolveClassification(it, lovs);
        S.rules.calc(it, it.pf === 'legislation' ? validationDate : today);
        if (pf === 'legislation' && !it.all.some(function (f) { return f.field === 'legislationMonth'; })) it.all.push({ label: 'شهر التشريع', field: 'legislationMonth', calc: true, value: '' });
        buildSearchIndex(it, SC.PF[pf]);
        items.push(it);
      });
    }
    if (!SC.ORDER.some(function (p) { return meta[p].found; })) throw fail('NOT_TEMPLATE');

    var byKey = {};
    items.forEach(function (it) { byKey[it.key] = it; });

    var snapshot = await readSnapshot(wb, lovs, notes);
    // The fixed source cutoff is the context of the saved aggregate block,
    // not an inferred date for the previous month. A live TODAY() formula or
    // a user-entered calculation date cannot establish that source context.
    snapshot.referenceDate = sourceCutoff.kind === 'fixed' ? savedReportDate : null;
    snapshot.referenceSource = sourceCutoff.source || '';
    snapshot.referenceKind = sourceCutoff.kind || 'unknown';
    var data = {
      file: { name: file.name || 'workbook.xlsx', size: file.size || buffer.byteLength, lastModified: file.lastModified ? new Date(file.lastModified) : null, saved: wb.modified,
        classification: wb.props.Classification || '' },
      sourceBytes:new Uint8Array(buffer), savedReportDate:savedReportDate, sourceValidationDate:sourceCutoff.cached != null ? sourceCutoff.cached : savedReportDate, referenceDateReady:sourceCutoff.value != null, sourceDateKind:sourceCutoff.kind || 'unknown', calculationDateKind:sourceCutoff.kind || 'unknown', cutoffSource:sourceCutoff.source, cutoffIssue:sourceCutoff.issue, today: today, validationDate: validationDate, year: U.ymd(today).y,
      items: items, byPf: byPf, byKey: byKey, meta: meta,
      lovs: lovs, snapshot: snapshot, notes: notes
    };
    // Generic local source identity preserves workbook-specific notes across
    // reloads/upgrades. No known file hash or data-purpose classification exists.
    if(window.crypto && window.crypto.subtle){try{var hash=await window.crypto.subtle.digest('SHA-256',buffer);data.fingerprint=Array.from(new Uint8Array(hash),function(x){return x.toString(16).padStart(2,'0');}).join('');}catch(e){/* optional local identity support */}}
    identityNotes(data);
    data.issues = S.checks.run(data);
    return data;
  }

  S.loader = { load: load, cutoff: cutoff, cutoffSerial: cutoffSerial, display: display, uniqueDepartmentSectors: uniqueDepartmentSectors, resolveClassification: resolveClassification, redate:function(data,date){data.referenceDateReady=true;data.calculationDateKind='confirmed';data.today=date;data.validationDate=date;data.year=U.ymd(date).y;data.items.forEach(function(it){describe(it,date);resolveClassification(it,data.lovs);S.rules.calc(it,date);buildSearchIndex(it,SC.PF[it.pf]);});data.issues=S.checks.run(data);} };
})(window.Saytara = window.Saytara || {});
