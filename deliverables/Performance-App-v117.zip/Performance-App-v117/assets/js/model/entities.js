/* Entity scope: source relationships only; each workbook row counted once. */
(function(S){'use strict';
var U=S.util, PFS=['agenda','council','special'];
function usable(i){return PFS.includes(i.pf)&&i.hasTitle;}
function known(data){return Array.from(new Set(S.order.list(data,'Entities').concat(data.items.filter(usable).map(function(i){return i.entity||'';})).filter(Boolean)));}
function relations(i,data,lookup){var primary=String(i.entity||'').trim(),raw=String(i.t.entities||'').trim(),dict=lookup||new Map(known(data).map(function(v){return[U.key(v),v];})),contributors=[],unresolved=[];
 if(raw){var parts=dict.has(U.key(raw))?[raw]:raw.split(/[\n\r;,،؛|]+/);parts.forEach(function(p){p=p.trim();if(!p)return;var hit=dict.get(U.key(p));if(hit){if(!contributors.some(function(v){return U.key(v)===U.key(hit);}))contributors.push(hit);}else unresolved.push(p);});}
 return {primary:primary,contributors:contributors,raw:raw,unresolved:unresolved};}
function matches(i,data,scope,lookup){if(!usable(i)||!areaMatches(i,scope))return false;var roles=scope.role==='all'?['primary','contributor']:U.selection(scope.role||'primary');if(!U.hasSelection(scope.entity)&&(!roles.length||roles.includes('primary')))return true;var r=relations(i,data,lookup);if(!U.hasSelection(scope.entity))return roles.includes('contributor')&&r.contributors.length>0;return (!roles.length||roles.includes('primary'))&&U.selected(r.primary,scope.entity)||(!roles.length||roles.includes('contributor'))&&r.contributors.some(function(v){return U.selected(v,scope.entity);});}
function dictionary(data){return new Map(known(data).map(function(v){return[U.key(v),v];}));}
function rows(data,scope){if(!data)return [];var lookup=dictionary(data);return data.items.filter(function(i){return matches(i,data,scope,lookup);});}
function group(i){if(i.pf!=='agenda')return i.pf;return S.rules.test('agendaPlanned',i)?'agenda':S.rules.test('agendaEmerging',i)?'agendaNew':'agendaOther';}
var GROUPS=[['agenda','الأجندة المعتمدة'],['agendaNew','مستجدات الأجندة'],['agendaOther','أجندة بتصنيف آخر'],['council','قرارات المجالس'],['special','المشاريع الخاصة']];
function areaMatches(i,scope){return !U.hasSelection((scope||{}).areas)||U.selected(group(i),scope.areas);}
function portfolios(scope){var selected=U.selection((scope||{}).areas);return !selected.length?PFS.slice():Array.from(new Set(GROUPS.filter(function(g){return selected.includes(g[0]);}).map(function(g){return g[0].startsWith('agenda')?'agenda':g[0];})));}
function areaOptions(st){var observed=new Set([st.data,st.previous].filter(Boolean).flatMap(function(d){return d.items.filter(usable).map(group);}));return GROUPS.filter(function(g){return g[0]!=='agendaOther'||observed.has(g[0])||U.selected(g[0],(st.entity||{}).areas)&&U.hasSelection((st.entity||{}).areas);}).map(function(g){return {v:g[0],label:g[1]};});}
function areaText(scope){var selected=U.selection((scope||{}).areas);return !selected.length?'كل المجالات':selected.map(function(k){var g=GROUPS.find(function(g){return g[0]===k;});return g?g[1]:'اختيار مجال غير متاح';}).join('، ');}
function metrics(rs){var done=rs.filter(function(i){return i.statusCat==='done';}).length;return {total:rs.length,done:done,progress:rs.filter(function(i){return ['progress','review'].includes(i.statusCat);}).length,delayed:rs.filter(function(i){return i.statusCat==='delayed';}).length,other:rs.filter(function(i){return !['done','progress','review','delayed'].includes(i.statusCat);}).length,rate:rs.length?done/rs.length*100:null};}
function due(i){var t=i.t||{},m,y;if(i.pf==='agenda'){m=U.monthIndexAr(t.newMonth)||U.monthIndexAr(t.month);y=Number(t.year);}else if(i.pf==='special'){m=U.monthIndexAr(t.endMonth);y=Number(t.endYear);}else return null;return m&&Number.isInteger(y)&&y>=1900&&y<=2200?U.eomonth(y,m):null;}
function validDate(n){return typeof n==='number'&&Number.isFinite(n)&&n>0&&n<2958466?Math.floor(n):null;}
function presentation(i,cutoff){
 var t=i.t||{},c=i.c||{},dates=[],recorded=false;
 var columns=Array.isArray(i.all)?i.all.map(function(x){return x.field;}):Object.keys(c),available=['dateSac','dateEc'].every(function(f){return columns.includes(f);});
 if(i.pf==='agenda') ['dateSac','dateEc'].forEach(function(f){var cell=c[f],value=cell&&cell.t!=='e'?cell.v:t[f];if(value!=null&&String(value).trim()!=='')recorded=true;var date=cell&&cell.t==='n'?validDate(cell.v):null;if(date!=null)dates.push({field:f,date:date});});
 dates.sort(function(a,b){return a.date-b.date;});
 var reference=validDate(cutoff),upcoming=reference==null?dates:dates.filter(function(x){return x.date>=reference;}),chosen=upcoming[0]||dates[dates.length-1]||null;
 return {recorded:recorded,available:available,dates:dates,date:chosen?chosen.date:null,field:chosen?chosen.field:''};
}
function deadlineLabel(i,cutoff){var p=presentation(i,cutoff);return i.pf==='agenda'?(i.statusCat==='ready'&&p.date!=null?'موعد العرض المسجل':'موعد الإنجاز المخطط'):i.pf==='special'?'موعد انتهاء المشروع':'موعد غير محدد في المصدر';}
function deadlineReason(i,date,cutoff){
 var target=validDate(date),reference=validDate(cutoff),cat=i.statusCat||'none',closed=['done','cancelled','hold'].includes(cat),p=presentation(i,cutoff);
 if(closed||target==null||reference==null)return '';
 var late=target<reference,soon=!late&&target<=reference+30;
 if(!late&&!soon)return '';
 if(i.pf==='agenda'){
  if(cat==='ready'){
   if(p.date!=null)return late?'جاهز للعرض · متابعة نتيجة العرض المسجل':'جاهز للعرض · موعد العرض المسجل خلال 30 يوماً';
   if(p.recorded)return late?'جاهز للعرض · تجاوز الموعد المخطط؛ موعد العرض المسجل يحتاج مراجعة':'جاهز للعرض · الموعد المخطط خلال 30 يوماً؛ موعد العرض المسجل يحتاج مراجعة';
   if(!p.available)return late?'جاهز للعرض · متابعة تحديد موعد العرض بعد تجاوز الموعد المخطط':'جاهز للعرض · متابعة تحديد موعد العرض قبل الموعد المخطط خلال 30 يوماً';
   return late?'جاهز للعرض · تأخر حجز موعد العرض':'جاهز للعرض · يلزم حجز موعد العرض قبل الموعد المخطط خلال 30 يوماً';
  }
  if(cat==='review')return late?'قيد المراجعة · تجاوز الموعد المخطط':'قيد المراجعة · موعد الإنجاز المخطط خلال 30 يوماً';
  if(cat==='progress')return late?'قيد التطوير · تجاوز موعد الإنجاز المخطط':'قيد التطوير · موعد الإنجاز المخطط خلال 30 يوماً';
  return late?'تجاوز موعد الإنجاز المخطط':'موعد الإنجاز المخطط خلال 30 يوماً';
 }
 if(i.pf==='special')return late?'تجاوز موعد انتهاء المشروع':'موعد انتهاء المشروع خلال 30 يوماً';
 return '';
}
function deadline(i,cutoff){
 var planned=validDate(due(i)),reference=validDate(cutoff),p=presentation(i,cutoff),cat=i.statusCat||'none',closed=['done','cancelled','hold'].includes(cat);
 // A ready topic has completed development. Use its recorded presentation
 // date when available; a passed development plan does not make a future
 // booked presentation late. Neither date proves presentation or completion.
 var target=i.pf==='agenda'&&cat==='ready'&&p.date!=null?p.date:planned;
 var late=!closed&&target!=null&&reference!=null&&target<reference;
 var soon=!closed&&!late&&target!=null&&reference!=null&&target<=reference+30;
 return {plannedDue:planned,due:target,label:deadlineLabel(i,cutoff),reason:deadlineReason(i,target,cutoff),lateByDate:late,soon:soon,closed:closed,
  stage:cat,presentationDate:p.date,presentationField:p.field,presentationRecorded:p.recorded,presentationAvailable:p.available,presentationDates:p.dates};
}
function sort(data,rs){var dates=new Map(rs.map(function(i){return [i,deadline(i,data.today).due];}));return rs.slice().sort(function(a,b){var ad=dates.get(a),bd=dates.get(b);return S.order.status(data,a.statusLabel,b.statusLabel)||(ad==null?Infinity:ad)-(bd==null?Infinity:bd)||PFS.indexOf(a.pf)-PFS.indexOf(b.pf)||a.seq-b.seq;});}
function build(st){var scope=st.entity||{entity:'',role:'primary'},data=st.data,cur=sort(data,rows(data,scope)),prior=rows(st.previous,scope),cs=st.comparison||{previous:{},current:{}},err=S.comparison.validate(cs.previous,cs.current,st.previous,data),cmp=null;
 var currentLookup=dictionary(data),previousLookup=st.previous?dictionary(st.previous):null;
 if(!err){var oldRows=new Set(st.previous.items),match=function(i){var old=oldRows.has(i);return matches(i,old?st.previous:data,scope,old?previousLookup:currentLookup);};cmp=S.comparison.compare(st.previous,data,{entityMatch:match});cmp.rows.forEach(function(x){if(x.before&&x.after&&String(x.before.t.entities||'')!==String(x.after.t.entities||''))x.changes.push({field:'الجهات المساهمة (النص المصدر)',before:x.before.t.entities||'',after:x.after.t.entities||''});});}
 var visiblePrior=err?[]:prior,panels=GROUPS.map(function(g){var a=cur.filter(function(i){return group(i)===g[0];}),b=visiblePrior.filter(function(i){return group(i)===g[0];});var pf=g[0].startsWith('agenda')?'agenda':g[0],available=!!(data.meta[pf]&&data.meta[pf].found),pa=!!(st.previous&&st.previous.meta[pf]&&st.previous.meta[pf].found);var field=S.schema.PF[pf].fields.status.h,sa=available&&!(data.meta[pf].missing||[]).includes(field),psa=pa&&!(st.previous.meta[pf].missing||[]).includes(field),now=available?metrics(a):{total:null,done:null,progress:null,delayed:null,other:null,rate:null},before=err||!pa?null:metrics(b);if(!sa)['done','progress','delayed','other','rate'].forEach(function(k){now[k]=null;});if(before&&!psa)['done','progress','delayed','other','rate'].forEach(function(k){before[k]=null;});return{id:g[0],label:g[1],rows:a,prior:b,now:now,before:before,statusAvailable:sa,previousStatusAvailable:!err&&psa};}).filter(function(p){return p.rows.length||p.prior.length;}),attention=[];
 cur.forEach(function(i){var reasons=[],d=deadline(i,data.today);if(i.statusCat==='delayed')reasons.push('متأخر حسب الحالة المسجلة');if(d.reason&&(d.lateByDate||i.statusCat!=='delayed'))reasons.push(d.reason);if(i.pf==='council'&&U.key(i.t.hasReport)===U.key('لا'))reasons.push('لا يتوفر تقرير بالمستجدات حسب المصدر');if(cmp&&cmp.rows.some(function(x){return x.after===i&&x.changes.some(function(c){return c.field==='المواعيد';});}))reasons.push('تغيرت المواعيد بين النسختين');if(reasons.length)attention.push({it:i,reasons:reasons,deadline:d});});
 return {scope:scope,rows:cur,prior:visiblePrior,panels:panels,attention:attention,comparison:cmp,error:err,unassigned:data.items.filter(function(i){return usable(i)&&areaMatches(i,scope)&&!i.entity;}).length,ambiguous:cur.filter(function(i){return relations(i,data,currentLookup).unresolved.length;}).length};}
function options(st){var all=[st.data,st.previous].filter(Boolean),vals=new Map();all.forEach(function(d){var lookup=dictionary(d);d.items.filter(usable).forEach(function(i){var r=relations(i,d,lookup);[r.primary].concat(r.contributors).filter(Boolean).forEach(function(v){vals.set(U.key(v),v);});});});return S.order.sort(st.data,Array.from(vals.values()),'Entities');}
function statusKey(i){return U.key(i.statusLabel)||'__missing__';}
function statusRows(data,rs,prior,available,previousAvailable,pf){
 var all=new Map();(available?rs:[]).concat(previousAvailable?prior||[]:[]).forEach(function(i){var k=statusKey(i);if(!all.has(k))all.set(k,{key:k,label:i.statusLabel||'غير مسجل',cat:i.statusCat||'none'});});
 return Array.from(all.values()).sort(function(a,b){return S.order.status(data,a.key==='__missing__'?'':a.label,b.key==='__missing__'?'':b.label,pf);}).map(function(x){x.current=available?rs.filter(function(i){return statusKey(i)===x.key;}).length:null;x.previous=previousAvailable?(prior||[]).filter(function(i){return statusKey(i)===x.key;}).length:null;return x;});
}
function noteFields(i){return (i.pf==='agenda'?['notes','rapporteur']:i.pf==='special'?['recs','achieved','notes']:['notes']).filter(function(k){return i.t[k];});}
function filterItem(i,scope){return (!scope.area||group(i)===scope.area)&&(!U.hasSelection(scope.status)||U.selected(statusKey(i),scope.status))&&(!scope.q||U.norm([i.title,i.entity,i.sector,i.unit,i.statusLabel].concat(Object.values(i.t||{})).join(' ')).includes(U.norm(scope.q)));}
function changeRows(r){return r.comparison?r.comparison.rows.filter(function(x){return x.kind!=='matched'||x.changes.length;}):[];}
function focus(r,st){var s=st.entity||{},mode=['records','attention','changes','notes'].includes(s.mode)?s.mode:'',rows=[];
 if(mode==='changes'){var oldLookup=st.previous?dictionary(st.previous):null,newLookup=dictionary(st.data);rows=changeRows(r).filter(function(x){return (x.before&&matches(x.before,st.previous,r.scope,oldLookup)&&filterItem(x.before,s))||(x.after&&matches(x.after,st.data,r.scope,newLookup)&&filterItem(x.after,s));});}
 else{rows=r.rows.filter(function(i){return filterItem(i,s)&&(mode!=='attention'||r.attention.some(function(a){return a.it===i;}))&&(mode!=='notes'||noteFields(i).length);});}
 var size=12,pages=Math.max(1,Math.ceil(rows.length/size)),page=Math.min(pages,Math.max(1,Number(s.page)||1));return {mode:mode,rows:rows,total:rows.length,page:page,pages:pages,visible:rows.slice((page-1)*size,page*size),unresolved:mode==='changes'&&r.comparison?r.comparison.unresolved.filter(function(x){return filterItem(x.it,s);}):[]};
}
S.entities={areaMatches:areaMatches,areaOptions:areaOptions,areaText:areaText,portfolios:portfolios,statusKey:statusKey,statusRows:statusRows,noteFields:noteFields,filterItem:filterItem,changeRows:changeRows,focus:focus,groups:GROUPS,usable:usable,relations:relations,matches:matches,rows:rows,metrics:metrics,due:due,deadline:deadline,deadlineLabel:deadlineLabel,deadlineReason:deadlineReason,sort:sort,group:group,build:build,options:options};
})(window.Saytara=window.Saytara||{});
