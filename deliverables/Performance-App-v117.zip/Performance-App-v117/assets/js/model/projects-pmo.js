/* Additive PMO readings of the existing, filtered Projects source rows.
   Timeline follows the workbook's month-end convention; schedule elapsed time
   uses the recorded numeric start/end days. Neither reading predicts delivery. */
(function (S) {
  'use strict';

  var FINANCE = [
    ['approved', 'الموازنة الأصلية'], ['revised', 'الموازنة المعتمدة'],
    ['committed', 'المخصص'], ['nonCommitted', 'غير المخصص'],
    ['workDone', 'قيمة الأعمال المنجزة'], ['spent', 'المنفق حسب الفواتير']
  ];
  var LABELS = {
    'timeline:overdue': 'متأخر',
    'timeline:next30': 'مشاريع مفتوحة يحل موعدها خلال 30 يوماً',
    'timeline:later': 'مشاريع مفتوحة بموعد لاحق',
    'timeline:noDate': 'مشاريع مفتوحة دون موعد انتهاء متاح',
    'timeline:completed': 'مشاريع منجزة حسب الحالة',
    'timeline:cancelled': 'مشاريع ملغاة', 'timeline:frozen': 'مشاريع معلقة', 'timeline:transferred': 'مشاريع منقولة',
    'timeline:unknown': 'مشاريع بحالة غير معروفة أو غير مسجلة',
    'timeline:cutoffUnavailable': 'مشاريع مفتوحة بموعد مسجل وتاريخ مرجعي غير متاح',
    'progress:zero': 'إنجاز مسجل 0%', 'progress:early': 'إنجاز مسجل أكبر من 0% وأقل من 25%',
    'progress:middle': 'إنجاز مسجل من 25% إلى أقل من 75%',
    'progress:advanced': 'إنجاز مسجل من 75% إلى أقل من 100%',
    'progress:complete': 'إنجاز مسجل 100%',
    'progress:missing': 'نسبة إنجاز غير مسجلة', 'progress:invalid': 'نسبة إنجاز غير صالحة للقراءة',
    'attention:overdueHigh': 'متأخر · أولوية عالية',
    'attention:overBudget': 'منفق يتجاوز الموازنة على مشاريع قابلة للمقارنة',
    'attention:negativeFinance': 'مشاريع بقيم مالية سالبة',
    'attention:noDate': 'مشاريع مفتوحة دون موعد انتهاء متاح',
    'attention:noProgress': 'نسبة إنجاز مفقودة أو غير صالحة',
    'pair:budgetSpent': 'مشاريع بموازنة ومنفق مسجلين',
    'pair:budgetWork': 'مشاريع بموازنة وقيمة أعمال مسجلتين',
    'pair:workSpent': 'مشاريع بقيمة أعمال ومنفق مسجلين',
    'ratio:budgetSpent': 'نسبة المنفق على مشاريع بموازنة موجبة ومنفق غير سالب',
    'ratio:budgetWork': 'نسبة قيمة الأعمال على مشاريع بموازنة موجبة وقيمة أعمال غير سالبة',
    'schedule:eligible': 'قراءة الزمن المنقضي والتقدم المسجل',
    'schedule:unavailable': 'مشاريع لا تكتمل فيها حقول القراءة الزمنية',
    'source:late': 'التأخر حسب قواعد المصدر'
  };
  var TYPE_NAMES = { strategic: 'استراتيجي', operational: 'تشغيلي' };
  var PRIORITY_NAMES = { h: 'عالية', m: 'متوسطة', l: 'منخفضة' };

  function own(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
  function cell(it, field) { return it.c && it.c[field]; }
  function blank(c) { return !c || c.t === 's' && !String(c.v).trim(); }
  function money(c) { return S.projectsReport.money(c); }
  function date(c) {
    return c && c.t === 'n' && typeof c.v === 'number' && Number.isFinite(c.v) && c.v > 0 && c.v < 2958466
      ? Math.floor(c.v) : null;
  }
  function monthOnly(c) {
    return !!(c && c.t === 's' && S.util.MONTHS_EN3.indexOf(S.util.xlTrim(c.v).toUpperCase()) >= 0);
  }
  function deadline(it, numericEnd) {
    // The shared source calculation already assigns month-only inputs to this
    // workbook's reference year. An explicit numeric date retains its own year.
    if (numericEnd == null && !monthOnly(cell(it, 'end'))) return null;
    var due = it.calc && it.calc.due;
    return typeof due === 'number' && Number.isFinite(due) && due > 0 && due < 2958466 ? Math.floor(due) : null;
  }
  function amount(items, field) {
    return S.projectsReport.amount(items, field);
  }
  function finance(items) {
    return FINANCE.map(function (f) { return Object.assign({ key: f[0], name: f[1] }, amount(items, f[0])); });
  }
  function status(it) {
    var c = cell(it, 'status'), x = c && c.t === 's' ? S.util.xlTrim(c.v).toLowerCase() : '';
    var cat = it.statusCat;
    if (cat === 'progress' || cat === 'notStarted') return 'open';
    if (cat === 'done') return 'completed';
    if (cat === 'cancelled') return 'cancelled';
    if (cat === 'hold') return 'frozen';
    if (cat === 'transferred') return 'transferred';
    if (x === 'active' || x === 'not started') return 'open';
    if (x === 'completed') return 'completed';
    if (x === 'cancelled') return 'cancelled';
    if (x === 'frozen') return 'frozen';
    if (x === 'transferred') return 'transferred';
    return 'unknown';
  }
  function progress(it) {
    var c = cell(it, 'progress'), p = it.progress;
    if (blank(c)) return { key: 'missing', value: null };
    if (!c || c.t !== 'n' || typeof p !== 'number' || !Number.isFinite(p) || p < 0 || p > 100)
      return { key: 'invalid', value: null };
    return { key: p === 0 ? 'zero' : p < 25 ? 'early' : p < 75 ? 'middle' : p < 100 ? 'advanced' : 'complete', value: p };
  }
  function coverage(known, total) { return total ? known / total : null; }
  function fieldName(key) { return FINANCE.find(function (f) { return f[0] === key; })[1]; }
  function categoryName(field, key) {
    if (!String(key).trim()) return 'غير مسجل';
    var names = field === 'projectType' ? TYPE_NAMES : field === 'priority' ? PRIORITY_NAMES : {};
    return names[S.util.key(key)] || key;
  }
  function orderedKeys(data, items, field, lov) {
    var keys = [];
    items.forEach(function (it) {
      var key = field === 'unit' ? it.unit || '' : (it.t || {})[field === 'projectType' ? 'ptype' : field] || '';
      if (keys.indexOf(key) < 0) keys.push(key);
    });
    var source = S.order.list(data, lov).map(S.util.key), positions = Object.create(null);
    keys.forEach(function (key, i) { positions[key] = i; });
    return keys.sort(function (a, b) {
      var ai = source.indexOf(S.util.key(a)), bi = source.indexOf(S.util.key(b));
      if (ai >= 0 || bi >= 0) return (ai < 0 ? 1000000 : ai) - (bi < 0 ? 1000000 : bi) || positions[a] - positions[b];
      return positions[a] - positions[b];
    });
  }
  function valueOf(it, field) { return field === 'unit' ? it.unit || '' : (it.t || {})[field === 'projectType' ? 'ptype' : field] || ''; }
  function label(value) {
    if (own(LABELS, value)) return LABELS[value];
    try {
      var subgroup = /^(unit|type|priority)-(done|budget):(.+|)$/.exec(value);
      if (subgroup) {
        var field = subgroup[1] === 'type' ? 'projectType' : subgroup[1];
        var name = categoryName(field, decodeURIComponent(subgroup[3]));
        return (subgroup[2] === 'done' ? 'منجز حسب الحالة' : 'مشاريع بموازنة مسجلة') + ' · ' + name;
      }
      if (/^unit-overdue:/.test(value)) return 'متأخر · الوحدة: ' + categoryName('unit', decodeURIComponent(value.slice(13)));
      if (/^unit:/.test(value)) return 'الوحدة: ' + categoryName('unit', decodeURIComponent(value.slice(5)));
      if (/^matrix:/.test(value)) {
        var pair = value.slice(7).split(':');
        if (pair.length === 2) return categoryName('projectType', decodeURIComponent(pair[0])) + ' · أولوية ' + categoryName('priority', decodeURIComponent(pair[1]));
      }
      if (/^type:/.test(value)) return 'النوع: ' + categoryName('projectType', decodeURIComponent(value.slice(5)));
      if (/^priority:/.test(value)) return 'الأولوية: ' + categoryName('priority', decodeURIComponent(value.slice(9)));
    } catch (e) { /* Malformed route text cannot create a selection or condition. */ }
    return 'قائمة المشاريع';
  }
  function select(model, value, legacyValue) {
    // IDs are generated from this model's source rows. No arbitrary conditions,
    // JSON predicates, selectors or property traversal can be supplied by a URL.
    if (legacyValue != null) value = value === 'pmo' ? legacyValue : value + ':' + legacyValue;
    return model && model.selections && own(model.selections, value) ? model.selections[value].slice() : [];
  }

  function model(state, baseModel) {
    var data = state && state.data || {}, base = baseModel || S.projects.model(state);
    var items = (base.items || []).filter(function (it) {
      return it.pf === 'secretariat' && it.c && S.rules.MET.secTotal.test(it);
    });
    var sourcePosition = new Map(), inputPosition = new Map();
    (data.items || []).forEach(function (it, index) { sourcePosition.set(it, index); });
    items.forEach(function (it, index) { inputPosition.set(it, index); });
    // The legacy base model sorts its register for reporting. Additive PMO
    // previews retain the workbook encounter order within that same scope.
    items.sort(function (a, b) {
      var ai = sourcePosition.has(a) ? sourcePosition.get(a) : inputPosition.get(a);
      var bi = sourcePosition.has(b) ? sourcePosition.get(b) : inputPosition.get(b);
      return ai - bi;
    });
    var rawCutoff = data.today;
    var cutoff = typeof rawCutoff === 'number' && Number.isFinite(rawCutoff) && rawCutoff > 0 && rawCutoff < 2958466
      ? Math.floor(rawCutoff) : null;
    var selections = Object.create(null);
    function register(id, rows) { selections[id] = rows.slice(); return id; }
    var readings = items.map(function (it) {
      var end = date(cell(it, 'end')), start = date(cell(it, 'start')), due = deadline(it, end);
      var st = status(it), band = progress(it), timeline = st;
      if (st === 'open') timeline = due == null ? 'noDate' : cutoff == null ? 'cutoffUnavailable' : due < cutoff ? 'overdue' : due <= cutoff + 30 ? 'next30' : 'later';
      return { item: it, status: st, start: start, end: end, due: due, monthOnlyEnd: monthOnly(cell(it, 'end')), progress: band, timeline: timeline };
    });
    var timeline = ['overdue', 'next30', 'later', 'noDate', 'completed', 'cancelled', 'frozen', 'transferred', 'unknown', 'cutoffUnavailable'].map(function (key) {
      var rows = readings.filter(function (r) { return r.timeline === key; }), id = 'timeline:' + key;
      var known = rows.filter(function (r) { return r.end != null; }).length;
      return { key: key, label: LABELS[id], n: rows.length, items: rows.map(function (r) { return r.item; }),
        numericDateKnown: known, numericDateMissing: rows.length - known,
        deadlineKnown: rows.filter(function (r) { return r.due != null; }).length,
        monthDateKnown: rows.filter(function (r) { return r.monthOnlyEnd && r.due != null; }).length,
        missingDate: rows.filter(function (r) { return blank(cell(r.item, 'end')); }).length,
        invalidDate: rows.filter(function (r) { return r.end == null && !r.monthOnlyEnd && !blank(cell(r.item, 'end')); }).length,
        numericPastDue: cutoff == null ? null : rows.filter(function (r) { return r.end != null && r.due != null && r.due < cutoff; }).length,
        pastDue: cutoff == null ? null : rows.filter(function (r) { return r.due != null && r.due < cutoff; }).length,
        id: register(id, rows.map(function (r) { return r.item; })) };
    });
    var bands = ['zero', 'early', 'middle', 'advanced', 'complete', 'missing', 'invalid'].map(function (key) {
      var rows = readings.filter(function (r) { return r.progress.key === key; }).map(function (r) { return r.item; });
      return { key: key, label: LABELS['progress:' + key], n: rows.length, items: rows, id: register('progress:' + key, rows) };
    });
    var overdue = timeline[0].items;
    var overBudget = items.filter(function (it) {
      var budget = money(cell(it, 'revised')), spent = money(cell(it, 'spent'));
      return budget != null && spent != null && budget >= 0 && spent >= 0 && spent > budget;
    });
    var overBudgetEligible = items.filter(function (it) {
      var budget = money(cell(it, 'revised')), spent = money(cell(it, 'spent'));
      return budget != null && spent != null && budget >= 0 && spent >= 0;
    });
    var attention = {
      overdueHigh: overdue.filter(function (it) { return (it.t || {}).priority === 'H'; }),
      overBudget: overBudget,
      negativeFinance: items.filter(function (it) { return FINANCE.some(function (f) { var v = money(cell(it, f[0])); return v != null && v < 0; }); }),
      noDate: timeline[3].items,
      noProgress: readings.filter(function (r) { return r.progress.value == null; }).map(function (r) { return r.item; })
    };
    Object.keys(attention).forEach(function (key) { register('attention:' + key, attention[key]); });
    register('source:late', (base.late || []).filter(function (it) { return items.indexOf(it) >= 0; }));
    function pair(key, left, right) {
      var rows = items.filter(function (it) { return money(cell(it, left)) != null && money(cell(it, right)) != null; });
      var lv = amount(rows, left).value, rv = amount(rows, right).value;
      var ratioRows = left === 'revised' ? rows.filter(function (it) { return money(cell(it, left)) > 0 && money(cell(it, right)) >= 0; }) : [];
      var ratioLeft = amount(ratioRows, left).value, ratioRight = amount(ratioRows, right).value;
      return { key: key, left: left, right: right, leftLabel: fieldName(left), rightLabel: fieldName(right),
        leftValue: lv, rightValue: rv, difference: rows.length ? rv - lv : null,
        known: rows.length, total: items.length, coverage: coverage(rows.length, items.length), items: rows,
        id: register('pair:' + key, rows), ratio: ratioLeft > 0 ? ratioRight / ratioLeft * 100 : null,
        ratioId: left === 'revised' ? register('ratio:' + key, ratioRows) : null,
        ratioKnown: ratioRows.length, ratioTotal: items.length, ratioLeftValue: ratioLeft, ratioRightValue: ratioRight,
        ratioNote: 'نسبة القيم المسجلة على مشاريع ذات موازنة موجبة وقيمة مقارنة غير سالبة؛ ليست نسبة إنجاز.',
        differenceNote: 'فرق قيم مسجلة في المشاريع نفسها؛ لا يمثل مستحقات غير مدفوعة.' };
    }
    var comparisons = { budgetSpent: pair('budgetSpent', 'revised', 'spent'), budgetWork: pair('budgetWork', 'revised', 'workDone'), workSpent: pair('workSpent', 'workDone', 'spent') };
    var groups = {};
    [['projectType', 'ProjectType', 'type:'], ['priority', 'ProjectPriority', 'priority:'], ['unit', 'Departments', 'unit:']].forEach(function (spec) {
      groups[spec[0]] = orderedKeys(data, items, spec[0], spec[1]).map(function (key) {
        var rows = items.filter(function (it) { return valueOf(it, spec[0]) === key; });
        var late = rows.filter(function (it) { return overdue.indexOf(it) >= 0; });
        var prefix = spec[2].slice(0, -1), encodedKey = encodeURIComponent(key);
        var result = { key: key, name: categoryName(spec[0], key), n: rows.length,
          done: rows.filter(S.rules.MET.secDone.test).length, overdue: late.length,
          finance: finance(rows), items: rows, id: register(spec[2] + encodedKey, rows),
          doneId: register(prefix + '-done:' + encodedKey, rows.filter(S.rules.MET.secDone.test)),
          budgetId: register(prefix + '-budget:' + encodedKey, rows.filter(function (it) { return money(cell(it, 'revised')) != null; })) };
        if (spec[0] === 'unit') result.overdueId = register('unit-overdue:' + encodedKey, late);
        return result;
      });
    });
    function matrixKeys(field, lov, canonical) {
      var keys = canonical.slice().sort(function (a, b) { return S.order.compare(data, lov, a, b); });
      groups[field].forEach(function (g) { if (keys.indexOf(g.key) < 0) keys.push(g.key); });
      return keys.map(function (key) { return { key: key, name: categoryName(field, key) }; });
    }
    // A filtered empty category is still a known zero. Stable canonical rows and
    // columns keep the mix comparable; actual unknown/blank source values follow.
    var matrix = { types: matrixKeys('projectType', 'ProjectType', ['Strategic', 'Operational']),
      priorities: matrixKeys('priority', 'ProjectPriority', ['H', 'M', 'L']), rows: [], cells: [], total: items.length };
    [['types', 'projectType', 'type:'], ['priorities', 'priority', 'priority:']].forEach(function (spec) {
      matrix[spec[0]].forEach(function (category) {
        var rows = items.filter(function (it) { return valueOf(it, spec[1]) === category.key; });
        var prefix = spec[2].slice(0, -1), encodedKey = encodeURIComponent(category.key);
        category.id = register(spec[2] + encodedKey, rows);
        category.doneId = register(prefix + '-done:' + encodedKey, rows.filter(S.rules.MET.secDone.test));
        category.budgetId = register(prefix + '-budget:' + encodedKey, rows.filter(function (it) { return money(cell(it, 'revised')) != null; }));
      });
    });
    matrix.types.forEach(function (type) {
      var row = { key: type.key, name: type.name, cells: [] };
      matrix.priorities.forEach(function (priority) {
        var rows = items.filter(function (it) { return valueOf(it, 'projectType') === type.key && valueOf(it, 'priority') === priority.key; });
        var group = { type: type.key, priority: priority.key, n: rows.length, done: rows.filter(S.rules.MET.secDone.test).length,
          overdue: rows.filter(function (it) { return overdue.indexOf(it) >= 0; }).length,
          finance: finance(rows), items: rows, id: register('matrix:' + encodeURIComponent(type.key) + ':' + encodeURIComponent(priority.key), rows) };
        row.cells.push(group); matrix.cells.push(group);
      });
      matrix.rows.push(row);
    });
    var schedule = { rows: [], items: [], known: 0, total: items.length, coverage: null,
      missing: { start: 0, end: 0, progress: 0 }, invalid: { start: 0, end: 0, progress: 0, range: 0 },
      monthOnly: { start: 0, end: 0 }, dateUnavailable: { start: 0, end: 0 }, cutoffAvailable: cutoff != null };
    readings.forEach(function (r) {
      ['start', 'end'].forEach(function (field) {
        if (r[field] != null) return;
        schedule.dateUnavailable[field]++;
        schedule[blank(cell(r.item, field)) ? 'missing' : monthOnly(cell(r.item, field)) ? 'monthOnly' : 'invalid'][field]++;
      });
      if (r.progress.key === 'missing') schedule.missing.progress++;
      if (r.progress.key === 'invalid') schedule.invalid.progress++;
      if (r.start != null && r.end != null && r.start >= r.end) schedule.invalid.range++;
      if (cutoff == null || r.start == null || r.end == null || r.start >= r.end || r.progress.value == null) return;
      var elapsed = Math.max(0, Math.min(100, (cutoff - r.start) / (r.end - r.start) * 100));
      schedule.rows.push({ item: r.item, key: r.item.key, title: r.item.title, start: r.start, end: r.end,
        startLabel: S.util.fmtDate(r.start), endLabel: S.util.fmtDate(r.end), elapsedPct: elapsed, elapsedPercent: elapsed,
        progress: r.progress.value, recordedProgress: r.progress.value, durationDays: r.end - r.start });
      schedule.items.push(r.item);
    });
    schedule.known = schedule.items.length; schedule.unavailable = items.length - schedule.known;
    schedule.coverage = coverage(schedule.known, items.length);
    schedule.id = register('schedule:eligible', schedule.items);
    schedule.unavailableId = register('schedule:unavailable', items.filter(function (it) { return schedule.items.indexOf(it) < 0; }));
    return { items: items, total: items.length, cutoff: cutoff, dateAvailable: cutoff != null,
      timeline: timeline, timelineNumericDateKnown: readings.filter(function (r) { return r.end != null; }).length,
      timelineDeadlineKnown: readings.filter(function (r) { return r.due != null; }).length,
      timelineMonthDateKnown: readings.filter(function (r) { return r.monthOnlyEnd && r.due != null; }).length,
      progress: bands, progressKnown: readings.filter(function (r) { return r.progress.value != null; }).length,
      attention: attention, overBudgetEligible: overBudgetEligible.length,
      finance: finance(items), comparisons: comparisons, groups: groups, typePriority: matrix,
      schedule: schedule, sourceLate: selections['source:late'], selections: selections,
      unavailableMetrics: ['لا تتوفر بيانات خط أساس لإثبات اتجاه تاريخي أو انحراف عن خطة معتمدة.',
        'لا تتوفر مواعيد متوقعة أو مؤشرات قيمة مكتسبة أو سجل مخاطر معتمد؛ لا تستنتج من الملاحظات.',
        'لا يتوفر حقل صريح للمستحقات غير المدفوعة؛ لا تستنتج من الفرق بين الأعمال والفواتير.'],
      notes: { timeline: 'المواعيد حسب نهاية شهر الانتهاء؛ الشهر دون سنة يتبع سنة مرجع بيانات الملف، والتاريخ الكامل يحتفظ بسنته المسجلة.',
        schedule: 'الزمن المنقضي بين يومي البدء والانتهاء المسجلين؛ الشهر وحده يحدد الموعد الشهري ولا يحدد يوماً لحساب المدة. القراءة ليست توقعاً أو مؤشر أداء.',
        coverage: 'أعداد الحقول المفقودة وغير الصالحة قد تتداخل؛ كل مشروع يبقى محسوباً مرة واحدة في نطاق المحفظة.' } };
  }
  S.projectsPMO = { model: model, select: select, label: label };
})(window.Saytara = window.Saytara || {});
