/* Filter presentation only. Source strings, IDs, workbook comparisons and
   snapshot identity retain their original values. One choice can select every
   original token that differs only in invisible/presentation formatting. */
(function(S){
 'use strict';
 var U=S.util;
 function display(value){
  var text=String(value==null?'':value).normalize('NFC');
  // Fold Arabic presentation glyphs only, retaining spelling and diacritics.
  text=text.replace(/[\uFB50-\uFDFF\uFE70-\uFEFC]/g,function(c){return c.normalize('NFKC');});
  return text.replace(/[\u00AD\u061C\u200B-\u200F\u202A-\u202E\u2060\u2066-\u2069\uFEFF]/g,'').replace(/\s+/g,' ').trim();
 }
 function fieldOf(id){return String(id||'').split(':').pop();}
 function canonical(value,id){var field=fieldOf(id);return S.organizationReference&&['sector','unit'].includes(field)?S.organizationReference.canonical(field,value):display(value);}
 function key(value,id){return canonical(value,id).toLowerCase();}
 // Canonical comparison is limited to forming organizational filter choices.
 // Source population matching continues to use the exact selected tokens.
 function selected(value,selection,id){var values=U.selection(selection);return !values.length||values.some(function(v){return key(v,id)===key(value,id);});}
 function organizationOptions(state,id,values){
  var field=fieldOf(id),ref=S.organizationReference;
  if(!ref||!['sector','unit'].includes(field))return values;
  var prefix=id[0],scope=prefix==='p'?state.projects:prefix==='d'?state.dash:prefix==='c'?(state.comparison||{}).scope:prefix==='f'?(state.search||{}).f:prefix==='r'?state.report:null;
  var listed=field==='sector'?ref.sectors:ref.rows.filter(function(row){return selected(row.parent,scope&&scope.sector,'sector');}).map(function(row){return row.value;});
  if(prefix==='p'&&field==='sector')listed=listed.filter(function(v){return key(v,'sector')!==key('الأمانة العامة للمجلس التنفيذي','sector');});
  var counted=(values||[]).some(function(o){return o&&typeof o.n==='number';});
  var existing=(values||[]).map(function(value){
   var opt=value!=null&&typeof value==='object'?Object.assign({},value):{v:String(value==null?'':value),label:String(value==null?'':value)||'غير مسجل'};
   if(field==='unit'&&U.hasSelection(scope&&scope.sector)){var row=ref.rows.find(function(r){return key(r.value,'unit')===key(opt.v,'unit');});if(row&&!selected(row.parent,scope.sector,'sector'))opt.parentMismatch=true;}
   return opt;
  });
  // Existing facet counts precede zero-count reference choices so identical
  // tokens are never counted twice or accidentally replaced by zero.
  return existing.concat(listed.map(function(v){var o={v:v,label:v};if(counted)o.n=0;return o;}));
 }
 function unique(values){return Array.from(new Set(values));}
 function sourceAliases(state,id,values){
  var field=id.slice(2),prefix=id[0],mapped={projectType:'ptype',projectStatus:'status',lead:'lead',legislationMonth:'legislationMonth'},sourceField=mapped[field]||field;
  if(prefix==='e'&&['role','areas'].includes(field))return values;
  // Options use readable text; exact workbook scopes sometimes compare the
  // untrimmed cell. Keep both tokens in the same choice. In particular FEFF is
  // removed by String.trim() in displayed text but survives Excel equality.
  var allowed=new Map((values||[]).map(function(o){var v=o!=null&&typeof o==='object'?o.v:o;return [key(v,id),o!=null&&typeof o==='object'?o.label:String(v==null?'':v)];}));
  var datasets=[state.data];if(prefix==='d'||prefix==='c'||prefix==='e')datasets.push(state.previous);
  var records=datasets.filter(Boolean).flatMap(function(d){return d.items||[];});
  if(prefix==='d'&&state.data&&state.data.snapshot)records=records.concat(state.data.snapshot.rows||[]);
  if(prefix==='p')records=records.filter(function(it){return it.pf==='secretariat';});
  if(prefix==='r'){var pf={projects:'secretariat',hh:'special',agenda:'agenda',council:'council'}[(state.report||{}).kind];if(pf)records=records.filter(function(it){return it.pf===pf;});}
  var aliases=[],seen=new Set();
  function add(value){
   if(value==null||!['string','number'].includes(typeof value))return;
   var token=String(value),k=key(token,id);if(!allowed.has(k)||seen.has(token))return;
   seen.add(token);aliases.push({v:token,label:allowed.get(k)});
  }
  records.forEach(function(it){
   var actualField=sourceField==='entity'&&it.pf==='legislation'?'sender':sourceField;
   add(it[field]);add(it.t&&it.t[actualField]);add(it.x&&it.x[actualField]);
   var cell=it.c&&it.c[actualField];if(cell&&cell.t!=='e')add(cell.v);
   if(field==='projectStatus'||field==='status')add(it.statusLabel);
   if(field==='quarter')add(it.calc&&it.calc.quarter);
   if(field==='legislationMonth')add(it.calc&&it.calc.legislationMonth&&it.calc.legislationMonth.key);
   if(field==='entity'&&prefix==='d'&&S.rules&&S.schema&&S.schema.PF[it.pf])add(S.rules.concernedEntity(it));
  });
  // Alias metadata has no population count: adding the underlying token must
  // not count a source row twice in the visible option's facet total.
  return (values||[]).concat(aliases);
 }
 function group(values,selectionValue,id){
  var selection=U.selection(selectionValue),chosen=new Set(selection),map=new Map(),out=[],field=fieldOf(id),organizational=['sector','unit'].includes(field);
  (values||[]).forEach(function(value){
   var opt=value!=null&&typeof value==='object'?value:{v:String(value==null?'':value),label:String(value==null?'':value)||'غير مسجل'};
   var token=String(opt.v==null?'':opt.v),k=key(token,id),g=map.get(k);
   if(!g){g={v:token,key:k,label:(organizational&&k?canonical(token,id):display(opt.label==null?token:opt.label))||'غير مسجل',variants:[],stale:true};map.set(k,g);out.push(g);}
   if(opt.parentMismatch)g.parentMismatch=true;
   if(g.variants.indexOf(token)<0){
    g.variants.push(token);
    if(typeof opt.n==='number'&&Number.isFinite(opt.n))g.n=(g.n||0)+opt.n;
   }
   if(!opt.stale)g.stale=false;
  });
  // Keep saved exact tokens even when their spelling is no longer in this
  // scope. They are not silently widened on loading or merely opening a menu.
  selection.forEach(function(token){
   var k=key(token,id),g=map.get(k);
   if(!g){g={v:token,key:k,label:canonical(token,id)||'غير مسجل',variants:[],stale:true};map.set(k,g);out.unshift(g);}
   if(g.variants.indexOf(token)<0)g.variants.push(token);
  });
  var labels=new Map();out.forEach(function(g){var k=key(g.label);if(!labels.has(k))labels.set(k,[]);labels.get(k).push(g);});
  out.forEach(function(g){
   // Equal translated labels can conceal genuinely different source values.
   // Keep separate choices and show the recorded token, rather than merge them.
   if(labels.get(key(g.label)).length>1)g.label+=' ('+(display(g.v)||'قيمة فارغة')+')';
   if(g.stale)g.label+=' (غير موجود ضمن الخيارات الحالية)';
   var n=g.variants.filter(function(v){return chosen.has(v);}).length;
   g.selected=n>0;g.partial=n>0&&n<g.variants.length;
  });
  if(organizational&&S.organizationReference){var order=field==='sector'?S.organizationReference.sectors:S.organizationReference.units,rank=new Map(order.map(function(v,i){return [key(v,id),i];}));out.forEach(function(g){if(g.key&&!rank.has(g.key)&&!g.stale)g.label+=' · قيمة أخرى من الملف';else if(g.parentMismatch&&!g.stale)g.label+=' · تبعيتها مختلفة في الملف';});out.sort(function(a,b){var ra=rank.has(a.key)?rank.get(a.key):1e6,rb=rank.has(b.key)?rank.get(b.key):1e6;return ra-rb;});}
  return out;
 }
 function selectionGroups(values,options,id){
  var byKey=new Map((options||[]).map(function(o){return [o.key==null?key(o.v,id):o.key,o];})),seen=new Set();
  return U.selection(values).filter(function(v){var k=key(v,id);if(seen.has(k))return false;seen.add(k);return true;}).map(function(v){return byKey.get(key(v,id))||{v:v,key:key(v,id),label:canonical(v,id)||'غير مسجل',variants:[v],selected:true};});
 }
 function count(values,options,id){return selectionGroups(values,options,id).length;}
 function single(values){var groups=selectionGroups(values);return groups.length===1?display(groups[0].v):null;}
 function text(values,options,all,id){var groups=selectionGroups(values,options,id);return groups.length?groups.map(function(o){return o.label;}).join('، '):all||'';}
 function remove(values,value,id){var k=key(value,id);return U.selection(values).filter(function(v){return key(v,id)!==k;});}
 function toggle(values,option,checked,id){var tokens=remove(values,option.v,id);return checked?unique(tokens.concat(option.variants||[option.v])):tokens;}
 function all(options){return unique((options||[]).filter(function(o){return !o.stale;}).flatMap(function(o){return o.variants||[o.v];}));}
 function matches(option,query){var needle=U.norm(display(query));return !needle||[option.label].concat(option.variants||[option.v]).some(function(v){return U.norm(display(v)).includes(needle);});}
 S.filterOptions={display:display,canonical:canonical,key:key,selected:selected,organizationOptions:organizationOptions,sourceAliases:sourceAliases,group:group,selectionGroups:selectionGroups,count:count,single:single,text:text,remove:remove,toggle:toggle,all:all,matches:matches};
})(window.Saytara=window.Saytara||{});
