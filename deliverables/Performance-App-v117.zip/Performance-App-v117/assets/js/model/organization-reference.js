/* Approved sector/unit filter vocabulary supplied by the user, 2026-10-09.
   This registry changes filter presentation only. Workbook values, source
   classifications, identifiers and snapshot matching retain their originals. */
(function(S){
 'use strict';
 var pairs=[
  ['الأمانة العامة للمجلس التنفيذي','مكتب الأمين العام'],
  ['الأمانة العامة للمجلس التنفيذي','الشراكات والعلاقات الدولية'],
  ['الأمانة العامة للمجلس التنفيذي','مكتب التدقيق الداخلي'],
  ['الأمانة العامة للمجلس التنفيذي','مكتب خطة دبي'],
  ['الأمانة العامة للمجلس التنفيذي','الأبحاث والرصد'],
  ['الحوكمة','الحوكمة'],
  ['الحوكمة','التشريعات الحكومية'],
  ['الحوكمة','التنفيذ والأداء'],
  ['التنمية المستدامة','السياسات والاستراتيجيات الصحية والعدل'],
  ['التنمية المستدامة','السياسات والاستراتيجيات البيئية والبنية التحتية'],
  ['الاقتصاد والتنمية الاجتماعية','السياسات والإستراتيجيات الاجتماعية'],
  ['الاقتصاد والتنمية الاجتماعية','السياسات والإستراتيجيات الاقتصادية'],
  ['التميز والخدمات الحكومية','التقييم والدراسات'],
  ['التميز والخدمات الحكومية','التميز والخدمات الحكومية'],
  ['الاتصال الحكومي وشؤون الأمانة العامة','الاتصال الحكومي'],
  ['الاتصال الحكومي وشؤون الأمانة العامة','الاتصال الداخلي'],
  ['الاتصال الحكومي وشؤون الأمانة العامة','الخدمات المؤسسية'],
  ['الاتصال الحكومي وشؤون الأمانة العامة','تميز الموارد البشرية'],
  ['الاتصال الحكومي وشؤون الأمانة العامة','المشتريات والشؤون الإدارية'],
  ['الاتصال الحكومي وشؤون الأمانة العامة','تقنية المعلومات'],
  ['الاتصال الحكومي وشؤون الأمانة العامة','المالية والحسابات'],
  ['الاتصال الحكومي وشؤون الأمانة العامة','المراسلات والأرشفة'],
  ['الاتصال الحكومي وشؤون الأمانة العامة','تنفيذ ومتابعة المشاريع الميدانية']
 ];
 // Bounded aliases from the supplied mold's old Departments list. This is
 // deliberately not a general Arabic spelling or fuzzy matching rule.
 var legacy={
  'البحث والرصد':'الأبحاث والرصد',
  'السياسات والاستراتيجيات الاجتماعية':'السياسات والإستراتيجيات الاجتماعية',
  'السياسات والاستراتيجيات الاقتصادية':'السياسات والإستراتيجيات الاقتصادية',
  'الأرشفة':'المراسلات والأرشفة'
 };
 function display(value){
  // The filter module is loaded after this registry; call its shared formatter
  // at runtime rather than maintain another normalization implementation.
  if(S.filterOptions)return S.filterOptions.display(value);
  return String(value==null?'':value).normalize('NFC').replace(/\s+/g,' ').trim();
 }
 function canonical(field,value){
  var text=display(value);
  return field==='unit'&&Object.prototype.hasOwnProperty.call(legacy,text)?legacy[text]:text;
 }
 function key(field,value){return canonical(field,value).toLowerCase();}
 var rows=Object.freeze(pairs.map(function(p){return Object.freeze({parent:p[0],value:p[1]});}));
 var sectors=Object.freeze(Array.from(new Set(pairs.map(function(p){return p[0];}))));
 var units=Object.freeze(pairs.map(function(p){return p[1];}));
 S.organizationReference=Object.freeze({rows:rows,sectors:sectors,units:units,canonical:canonical,key:key});
})(window.Saytara=window.Saytara||{});
