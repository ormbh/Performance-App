/* Additive leadership readings of the existing entity row scope.
   A record is a source row, not a distinct project or deliverable. Recorded
   delay and stage-aware planned/presentation dates form one deduplicated late set. */
(function (S) {
  'use strict';

  var E = S.entities, U = S.util, CLOSED = ['done', 'cancelled', 'hold'];
  var LABELS = {
    all: 'كل البنود ضمن نطاق الجهة', late: 'متأخر حسب الحالة أو الموعد المسجل',
    lateRecorded: 'متأخر حسب الحالة المسجلة', lateByDate: 'بنود غير مغلقة تجاوزت الموعد المسجل',
    soon: 'مستحق خلال 30 يوماً', later: 'موعد لاحق', undated: 'موعد غير مسجل للأجندة أو المشاريع الخاصة',
    noDue: 'قرارات دون موعد متابعة محدد في المصدر',
    undatedApplicable: 'موعد غير مسجل للأجندة أو المشاريع الخاصة',
    cutoffUnavailable: 'بنود غير مغلقة بموعد مسجل وتاريخ مرجعي غير متاح',
    done: 'منجز حسب الحالة المسجلة', ready: 'جاهز للعرض حسب الحالة المسجلة', active: 'قيد العمل أو المراجعة حسب الحالة',
    open: 'البنود غير المغلقة', closed: 'منجز أو ملغى أو معلق حسب الحالة',
    cancelled: 'ملغى حسب الحالة', hold: 'معلق حسب الحالة', otherOpen: 'حالات أخرى غير مغلقة',
    missingStatus: 'الحالة غير مسجلة أو حقلها غير متاح',
    statusKnown: 'بنود بحالة مسجلة', statusMissing: 'بنود دون حالة مسجلة',
    statusUnavailable: 'بنود حقل الحالة غير متاح في محفظتها',
    datedOpen: 'بنود غير مغلقة بموعد متابعة متاح',
    notes: 'ملاحظات وتحديثات مسجلة', missingReport: 'قرارات لا يتوفر لها تقرير بالمستجدات حسب المصدر',
    'relation:primary': 'بنود الجهة المعنية', 'relation:contributor': 'بنود المساهمة المحددة',
    'relation:primaryOnly': 'جهة معنية فقط', 'relation:contributorOnly': 'جهة مساهمة فقط',
    'relation:both': 'جهة معنية ومساهمة', 'relation:neither': 'دون علاقة محددة ضمن نطاق الجهات'
  };
  var DELIVERY = [
    ['late', 'متأخر أو تجاوز الموعد'], ['ready', 'جاهز للعرض'], ['active', 'قيد العمل / المراجعة'], ['otherOpen', 'حالات أخرى غير مغلقة'],
    ['done', 'منجز'], ['cancelled', 'ملغى'], ['hold', 'معلق'], ['missingStatus', 'غير مسجل / غير متاح']
  ];
  var HORIZON = [
    ['late', 'متأخر أو تجاوز الموعد'], ['soon', 'خلال 30 يوماً'], ['later', 'موعد لاحق'],
    ['undated', 'موعد غير مسجل'], ['noDue', 'دون موعد متابعة محدد في المصدر'],
    ['cutoffUnavailable', 'مرجع البيانات غير متاح']
  ];

  function own(o, key) { return Object.prototype.hasOwnProperty.call(o, key); }
  function validDate(n) {
    return typeof n === 'number' && Number.isFinite(n) && n > 0 && n < 2958466 ? Math.floor(n) : null;
  }
  function statusAvailable(data, pf) {
    var meta = data.meta && data.meta[pf], spec = S.schema.PF[pf];
    return !!(meta && meta.found && spec && spec.fields.status &&
      (meta.missing || []).indexOf(spec.fields.status.h) < 0);
  }
  function dict(data) {
    var names = S.order.list(data, 'Entities').concat((data.items || []).filter(E.usable).map(function (it) { return it.entity || ''; }));
    return new Map(names.filter(Boolean).map(function (name) { return [U.key(name), name]; }));
  }
  function scopedLabel(text, scope) {
    var w = S.terms.words(scope);
    return text.replace(/البنود|بنود|البند|بند/g, function (noun) {
      return ({ 'البنود': w.definitePlural, 'بنود': w.plural, 'البند': w.definite, 'بند': w.single })[noun];
    });
  }
  function label(id, model, scope) {
    if (model && model.labels && own(model.labels, id) && (scope == null || /^row:/.test(id || ''))) return model.labels[id];
    if (own(LABELS, id)) return scopedLabel(LABELS[id], scope);
    var band = /^(delivery|timeline):(.+)$/.exec(id || '');
    if (band && own(LABELS, band[2])) return scopedLabel(LABELS[band[2]], scope);
    var applicableBand = /^due:(.+)$/.exec(id || '');
    if (applicableBand && own(LABELS, applicableBand[1])) return 'الأجندة والمشاريع الخاصة · ' + scopedLabel(LABELS[applicableBand[1]], scope);
    var match = /^portfolio:([^:]+):([^:]+)$/.exec(id || '');
    if (match) {
      var group = E.groups.find(function (g) { return g[0] === match[1]; });
      var metric = match[2].replace(/^delivery-/, '');
      if (group && own(LABELS, metric)) return group[1] + ' · ' + scopedLabel(LABELS[metric], match[1]);
    }
    var entity = /^entity-(primary|contributor|both|all):(.+)$/.exec(id || '');
    if (entity) {
      try { return ({ primary: 'الجهة المعنية', contributor: 'المساهمة المسجلة', both: 'جهة معنية ومساهمة', all: 'العلاقات المسجلة' }[entity[1]]) + ' · ' + decodeURIComponent(entity[2]); }
      catch (ignore) { /* Malformed route text does not define a selector. */ }
    }
    var entityMetric = /^entity:([^:]+):([^:]+)$/.exec(id || '');
    if (entityMetric && own(LABELS, entityMetric[2])) {
      try { return decodeURIComponent(entityMetric[1]) + ' · ' + scopedLabel(LABELS[entityMetric[2]], scope); }
      catch (ignoreMetric) { /* URL strings do not define selectors. */ }
    }
    if (/^row:.+:\d+$/.test(id || '')) return scopedLabel('البند المحدد في المصدر', scope);
    return scopedLabel('البنود الحالية', scope);
  }
  function select(model, id) {
    // Only selectors generated from this source scope may select rows. URL
    // strings cannot supply predicates, object paths, property names or code.
    return model && model.selections && own(model.selections, id) ? model.selections[id].slice() : [];
  }
  function model(state, base) {
    var data = state && state.data || {}, r = base || E.build(state), rows = r.rows || [], cutoff = validDate(data.today);
    var sourcePosition = new Map(), lookup = dict(data), scope = r.scope || state.entity || {}, selected = U.hasSelection(scope.entity);
    (data.items || []).forEach(function (it, index) { sourcePosition.set(it, index); });
    var selections = Object.create(null), labels = Object.create(null);
    function register(id, items, text) { selections[id] = items.slice(); labels[id] = text || label(id, null, items); return id; }
    var readings = rows.map(function (it, index) {
      var available = statusAvailable(data, it.pf), known = available && !!String(it.statusLabel || '').trim();
      var cat = available ? it.statusCat || 'none' : 'none', closed = known && CLOSED.indexOf(cat) >= 0;
      var phase = E.deadline(it, cutoff), due = validDate(phase.due), recorded = known && cat === 'delayed';
      var dateLate = !closed && phase.lateByDate;
      var late = recorded || dateLate;
      var soon = !closed && !late && phase.soon;
      var delivery = late ? 'late' : !known ? 'missingStatus' : cat === 'done' ? 'done' : cat === 'cancelled' ? 'cancelled' :
        cat === 'hold' ? 'hold' : cat === 'ready' ? 'ready' : ['progress', 'review'].indexOf(cat) >= 0 ? 'active' : 'otherOpen';
      var dueApplicable = it.pf === 'agenda' || it.pf === 'special';
      var horizon = closed ? null : late ? 'late' : due == null ? (dueApplicable ? 'undated' : 'noDue') : cutoff == null ? 'cutoffUnavailable' : soon ? 'soon' : 'later';
      var rel = E.relations(it, data, lookup);
      var primary = !!rel.primary && (!selected || U.selected(rel.primary, scope.entity));
      var contributor = rel.contributors.some(function (name) { return !selected || U.selected(name, scope.entity); });
      var relation = primary && contributor ? 'both' : primary ? 'primaryOnly' : contributor ? 'contributorOnly' : 'neither';
      var missingReport = it.pf === 'council' && U.key((it.t || {}).hasReport) === U.key('لا');
      var sourceIndex = sourcePosition.has(it) ? sourcePosition.get(it) : index;
      return { it: it, group: E.group(it), due: due, dueApplicable: dueApplicable, cutoff: cutoff, daysToDue: due != null && cutoff != null ? due - cutoff : null,
        statusAvailable: available, statusKnown: known, statusCat: cat, closed: closed, late: late, lateRecorded: recorded, deadline: phase,
        lateByDate: dateLate, soon: soon, delivery: delivery, horizon: horizon, relation: relation,
        primary: primary, contributor: contributor, relations: rel, missingReport: missingReport, note: E.noteFields(it).length > 0,
        sourceKey: it.key, sourceRef: { key: it.key, pf: it.pf, sheet: it.sheet, row: it.row },
        rowId: register('row:' + encodeURIComponent(String(it.key || it.pf)) + ':' + sourceIndex, [it], it.title) };
    });
    function items(predicate, source) { return (source || readings).filter(predicate).map(function (x) { return x.it; }); }
    var sets = {
      all: rows.slice(), late: items(function (x) { return x.late; }), lateRecorded: items(function (x) { return x.lateRecorded; }),
      lateByDate: items(function (x) { return x.lateByDate; }), soon: items(function (x) { return x.soon; }),
      later: items(function (x) { return x.horizon === 'later'; }), undated: items(function (x) { return !x.closed && x.dueApplicable && x.due == null; }),
      noDue: items(function (x) { return !x.closed && !x.dueApplicable; }),
      cutoffUnavailable: items(function (x) { return x.horizon === 'cutoffUnavailable'; }),
      done: items(function (x) { return x.statusKnown && x.statusCat === 'done'; }),
      ready: items(function (x) { return x.statusKnown && x.statusCat === 'ready'; }),
      active: items(function (x) { return x.statusKnown && ['progress', 'review'].indexOf(x.statusCat) >= 0; }),
      open: items(function (x) { return !x.closed; }), closed: items(function (x) { return x.closed; }),
      cancelled: items(function (x) { return x.statusKnown && x.statusCat === 'cancelled'; }),
      hold: items(function (x) { return x.statusKnown && x.statusCat === 'hold'; }),
      otherOpen: items(function (x) { return x.delivery === 'otherOpen'; }),
      missingStatus: items(function (x) { return !x.statusKnown; }),
      statusKnown: items(function (x) { return x.statusKnown; }),
      statusMissing: items(function (x) { return x.statusAvailable && !x.statusKnown; }),
      statusUnavailable: items(function (x) { return !x.statusAvailable; }),
      datedOpen: items(function (x) { return !x.closed && x.due != null; }),
      notes: items(function (x) { return x.note; }), missingReport: items(function (x) { return x.missingReport; })
    };
    sets.undatedApplicable = sets.undated.slice();
    Object.keys(sets).forEach(function (key) { register(key, sets[key]); });
    var counts = {};
    Object.keys(sets).forEach(function (key) { counts[key === 'all' ? 'total' : key === 'soon' ? 'dueSoon' : key === 'undated' ? 'undatedOpen' : key] = sets[key].length; });
    counts.changed = r.comparison ? E.changeRows(r).length : null;
    counts.rate = counts.total ? counts.done / counts.total * 100 : null;
    function bands(config, field, rr, prefix) {
      return config.map(function (c) {
        var selectedRows = items(function (x) { return x[field] === c[0]; }, rr), id = (prefix || '') + c[0];
        return { key: c[0], label: c[1], n: selectedRows.length, items: selectedRows, id: register(id, selectedRows) };
      });
    }
    function statusCoverage(rr) {
      return { total: rr.length, known: rr.filter(function (x) { return x.statusKnown; }).length,
        missing: rr.filter(function (x) { return x.statusAvailable && !x.statusKnown; }).length,
        unavailable: rr.filter(function (x) { return !x.statusAvailable; }).length };
    }
    function dateCoverage(rr) {
      var open = rr.filter(function (x) { return !x.closed; });
      return { total: rr.length, open: open.length, known: open.filter(function (x) { return x.due != null; }).length,
        missing: open.filter(function (x) { return x.dueApplicable && x.due == null; }).length,
        applicable: open.filter(function (x) { return x.dueApplicable; }).length,
        councilNoDue: open.filter(function (x) { return x.it.pf === 'council'; }).length };
    }
    var portfolios = (r.panels || []).map(function (p) {
      var rr = readings.filter(function (x) { return x.group === p.id; }), selectors = {}, ps = {};
      Object.keys(sets).forEach(function (key) {
        var selectedRows = sets[key].filter(function (it) { return E.group(it) === p.id; });
        selectors[key] = register('portfolio:' + p.id + ':' + key, selectedRows);
        ps[key] = selectedRows.length;
      });
      return { id: p.id, label: p.label, rows: p.rows, total: p.now.total, done: p.now.done, rate: p.now.rate,
        late: ps.late, dueSoon: ps.soon, open: ps.open, undatedOpen: ps.undated,
        statusCoverage: statusCoverage(rr), dateCoverage: dateCoverage(rr), selectors: selectors,
        delivery: bands(DELIVERY, 'delivery', rr, 'portfolio:' + p.id + ':delivery-'), source: p };
    });
    // Primary and contributor totals overlap. These four partitions are the
    // mutually exclusive relation view; all calculations remain row based.
    var accountability = { primary: readings.filter(function (x) { return x.primary; }).length,
      contributor: readings.filter(function (x) { return x.contributor; }).length, selectedEntities: selected,
      partitions: ['primaryOnly', 'contributorOnly', 'both', 'neither'].map(function (key) {
        var selectedRows = items(function (x) { return x.relation === key; });
        return { key: key, label: LABELS['relation:' + key], n: selectedRows.length, items: selectedRows,
          id: register('relation:' + key, selectedRows) };
      }) };
    accountability.partitions.forEach(function (x) { accountability[x.key] = x.n; });
    register('relation:primary', items(function (x) { return x.primary; }));
    register('relation:contributor', items(function (x) { return x.contributor; }));
    var entityNames = [], entityKeys = new Set();
    readings.forEach(function (x) {
      [x.relations.primary].concat(x.relations.contributors).filter(Boolean).forEach(function (name) {
        var key = U.key(name);
        if ((!selected || U.selected(name, scope.entity)) && !entityKeys.has(key)) { entityKeys.add(key); entityNames.push(name); }
      });
    });
    var orderedEntities = S.order.sort(data, entityNames, 'Entities'), entityPosition = new Map(orderedEntities.map(function (name, index) { return [U.key(name), index]; }));
    accountability.byEntity = orderedEntities.map(function (name) {
      var key = U.key(name), primaryRows = items(function (x) { return U.key(x.relations.primary) === key; });
      var contributorRows = items(function (x) { return x.relations.contributors.some(function (v) { return U.key(v) === key; }); });
      var bothRows = primaryRows.filter(function (it) { return contributorRows.indexOf(it) >= 0; });
      var allRows = rows.filter(function (it) { return primaryRows.indexOf(it) >= 0 || contributorRows.indexOf(it) >= 0; });
      var entry = { key: key, label: name, primary: primaryRows.length, contributor: contributorRows.length, both: bothRows.length,
        total: allRows.length, selectors: { primary: register('entity-primary:' + encodeURIComponent(name), primaryRows),
          contributor: register('entity-contributor:' + encodeURIComponent(name), contributorRows),
          both: register('entity-both:' + encodeURIComponent(name), bothRows) } };
      ['all', 'late', 'soon', 'done', 'open'].forEach(function (metric) {
        var selectedRows = metric === 'all' ? allRows : allRows.filter(function (it) { return sets[metric].indexOf(it) >= 0; });
        entry[metric === 'all' ? 'total' : metric === 'soon' ? 'dueSoon' : metric] = selectedRows.length;
        entry.selectors[metric] = register('entity:' + encodeURIComponent(name) + ':' + metric, selectedRows);
      });
      return entry;
    }).sort(function (a, b) { return b.late - a.late || b.open - a.open || entityPosition.get(a.key) - entityPosition.get(b.key); });
    accountability.overlapNote = 'قد يجمع البند الجهة المعنية والمساهمة؛ إجمالي الجهة يحتسب الصف مرة واحدة، ومجاميع الجهات ليست إجمالي البنود.';
    var queue = readings.filter(function (x) { return x.late || x.soon || x.missingReport; }).map(function (x, index) {
      var reasons = [];
      if (x.lateRecorded) reasons.push('متأخر حسب الحالة المسجلة');
      if ((x.lateByDate || x.soon) && x.deadline.reason) reasons.push(x.deadline.reason);
      if (x.missingReport) reasons.push('لا يتوفر تقرير بالمستجدات حسب المصدر');
      return { it: x.it, due: x.due, deadline: x.deadline, daysToDue: x.daysToDue, late: x.late,
        kind: x.late ? 'late' : x.soon ? 'soon' : 'missingReport', reasons: reasons, id: x.rowId, sourceOrder: index };
    }).sort(function (a, b) {
      var rank = { late: 0, soon: 1, missingReport: 2 };
      return rank[a.kind] - rank[b.kind] || a.sourceOrder - b.sourceOrder;
    });
    return { rows: rows, cutoff: cutoff, counts: counts, sets: sets, readings: readings, selections: selections,
      labels: labels, delivery: bands(DELIVERY, 'delivery', readings, 'delivery:'), timeline: bands(HORIZON, 'horizon', readings, 'timeline:'),
      timelineApplicable: bands(HORIZON.filter(function (x) { return x[0] !== 'noDue'; }), 'horizon', readings.filter(function (x) { return x.dueApplicable; }), 'due:'),
      portfolios: portfolios, accountability: accountability, queue: queue,
      coverage: { status: statusCoverage(readings), dates: dateCoverage(readings),
        portfoliosMissing: E.portfolios(scope).filter(function (pf) { return !(data.meta && data.meta[pf] || {}).found; }) },
      comparison: r.comparison, comparisonError: r.error, source: r };
  }

  function focus(r, state) {
    var original = E.focus(r, state), kind = (state.entity || {}).kind || '';
    if (!kind || original.mode === 'changes') return original;
    var m = model(state, r), known = own(m.selections, kind), allowed = new Set(select(m, kind));
    var rows = original.rows.filter(function (it) { return allowed.has(it); }), size = 12;
    var pages = Math.max(1, Math.ceil(rows.length / size)), page = Math.min(pages, Math.max(1, Number((state.entity || {}).page) || 1));
    return Object.assign({}, original, { rows: rows, total: rows.length, page: page, pages: pages,
      visible: rows.slice((page - 1) * size, page * size), kind: kind, selectionKnown: known,
      selectionLabel: known ? label(kind, m, (state.entity || {}).area || undefined) : 'اختيار غير متاح' });
  }

  S.entitiesLeadership = { model: model, select: select, label: label, focus: focus };
})(window.Saytara = window.Saytara || {});
