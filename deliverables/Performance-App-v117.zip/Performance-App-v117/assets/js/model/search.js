/*
 * Performance reporting · search
 * Matches any part of the text, like the Excel search sheet, across the same
 * columns it searches (plus the ones it shows). Arabic spelling variants are
 * treated as equal. Several words must all appear, in any column. "*" and "?"
 * work as wildcards, and "الكل" or "all" lists everything, as in Excel.
 */
(function (S) {
  'use strict';

  var U = S.util, SC = S.schema;

  var FILTERS = [
    { k: 'status', ar: 'مستوى الإنجاز' },
    { k: 'health', ar: 'الالتزام بالموعد' },
    { k: 'sector', ar: 'القطاع' },
    { k: 'unit', ar: 'الوحدة التنظيمية' },
    { k: 'coord', ar: 'المسؤول' },
    { k: 'entity', ar: 'الجهة المعنية' },
    { k: 'year', ar: 'السنة' },
    { k: 'legislationMonth', ar: 'شهر التشريع', pf: 'legislation' }
  ];
  var HEALTH_AR = { delayed: 'متأخر', doneLate: 'تجاوز الموعد', doneOnTime: 'ضمن الموعد بحسب المؤشر', none: 'دون علامة تأخر محسوبة' };
  var EMPTY_AR = { status: 'بدون حالة', health: 'دون علامة تأخر محسوبة', sector: 'بدون قطاع', unit: 'بدون وحدة', coord: 'بدون منسق', entity: 'بدون جهة', year: 'بدون سنة', legislationMonth: 'شهر التشريع غير متاح' };
  var TABS = ['all'].concat(SC.ORDER);
  var SEV = { delayed: 0, doneLate: 2, doneOnTime: 4 };
  var PER_PAGE = 25;

  function emptyF() { return { status: [], health: [], sector: [], unit: [], coord: [], entity: [], year: [], legislationMonth: [] }; }

  function rawVal(it, key) {
    switch (key) {
      case 'status': return it.statusLabel || '';
      case 'health': return it.health || 'none';
      case 'sector': return it.sector;
      case 'unit': return it.unit;
      case 'coord': return it.coord;
      case 'entity': return it.entity;
      case 'year': return it.year;
      case 'legislationMonth': return it.pf === 'legislation' && it.calc.legislationMonth ? it.calc.legislationMonth.key : '';
    }
    return '';
  }
  function valKey(it, key) { return key === 'health' ? rawVal(it, key) : U.key(rawVal(it, key)); }
  function optLabel(key, v, sample) {
    if (key === 'health') return HEALTH_AR[v] || v;
    if (key === 'legislationMonth' && /^\d{4}-\d{2}$/.test(v)) return U.MONTHS_AR[Number(v.slice(5)) - 1] + ' ' + Number(v.slice(0,4));
    return v ? (sample || v) : EMPTY_AR[key];
  }

  function tokens(q) {
    return U.norm(q).replace(/#/g, ' ').split(' ').filter(function (t) { return t; });
  }
  function isAllQuery(q) {
    var n = U.norm(q).trim();
    return n === 'all' || n === U.norm('الكل');
  }

  /* A small glob automaton, never a user-controlled RegExp. Each pattern
     position retains only its earliest source start. Stars have an epsilon
     transition and a consuming transition; no recursive backtracking occurs.
     Work is bounded by text length × pattern length, with O(pattern) memory.
     Substring search and lazy, nonoverlapping highlight ranges match the
     existing * / ? syntax. Input is already normalized by the caller. */
  function globPattern(token) { return String(token).replace(/\*+/g, '*'); }
  function globFind(text, pattern, from) {
    var n=pattern.length, states=new Float64Array(n+1), next=new Float64Array(n+1);
    states.fill(-1);
    function earliest(a,j,start) { if(a[j]<0||start<a[j])a[j]=start; }
    for(var at=from;at<=text.length;at++) {
      earliest(states,0,at);
      for(var j=0;j<n;j++) if(pattern[j]==='*'&&states[j]>=0)earliest(states,j+1,states[j]);
      if(states[n]>=0)return {start:states[n],end:at};
      if(at===text.length)break;
      next.fill(-1);
      var ch=text[at],dot=ch!=='\n'&&ch!=='\r'&&ch!=='\u2028'&&ch!=='\u2029';
      for(var k=0;k<n;k++)if(states[k]>=0) {
        if(pattern[k]==='*') { if(dot)earliest(next,k,states[k]); }
        else if(pattern[k]===ch||pattern[k]==='?'&&dot)earliest(next,k+1,states[k]);
      }
      var old=states;states=next;next=old;
    }
    return null;
  }
  function wildcardMatch(text,token) {
    text=String(text==null?'':text);token=String(token==null?'':token);
    return /[*?]/.test(token)?!!globFind(text,globPattern(token),0):text.indexOf(token)>=0;
  }
  function wildcardRanges(text,token,firstOnly) {
    text=String(text==null?'':text);token=String(token==null?'':token);
    var ranges=[],from=0,wild=/[*?]/.test(token),pattern=wild?globPattern(token):token;
    // A token made only of stars produces empty lazy matches and no highlight.
    if(!pattern||pattern==='*')return ranges;
    while(from<=text.length) {
      var at=wild?globFind(text,pattern,from):null;
      if(!wild){var i=text.indexOf(pattern,from);if(i>=0)at={start:i,end:i+pattern.length};}
      if(!at)break;
      if(at.end>at.start){ranges.push(at);if(firstOnly)break;from=at.end;}
      else from=at.end+1;
    }
    return ranges;
  }
  function matcher(tok) {
    if(/[*?]/.test(tok)){var pattern=globPattern(tok);return function(s){return !!globFind(s,pattern,0);};}
    return function(s){return s.indexOf(tok)>=0;};
  }

  /* rank: 0 exact number · 1 title · 2 coordinator · 3 part of number · 4 other columns */
  function match(it, toks, ms) {
    var sx = it.sx, rank = 9, fields = [];
    for (var i = 0; i < toks.length; i++) {
      var t = toks[i], m = ms[i], ok = false;
      if (sx.ref) {
        if (sx.ref === t) { ok = true; rank = Math.min(rank, 0); fields.push('ref'); }
        else if (m(sx.ref)) { ok = true; rank = Math.min(rank, 3); fields.push('ref'); }
      }
      if (sx.title && m(sx.title)) { ok = true; rank = Math.min(rank, 1); fields.push('title'); }
      if (sx.coord && m(sx.coord)) { ok = true; rank = Math.min(rank, 2); fields.push('coord'); }
      for (var j = 0; j < sx.other.length; j++) {
        if (m(sx.other[j].text)) { ok = true; rank = Math.min(rank, 4); fields.push(sx.other[j]); }
      }
      if (!ok) return null;
    }
    return { rank: rank, fields: fields };
  }

  function passF(it, f, skip, tab) {
    for (var i = 0; i < FILTERS.length; i++) {
      if (FILTERS[i].pf && (tab !== FILTERS[i].pf || it.pf !== FILTERS[i].pf)) continue;
      var key = FILTERS[i].k;
      if (key === skip) continue;
      var sel = f[key];
      if (sel && sel.length && sel.indexOf(valKey(it, key)) < 0) return false;
    }
    return true;
  }

  function cmpRef(a, b) {
    var x = parseFloat(a), y = parseFloat(b);
    if (!isNaN(x) && !isNaN(y) && x !== y) return x - y;
    return String(a).localeCompare(String(b), 'ar', { numeric: true });
  }

  var SORTS = {
    no: function (a, b) { return cmpRef(a.it.ref, b.it.ref); },
    title: function (a, b) { return a.it.title.localeCompare(b.it.title, 'ar'); },
    status: function (a, b) { return (a.it.statusLabel || '').localeCompare(b.it.statusLabel || '', 'ar'); },
    progress: function (a, b) { return progressOf(a.it) - progressOf(b.it); },
    coord: function (a, b) { return (a.it.coord || '').localeCompare(b.it.coord || '', 'ar'); },
    date: function (a, b) { return (a.it.dateSort == null ? 9e9 : a.it.dateSort) - (b.it.dateSort == null ? 9e9 : b.it.dateSort); },
    place: function (a, b) { return (a.it.sector + a.it.unit).localeCompare(b.it.sector + b.it.unit, 'ar'); }
  };
  /* Search tables use the same status LOV as their filter, then displayed date. */
  function statusDate(data, a, b, tab) {
    return S.order.status(data, a.it.statusLabel, b.it.statusLabel, tab) || SORTS.date(a, b);
  }

  function progressOf(it) {
    if (it.pf === 'kpi') return it.calc.resultRecorded == null ? -1 : it.calc.resultRecorded * 100;
    return it.progress == null ? -1 : it.progress;
  }
  function sev(it) { return it.health && SEV[it.health] != null ? SEV[it.health] : 3; }

  function run(data, s) {
    var t0 = performance.now();
    var all = isAllQuery(s.q);
    var toks = all ? [] : tokens(s.q);
    var joined = toks.join('');
    /* Live results from two characters (or a number); Enter searches any length, as in Excel. */
    var active = all || joined.length >= 2 || (joined.length >= 1 && (/^\d+$/.test(joined) || !!s.force)) || !!s.browse || !!s.drill;
    var hits = [];
    if (active) {
      var ms = toks.map(matcher);
      for (var i = 0; i < data.items.length; i++) {
        var it = data.items[i];
        if (s.drill) { if (!S.rules.test(s.drill.id, it) || !S.rules.inScope(it, s.drill.scope)) continue; }
        else if (!it.hasTitle) continue;
        if (toks.length) {
          var m = match(it, toks, ms);
          if (m) hits.push({ it: it, m: m });
        } else hits.push({ it: it, m: { rank: 5, fields: [] } });
      }
    }

    var counts = {};
    TABS.forEach(function (t) { counts[t] = 0; });
    hits.forEach(function (h) { if (passF(h.it, s.f, null, s.tab)) { counts.all++; counts[h.it.pf]++; } });

    var inTab = function (h) { return s.tab === 'all' || h.it.pf === s.tab; };
    var rows = hits.filter(function (h) { return inTab(h) && passF(h.it, s.f, null, s.tab); });

    if (s.sort && SORTS[s.sort.col]) {
      var g = SORTS[s.sort.col], dir = s.sort.dir === 'desc' ? -1 : 1;
      rows.sort(function (a, b) { return (s.sort.col === 'status' ? statusDate(data,a,b,s.tab) : s.sort.col === 'place' ? (S.order.compare(data,'Sectors',a.it.sector,b.it.sector)||S.order.compare(data,'Departments',a.it.unit,b.it.unit)) : g(a, b)) * dir || SC.ORDER.indexOf(a.it.pf) - SC.ORDER.indexOf(b.it.pf) || a.it.seq - b.it.seq; });
    } else {
      rows.sort(function (a, b) {
        return statusDate(data,a,b,s.tab) || a.m.rank - b.m.rank || SC.ORDER.indexOf(a.it.pf) - SC.ORDER.indexOf(b.it.pf) || a.it.seq - b.it.seq;
      });
    }

    var facets = {};
    FILTERS.forEach(function (F) {
      var c = Object.create(null), sample = Object.create(null);
      hits.forEach(function (h) {
        if (!inTab(h) || !passF(h.it, s.f, F.k, s.tab)) return;
        var v = valKey(h.it, F.k);
        c[v] = (c[v] || 0) + 1;
        if (!sample[v]) sample[v] = rawVal(h.it, F.k);
      });
      (s.f[F.k] || []).forEach(function (v) { if (!(v in c)) c[v] = 0; });
      facets[F.k] = Object.keys(c).map(function (v) { return { v: v, n: c[v], label: optLabel(F.k, v, sample[v]) }; })
        .sort(function (a, b) { return F.k === 'legislationMonth' ? (!a.v ? 1 : !b.v ? -1 : a.v.localeCompare(b.v)) : S.order.field(data,F.k,a.v,b.v,s.tab); });
    });

    var pages = Math.max(1, Math.ceil(rows.length / PER_PAGE));
    var page = Math.min(Math.max(1, s.page || 1), pages);
    return {
      toks: toks, all: all, active: active, hits: hits, rows: rows, counts: counts, facets: facets,
      page: page, pages: pages, pageRows: rows.slice((page - 1) * PER_PAGE, page * PER_PAGE),
      ms: performance.now() - t0
    };
  }

  /* Suggestions while typing: top items, coordinators and portfolios. */
  function suggest(data, q) {
    var res = run(data, { q: q, tab: 'all', f: emptyF() });
    var items = res.rows.slice(0, 5);
    var people = [];
    if (res.toks.length) {
      var seen = Object.create(null);
      data.items.forEach(function (it) {
        if (!it.coord) return;
        var n = U.norm(it.coord), key = U.key(it.coord);
        if (res.toks.every(function (t) { return n.indexOf(t) >= 0; })) {
          if (!seen[key]) { seen[key] = { name: it.coord, n: 0 }; people.push(seen[key]); }
          seen[key].n++;
        }
      });
    }
    var pfs = SC.ORDER.filter(function (pf) {
      var n = U.norm(SC.PF[pf].ar + ' ' + SC.PF[pf].src);
      return res.toks.length && res.toks.every(function (t) { return n.indexOf(t) >= 0; });
    });
    return { total: res.counts.all, items: items, people: people.slice(0, 3), pfs: pfs.slice(0, 2), toks: res.toks };
  }

  /* Highlight matches in the original text (safe HTML). */
  function highlight(text, toks) {
    text = String(text == null ? '' : text);
    if (!toks || !toks.length) return U.esc(text);
    var nm = U.normMap(text), mk = new Array(text.length);
    toks.forEach(function (tk) {
      if (!tk) return;
      wildcardRanges(nm.text,tk).forEach(function(range){
        for(var j=range.start;j<range.end;j++)mk[nm.map[j]]=true;
      });
    });
    var out = '', buf = '', cur = false;
    for (var c = 0; c < text.length; c++) {
      var on = !!mk[c];
      if (on !== cur && buf) { out += cur ? '<mark>' + U.esc(buf) + '</mark>' : U.esc(buf); buf = ''; }
      cur = on; buf += text[c];
    }
    if (buf) out += cur ? '<mark>' + U.esc(buf) + '</mark>' : U.esc(buf);
    return out;
  }

  /* The Excel search sheet's 11 columns, filled the same way, plus the sheet and row. */
  function excelRow(it) {
    var t = it.t, pf = it.pf;
    var no = pf === 'agenda' ? t.type : pf === 'council' ? t.no : pf === 'legislation' ? t.mcms : pf === 'special' ? t.lead : pf === 'secretariat' ? t.no : '';
    var status = it.statusLabel + (pf === 'legislation' && it.calc.overrun ? ' | تجاوز الموعد' : '');
    var prog = pf === 'kpi' ? (t.result || '') : (pf === 'special' || pf === 'council' || pf === 'secretariat') ? t.progress : '';
    return [SC.PF[pf].ar, it.hasTitle ? it.title : '', no, it.entity, it.sector, it.unit, status, prog, it.coord, it.dateLabel, it.notes, it.sheet, it.row];
  }
  var EXCEL_HEAD = ['المصدر', 'العنوان', 'الرقم / التصنيف', 'الجهة المعنية', 'القطاع', 'الوحدة التنظيمية', 'حالة الإنجاز', 'نسبة الإنجاز', 'المنسق / مدير المشروع', 'التاريخ / الموعد', 'الملاحظات والمستجدات', 'الورقة', 'الصف'];

  function exportCsv(rows) {
    var head = EXCEL_HEAD.slice();
    head[1] = S.ui.contentHeader(rows.map(function(h){return h.it;}));
    return U.csv([head].concat(rows.map(function (h) { return excelRow(h.it); })));
  }

  S.search = {
    FILTERS: FILTERS, TABS: TABS, PER_PAGE: PER_PAGE, HEALTH_AR: HEALTH_AR,
    emptyF: emptyF, run: run, suggest: suggest, highlight: highlight, tokens: tokens,
    optLabel: optLabel, exportCsv: exportCsv, excelRow: excelRow, EXCEL_HEAD: EXCEL_HEAD, valKey: valKey,
    wildcardMatch:wildcardMatch, wildcardRanges:wildcardRanges
  };
})(window.Saytara = window.Saytara || {});
