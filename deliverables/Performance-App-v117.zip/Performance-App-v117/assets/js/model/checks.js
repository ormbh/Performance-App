/*
 * Performance reporting · data checks
 * Lists rows that the report cannot count the way people expect: values outside
 * the lists, units under the wrong sector, missing dates, rows the report skips.
 * Severity: error (structure) · warn (affects the report) · info (worth a look).
 */
(function (S) {
  'use strict';

  var U = S.util, SC = S.schema, R = S.rules;

  function run(data) {
    var out = data.notes.slice();
    var lovs = data.lovs;
    // The approved organizational aliases also apply to validation. Compare
    // against the workbook's actual list, preserving all original cell tokens.
    function orgKey(field, value) {
      return S.organizationReference ? S.organizationReference.key(field, value) : U.key(value);
    }
    var orgSets = {}, orgParents = new Map(), parentCandidates = new Map();
    [['sector', 'Sectors'], ['unit', 'Departments']].forEach(function(pair) {
      orgSets[pair[0]] = new Set((lovs.lists[pair[1]] || []).map(function(value) {
        return orgKey(pair[0], typeof value === 'object' ? value.value : value);
      }));
    });
    (lovs.lists.Departments || []).forEach(function(row) {
      var unit = orgKey('unit', row.value), sector = orgKey('sector', row.parent);
      if (!unit) return;
      if (!parentCandidates.has(unit)) parentCandidates.set(unit, new Map());
      parentCandidates.get(unit).set(sector, row.parent);
    });
    parentCandidates.forEach(function(parents, unit) {
      // Conflicting/blank source parents are never resolved by the UI registry.
      if (parents.size === 1 && !parents.has('')) orgParents.set(unit, Array.from(parents.values())[0]);
    });

    function push(sev, it, field, problem, value, fix) {
      out.push({
        sev: sev, sheet: it ? it.sheet : '', row: it ? String(it.row) : '', field: field,
        problem: problem, value: value == null ? '' : String(value), fix: fix || '',
        key: it ? it.key : null, pf: it ? it.pf : null
      });
    }

    var titles = {};
    data.items.forEach(function (it) {
      var spec = SC.PF[it.pf], f = spec.fields, t = it.t, c = it.c;

      if (!it.hasTitle) push('warn', it, f.title.h, 'صف فيه بيانات بدون عنوان', '', 'راجع العنوان مع مسؤول البيانات مع الحفاظ على محتوى الصف');
      else {
        var tk = it.pf + '|' + U.key(it.title);
        (titles[tk] = titles[tk] || []).push(it);
      }

      Object.keys(f).forEach(function (fk) {
        var fd = f[fk];
        if (!fd.lov || !c[fk] || fd.lov === 'CompletionPercent') return;
        var set = lovs.sets[fd.lov];
        if (!set || !set.size) return;
        var acceptedAlias = orgSets[fk] && orgSets[fk].has(orgKey(fk, t[fk]));
        if (it.k[fk] && !set.has(it.k[fk]) && !acceptedAlias) push('warn', it, fd.h, 'القيمة ليست من القائمة المعتمدة', t[fk], 'اختر قيمة من القائمة');
        var raw = c[fk].t === 's' ? String(c[fk].v) : '';
        if (raw && (raw !== raw.trim() || / |\s{2,}/.test(raw))) {
          var trimmed = it.pf === 'council' && ['status', 'followup', 'sector', 'unit'].indexOf(fk) >= 0;
          if (trimmed) push('info', it, fd.h, 'في القيمة مسافات زائدة، ويحتسبها التقرير لأن معادلات القرارات تتجاهلها', raw, 'احذف المسافات الزائدة');
          else push('warn', it, fd.h, 'في القيمة مسافات زائدة، فلا تطابق القائمة ولا تُحتسب في أرقام التقرير، كما في ملف Excel', raw, 'احذف المسافات الزائدة');
        }
      });

      if (it.k.unit && it.k.sector && orgParents.has(orgKey('unit', t.unit))) {
        var owner = orgParents.get(orgKey('unit', t.unit));
        if (orgKey('sector', owner) !== orgKey('sector', t.sector)) push('warn', it, f.unit.h, 'الوحدة التنظيمية تتبع قطاعاً آخر: ' + owner, t.unit, 'صحّح القطاع أو الوحدة');
      }

      if (c.progress && c.progress.t === 'n' && (c.progress.v < 0 || c.progress.v > 1)) {
        push('warn', it, f.progress.h, 'نسبة الإنجاز خارج المدى 0% إلى 100%', t.progress, 'اختر نسبة من القائمة');
      }

      if (it.pf === 'special' && it.hasTitle && R.test('specialNoRequester', it)) {
        push('warn', it, f.lead.h, it.c.lead ? 'قيمة «مشاريع سموه» ليست «نعم» أو «لا» تماماً، فلا يظهر المشروع في توزيع الجهة الطالبة؛ ويظل ضمن إجمالي المشاريع' : 'حقل «مشاريع سموه» فارغ؛ يظل المشروع ضمن الإجمالي ولا يظهر في توزيع الجهة الطالبة', t.lead, 'اختر «نعم» أو «لا»');
      }

      if (it.pf === 'council' && it.hasTitle && !it.k.followup) {
        push('info', it, f.followup.h, 'لا يدخل القرار في أرقام التقرير لأن «متطلبات المتابعة» فارغة', '', 'حدد متطلبات المتابعة');
      }
      if (it.pf === 'council' && it.hasTitle && c.year && c.year.t === 'n' && c.meetingDate && c.meetingDate.t === 'n' && U.validDateSerial(c.meetingDate.v)) {
        var meetingYear = U.ymd(c.meetingDate.v).y;
        if (c.year.v !== meetingYear) push('warn', it, f.year.h,
          'سنة الاجتماع لا تطابق سنة تاريخ الاجتماع؛ حُفظت القيمتان كما وردتا في المصدر',
          t.year + ' · ' + t.meetingDate, 'راجع السنة والتاريخ مع مسؤول البيانات؛ لم تُعدّل هوية القرار أو قيم المصدر');
      }

      if (it.pf === 'legislation' && it.hasTitle) {
        if (!it.c.kpi) push('warn', it, f.kpi.h, 'مؤشرات الأداء فارغة، فلا يظهر التشريع في حالات البطاقة', '', 'أدخل «قيد الإجراء» أو «في الموعد»');
        else if (it.x.kpi !== 'قيد الإجراء' && it.x.kpi !== 'في الموعد') {
          var near = it.k.kpi === U.key('قيد الإجراء') || it.k.kpi === U.key('في الموعد');
          push('warn', it, f.kpi.h, near ? 'في القيمة مسافات زائدة، فلا يُحتسب التشريع في حالات البطاقة، كما في ملف Excel' : 'قيمة غير متوقعة، فلا يظهر التشريع في حالات البطاقة', near ? String(it.c.kpi.v) : t.kpi, 'استخدم «قيد الإجراء» أو «في الموعد»');
        }
        if (!c.actual && !c.ext && !c.slc) push('info', it, f.slc.h, 'لا يوجد تاريخ SLC ولا تمديد، فلا يمكن حساب التأخر', '', 'أدخل تاريخ الإنجاز وفق SLC');
        [['slc', c.slc], ['ext', c.ext], ['actual', c.actual], ['deptDate', c.deptDate]].forEach(function (p) {
          if (p[1] && p[1].t === 's') push('warn', it, f[p[0]].h, 'التاريخ مكتوب نصاً، فلا تحتسبه معادلات التأخر', t[p[0]], 'أدخل التاريخ بصيغة تاريخ');
        });
      }

      if (it.pf === 'secretariat' && it.hasTitle) {
        if (c.nonCommitted && c.nonCommitted.t === 'n' && c.nonCommitted.v < 0) push('warn', it, f.nonCommitted.h, 'قيمة غير المخصص سالبة في المصدر؛ حُفظت كما هي ضمن الإجمالي', t.nonCommitted, 'راجع القيمة مع المالية دون تغيير نطاق التقرير');
        if (!c.end) push('warn', it, f.end.h, 'تاريخ الانتهاء فارغ، فلا يدخل المشروع في الأرباع ولا يُحسب تأخره', '', 'أدخل تاريخ الانتهاء');
        else if (c.end.t === 's' && !it.calc.quarter) push('warn', it, f.end.h, 'تاريخ الانتهاء نص غير مقروء', t.end, 'أدخل التاريخ بصيغة تاريخ');
        else if (it.calc.quarter && it.calc.quarter.indexOf(' ') > 0) push('info', it, f.end.h, 'تاريخ الانتهاء في سنة أخرى، فلا يدخل في أرباع سنة التقرير', t.end, 'تحقق من السنة');
        if (it.k.status === 'active' && c.progress && c.progress.t === 'n' && c.progress.v === 0) push('warn', it, f.progress.h, 'الحالة «Active» ونسبة الإنجاز 0%', t.progress, 'تحقق من نسبة الإنجاز');
        if (it.k.status === 'completed' && c.progress && c.progress.t === 'n' && c.progress.v < 1) push('warn', it, f.progress.h, 'الحالة «Completed» ونسبة الإنجاز أقل من 100%', t.progress, 'راجع الحالة ونسبة الإنجاز مع مسؤول البيانات');
      }

      if ((it.pf === 'special' || it.pf === 'council') && it.hasTitle && it.k.status === U.key('منجز') && c.progress && c.progress.t === 'n' && c.progress.v < 1) {
        push('warn', it, f.progress.h, 'مستوى الإنجاز «منجز» ونسبة الإنجاز أقل من 100%', t.progress, 'راجع الحالة ونسبة الإنجاز مع مسؤول البيانات');
      }

      if (it.pf === 'kpi' && it.hasTitle && it.calc.measurementIssue) {
        var measurementProblems = {
          unknownState: 'حالة القياس غير معتمدة أو أعمدتها متعارضة؛ استُبعدت النتيجة من إحصاءات القياس',
          missingMeasuredResult: 'حالة القياس «مقاس» دون نتيجة رقمية صالحة؛ النتيجة غير متاحة ولم تُحوَّل إلى صفر',
          excludedStateWithResult: 'حالة القياس تستبعد المؤشر مع وجود نتيجة غير صفرية؛ حُفظت النتيجة واستُبعدت من إحصاءات القياس'
        };
        push('warn', it, f.measurementState.h, measurementProblems[it.calc.measurementIssue], t.measurementState,
          'راجع حالة القياس والنتيجة مع مسؤول البيانات؛ القيم المعتمدة: مقاس / غير مقاس / لا ينطبق أو Measured / Unmeasured / Not applicable');
      }

      if (it.pf === 'kpi' && it.hasTitle && it.calc.result != null && it.calc.target == null) {
        push('info', it, f.target.h, 'للمؤشر نتيجة وليس له مستهدف', '', 'أدخل المستهدف للعام');
      }
    });

    Object.keys(titles).forEach(function (tk) {
      var list = titles[tk];
      if (list.length < 2) return;
      list.forEach(function (it) {
        var others = list.filter(function (x) { return x !== it; }).map(function (x) { return x.row; }).join('، ');
        push('info', it, SC.PF[it.pf].fields.title.h, 'العنوان نفسه مستخدم في صفوف أخرى: ' + others, it.title, 'تكرار العنوان وحده لا يثبت تكرار السجل؛ راجع مفتاح الربط المعتمد قبل تعديل العنوان');
      });
    });

    var d = R.dashboard(data, {}), n = d.n;
    function recon(pf, field, total, sum, fix) {
      var untitled = data.byPf[pf].some(function(it) { return !it.hasTitle; });
      push('warn', null, field, untitled ? 'مجموع الحالات لا يطابق الإجمالي؛ توجد سجلات بدون عنوان، وتختلف شروط احتساب الحالات عن الإجمالي في القالب' : 'مجموع الحالات لا يطابق إجمالي ' + SC.PF[pf].ar, U.fmtN(sum) + ' مقابل ' + U.fmtN(total), untitled ? 'راجع العناوين والحالات وشروط الاحتساب؛ لم تُغيَّر الأرقام أو بيانات المصدر' : fix);
      out[out.length - 1].sheet = data.meta[pf].sheet;
    }
    if (d.missing.agenda) recon('agenda', 'مستوى الإنجاز', n.agendaTotal, n.agendaProgress + n.agendaReady + n.agendaDone + n.agendaLate, 'أكمل مستوى الإنجاز لكل موضوع');
    if (d.missing.council) recon('council', 'مستوى الإنجاز', n.councilTotal, n.councilProgress + n.councilDone + n.councilLate, 'أكمل مستوى الإنجاز للقرارات التي تتطلب متابعة');
    if (d.missing.legislation) recon('legislation', 'مؤشرات الأداء', n.legTotal, n.legProgress + n.legOnTime + n.legOverrun, 'أكمل مؤشرات الأداء لكل تشريع');
    // Dates in another year are valid source values, not missing-data defects.
    if (n.secNoQuarter) push('info', null, 'ربع الانتهاء', 'توجد مشاريع خارج سنة المرجع أو دون تاريخ؛ وهي محفوظة ضمن الإجمالي', n.secNoQuarter, 'راجع فئة خارج سنة المرجع / غير مؤرخ');
    var quarterSum = n.secQ1 + n.secQ2 + n.secQ3 + n.secQ4 + n.secNoQuarter;
    if (quarterSum !== n.secTotal) {
      push('warn', null, 'ربع الانتهاء', 'توزيع الأرباع لا يطابق الإجمالي؛ القالب يحتسب الأرباع حسب التاريخ والإجمالي حسب وجود عنوان المشروع', U.fmtN(quarterSum) + ' مقابل ' + U.fmtN(n.secTotal), 'راجع عناوين المشاريع وتواريخ الانتهاء؛ لم تُغيَّر شروط القالب');
      out[out.length - 1].sheet = data.meta.secretariat.sheet;
    }

    var snap = data.snapshot;
    if (!snap.found) out.push({ sev: 'info', sheet: (SC.SNAPSHOT.sheets || [SC.SNAPSHOT.sheet]).join(' / '), row: '', field: 'الشهر السابق', problem: 'لم يُعثر على كتلة «الشهر السابق» في أوراق الحسابات، فلا تظهر أسهم التغيير', value: '', fix: 'استخدم قالب التقرير نفسه' });
    else if (!snap.hasData && !snap.issue) out.push({ sev: 'info', sheet: snap.sheet || SC.SNAPSHOT.sheet, row: '', field: 'الشهر السابق', problem: 'كتلة «الشهر السابق» فارغة، فلا تظهر أسهم التغيير', value: '', fix: 'الصق قيم الشهر السابق كما في ملف Excel' });

    var order = { error: 0, warn: 1, info: 2 };
    return out.sort(function (a, b) {
      return order[a.sev] - order[b.sev] || String(a.sheet).localeCompare(String(b.sheet), 'ar') || (parseInt(a.row, 10) || 0) - (parseInt(b.row, 10) || 0);
    });
  }

  S.checks = { run: run };
})(window.Saytara = window.Saytara || {});
