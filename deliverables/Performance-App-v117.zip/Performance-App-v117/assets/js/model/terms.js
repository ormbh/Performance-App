/* Arabic domain nouns for generated labels only. Source cells and stable keys stay unchanged. */
(function (S) {
  'use strict';
  var FORMS = {
    agenda: ['موضوع', 'الموضوع', 'مواضيع', 'المواضيع'],
    council: ['قرار', 'القرار', 'قرارات', 'القرارات'],
    legislation: ['تشريع', 'التشريع', 'تشريعات', 'التشريعات'],
    special: ['مشروع', 'المشروع', 'مشاريع', 'المشاريع'],
    secretariat: ['مشروع', 'المشروع', 'مشاريع', 'المشاريع'],
    kpi: ['مؤشر', 'المؤشر', 'مؤشرات', 'المؤشرات'],
    mixed: ['بند', 'البند', 'بنود', 'البنود']
  };
  function family(value) {
    var pf = typeof value === 'string' ? value : value && value.pf;
    if (['agendaPlanned', 'agendaEmerging', 'agendaNew', 'agendaOther'].indexOf(pf) >= 0) pf = 'agenda';
    return FORMS[pf] ? pf : 'mixed';
  }
  function words(scope, fallback) {
    var list = Array.isArray(scope) ? scope : scope == null || scope === '' ? [] : [scope];
    if (!list.length && fallback != null) list = Array.isArray(fallback) ? fallback : [fallback];
    var forms = list.map(function (value) { return FORMS[family(value)]; });
    var chosen = forms.length && forms.every(function (f) { return f[0] === forms[0][0]; }) ? forms[0] : FORMS.mixed;
    return { single: chosen[0], definite: chosen[1], plural: chosen[2], definitePlural: chosen[3] };
  }
  function reportPf(state) { return state.report.kind === 'agenda' ? 'agenda' : state.report.kind === 'hh' ? 'special' : state.report.kind === 'council' ? 'council' : 'secretariat'; }
  function count(n, scope, fallback) { return 'عدد ' + words(scope, fallback).definitePlural + ': ' + S.util.fmtN(n); }
  S.terms = { words: words, reportPf: reportPf, count: count };
})(window.Saytara = window.Saytara || {});
