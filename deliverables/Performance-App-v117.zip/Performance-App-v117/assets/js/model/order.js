/* Workbook LOV row order is the display order. Unknown values follow known values. */
(function(S){
 'use strict';
 var U=S.util,SC=S.schema;
 /* LOVs are fixed for a loaded workbook. Release their indexes with the data,
    and keep public arrays separate so callers cannot mutate the cached order. */
 var CACHE=new WeakMap(),DEFAULT_CACHE=createCache();
 function createCache(){return {lists:Object.create(null),statuses:Object.create(null),keys:new Map()};}
 function cacheFor(data){
  if(!data||(typeof data!=='object'&&typeof data!=='function'))return DEFAULT_CACHE;
  var cache=CACHE.get(data);if(!cache){cache=createCache();CACHE.set(data,cache);}return cache;
 }
 function key(cache,v){
  if(!cache)return U.key(v);
  if(!cache.keys.has(v))cache.keys.set(v,U.key(v));return cache.keys.get(v);
 }
 function makeOrder(values,cache){
  var index=new Map();values.forEach(function(v,i){var k=key(cache,v);if(!index.has(k))index.set(k,i);});
  return {values:values,index:index,cache:cache};
 }
 function listOrder(data,name){
  var cache=cacheFor(data);if(cache.lists[name])return cache.lists[name];
  var source=data&&data.lovs&&data.lovs.lists[name];
  if(!source)source=(SC.LOVS[name]||{}).defaults||[];
  var seen=new Set(),values=source.map(function(v){return typeof v==='object'?v.value:String(v);}).filter(function(v){var k=key(cache,v);if(!k||seen.has(k))return false;seen.add(k);return true;});
  return cache.lists[name]=makeOrder(values,cache);
 }
 function list(data,name){return listOrder(data,name).values.slice();}
 function compareOrder(order,a,b){
  var ka=key(order.cache,a),kb=key(order.cache,b);if(ka===kb)return 0;
  if(!ka)return 1;if(!kb)return -1;
  var ia=order.index.get(ka),ib=order.index.get(kb);
  if(ia!=null||ib!=null)return (ia==null?1e6:ia)-(ib==null?1e6:ib);
  return String(a).localeCompare(String(b),'ar',{numeric:true});
 }
 function compareValues(values,a,b){return compareOrder(makeOrder(values),a,b);}
 function compare(data,name,a,b){return compareOrder(listOrder(data,name),a,b);}
 var STATUS_DISPLAY=Object.assign(Object.create(null),{'active':'قيد العمل','not started':'لم يبدأ','completed':'منجز','frozen':'معلق','cancelled':'ملغى','transferred':'منقول'});
 function statusLabel(v,cache){return STATUS_DISPLAY[key(cache,v)]||v;}
 function statusOrder(data,pf){
  var cache=cacheFor(data),cacheKey=pf||'';if(cache.statuses[cacheKey])return cache.statuses[cacheKey];
  var spec=SC.PF[pf],f=spec&&spec.fields.status;
  var out=[];
  if(f&&f.lov)out=listOrder(data,f.lov).values.map(function(v){return f.lov==='ProjectStatus'?statusLabel(v,cache):v;});
  else ['AgendaStatus','WorkStatus','ProjectStatus'].forEach(function(name){
   var values=listOrder(data,name).values.map(function(v){return name==='ProjectStatus'?statusLabel(v,cache):v;});
   values.forEach(function(v,i){if(out.some(function(x){return U.key(x)===U.key(v);}))return;
    var next=values.slice(i+1).find(function(x){return out.some(function(y){return U.key(x)===U.key(y);});});
    if(next)out.splice(out.findIndex(function(x){return U.key(x)===U.key(next);}),0,v);else out.push(v);
   });
  });return cache.statuses[cacheKey]=makeOrder(out,cache);
 }
 function statuses(data,pf){return statusOrder(data,pf).values.slice();}
 function status(data,a,b,pf){var order=statusOrder(data,pf);return compareOrder(order,statusLabel(a,order.cache),statusLabel(b,order.cache));}
 var FIELDS={sector:'Sectors',unit:'Departments',entity:'Entities',year:'Years',quarter:'Quarters',month:'Months',type:'TopicTypes',priority:'ProjectPriority',ptype:'ProjectType',freq:'Frequency'};
 function field(data,key,a,b,pf){return key==='status'?status(data,a,b,pf):compare(data,FIELDS[key],a,b);}
 function period(data,it){
  var t=it.t||{},month='',quarter='',year='';
  if(it.pf==='agenda'){month=t.month||'';quarter=t.quarter||'';year=t.year||'';}
  else if(it.pf==='special'){month=t.endMonth||'';year=t.endYear||'';}
  else if(it.pf==='secretariat'){
   var end=it.c&&it.c.end,due=it.calc&&it.calc.due;
   var numeric=end&&end.t==='n'&&typeof end.v==='number'&&Number.isFinite(end.v)&&end.v>0&&end.v<2958466;
   var monthOnly=end&&end.t==='s'&&U.MONTHS_EN3.indexOf(U.xlTrim(end.v).toUpperCase())>=0;
   if((numeric||monthOnly)&&typeof due==='number'&&Number.isFinite(due)&&due>0&&due<2958466){var p=U.ymd(due);month=U.MONTHS_AR[p.m-1];year=String(p.y);}
  }
  else if(it.c&&it.c.end&&it.c.end.t==='n'){var d=U.ymd(it.c.end.v);if(d){month=U.MONTHS_AR[d.m-1];year=String(d.y);}}
  var q=/([1-4])/.exec(quarter),words=['الاول','الثاني','الثالث','الرابع'];
  if(q)quarter=['الربع الأول','الربع الثاني','الربع الثالث','الربع الرابع'][Number(q[1])-1];
  else if(quarter){var at=words.findIndex(function(w){return U.norm(quarter).includes(w);});if(at>=0)quarter=['الربع الأول','الربع الثاني','الربع الثالث','الربع الرابع'][at];}
  if(!quarter&&U.monthIndexAr(month))quarter=['الربع الأول','الربع الثاني','الربع الثالث','الربع الرابع'][Math.ceil(U.monthIndexAr(month)/3)-1];
  return {quarter:quarter,month:month,year:year};
 }
 function items(data,a,b){
  var da=period(data,a),db=period(data,b);
  return compare(data,'Quarters',da.quarter,db.quarter)||compare(data,'Months',da.month,db.month)||status(data,a.statusLabel||a.t.status,b.statusLabel||b.t.status)||
   compare(data,'Sectors',a.sector,b.sector)||compare(data,'Departments',a.unit,b.unit)||
   compare(data,'Entities',a.entity,b.entity)||SC.ORDER.indexOf(a.pf)-SC.ORDER.indexOf(b.pf)||a.seq-b.seq;
 }
 function sort(data,values,name){return values.slice().sort(function(a,b){return compare(data,name,a,b);});}
 S.order={list:list,compare:compare,compareValues:compareValues,statuses:statuses,status:status,field:field,items:items,sort:sort,period:period};
})(window.Saytara=window.Saytara||{});
