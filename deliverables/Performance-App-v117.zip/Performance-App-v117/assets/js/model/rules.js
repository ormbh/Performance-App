/*
 * Performance reporting · report rules
 * The same rules as the workbook's Dashboards sheet and calculated columns, so
 * every figure matches the Excel report. Each dashboard number is a named metric
 * with a test per item; clicking a number opens exactly the items it counts.
 */
(function (S) {
  'use strict';

  var U = S.util, k = U.key;

  /* Excel's `<>""`: any value, even spaces, counts as present. */
  function present(it, f) { var c = it.c[f]; return !!c && c.t !== 'e' && !(c.t === 's' && c.v === ''); }

  /* Excel's "=": case-insensitive, spaces kept (most of the workbook's formulas). */
  function is(it, f, v) { return it.x[f] === String(v).toLowerCase(); }
  function isAny(it, f, list) {
    var x = it.x[f];
    for (var i = 0; i < list.length; i++) if (x === String(list[i]).toLowerCase()) return true;
    return false;
  }

  /* Council decisions formulas compare TRIM(SUBSTITUTE(x, CHAR(160), " ")). */
  function tv(it, f) {
    var c = it.c[f];
    if (!c || c.t === 'e') return '';
    return U.xlTrim(c.t === 's' ? c.v : String(c.v), true).toLowerCase();
  }
  function tNorm(v) { return U.xlTrim(v, true).toLowerCase(); }
  function tIs(it, f, v) { return tv(it, f) === tNorm(v); }
  function tIsAny(it, f, list) {
    var x = tv(it, f);
    for (var i = 0; i < list.length; i++) if (x === tNorm(list[i])) return true;
    return false;
  }

  var IN_PROGRESS = ['قيد التطوير', 'قيد المراجعة'];
  var FOLLOW_UP_REQUIRED = ['رسالة رسمية', 'بريد من الوحدة التنظيمية'];
  var NOTE_STATUSES = ['متأخر', 'معلق', 'ملغى'];
  var SEC_STATUS_AR = { 'active': 'قيد العمل', 'not started': 'لم يبدأ', 'completed': 'منجز', 'frozen': 'معلق', 'cancelled': 'ملغى', 'transferred': 'منقول' };

  var CAT = {};
  [['منجز', 'done'], ['completed', 'done'], ['في الموعد', 'done'], ['مكتمل', 'done'],
    ['قيد التطوير', 'progress'], ['قيد العمل', 'progress'], ['active', 'progress'], ['قيد الإجراء', 'progress'], ['قيد التنفيذ', 'progress'],
    ['قيد المراجعة', 'review'], ['جاهز للعرض', 'ready'],
    ['معلق', 'hold'], ['frozen', 'hold'], ['ملغى', 'cancelled'], ['ملغي', 'cancelled'], ['cancelled', 'cancelled'],
    ['لم يبدأ', 'notStarted'], ['not started', 'notStarted'], ['متأخر', 'delayed'], ['منقول', 'transferred'], ['transferred', 'transferred'], ['مغلق', 'done']
  ].forEach(function (p) { CAT[k(p[0])] = p[1]; });
  function catOf(label) { return CAT[k(label)] || 'other'; }

  /* Excel's YEAR/MONTH for a date serial (serials below 61 follow Excel's 1900 calendar). */
  function xlYM(s) {
    s = Math.floor(s);
    if (s >= 61) { var p = U.ymd(s); return { y: p.y, m: p.m }; }
    if (s === 60) return { y: 1900, m: 2 };
    if (s >= 1) { var q = U.ymd(s + 1); return { y: q.y, m: q.m }; }
    if (s === 0) return { y: 1900, m: 1 };
    return null;
  }

  /* ---------- calculated columns ---------- */

  /* مشاريع_الأمانة · Quarter and Late KPI (columns U and V). */
  function calcSecretariat(it, today) {
    var cell = it.c.end, ty = U.ymd(today).y, m = 0, y = ty, quarter = '';
    if (cell && cell.t === 'n') {
      var d = xlYM(cell.v);
      if (d) { m = d.m; y = d.y; quarter = (d.y === ty ? 'Q' : d.y + ' Q') + Math.ceil(d.m / 3); }
    } else if (cell && cell.t === 's') {
      m = U.MONTHS_EN3.indexOf(U.xlTrim(cell.v).toUpperCase()) + 1;
      if (m) quarter = 'Q' + Math.ceil(m / 3);
    }
    var due = m ? U.eomonth(y, m) : null;
    var sc = it.c.status;
    var st = sc && sc.t !== 'e' ? U.xlTrim(sc.t === 's' ? sc.v : String(sc.v), true).toLowerCase() : '';
    var eligible = present(it, 'title') && (st === 'active' || st === 'not started');
    it.calc.quarter = quarter;
    it.calc.due = due;
    it.calc.late = due != null && eligible && today > due;
  }

  /* Mold W: COUNT(F:K) guard, then first nonblank K/I/J/H/G/F (not MAX).
     Never use W's potentially stale cache or parse locale-dependent text dates. */
  function calcLegislationMonth(it) {
    var order = ['actual', 'ext', 'deptDate', 'slc', 'assigned', 'received'];
    var out = { key: '', label: '', month: null, year: null, serial: null, source: '', reason: '' };
    var numeric = order.some(function (f) { return it.c[f] && it.c[f].t === 'n' && Number.isFinite(it.c[f].v); });
    if (!numeric) out.reason = 'لا يوجد تاريخ رقمي لحساب شهر التشريع';
    else {
      var field = order.find(function (f) { var c = it.c[f]; return c && !(c.t === 's' && c.v === ''); });
      var cell = it.c[field]; out.source = field || '';
      if (!cell || cell.t !== 'n' || !Number.isFinite(cell.v) || cell.v < 0 || cell.v >= 2958466) {
        out.reason = 'التاريخ ذو الأولوية غير صالح لحساب شهر التشريع';
      } else {
        var d = xlYM(cell.v);
        if (d) {
          out.month = d.m; out.year = d.y; out.serial = cell.v;
          out.key = String(d.y).padStart(4, '0') + '-' + String(d.m).padStart(2, '0');
          out.label = U.MONTHS_AR[d.m - 1] + ' ' + d.y;
        }
      }
    }
    it.calc.legislationMonth = out;
  }

  /* التشريعات · Late KPI and تجاوز الموعد (columns U and V). */
  function calcLegislation(it, today) {
    calcLegislationMonth(it);
    var K = it.c.actual, I = it.c.ext, H = it.c.slc, J = it.c.deptDate;
    var late = false, deadline = null;
    if (!K) {
      var dl = I || H;
      if (dl && dl.t === 'n') { deadline = dl.v; if (today > dl.v) late = true; }
    }
    var overrun = false;
    if (is(it, 'kpi', 'في الموعد') && K && K.t === 'n') {
      var kd = Math.floor(K.v);
      var after = function (c) { return !!c && c.t === 'n' && kd > Math.floor(c.v); };
      overrun = after(H) || after(I) || after(J);
    }
    it.calc.late = late;
    it.calc.overrun = overrun;
    it.calc.deadline = deadline;
  }

  /* Legacy molds exclude zero. Explicit measurement state can identify a genuine
     measured zero without changing the separate nonzero target population. */
  function calcKpi(it) {
    var R = it.c.result, T = it.c.target, stateCell = it.c.measurementState;
    var titled = present(it, 'title');
    var numeric = !!R && R.t === 'n' && Number.isFinite(R.v);
    var rawState = stateCell && stateCell.t === 's' ? String(stateCell.v) : '';
    var explicit = !!stateCell && !(stateCell.t === 's' && rawState.trim() === '');
    var states = { 'مقاس': 'measured', 'Measured': 'measured', 'غير مقاس': 'unmeasured', 'Unmeasured': 'unmeasured', 'لا ينطبق': 'notApplicable', 'Not applicable': 'notApplicable' };
    var state = explicit ? states[rawState] || 'unknown' : 'legacy';
    // Competing headings are quarantined by the loader; never restore legacy
    // eligibility merely because their ambiguous cell was deliberately omitted.
    if (it.measurementStateAmbiguous) { explicit = true; state = 'unknown'; }
    var issue = state === 'unknown' ? 'unknownState' : state === 'measured' && !numeric ? 'missingMeasuredResult' :
      (state === 'unmeasured' || state === 'notApplicable') && numeric && R.v !== 0 ? 'excludedStateWithResult' : '';
    var measured = titled && numeric && (state === 'measured' || state === 'legacy' && R.v !== 0);
    it.calc.measurementState = state;
    it.calc.measurementStateExplicit = explicit;
    it.calc.measurementIssue = issue;
    it.calc.measured = measured;
    // Backward-compatible consumer alias: now eligible measured result, including
    // an explicitly measured zero. Use `measured` for new consumers.
    it.calc.resultNonZero = measured;
    it.calc.result = measured ? R.v : null;
    it.calc.target = titled && T && T.t === 'n' && Number.isFinite(T.v) && T.v !== 0 ? T.v : null;
    it.calc.resultRecorded = numeric ? R.v : null;
    it.calc.targetRecorded = T && T.t === 'n' && Number.isFinite(T.v) ? T.v : null;
  }

  function statusOf(it) {
    var label = '', cat = 'other', health = null;
    if (it.pf === 'secretariat') {
      label = SEC_STATUS_AR[it.k.status] || it.t.status;
      cat = catOf(label);
      if (it.calc.late) health = 'delayed';
    } else if (it.pf === 'legislation') {
      label = it.t.state || it.t.kpi;
      cat = it.t.state ? catOf(it.t.state) : 'other';
      if (it.calc.late) health = 'delayed';
      else if (it.calc.overrun) health = 'doneLate';
      else if (is(it, 'kpi', 'في الموعد')) health = 'doneOnTime';
    } else if (it.pf === 'kpi') {
      label = it.calc.measurementState === 'unknown' ? 'حالة قياس غير معتمدة' : it.calc.measurementIssue === 'missingMeasuredResult' ? 'مقاس — النتيجة غير متاحة' : it.calc.measurementIssue === 'excludedStateWithResult' ? 'تعارض حالة القياس والنتيجة' : it.calc.measurementState === 'notApplicable' ? 'لا ينطبق' : it.calc.measured ? 'مقاس' : 'غير مقاس';
      cat = it.calc.measurementIssue ? 'measurementUnavailable' : it.calc.measurementState === 'notApplicable' ? 'notApplicable' : it.calc.measured ? 'measured' : 'notMeasured';
    } else {
      label = it.t.status;
      cat = catOf(label);
      if (cat === 'delayed') health = 'delayed';
    }
    it.statusLabel = label || '';
    it.statusCat = label ? cat : 'none';
    it.health = health;
  }

  function calc(it, today) {
    if (it.pf === 'secretariat') calcSecretariat(it, today);
    else if (it.pf === 'legislation') calcLegislation(it, today);
    else if (it.pf === 'kpi') calcKpi(it);
    statusOf(it);
  }

  /* ---------- follow-up notes (Dashboards!BW2) ---------- */
  function followStatus(it) {
    if (it.pf === 'council') return councilBase(it) && tIsAny(it, 'status', NOTE_STATUSES) ? tv(it, 'status') : null;
    if (it.pf === 'special' || it.pf === 'agenda') {
      return present(it, 'title') && isAny(it, 'status', NOTE_STATUSES) ? it.t.status : null;
    }
    if (it.pf === 'secretariat') {
      if (!present(it, 'title')) return null;
      if (is(it, 'status', 'Cancelled')) return 'ملغى';
      if (is(it, 'status', 'Frozen')) return 'معلق';
      if (is(it, 'status', 'Transferred')) return 'منقول';
      return it.calc.late ? 'متأخر' : null;
    }
    if (it.pf === 'legislation') return present(it, 'title') && it.calc.late ? 'متأخر' : null;
    return null;
  }

  /* ---------- metrics ---------- */
  var MET = {};
  function def(id, pf, label, definition, test) { MET[id] = { id: id, pf: pf, label: label, def: definition, test: test }; }

  function councilBase(it) { return present(it, 'title') && tIsAny(it, 'followup', FOLLOW_UP_REQUIRED); }
  function specialCounted(it) { return present(it, 'title'); }
  function specialRequester(it) { return is(it, 'lead', 'نعم') || is(it, 'lead', 'لا'); }

  // الأجندة السنوية
  def('agendaTotal', 'agenda', 'الأجندة السنوية', 'مواضيع الأجندة السنوية (الصفوف التي فيها «الموضوع»)', function (it) { return present(it, 'title'); });
  def('agendaPlanned', 'agenda', 'من الأجندة', 'تصنيف الموضوع = «الأجندة السنوية»', function (it) { return is(it, 'type', 'الأجندة السنوية'); });
  def('agendaEmerging', 'agenda', 'ما يستجد', 'تصنيف الموضوع = «مستجد»', function (it) { return is(it, 'type', 'مستجد'); });
  def('agendaProgress', 'agenda', 'قيد العمل', 'مستوى الإنجاز = «قيد التطوير» أو «قيد المراجعة»', function (it) { return isAny(it, 'status', IN_PROGRESS); });
  def('agendaReady', 'agenda', 'جاهز للعرض', 'مستوى الإنجاز = «جاهز للعرض»', function (it) { return is(it, 'status', 'جاهز للعرض'); });
  def('agendaDone', 'agenda', 'منجز', 'مستوى الإنجاز = «منجز»', function (it) { return is(it, 'status', 'منجز'); });
  def('agendaLate', 'agenda', 'متأخر', 'مستوى الإنجاز = «متأخر»', function (it) { return is(it, 'status', 'متأخر'); });
  def('agendaNoStatus', 'agenda', 'بدون حالة', 'مواضيع بلا مستوى إنجاز من القائمة', function (it) { return present(it, 'title') && !isAny(it, 'status', IN_PROGRESS.concat(['جاهز للعرض', 'منجز', 'متأخر'])); });

  // قرارات المجالس
  def('councilTotal', 'council', 'قرارات المجالس', 'القرارات التي متطلبات متابعتها «رسالة رسمية» أو «بريد من الوحدة التنظيمية»', councilBase);
  def('councilProgress', 'council', 'قيد العمل', 'قرارات تتطلب متابعة، ومستوى إنجازها «قيد التطوير» أو «قيد المراجعة»', function (it) { return councilBase(it) && tIsAny(it, 'status', IN_PROGRESS); });
  def('councilDone', 'council', 'منجز', 'قرارات تتطلب متابعة، ومستوى إنجازها «منجز»', function (it) { return councilBase(it) && tIs(it, 'status', 'منجز'); });
  def('councilLate', 'council', 'متأخر', 'قرارات تتطلب متابعة، ومستوى إنجازها «متأخر»', function (it) { return councilBase(it) && tIs(it, 'status', 'متأخر'); });
  def('councilNoStatus', 'council', 'بدون حالة', 'قرارات تتطلب متابعة بلا مستوى إنجاز من القائمة', function (it) { return councilBase(it) && !tIsAny(it, 'status', IN_PROGRESS.concat(['منجز', 'متأخر'])); });
  def('councilExcluded', 'council', 'لا تتطلب متابعة', 'قرارات متطلبات متابعتها مغلقة أو ملغاة أو فارغة، فلا تدخل في التقرير', function (it) { return present(it, 'title') && !councilBase(it); });

  // التشريعات
  def('legTotal', 'legislation', 'التشريعات', 'التشريعات المسجلة (الصفوف التي فيها «عنوان التشريع»)', function (it) { return present(it, 'title'); });
  def('legProgress', 'legislation', 'قيد العمل', 'مؤشرات الأداء = «قيد الإجراء»', function (it) { return is(it, 'kpi', 'قيد الإجراء'); });
  def('legOnTime', 'legislation', 'ضمن الموعد بحسب المؤشر', 'مؤشرات الأداء = «في الموعد»، باستثناء ما تجاوز الموعد', function (it) { return is(it, 'kpi', 'في الموعد') && !it.calc.overrun; });
  def('legOverrun', 'legislation', 'تجاوز الموعد', 'مصنفة «في الموعد» لكن تاريخ الإنجاز الفعلي بعد تاريخ SLC أو التمديد أو التاريخ المحدد من إدارة التشريعات', function (it) { return !!it.calc.overrun; });
  def('legLate', 'legislation', 'متأخر', 'لم يُسجَّل تاريخ إنجاز فعلي، ومضى تاريخ التمديد (أو تاريخ SLC إن لم يوجد تمديد)', function (it) { return !!it.calc.late; });
  def('legNoStatus', 'legislation', 'بدون حالة', 'تشريعات مؤشر أدائها ليس «قيد الإجراء» ولا «في الموعد»', function (it) { return present(it, 'title') && !is(it, 'kpi', 'قيد الإجراء') && !is(it, 'kpi', 'في الموعد'); });

  // المشاريع الخاصة
  def('specialTotal', 'special', 'المشاريع الخاصة', 'المشاريع المسجلة (الصفوف التي فيها «اسم المشروع»)', specialCounted);
  def('specialLead', 'special', 'للقيادة', 'مشاريع سموه = «نعم»', function (it) { return is(it, 'lead', 'نعم'); });
  def('specialGs', 'special', 'للأمانة العامة', 'مشاريع سموه = «لا»', function (it) { return is(it, 'lead', 'لا'); });
  def('specialDone', 'special', 'منجز', 'مستوى الإنجاز = «منجز»', function (it) { return specialCounted(it) && is(it, 'status', 'منجز'); });
  def('specialLate', 'special', 'متأخر', 'مستوى الإنجاز = «متأخر»', function (it) { return specialCounted(it) && is(it, 'status', 'متأخر'); });
  def('specialProgress', 'special', 'قيد العمل', 'المجموع ناقص المنجز والمتأخر', function (it) { return specialCounted(it) && !is(it, 'status', 'منجز') && !is(it, 'status', 'متأخر'); });
  def('specialLeadDone', 'special', 'للقيادة · منجز', 'مشاريع سموه = «نعم» ومستوى الإنجاز = «منجز»', function (it) { return is(it, 'lead', 'نعم') && is(it, 'status', 'منجز'); });
  def('specialLeadLate', 'special', 'للقيادة · متأخر', 'مشاريع سموه = «نعم» ومستوى الإنجاز = «متأخر»', function (it) { return is(it, 'lead', 'نعم') && is(it, 'status', 'متأخر'); });
  def('specialLeadOpen', 'special', 'للقيادة · مفتوح', 'مشاريع سموه = «نعم» وغير منجزة', function (it) { return is(it, 'lead', 'نعم') && !is(it, 'status', 'منجز'); });
  def('specialGsDone', 'special', 'للأمانة العامة · منجز', 'مشاريع سموه = «لا» ومستوى الإنجاز = «منجز»', function (it) { return is(it, 'lead', 'لا') && is(it, 'status', 'منجز'); });
  def('specialGsLate', 'special', 'للأمانة العامة · متأخر', 'مشاريع سموه = «لا» ومستوى الإنجاز = «متأخر»', function (it) { return is(it, 'lead', 'لا') && is(it, 'status', 'متأخر'); });
  def('specialGsOpen', 'special', 'للأمانة العامة · مفتوح', 'مشاريع سموه = «لا» وغير منجزة', function (it) { return is(it, 'lead', 'لا') && !is(it, 'status', 'منجز'); });
  def('specialNoRequester', 'special', 'بدون جهة طالبة', 'مشاريع مسجلة لا تحدد «مشاريع سموه» فيها «نعم» أو «لا»؛ تُحتسب في الإجمالي ولا في توزيع الجهة الطالبة', function (it) { return present(it, 'title') && !specialRequester(it); });

  def('specialLeadProgress', 'special', 'للقيادة · قيد العمل', 'مشاريع القيادة غير المنجزة وغير المتأخرة', function(it){ return is(it,'lead','نعم') && !isAny(it,'status',['منجز','متأخر']); });
  def('specialGsProgress', 'special', 'للأمانة العامة · قيد العمل', 'مشاريع الأمانة العامة غير المنجزة وغير المتأخرة', function(it){ return is(it,'lead','لا') && !isAny(it,'status',['منجز','متأخر']); });

  // مشاريع بموازنة استراتيجية
  def('secTotal', 'secretariat', 'مشاريع بموازنة استراتيجية', 'المشاريع المسجلة (الصفوف التي فيها «Project Name»)', function (it) { return present(it, 'title'); });
  def('secActive', 'secretariat', 'قيد العمل', 'Status = Active', function (it) { return is(it, 'status', 'Active'); });
  def('secHeld', 'secretariat', 'ملغى/معلق', 'Status = Cancelled أو Frozen', function (it) { return isAny(it, 'status', ['Cancelled', 'Frozen']); });
  def('secDone', 'secretariat', 'منجز', 'Status = Completed', function (it) { return is(it, 'status', 'Completed'); });
  def('secNotStarted', 'secretariat', 'لم يبدأ', 'Status = Not Started', function (it) { return is(it, 'status', 'Not Started'); });
  def('secNoStatus', 'secretariat', 'بدون حالة', 'مشاريع بلا حالة من القائمة', function (it) { return present(it, 'title') && !isAny(it, 'status', ['Active', 'Cancelled', 'Frozen', 'Completed', 'Not Started', 'Transferred']); });
  def('secTransferred', 'secretariat', 'منقول', 'Status = Transferred', function (it) { return is(it, 'status', 'Transferred'); });
  def('secLate', 'secretariat', 'متأخر', 'مشروع له عنوان ومضى آخر يوم في شهر End Date، والحالة Active أو Not Started فقط', function (it) { return !!it.calc.late; });
  [1, 2, 3, 4].forEach(function (q) {
    def('secQ' + q, 'secretariat', 'الربع ' + q, 'المشاريع التي يقع End Date في الربع ' + q + ' من سنة التقرير (بجميع حالاتها)', function (it) { return it.calc.quarter === 'Q' + q; });
  });
  def('secNoQuarter', 'secretariat', 'خارج سنة التقرير / غير مؤرخ', 'مشاريع بتاريخ انتهاء خارج سنة التقرير أو دون شهر انتهاء صالح لأرباعها', function (it) { return present(it, 'title') && ['Q1', 'Q2', 'Q3', 'Q4'].indexOf(it.calc.quarter) < 0; });
  def('secBudget', 'secretariat', 'لها موازنة', 'مشاريع لها قيمة في الموازنة أو المخصص أو المنفق', function (it) {
    return ['approved', 'revised', 'committed', 'nonCommitted', 'spent'].some(function (f) { return U.toNumber(it.c[f]) !== 0; });
  });

  // المؤشرات
  def('kpiTotal', 'kpi', 'المؤشرات', 'المؤشرات المسجلة (الصفوف التي فيها «المؤشر»)', function (it) { return present(it, 'title'); });
  def('kpiMeasured', 'kpi', 'المؤشرات المقاسة', 'نتيجة رقمية مع حالة قياس صريحة «مقاس»، أو نتيجة غير صفرية وفق القالب عند غياب الحالة', function (it) { return !!it.calc.measured; });
  def('kpiNotMeasured', 'kpi', 'المؤشرات خارج إحصاءات القياس', 'مؤشرات غير مقاسة أو لا تنطبق أو لا تتوفر لها نتيجة قياس معتمدة؛ يشمل القالب القديم النتائج الصفرية', function (it) { return present(it, 'title') && !it.calc.measured; });

  def('kpiTargeted', 'kpi', 'مؤشرات تدخل في متوسط المستهدفات', 'مؤشرات لها عنوان ومستهدف سنوي رقمي غير صفري؛ مستقل عن توفر النتيجة', function (it) { return it.calc.target != null; });

  // Financial drilldowns use precisely the populated source field, including recorded zero.
  [['secRevised','revised','الموازنة المعتمدة الجديدة'],['secCommitted','committed','المخصص'],['secNonCommitted','nonCommitted','غير المخصص'],['secSpent','spent','المنفق الفعلي']].forEach(function (m) {
    def(m[0], 'secretariat', 'مشاريع لها قيمة في ' + m[2], 'مشاريع لها قيمة رقمية في «' + m[2] + '»، بما فيها الصفر المسجل', function (it) {
      var c = it.c[m[1]];
      if (!c || !['n','s'].includes(c.t)) return false;
      var v = c.t === 'n' ? c.v : String(c.v).replace(/[,\s ]/g, '');
      return v !== '' && Number.isFinite(Number(v));
    });
  });

  // جميع المحافظ
  def('allLate', '*', 'البنود المتأخرة', 'مجموع المتأخر في المحافظ الخمس بحسب قواعد التقرير', function (it) {
    return (it.pf === 'agenda' && MET.agendaLate.test(it)) || (it.pf === 'council' && MET.councilLate.test(it)) ||
      (it.pf === 'legislation' && MET.legLate.test(it)) || (it.pf === 'special' && MET.specialLate.test(it)) ||
      (it.pf === 'secretariat' && MET.secLate.test(it));
  });
  def('follow', '*', 'بنود تستدعي المتابعة', 'المتأخر والمعلق والملغى والمنقول وفق ملاحظات المصدر ومتطلبات متابعة القرارات', function (it) { return followStatus(it) != null; });

  function test(id, it) {
    var m = MET[id];
    return !!m && (m.pf === '*' || m.pf === it.pf) && m.test(it);
  }

  /* ---------- dashboard ---------- */
  /* Sector and unit filters: exact, except council decisions (trimmed, as in the workbook). */
  // Explicit user mapping (2026-10-03): these two portfolios belong to the General Secretariat. Source cells remain unchanged.
  function concernedEntity(it) { return ['kpi','secretariat'].includes(it.pf) ? 'الأمانة العامة للمجلس التنفيذي' : S.schema.PF[it.pf].fields.entity ? it.entity || '' : null; }
  function inScope(it, scope) {
    if (!scope) return true;
    if (scope.entityMode === 'concerned' && U.hasSelection(scope.entity) && (concernedEntity(it) === null || !U.selected(concernedEntity(it), scope.entity))) return false;
    return ['sector','unit'].every(function(k){
      if(k==='sector'&&it.classification) return U.selected(it.sector,scope[k],U.key);
      return U.selected(it.pf==='council' ? tv(it,k) : it.x[k],scope[k],it.pf==='council' ? tNorm : function(v){return String(v == null ? '' : v).toLowerCase();});
    });
  }

  var KIND = { kpiMeasured: 'kpi', kpiAvg: 'kpiAvg', budApproved: 'budget', budSpent: 'budget', budAllocated: 'budget', budUnallocated: 'budget' };
  var EMBEDDED_TIMING = ['secLate','legLate','secQ1','secQ2','secQ3','secQ4','allLate'];

  // Entity history is recoverable only for portfolios explicitly mapped to the Secretariat.
  // The saved snapshot is sector/unit aggregate data, not entity-level history for other portfolios.
  function embeddedMetricAllowed(scope, metric) {
    scope = scope || {};
    if (scope.entityMode !== 'concerned' || !U.hasSelection(scope.entity)) return true;
    if (!U.selected('الأمانة العامة للمجلس التنفيذي', scope.entity)) return false;
    var pf = MET[metric] ? MET[metric].pf : /^bud/.test(metric) ? 'secretariat' : metric === 'kpiAvg' ? 'kpi' : null;
    return pf === 'secretariat' || pf === 'kpi';
  }

  function previous(snapshot, scope) {
    if (!snapshot || !snapshot.hasData) return null;
    if (scope && scope.entityMode === 'concerned' && U.hasSelection(scope.entity) && !U.selected('الأمانة العامة للمجلس التنفيذي',scope.entity)) return null;
    scope = scope || {};
    var rows = snapshot.rows.filter(function (r) {
      return U.selected(r.sector,scope.sector,function(v){return String(v||'').toLowerCase();}) &&
        U.selected(r.unit,scope.unit,function(v){return String(v||'').toLowerCase();});
    });
    if (!rows.length) return null;
    var out = {};
    Object.keys(S.schema.SNAPSHOT.metrics).forEach(function (h) {
      var m = S.schema.SNAPSHOT.metrics[h];
      if (m === 'kpiAvg') return;
      var values = rows.filter(function(r){ return typeof r.v[m] === 'number' && Number.isFinite(r.v[m]) && !(r.quarantined && r.quarantined[m]); });
      // A partial total is not a historical total for the selected scope.
      out[m] = values.length === rows.length ? values.reduce(function(a,r){ return a + r.v[m]; },0) : null;
    });
    var w = 0, s = 0, complete = true;
    rows.forEach(function (r) {
      var wt = r.v.kpiMeasured, res = r.v.kpiAvg;
      if (typeof wt !== 'number' || !Number.isFinite(wt) || wt < 0 || (r.quarantined && r.quarantined.kpiMeasured)) { complete = false; return; }
      if (wt === 0) return;
      if (typeof res !== 'number' || !Number.isFinite(res)) { complete = false; return; }
      w += wt; s += wt * res;
    });
    out.kpiAvg = complete && w > 0 ? s / w : null;
    // HTML(5), template workbook BJ30: prior legislation in-progress = total − on-time − overrun.
    var legKeys=['legTotal','legOnTime','legOverrun'],legPrior=legKeys.every(function(k){return out[k]!=null;}) ? out.legTotal-out.legOnTime-out.legOverrun : null;
    out.legProgress=legPrior!=null&&legPrior>=0?legPrior:null;
    var lateKeys=['specialLeadLate','specialGsLate','agendaLate','councilLate','secLate','legLate'];
    out.allLate = lateKeys.every(function(k){return out[k]!=null;}) ? lateKeys.reduce(function(sum,k){return sum+out[k];},0) : null;
    Object.keys(out).forEach(function(metric) { if (!embeddedMetricAllowed(scope, metric)) out[metric] = null; });
    return out;
  }

  function change(metric, cur, prev) {
    if (!prev) return { state: 'none' };
    var kind = KIND[metric] || 'count';
    var p = prev[metric], c = cur[metric];
    if (p == null || c == null || !Number.isFinite(p) || !Number.isFinite(c)) return { state: 'none' };
    var d = c - p;
    if (kind === 'kpiAvg') {
      if (Math.abs(d) < 0.0005) return { state: 'same', d: 0, text: '–' };
      return { state: 'diff', d: d, text: (Math.abs(d) * 100).toFixed(1) };
    }
    if (Math.abs(d) < 1e-7) return { state: 'same', d: 0, text: '–' };
    return { state: 'diff', d: d, text: U.fmtN(Math.abs(d)) };
  }

  function metricAvailable(data, metric, scope) {
    if (metric === 'allLate') return ['specialLeadLate','specialGsLate','agendaLate','councilLate','secLate','legLate'].every(function(k) { return metricAvailable(data,k,scope); });
    var pf = MET[metric] ? MET[metric].pf : /^bud/.test(metric) ? 'secretariat' : metric === 'kpiAvg' ? 'kpi' : null;
    if (!pf || !data.meta) return true;
    var meta = data.meta[pf];
    if (!meta || !meta.found) return false;
    var fields = ['title'];
    if (scope.entityMode === 'concerned' && U.hasSelection(scope.entity)) { if (!['kpi','secretariat'].includes(pf)) { if (!S.schema.PF[pf].fields.entity) return false; fields.push('entity'); } }
    if (U.hasSelection(scope.sector)) fields.push('sector');
    if (U.hasSelection(scope.unit)) fields.push('unit');
    if (pf === 'special') { if (metric !== 'specialTotal') fields.push('lead'); if (!['specialTotal','specialLead','specialGs','specialNoRequester'].includes(metric)) fields.push('status'); }
    if (pf === 'agenda' && metric !== 'agendaTotal') fields.push(['agendaPlanned','agendaEmerging'].includes(metric) ? 'type' : 'status');
    if (pf === 'council') { fields.push('followup'); if (metric !== 'councilTotal') fields.push('status'); }
    if (pf === 'secretariat') {
      var money = {budApproved:'revised',budSpent:'spent',budAllocated:'committed',budUnallocated:'nonCommitted',secRevised:'revised',secSpent:'spent',secCommitted:'committed',secNonCommitted:'nonCommitted'};
      if (money[metric]) fields.push(money[metric]);
      else if (/^secQ/.test(metric)) fields.push('end');
      else if (metric !== 'secTotal') { fields.push('status'); if (metric === 'secLate') fields.push('end'); }
    }
    if (pf === 'legislation' && metric !== 'legTotal') { if (metric === 'legLate') fields = fields.concat(['actual','slc','ext']); else { fields.push('kpi'); if (metric !== 'legProgress') fields = fields.concat(['actual','slc','ext','deptDate']); } }
    if (pf === 'kpi' && metric !== 'kpiTotal') fields.push(metric === 'kpiTargeted' ? 'target' : 'result');
    return fields.every(function(f) { var def = S.schema.PF[pf].fields[f]; return !def || !(meta.missing || []).includes(def.h); });
  }

  function mean(a) { return a.length ? a.reduce(function (x, y) { return x + y; }, 0) / a.length : null; }

  function measurementComparisonReason(previousData,currentData,scope) {
    scope = scope || {};
    function rows(data) { return data.items.filter(function(it) { return it.pf === 'kpi' && inScope(it,scope); }); }
    var all = rows(previousData).concat(rows(currentData));
    if (!all.some(function(it) { return it.calc.measurementStateExplicit; })) return '';
    function hasField(data) { var m = data.meta.kpi; return !!(m && m.cols && m.cols.measurementState); }
    return !hasField(previousData) || !hasField(currentData) || all.some(function(it) { return !!it.calc.measurementIssue; }) ?
      'تعذرت مقارنة إحصاءات القياس: حالة القياس الصريحة غير متاحة أو غير محسومة في إحدى النسختين' : '';
  }

  function dashboard(data, scope, history) {
    scope = scope || {};
    var items = data.items.filter(function (it) { return inScope(it, scope); });
    var n = {};
    Object.keys(MET).forEach(function (id) {
      var m = MET[id], c = 0;
      for (var i = 0; i < items.length; i++) { var it = items[i]; if ((m.pf === '*' || it.pf === m.pf) && m.test(it)) c++; }
      n[id] = c;
    });

    var sec = items.filter(function (it) { return it.pf === 'secretariat'; });
    var sum = function (f) { return sec.reduce(function (a, it) { return a + U.toNumber(it.c[f]); }, 0); };
    var budget = { approved: sum('revised'), spent: sum('spent'), allocated: sum('committed'), unallocated: sum('nonCommitted'), approvedOriginal: sum('approved') };

    var kp = items.filter(function (it) { return it.pf === 'kpi'; });
    var avgResult = mean(kp.map(function (it) { return it.calc.result; }).filter(function (v) { return v != null; }));
    var avgTarget = mean(kp.map(function (it) { return it.calc.target; }).filter(function (v) { return v != null; }));

    var cur = {
      kpiMeasured: n.kpiMeasured, kpiAvg: avgResult,
      specialTotal: n.specialTotal,
      specialLeadDone: n.specialLeadDone, specialLeadLate: n.specialLeadLate,
      specialGsDone: n.specialGsDone, specialGsLate: n.specialGsLate,
      agendaTotal: n.agendaTotal, agendaDone: n.agendaDone, agendaLate: n.agendaLate,
      councilTotal: n.councilTotal, councilDone: n.councilDone, councilLate: n.councilLate,
      secTotal: n.secTotal, secDone: n.secDone, secLate: n.secLate,
      legTotal: n.legTotal, legOnTime: n.legOnTime, legOverrun: n.legOverrun, legLate: n.legLate,
      budApproved: budget.approved, budSpent: budget.spent, budAllocated: budget.allocated, budUnallocated: budget.unallocated
    };
    ['legProgress','specialLead','specialGs','specialLeadProgress','specialGsProgress','agendaPlanned','agendaEmerging','agendaProgress','agendaReady','councilProgress','secActive','secHeld','secTransferred','secQ1','secQ2','secQ3','secQ4'].forEach(function(k){cur[k]=n[k];});
    cur.allLate = n.allLate;

    // Uploaded snapshots use the very same metrics and scope as the current report.
    // Validation is performed by comparison.dashboardHistory before a source is supplied.
    var priorData = history && history.source === 'workbook' ? history.data : null;
    var prev = priorData ? dashboard(priorData, scope).cur : history && history.source === 'unavailable' ? null : previous(data.snapshot, scope);
    if (priorData) Object.keys(prev).forEach(function(k) { if (!metricAvailable(priorData, k, scope)) prev[k] = null; });
    var comparison = { source: priorData ? 'workbook' : history && history.source === 'unavailable' ? 'unavailable' : 'embedded', reason: history && history.reason || '', previousDate: history && history.previousDate || '', currentDate: history && history.currentDate || '' };
    var scopedHistory = !priorData && comparison.source === 'embedded' && data.snapshot ? data.snapshot.rows.filter(function(row) {
      return U.selected(row.sector,scope.sector,function(v){return String(v||'').toLowerCase();}) && U.selected(row.unit,scope.unit,function(v){return String(v||'').toLowerCase();});
    }) : [];
    var historyIssues = !priorData && comparison.source === 'embedded' && data.snapshot ? (data.snapshot.qualityIssues || []).filter(function(issue) {
      return scopedHistory.some(function(row) { return issue.rows.indexOf(row.row) >= 0; }) && issue.metrics.some(function(metric) { return embeddedMetricAllowed(scope,metric); });
    }) : [];
    var historyReasons = {};
    scopedHistory.forEach(function(row) { Object.keys(row.quarantined || {}).forEach(function(metric) {
      if (embeddedMetricAllowed(scope,metric)) historyReasons[metric] = row.quarantined[metric];
    }); });
    if (!priorData && comparison.source === 'embedded' && kp.some(function(it) { return it.calc.measurementStateExplicit; })) {
      var stateHistoryReason = 'حالات القياس الصريحة غير محفوظة في ملخص الشهر السابق؛ تعذرت مقارنة إحصاءات القياس بالتعريف نفسه';
      historyReasons.kpiMeasured = stateHistoryReason;
      historyIssues.push({ kind: 'measurement_definition', metrics: ['kpiMeasured','kpiAvg'], rows: [], reason: stateHistoryReason });
    }
    if (priorData) {
      var uploadedStateReason = measurementComparisonReason(priorData,data,scope);
      if (uploadedStateReason) {
        historyReasons.kpiMeasured = uploadedStateReason;
        historyIssues.push({ kind: 'measurement_definition', metrics: ['kpiMeasured','kpiAvg'], rows: [], reason: uploadedStateReason });
      }
    }
    if (historyReasons.kpiMeasured) historyReasons.kpiAvg = historyReasons.kpiMeasured;
    if (['specialLeadLate','specialGsLate','agendaLate','councilLate','secLate','legLate'].some(function(metric) { return historyReasons[metric]; }))
      historyReasons.allLate = 'توجد قيمة تاريخية غير صالحة ضمن مجموع التأخر';
    if (!priorData && comparison.source === 'embedded' && data.snapshot && data.snapshot.issue) {
      historyIssues.push({ kind: 'invalid', metrics: [], rows: [], reason: data.snapshot.issue });
      Object.keys(cur).forEach(function(metric) { if (embeddedMetricAllowed(scope,metric)) historyReasons[metric] = data.snapshot.issue; });
    }
    if (!priorData && comparison.source === 'embedded' && prev && data.snapshot) {
      var referenceDate = data.snapshot.referenceDate;
      var fixedReference = typeof referenceDate === 'number' && Number.isFinite(referenceDate);
      var timing = EMBEDDED_TIMING.filter(function(metric) {
        var selected = metric === 'legLate' ? data.validationDate : data.today;
        var matching = fixedReference && selected === referenceDate;
        if (metric === 'allLate') matching = matching && data.validationDate === referenceDate;
        return embeddedMetricAllowed(scope,metric) && !matching;
      });
      if (timing.length) {
        var timingReason = fixedReference ?
          'حُجبت تغيّرات التأخر والأرباع المحفوظة لأن تاريخ الحساب المختار يختلف عن مرجع المصدر ' + U.fmtDate(referenceDate) + '؛ بقيت الأعداد الحالية والتغيّرات الأخرى كما هي' :
          'حُجبت تغيّرات التأخر والأرباع المحفوظة لعدم توافر مرجع تاريخ ثابت في المصدر؛ بقيت الأعداد الحالية والتغيّرات الأخرى كما هي';
        timing.forEach(function(metric) { historyReasons[metric] = timingReason; });
        historyIssues.push({ kind: 'date_context', metrics: timing, rows: scopedHistory.map(function(row) { return row.row; }), reason: timingReason });
      }
      comparison.referenceDate = fixedReference ? referenceDate : null;
      comparison.referenceSource = data.snapshot.referenceSource || '';
    }
    var filtered = U.hasSelection(scope.sector) || U.hasSelection(scope.unit) || U.hasSelection(scope.entity);
    if (scope.entityMode === 'concerned' && U.hasSelection(scope.entity) && !priorData && comparison.source === 'embedded') { if (embeddedMetricAllowed(scope,'budApproved')) comparison.partialEntity = true; else { comparison.source = 'unavailable'; comparison.reason = 'البيانات السابقة المحفوظة مجمّعة حسب القطاع والوحدة، ولا تتضمن الجهة المعنية'; } }

    var missing = {
      special: cur.specialTotal !== n.specialLead + n.specialGs,
      secretariat: n.secTotal !== n.secQ1 + n.secQ2 + n.secQ3 + n.secQ4,
      agenda: n.agendaTotal !== n.agendaProgress + n.agendaReady + n.agendaDone + n.agendaLate,
      council: n.councilTotal !== n.councilProgress + n.councilDone + n.councilLate,
      legislation: n.legTotal !== n.legProgress + n.legOnTime + n.legOverrun
    };

    var follow = [];
    ['special', 'secretariat', 'agenda', 'council', 'legislation'].forEach(function (pf) {
      items.forEach(function (it) {
        if (it.pf !== pf) return;
        var st = followStatus(it);
        if (st != null) follow.push({ it: it, status: st, note: pf === 'legislation' ? it.t.updates : pf === 'secretariat' ? it.t.ownerRemarks : it.t.notes });
      });
    });

    return {
      scope: scope, filtered: filtered, items: items, n: n, cur: cur, prev: prev, priorData: priorData, comparison: comparison, historyIssues: historyIssues, historyReasons: historyReasons, budget: budget,
      kpi: { avgResult: avgResult, avgTarget: avgTarget, measured: n.kpiMeasured, total: n.kpiTotal,
        explicitState: kp.some(function(it) { return it.calc.measurementStateExplicit; }),
        notMeasured: kp.filter(function(it) { return present(it,'title') && !it.calc.measured && !it.calc.measurementIssue && it.calc.measurementState !== 'notApplicable'; }).length,
        notApplicable: kp.filter(function(it) { return present(it,'title') && !it.calc.measurementIssue && it.calc.measurementState === 'notApplicable'; }).length,
        unavailable: kp.filter(function(it) { return present(it,'title') && it.calc.measurementIssue === 'missingMeasuredResult'; }).length,
        unknown: kp.filter(function(it) { return present(it,'title') && it.calc.measurementIssue === 'unknownState'; }).length,
        conflict: kp.filter(function(it) { return present(it,'title') && it.calc.measurementIssue === 'excludedStateWithResult'; }).length },
      missing: missing, follow: follow,
      change: function (metric) { return historyReasons[metric] ? { state: 'none', reason: historyReasons[metric] } : metricAvailable(data, metric, scope) ? change(metric, cur, prev) : { state: 'none', reason: 'أعمدة المصدر المطلوبة للمقياس غير مكتملة' }; }
    };
  }

  // Translate calculation explanations only; source values and tests stay intact.
  Object.keys(MET).forEach(function(id){
    var labels={'Non-Committed':'غير المخصص','Revised Budget':'الموازنة المعتمدة','Approved Budget':'الموازنة الأصلية','Actual Spent':'المنفق الفعلي','Project Name':'اسم المشروع','End Date':'تاريخ انتهاء المشروع','Status':'مستوى الإنجاز','Not Started':'لم يبدأ','Completed':'منجز','Cancelled':'ملغى','Frozen':'معلق','Active':'قيد العمل','Transferred':'منقول','Committed':'المخصص','Late KPI':'مؤشر التأخر'};
    Object.keys(labels).forEach(function(k){ MET[id].def=MET[id].def.split(k).join(labels[k]); });
  });

  S.rules = {
    measurementComparisonReason: measurementComparisonReason, embeddedMetricAllowed: embeddedMetricAllowed, concernedEntity: concernedEntity, metricAvailable: metricAvailable, calc: calc, test: test, inScope: inScope, dashboard: dashboard, previous: previous,
    MET: MET, catOf: catOf, followStatus: followStatus, present: present,
    FOLLOW_UP_REQUIRED: FOLLOW_UP_REQUIRED
  };
})(window.Saytara = window.Saytara || {});
