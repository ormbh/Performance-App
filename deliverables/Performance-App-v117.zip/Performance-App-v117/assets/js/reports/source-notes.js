/* Source notes are carried by exact record identity, never inferred or rewritten.
   The same selected records feed the screen/PDF appendix and editable slides. */
(function(S){
 'use strict';
 var U=S.util,FIELDS={agenda:['notes','rapporteur'],council:['notes']};
 function rows(data,pf,items){
  var wanted=FIELDS[pf]||[],definition=S.schema.PF[pf];
  return (items||[]).map(function(it){
   var fields=(it.all||[]).filter(function(x){return wanted.includes(x.field)&&!x.calc&&String(x.value==null?'':x.value).trim();}).map(function(x,index){return {field:x.field,label:x.label||definition.fields[x.field].h,value:String(x.value),column:x.column==null?(x.col==null?(it.all||[]).indexOf(x):x.col):x.column};});
   // Browser-only QA records may omit the raw column list; real imports retain it.
   if(!(it.all||[]).length)fields=wanted.filter(function(k){return String((it.t||{})[k]||'').trim();}).map(function(k){return {field:k,label:definition.fields[k].h,value:String(it.t[k]),column:k};});
   return {key:it.key,seq:it.seq,title:it.title||'',sheet:it.sheet||definition.sheet,row:it.row,unit:it.unit||'',fields:fields};
  }).filter(function(row){return row.fields.length;});
 }
 function origin(row){return row.sheet+(row.row==null?'':' · الصف '+row.row);}
 function render(data,pf,items,id,contents){
  var selected=rows(data,pf,items);if(!selected.length)return '';
  return '<section id="'+U.esc(id)+'" class="source-notes-appendix ag-page" dir="rtl"><h2>ملحق ملاحظات المصدر <span>('+U.esc(S.terms.count(selected.length,pf))+')</span></h2>'+S.reportNavigation.returnLink(contents)+'<p class="source-notes-context">النصوص كما وردت في أعمدة المصدر للبنود المشمولة في عوامل تصفية هذا التقرير.</p>'+selected.map(function(row){var length=row.fields.reduce(function(n,f){return n+f.value.length;},0);return '<article class="source-notes-record'+(length>900?' source-notes-long':'')+'" data-source-note-key="'+U.esc(row.key)+'"><h3>'+U.esc(row.title)+'</h3><p class="source-notes-origin">'+U.esc(origin(row))+'</p><dl>'+row.fields.map(function(f){return '<div data-source-note-field="'+U.esc(f.field)+'" data-source-note-column="'+U.esc(f.column)+'"><dt>'+U.esc(f.label)+'</dt><dd dir="auto">'+U.esc(f.value)+'</dd></div>';}).join('')+'</dl></article>';}).join('')+'</section>';
 }
 // Pack short records together; split arbitrarily long text without truncation.
 // Every continuation carries its exact source record/row reference.
 function pages(selected,wrap,maxLines){
  maxLines=maxLines||22;var pages=[],current={lines:[],records:[]};
  function flush(){if(current.lines.length){pages.push(current);current={lines:[],records:[]};}}
  selected.forEach(function(row){
   var identity='سجل المصدر: '+origin(row);
   var content=wrap(row.title+'\n'+identity+'\n'+row.fields.map(function(f){return f.label+'\n'+f.value;}).join('\n\n'));
   for(var at=0;at<content.length;){var prefix=at?wrap(identity+' (تابع)'):[],capacity=Math.max(1,maxLines-prefix.length),chunk=content.slice(at,at+capacity),lines=prefix.concat(chunk);
    if(current.lines.length&&current.lines.length+lines.length+1>maxLines)flush();
    if(current.lines.length)current.lines.push('');current.lines.push.apply(current.lines,lines);current.records.push({key:row.key,continuation:at>0,fields:row.fields.map(function(f){return f.field;})});at+=chunk.length;
    if(at<content.length)flush();
   }
  });flush();return pages;
 }
 S.sourceNotes={rows:rows,render:render,pages:pages};
})(window.Saytara=window.Saytara||{});
