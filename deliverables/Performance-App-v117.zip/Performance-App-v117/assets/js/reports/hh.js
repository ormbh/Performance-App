/* تقرير الأداء والتنفيذ · editable HH report. The supplied HH template and data remain on this device. */
(function(S){
 'use strict';
 var C='http://schemas.openxmlformats.org/drawingml/2006/chart';
 var U=S.util,A='http://schemas.openxmlformats.org/drawingml/2006/main',P='http://schemas.openxmlformats.org/presentationml/2006/main',R='http://schemas.openxmlformats.org/officeDocument/2006/relationships',PK='http://schemas.openxmlformats.org/package/2006/relationships',CT='http://schemas.openxmlformats.org/package/2006/content-types';
 var encoder=new TextEncoder(),decoder=new TextDecoder(),templatePromise;
 var INK='756B5F',BODY='4F4E4E',PAPER='FCFBFB',ACCENT='115E67',RULE='C8C7C7',MISSING='غير متوفر';
 // Apply the TEC palette at export time; the supplied reference template stays intact.
 var LEGACY_COLORS={'8D7C6A':'756B5F','6E5F4F':'756B5F','E5DCD5':'EFEBE7','E5DED8':'EFEBE7','E8E8E8':'FCFBFB','FFFFFF':'FCFBFB','000000':'333333','3A3A3A':'4F4E4E','CA8E3A':'756B5F','01831E':'115E67','C24839':'651D32','BEB8B2':'4F4E4E'};
 function brandXml(source){
  var doc=xml(source);all(doc,A,'srgbClr').forEach(function(n){var c=n.getAttribute('val').toUpperCase();if(LEGACY_COLORS[c])n.setAttribute('val',LEGACY_COLORS[c]);});
  var scheme=first(doc,A,'clrScheme');if(scheme){scheme.setAttribute('name','TEC');var colors={dk1:BODY,lt1:PAPER,dk2:'333333',lt2:'EFEBE7',accent1:ACCENT,accent2:INK,accent3:'651D32',accent4:'ABA394',accent5:'D9E1E2',accent6:'E7E0D3',hlink:ACCENT,folHlink:'651D32'};Array.from(scheme.children).forEach(function(n){if(colors[n.localName]){while(n.firstChild)n.firstChild.remove();n.appendChild(node(doc,A,'a:srgbClr',{val:colors[n.localName]}));}});}
  return serial(doc);
 }
 function xml(s){var d=new DOMParser().parseFromString(s,'application/xml');if(d.getElementsByTagName('parsererror').length)throw new Error('تعذّر قراءة قالب التقرير');return d;}
 // Darken neutral text only. Chart fills, approved status accents and logo artwork stay intact.
 function readableText(d){
  ['rPr','defRPr','endParaRPr'].forEach(function(tag){all(d,A,tag).forEach(function(pr){
   var owner=pr;while(owner&&!(owner.namespaceURI===P&&owner.localName==='sp'))owner=owner.parentNode;var meta=owner&&first(owner,P,'cNvPr');if(meta&&meta.getAttribute('name')==='Recorded status header')return;
   var fill=first(pr,A,'solidFill'),c=fill&&first(fill,A,'srgbClr');if(!c)return;
   var v=c.getAttribute('val').toUpperCase();
   if(['756B5F','ABA394','808080','C8C7C7'].includes(v))c.setAttribute('val',Number(pr.getAttribute('sz')||0)>=1800?'333333':'4F4E4E');
   if(v==='00ACA0')c.setAttribute('val','115E67');
  });});
 }
 function serial(d){readableText(d);return new XMLSerializer().serializeToString(d);}
 function all(e,ns,name){return Array.from(e.getElementsByTagNameNS(ns,name));}
 function first(e,ns,name){return e.getElementsByTagNameNS(ns,name)[0];}
 // DOM insertion references must be immediate children, never descendants.
 function child(e,ns,name){return Array.from(e.children).find(function(n){return n.namespaceURI===ns&&n.localName===name;})||null;}
 function node(d,ns,name,attrs){var n=d.createElementNS(ns,name);Object.keys(attrs||{}).forEach(function(k){if(k==='xmlns'||k.indexOf('xmlns:')===0)n.setAttributeNS('http://www.w3.org/2000/xmlns/',k,String(attrs[k]));else n.setAttribute(k,String(attrs[k]));});return n;}
 // The generated deck replaces every template slide ID. PowerPoint sections use
 // the Office 2010 namespace, not PML. Schema validation does not resolve these
 // IDs, so stale section references can survive a schema-clean export.
 function clearTemplateSlideLists(presentation){
  all(presentation,'http://schemas.microsoft.com/office/powerpoint/2010/main','sectionLst').forEach(function(list){
   var ext=list.parentNode;list.remove();
   if(ext&&ext.namespaceURI===P&&ext.localName==='ext'&&!ext.children.length){var extensions=ext.parentNode;ext.remove();if(extensions&&!extensions.children.length)extensions.remove();}
  });
  all(presentation,P,'custShowLst').forEach(function(n){n.remove();});
 }
 function clean(s){return String(s==null?'':s).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'');}
 function esc(s){return U.esc(clean(s));}
 // ZIP writer for PPTX and its small chart workbooks. Stored entries work offline in Edge/Chrome.
 var crcTable;
 function crc32(bytes){if(!crcTable){crcTable=new Uint32Array(256);for(var i=0;i<256;i++){var c=i;for(var j=0;j<8;j++)c=c&1?0xedb88320^(c>>>1):c>>>1;crcTable[i]=c;}}var crc=0xffffffff;for(var k=0;k<bytes.length;k++)crc=crcTable[(crc^bytes[k])&255]^(crc>>>8);return (crc^0xffffffff)>>>0;}
 function zip(parts,type){
  var body=[],central=[],offset=0;
  parts.forEach(function(value,name){var bytes=typeof value==='string'?encoder.encode(value):value,n=encoder.encode(name),crc=crc32(bytes),l=new Uint8Array(30+n.length),v=new DataView(l.buffer);v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint32(14,crc,true);v.setUint32(18,bytes.length,true);v.setUint32(22,bytes.length,true);v.setUint16(26,n.length,true);l.set(n,30);body.push(l,bytes);var ch=new Uint8Array(46+n.length),cv=new DataView(ch.buffer);cv.setUint32(0,0x02014b50,true);cv.setUint16(4,20,true);cv.setUint16(6,20,true);cv.setUint16(8,0x800,true);cv.setUint32(16,crc,true);cv.setUint32(20,bytes.length,true);cv.setUint32(24,bytes.length,true);cv.setUint16(28,n.length,true);cv.setUint32(42,offset,true);ch.set(n,46);central.push(ch);offset+=l.length+bytes.length;});
  var size=central.reduce(function(n,b){return n+b.length;},0),end=new Uint8Array(22),ev=new DataView(end.buffer);ev.setUint32(0,0x06054b50,true);ev.setUint16(8,parts.size,true);ev.setUint16(10,parts.size,true);ev.setUint32(12,size,true);ev.setUint32(16,offset,true);return new Blob(body.concat(central,[end]),{type:type||'application/zip'});
 }
 function shape(doc,id){return all(doc,P,'sp').find(function(s){var p=first(s,P,'cNvPr');return p&&p.getAttribute('id')===String(id);});}
 function position(el,x,y,w,h){var xf=first(el,A,'xfrm')||first(el,P,'xfrm');if(!xf)return;var off=first(xf,A,'off'),ext=first(xf,A,'ext');if(x!=null)off.setAttribute('x',Math.round(x*9525));if(y!=null)off.setAttribute('y',Math.round(y*9525));if(w!=null)ext.setAttribute('cx',Math.round(w*9525));if(h!=null)ext.setAttribute('cy',Math.round(h*9525));}
 function textProperties(doc,tag,size,font,color,rtl){
  var pr=node(doc,A,'a:'+tag,{lang:rtl?'ar-AE':'en-US',altLang:rtl?'en-US':'ar-AE',sz:Math.round(size*100),b:'0',i:'0',dirty:'0'}),fill=node(doc,A,'a:solidFill');fill.appendChild(node(doc,A,'a:srgbClr',{val:color||'4F4E4E'}));pr.appendChild(fill);
  // English heading glyphs may use an installed Ample face; Arabic and body faces remain unchanged.
  ['latin','ea','cs'].forEach(function(n){pr.appendChild(node(doc,A,'a:'+n,{typeface:n==='latin'&&/^DIN/.test(font||'')?'Ample':font||'Dubai'}));});pr.appendChild(node(doc,A,'a:rtl',{val:rtl?'1':'0'}));return pr;
 }
 function paragraphs(doc,text,size,font,color,align){
  return clean(text).replace(/\r\n?/g,'\n').split('\n').map(function(line){
   var p=node(doc,A,'a:p'),pr=node(doc,A,'a:pPr',{algn:align||'r',rtl:'1',marL:'0',marR:'0',indent:'0'});pr.appendChild(node(doc,A,'a:lnSpc'));pr.lastChild.appendChild(node(doc,A,'a:spcPct',{val:110000}));['spcBef','spcAft'].forEach(function(n){var space=node(doc,A,'a:'+n);space.appendChild(node(doc,A,'a:spcPts',{val:0}));pr.appendChild(space);});pr.appendChild(node(doc,A,'a:buNone'));pr.appendChild(textProperties(doc,'defRPr',size,font,color,true));p.appendChild(pr);
   // Separate Latin identifiers and numbers from Arabic runs without changing source text.
   var spans=[],at=0,re=/[A-Za-z][A-Za-z0-9]*(?:[ \t]+[A-Za-z][A-Za-z0-9]*)*|[0-9]+(?:[.,:/+–-][0-9]+)*(?:[ \t]?%)?/g,m;
   while((m=re.exec(line))){if(m.index>at)spans.push({text:line.slice(at,m.index),rtl:true});spans.push({text:m[0],rtl:false});at=re.lastIndex;}if(at<line.length)spans.push({text:line.slice(at),rtl:true});if(!spans.length)spans.push({text:line,rtl:true});
   spans.forEach(function(span){var run=node(doc,A,'a:r');run.appendChild(textProperties(doc,'rPr',size,font,color,span.rtl));var t=node(doc,A,'a:t');t.textContent=span.text;run.appendChild(t);p.appendChild(run);});p.appendChild(textProperties(doc,'endParaRPr',size,font,color,true));return p;
  });
 }
 function cleanBody(doc,bp){
  ['spAutoFit','normAutofit','noAutofit'].forEach(function(n){all(bp,A,n).forEach(function(x){x.remove();});});bp.setAttribute('wrap','square');bp.setAttribute('vert','horz');bp.setAttribute('rtlCol','1');bp.setAttribute('anchorCtr','0');bp.appendChild(node(doc,A,'a:noAutofit'));
 }
 var fontPromise;
 function loadFonts(){if(S.agendaFonts)return Promise.resolve();if(!fontPromise)fontPromise=new Promise(function(resolve,reject){var s=document.createElement('script');s.src='assets/js/reports/agenda-fonts.js';s.onload=resolve;s.onerror=function(){s.remove();fontPromise=null;reject(new Error('ملفات خطوط PowerPoint غير موجودة. فك ضغط مجلد التطبيق كاملاً.'));};document.head.appendChild(s);});return fontPromise;}
 function embedReportFonts(parts,presentation,rels){
  all(presentation,P,'embeddedFontLst').forEach(function(n){n.remove();});Array.from(rels.documentElement.children).filter(function(n){return n.getAttribute('Type')===R+'/font';}).forEach(function(n){n.remove();});
  var list=node(presentation,P,'p:embeddedFontLst'),entry=node(presentation,P,'p:embeddedFont');entry.appendChild(node(presentation,P,'p:font',{typeface:S.agendaFonts.family}));
  S.agendaFonts.faces.forEach(function(face){parts.set(face.partName,S.agendaFonts.bytes(face));rels.documentElement.appendChild(node(rels,PK,'Relationship',{Id:face.relationshipId,Type:S.agendaFonts.relationshipType,Target:face.partName.replace(/^ppt\//,'')}));var font=node(presentation,P,'p:'+face.style);font.setAttributeNS(R,'r:id',face.relationshipId);entry.appendChild(font);});list.appendChild(entry);
  var root=presentation.documentElement,before=Array.from(root.children).find(function(n){return ['custShowLst','photoAlbum','custDataLst','kinsoku','defaultTextStyle','modifyVerifier','extLst'].includes(n.localName);});root.insertBefore(list,before||null);root.setAttribute('embedTrueTypeFonts','1');root.setAttribute('saveSubsetFonts','0');
 }
 function textShape(doc,id,text,opts){
  opts=opts||{};var s=shape(doc,id);if(!s)return;
  var tb=first(s,P,'txBody');if(!tb)return;
  var bp=first(tb,A,'bodyPr');bp.setAttribute('wrap','square');bp.setAttribute('lIns','0');bp.setAttribute('rIns','0');bp.setAttribute('tIns','0');bp.setAttribute('bIns','0');bp.setAttribute('anchor',opts.anchor||'t');
  all(tb,A,'p').forEach(function(p){p.remove();});cleanBody(doc,bp);
  paragraphs(doc,text,opts.size||16,opts.font||'Dubai',opts.color||'4F4E4E',opts.align).forEach(function(p){tb.appendChild(p);});
  if(opts.box)position.apply(null,[s].concat(opts.box));return s;
 }
 function addText(doc,text,box,size,font,color,align){
  var tree=first(doc,P,'spTree'),id=Math.max(100,...all(doc,P,'cNvPr').map(function(n){return Number(n.getAttribute('id'));}))+1;
  var sp=node(doc,P,'p:sp'),nv=node(doc,P,'p:nvSpPr');nv.appendChild(node(doc,P,'p:cNvPr',{id:id,name:'Report text '+id}));nv.appendChild(node(doc,P,'p:cNvSpPr',{txBox:1}));nv.appendChild(node(doc,P,'p:nvPr'));sp.appendChild(nv);
  var pr=node(doc,P,'p:spPr'),xf=node(doc,A,'a:xfrm');xf.appendChild(node(doc,A,'a:off',{x:Math.round(box[0]*9525),y:Math.round(box[1]*9525)}));xf.appendChild(node(doc,A,'a:ext',{cx:Math.round(box[2]*9525),cy:Math.round(box[3]*9525)}));pr.appendChild(xf);pr.appendChild(node(doc,A,'a:noFill'));sp.appendChild(pr);
  var tb=node(doc,P,'p:txBody');tb.appendChild(node(doc,A,'a:bodyPr',{wrap:'square',lIns:0,rIns:0,tIns:0,bIns:0}));tb.appendChild(node(doc,A,'a:lstStyle'));sp.appendChild(tb);tree.appendChild(sp);textShape(doc,id,text,{box:box,size:size||16,font:font||'Dubai',color:color||'4F4E4E',align:align||'r'});return sp;
 }

 function loadTemplate(){
  if(S.hhTemplateBase64)return Promise.resolve();
  if(!templatePromise)templatePromise=new Promise(function(resolve,reject){var script=document.createElement('script');script.src='assets/js/reports/hh-template.js';script.onload=resolve;script.onerror=function(){script.remove();templatePromise=null;reject(new Error('ملف قالب HH غير موجود. فك ضغط مجلد التطبيق كاملاً.'));};document.head.appendChild(script);});
  return templatePromise;
 }
 function value(v){return clean(v).trim()||MISSING;}
 function optional(it,label){var f=(it.all||[]).find(function(x){return U.key(x.label)===U.key(label);});return f?f.value:'';}
 function status(it){return value(it.statusLabel||(it.t||{}).status);}
 function progress(it){return it.progress==null?value((it.t||{}).progress):U.displayNumber(it.progress,1,'%');}
 function date(it,key){return value([it.t[key+'Month'],it.t[key+'Year']].filter(Boolean).join(' '));}
 function scope(state){var fields=[['القطاع',state.dash.sector,'sector'],['الإدارة',state.dash.unit,'unit'],['الجهة المعنية',state.dash.entity,'entity']],full=fields.filter(function(x){return U.hasSelection(x[1]);}).map(function(x){return x[0]+': '+U.selectionText(x[1],undefined,x[2]);}).join('   |   ');if(fields.some(function(x){return S.filterOptions.count(x[1],null,x[2])>1;})&&(full.length>140||lines(full,1016,11).length>1))return fields.filter(function(x){return U.hasSelection(x[1]);}).map(function(x){return x[0]+': '+S.filterOptions.count(x[1],null,x[2])+' محدد';}).join('   |   ');return full;}
 function remove(doc,ids){all(doc,P,'sp').concat(all(doc,P,'grpSp'),all(doc,P,'graphicFrame'),all(doc,P,'pic')).forEach(function(s){var n=first(s,P,'cNvPr');if(n&&ids.includes(Number(n.getAttribute('id'))))s.remove();});}
 function strip(doc,keep){var tree=first(doc,P,'spTree');Array.from(tree.children).forEach(function(s){if(['sp','grpSp','graphicFrame','pic','cxnSp'].includes(s.localName)){var n=first(s,P,'cNvPr');if(!n||!keep.includes(Number(n.getAttribute('id'))))s.remove();}});return doc;}
 function cleanRels(source){var rel=xml(source);Array.from(rel.documentElement.children).filter(function(n){return !n.getAttribute('Type').endsWith('/slideLayout')&&!n.getAttribute('Type').endsWith('/image');}).forEach(function(n){n.remove();});return rel;}
 function clearLinks(doc){all(doc,A,'hlinkClick').concat(all(doc,A,'hlinkMouseOver')).forEach(function(n){n.remove();});}
 function box(s){var xf=first(s,A,'xfrm')||first(s,P,'xfrm'),off=first(xf,A,'off'),ext=first(xf,A,'ext');return [Number(off.getAttribute('x'))/9525,Number(off.getAttribute('y'))/9525,Number(ext.getAttribute('cx'))/9525,Number(ext.getAttribute('cy'))/9525];}
 // Conservative line measurement in the same bundled Dubai face used by the app.
 // Each chunk is exported; a long field never gets a substring/ellipsis cap.
 var canvas;
 function lines(text,width,size){
  canvas=canvas||document.createElement('canvas');var ctx=canvas.getContext('2d');ctx.font=(size*4/3)+'px "TEC Dubai"';var out=[];
  clean(text).replace(/\r\n?/g,'\n').split('\n').forEach(function(p){var line='';p.split(/\s+/).forEach(function(word){if(!word)return;var test=line?line+' '+word:word;if(line&&ctx.measureText(test).width>width){out.push(line);line='';}if(ctx.measureText(word).width>width){for(var c of word){if(line&&ctx.measureText(line+c).width>width){out.push(line);line='';}line+=c;}}else line=line?line+' '+word:word;});out.push(line);});return out;
 }
 function chunks(text,w,h,size){var ls=lines(value(text),w-20,size),n=Math.max(1,Math.floor((h-16)/(size*4/3*1.18))),out=[];for(var i=0;i<ls.length;i+=n)out.push(ls.slice(i,i+n).join('\n'));return out;}
 function set(doc,id,text,size,align){return textShape(doc,id,text,{size:size||11,font:'Dubai',color:BODY,align:align||'r',anchor:'ctr'});}
 function label(doc,id,text,size,color,align){var sp=textShape(doc,id,text,{size:size||12,font:'Dubai',color:color||INK,align:align||'ctr',anchor:'ctr'});all(sp,A,'rPr').concat(all(sp,A,'defRPr')).forEach(function(pr){pr.setAttribute('b','1');});return sp;}
 function fitted(doc,id,text,size){var s=shape(doc,id),b=box(s);return {id:id,text:value(text),parts:chunks(text,b[2],b[3],size||11),size:size||11};}
 // Keep source newlines as list boundaries. Soft wrapping never makes extra bullets.
 function fittedBullet(doc,id,text,size){
  text=value(text);var f=fitted(doc,id,text,size);
  var b=box(shape(doc,id)),capacity=Math.max(1,Math.floor((b[3]-16)/(f.size*4/3*1.18))),pages=[],current=[],used=0;
  clean(text).replace(/\r\n?/g,'\n').split('\n').filter(function(p){return p.replace(/[\u200B\uFEFF]/g,'').trim();}).forEach(function(p){
   var wrapped=lines(p,b[2]-32,f.size),at=0;
   while(at<wrapped.length){if(used===capacity){pages.push(current);current=[];used=0;}var take=Math.min(capacity-used,wrapped.length-at);current.push({text:wrapped.slice(at,at+take).join(' '),bullet:at===0});at+=take;used+=take;}
  });if(current.length)pages.push(current);f.bulletPages=pages;f.parts=pages.map(function(p){return p.map(function(x){return x.text;}).join('\n');});return f;
 }
 function put(doc,f,page){
  var t=f.parts[page];if(t==null)t=f.repeat&&f.parts.length===1?f.parts[0]:page?'ورد في الصفحة الأولى':MISSING;var sp=set(doc,f.id,t,f.size);
  if(f.bulletPages&&f.bulletPages[page]){
   var tb=first(sp,P,'txBody');all(tb,A,'p').forEach(function(p){p.remove();});
   f.bulletPages[page].forEach(function(item){var p=paragraphs(doc,item.text,f.size,'Dubai',BODY,'r')[0],pr=first(p,A,'pPr');
    pr.setAttribute('marL','285750');pr.setAttribute('marR','0');if(item.bullet){pr.setAttribute('indent','-190500');all(pr,A,'buNone').forEach(function(n){n.remove();});pr.insertBefore(node(doc,A,'a:buFont',{typeface:'Dubai'}),child(pr,A,'defRPr'));pr.insertBefore(node(doc,A,'a:buChar',{char:'•'}),child(pr,A,'defRPr'));}tb.appendChild(p);
   });
  }
  // Project values read from the top-right with consistent cell breathing room.
  var bp=first(first(sp,P,'txBody'),A,'bodyPr');bp.setAttribute('anchor','t');
  ['lIns','rIns'].forEach(function(k){bp.setAttribute(k,'76200');});
  ['tIns','bIns'].forEach(function(k){bp.setAttribute(k,'57150');});
  if(f.bold)all(sp,A,'rPr').concat(all(sp,A,'defRPr')).forEach(function(pr){pr.setAttribute('b','1');});
 }
 function link(entry,sp,slideNumber,key){var rId='rIdHH_'+key;all(sp,A,'rPr').forEach(function(rp){var n=node(entry.doc,A,'a:hlinkClick',{action:'ppaction://hlinksldjump'});n.setAttributeNS(R,'r:id',rId);var extList=node(entry.doc,A,'a:extLst'),ext=node(entry.doc,A,'a:ext',{uri:'{A12FA001-AC4F-418D-AE19-62706E023703}'}),clr=node(entry.doc,'http://schemas.microsoft.com/office/drawing/2018/hyperlinkcolor','ahyp:hlinkClr',{'xmlns:ahyp':'http://schemas.microsoft.com/office/drawing/2018/hyperlinkcolor',val:'tx'});ext.appendChild(clr);extList.appendChild(ext);n.appendChild(extList);rp.insertBefore(n,child(rp,A,'rtl')||null);});entry.rels.documentElement.appendChild(node(entry.rels,PK,'Relationship',{Id:rId,Type:R+'/slide',Target:'slide'+slideNumber+'.xml'}));}
 function footer(entry,index,home,master){
  addText(entry.doc,String(index+1),[27,686,40,20],8,'Dubai',INK,'l');
  if(home){
   var s=addText(entry.doc,'العودة لقائمة المحتويات',[82,686,292,20],9,'Dubai',INK,'l');link(entry,s,2,'contents');
   all(s,A,'hlinkClick').forEach(function(n){n.remove();});var jump=node(entry.doc,A,'a:hlinkClick',{action:'ppaction://hlinksldjump'});jump.setAttributeNS(R,'r:id','rIdHH_contents');first(s,P,'cNvPr').appendChild(jump);
   if(master){var ms=addText(entry.doc,'العودة للقائمة الرئيسية للمشاريع',[597,686,297,20],9,'Dubai',ACCENT,'r');link(entry,ms,master,'master');all(ms,A,'hlinkClick').forEach(function(n){n.remove();});var mj=node(entry.doc,A,'a:hlinkClick',{action:'ppaction://hlinksldjump'});mj.setAttributeNS(R,'r:id','rIdHH_master');first(ms,P,'cNvPr').appendChild(mj);}
  }
 }
 function contents(source,active,state,m){var doc=xml(source);clearLinks(doc);remove(doc,[3]);
  // Keep a readable cue below the title rather than the cramped template callout.
  var cue=textShape(doc,4,'انقر على عنوان القسم للانتقال إليه',{size:13,font:'Dubai',color:BODY,box:[94,237,1049,28],align:'r',anchor:'ctr'}),cuePr=first(cue,P,'spPr');
  Array.from(cuePr.children).filter(function(n){return n.localName!=='xfrm';}).forEach(function(n){n.remove();});cuePr.appendChild(node(doc,A,'a:noFill'));var cueLine=node(doc,A,'a:ln');cueLine.appendChild(node(doc,A,'a:noFill'));cuePr.appendChild(cueLine);
  var table=first(doc,A,'tbl'),existing=all(table,A,'tr');
  while(existing.length<4){var copy=existing[existing.length-1].cloneNode(true);all(copy,A,'extLst').forEach(function(n){n.remove();});table.appendChild(copy);existing.push(copy);}
  existing.forEach(function(row){row.setAttribute('h',Math.round(77*9525));all(row,A,'tcPr').forEach(function(pr){pr.setAttribute('marT','47625');pr.setAttribute('marB','47625');});});
  var tableFrame=first(doc,P,'graphicFrame');position(tableFrame,94,278,1049,308);
  var rows=all(doc,A,'tr'),labels=['ملخص تقرير المشاريع الاستراتيجية الخاصة','القائمة الرئيسية للمشاريع','ملحق – المستجدات التفصيلية للمشاريع قيد المتابعة','ملحق – المستجدات التفصيلية للمشاريع المنجزة'];
  rows.forEach(function(row,i){all(row,A,'tc').forEach(function(tc,j){var tb=first(tc,A,'txBody');all(tb,A,'p').forEach(function(n){n.remove();});paragraphs(doc,j?'0'+(i+1):labels[i],j?26:18,'Dubai',active===i?ACCENT:BODY,j?'ctr':'r').forEach(function(p){all(p,A,'rPr').concat(all(p,A,'defRPr')).forEach(function(pr){pr.setAttribute('b','1');});tb.appendChild(p);});['lnL','lnR','lnT','lnB'].forEach(function(edge){var rule=first(first(tc,A,'tcPr'),A,edge),fill=rule&&first(rule,A,'solidFill');if(fill){while(fill.firstChild)fill.firstChild.remove();fill.appendChild(node(doc,A,'a:srgbClr',{val:RULE}));}});});});
  addText(doc,S.reportDisplay.get(state).period+'    •    عدد المشاريع: '+m.items.length,[110,632,1030,32],S.reportDisplay.get(state).period.length>60?10:14,'Dubai',INK,'r');if(scope(state))addText(doc,scope(state),[110,672,1030,25],11,'Dubai',BODY,'r');return doc;
 }
 function addPanel(doc,text,b,fill){var sp=addText(doc,text,b,15,'Dubai',INK,'ctr'),pr=first(sp,P,'spPr');all(pr,A,'noFill').forEach(function(n){n.remove();});var geo=node(doc,A,'a:prstGeom',{prst:'rect'});geo.appendChild(node(doc,A,'a:avLst'));pr.appendChild(geo);var solid=node(doc,A,'a:solidFill');solid.appendChild(node(doc,A,'a:srgbClr',{val:fill||'EFEBE7'}));pr.appendChild(solid);return sp;}
 async function workbook(categories,series){
  var totalSeries=series.find(function(s){return s.totals;}),rows=[['القطاع'].concat(series.map(function(s){return s.name;})).concat(totalSeries?['إجمالي القطاع']:[])].concat(categories.map(function(c,i){var row=[c].concat(series.map(function(s){return s.values[i];}));if(totalSeries)row.push({formula:'SUM(B'+(i+2)+':'+String.fromCharCode(64+series.length)+(i+2)+')',value:totalSeries.totals[i]});return row;}));
  var sheet='<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+rows.map(function(row,r){return '<row r="'+(r+1)+'">'+row.map(function(v,c){var ref=String.fromCharCode(65+c)+(r+1);return v&&typeof v==='object'?'<c r="'+ref+'"><f>'+esc(v.formula)+'</f><v>'+v.value+'</v></c>':typeof v==='number'?'<c r="'+ref+'"><v>'+v+'</v></c>':'<c r="'+ref+'" t="inlineStr"><is><t>'+esc(v)+'</t></is></c>';}).join('')+'</row>';}).join('')+'</sheetData></worksheet>';
  var parts=new Map([
   ['[Content_Types].xml','<Types xmlns="'+CT+'"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>'],
   ['_rels/.rels','<Relationships xmlns="'+PK+'"><Relationship Id="rId1" Type="'+R+'/officeDocument" Target="xl/workbook.xml"/></Relationships>'],
   ['xl/workbook.xml','<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="'+R+'"><sheets><sheet name="Data" sheetId="1" r:id="rId1"/></sheets><calcPr calcId="0" fullCalcOnLoad="1"/></workbook>'],
   ['xl/_rels/workbook.xml.rels','<Relationships xmlns="'+PK+'"><Relationship Id="rId1" Type="'+R+'/worksheet" Target="worksheets/sheet1.xml"/></Relationships>'],['xl/worksheets/sheet1.xml',sheet]]);
  return new Uint8Array(await zip(parts).arrayBuffer());
 }
 var HH_COLORS={'متأخر':'651D32','جاهز للعرض':'00ACA0','قيد المراجعة':'ABA394','قيد التطوير':'756B5F','قيد العمل':'756B5F','جاري العمل':'756B5F','لم يبدأ':'ABA394','معلق':'808080','ملغى':'651D32','منجز':'115E67','حالات أخرى':'808080'};
 async function nativeChart(parts,entry,index,categories,series,b,source,horizontal,maximum){
  if(!categories.length||!series.length)return false;
  var totals=categories.map(function(_,i){return series.reduce(function(n,s){return n+s.values[i];},0);});series=series.concat([{name:'موضع إجمالي القطاع',color:PAPER,values:categories.map(function(){return 0;}),totals:totals}]);
  var chart=xml(source),bar=first(chart,C,'barChart'),prototype=first(bar,C,'ser').cloneNode(true);
  all(bar,C,'ser').forEach(function(n){n.remove();});all(chart,C,'title').forEach(function(n){n.remove();});
  // The optional template extension only changes NaN display. Every exported count is finite.
  var chartBody=first(chart,C,'chart'),chartExt=child(chartBody,C,'extLst');if(chartExt){Array.from(chartExt.children).filter(function(e){return e.getAttribute('uri')==='{56B9EC1D-385E-4148-901F-78D8002777C0}';}).forEach(function(e){e.remove();});if(!chartExt.children.length)chartExt.remove();}
  first(chart,C,'autoTitleDeleted').setAttribute('val','1');first(bar,C,'barDir').setAttribute('val',horizontal?'bar':'col');
  // A single native stacked plot uses the same count scale on every summary page.
  first(bar,C,'grouping').setAttribute('val','stacked');first(bar,C,'gapWidth').setAttribute('val','80');
  all(bar,C,'overlap').forEach(function(n){n.remove();});bar.insertBefore(node(chart,C,'c:overlap',{val:100}),child(bar,C,'axId'));
  all(chart,C,'legend').forEach(function(n){n.remove();}); // One shared, editable RTL legend sits below the chart.
  var plot=first(chart,C,'plotArea'),layout=first(plot,C,'layout');while(layout.firstChild)layout.firstChild.remove();
  var manual=node(chart,C,'c:manualLayout');manual.appendChild(node(chart,C,'c:layoutTarget',{val:'inner'}));
  ['xMode','yMode','wMode','hMode'].forEach(function(n){manual.appendChild(node(chart,C,'c:'+n,{val:'factor'}));});
  [['x',0.015],['y',0.025],['w',0.65],['h',0.75]].forEach(function(v){manual.appendChild(node(chart,C,'c:'+v[0],{val:v[1]}));});layout.appendChild(manual);
  var chartBorder=Array.from(chart.documentElement.children).find(function(n){return n.localName==='spPr';});
  if(chartBorder){all(chartBorder,A,'ln').forEach(function(n){n.remove();});var border=node(chart,A,'a:ln');border.appendChild(node(chart,A,'a:noFill'));chartBorder.insertBefore(border,child(chartBorder,A,'effectLst')||child(chartBorder,A,'effectDag')||child(chartBorder,A,'scene3d')||child(chartBorder,A,'sp3d')||child(chartBorder,A,'extLst'));}
  function ref(holder,type,formula,vals){while(holder.firstChild)holder.firstChild.remove();var r=node(chart,C,'c:'+type+'Ref'),f=node(chart,C,'c:f');f.textContent=formula;r.appendChild(f);var cache=node(chart,C,'c:'+type+'Cache');if(type==='num'){var format=node(chart,C,'c:formatCode');format.textContent='0';cache.appendChild(format);}cache.appendChild(node(chart,C,'c:ptCount',{val:vals.length}));vals.forEach(function(v,i){var pt=node(chart,C,'c:pt',{idx:i}),val=node(chart,C,'c:v');val.textContent=String(v);pt.appendChild(val);cache.appendChild(pt);});r.appendChild(cache);holder.appendChild(r);}
  series.forEach(function(sr,i){var ser=prototype.cloneNode(true),col=String.fromCharCode(66+i);first(ser,C,'idx').setAttribute('val',i);first(ser,C,'order').setAttribute('val',i);all(ser,C,'extLst').concat(all(ser,C,'dPt')).forEach(function(n){n.remove();});ref(first(ser,C,'tx'),'str','Data!$'+col+'$1',[sr.name]);ref(first(ser,C,'cat'),'str','Data!$A$2:$A$'+(categories.length+1),categories);ref(first(ser,C,'val'),'num','Data!$'+col+'$2:$'+col+'$'+(categories.length+1),sr.values);var fill=first(first(ser,C,'spPr'),A,'srgbClr');if(fill)fill.setAttribute('val',sr.color||HH_COLORS[sr.name]||'756B5F');bar.insertBefore(ser,child(bar,C,'dLbls'));});
  all(chart,A,'defRPr').concat(all(chart,A,'rPr')).forEach(function(pr){pr.setAttribute('sz',horizontal?'1100':'1200');pr.setAttribute('lang','ar-AE');all(pr,A,'solidFill').forEach(function(n){n.remove();});var textFill=node(chart,A,'a:solidFill');textFill.appendChild(node(chart,A,'a:srgbClr',{val:BODY}));pr.insertBefore(textFill,pr.firstChild);['latin','ea','cs'].forEach(function(tag){var f=first(pr,A,tag);if(f)f.setAttribute('typeface','Dubai');else pr.appendChild(node(chart,A,'a:'+tag,{typeface:'Dubai'}));});});
  all(chart,A,'pPr').forEach(function(pr){pr.setAttribute('rtl','1');});
  all(chart,C,'dLbls').forEach(function(dl){
   all(dl,C,'extLst').forEach(function(n){n.remove();});first(dl,C,'dLblPos').setAttribute('val','ctr');
   var fmt=first(dl,C,'numFmt');if(!fmt){fmt=node(chart,C,'c:numFmt');dl.insertBefore(fmt,dl.firstChild);}fmt.setAttribute('formatCode','0;-0;;');fmt.setAttribute('sourceLinked','0');
   all(dl,A,'pPr').forEach(function(pr){pr.setAttribute('rtl','0');});
  });
  all(bar,C,'ser').forEach(function(ser,i){all(first(ser,C,'dLbls'),A,'srgbClr').forEach(function(n){n.setAttribute('val',['قيد المراجعة','لم يبدأ','جاهز للعرض'].includes(series[i].name)?BODY:PAPER);});});
  all(chart,C,'catAx').forEach(function(ax){first(ax,C,'axPos').setAttribute('val',horizontal?'r':'b');first(ax,C,'orientation').setAttribute('val',horizontal?'maxMin':'minMax');first(ax,C,'crosses').setAttribute('val','autoZero');all(ax,A,'bodyPr').forEach(function(bp){bp.setAttribute('rot','0');});});
  all(chart,C,'valAx').forEach(function(ax){
   first(ax,C,'axPos').setAttribute('val',horizontal?'b':'l');first(ax,C,'orientation').setAttribute('val',horizontal?'maxMin':'minMax');first(ax,C,'delete').setAttribute('val','0');first(ax,C,'crosses').setAttribute('val','max');first(ax,C,'tickLblPos').setAttribute('val','nextTo');first(ax,C,'majorTickMark').setAttribute('val','none');first(ax,C,'minorTickMark').setAttribute('val','none');
   var scaling=first(ax,C,'scaling');all(scaling,C,'min').concat(all(scaling,C,'max')).forEach(function(n){n.remove();});scaling.appendChild(node(chart,C,'c:max',{val:maximum||1}));scaling.appendChild(node(chart,C,'c:min',{val:0}));
   var unit=Math.max(1,Math.ceil((maximum||1)/4));all(ax,C,'majorUnit').forEach(function(n){n.remove();});ax.appendChild(node(chart,C,'c:majorUnit',{val:unit}));
   var grid=node(chart,C,'c:majorGridlines'),sp=node(chart,C,'c:spPr'),ln=node(chart,A,'a:ln',{w:6350}),fill=node(chart,A,'a:solidFill');fill.appendChild(node(chart,A,'a:srgbClr',{val:'E4DFD8'}));ln.appendChild(fill);sp.appendChild(ln);grid.appendChild(sp);ax.insertBefore(grid,child(ax,C,'numFmt'));
   var axisTitle=node(chart,C,'c:title'),titleTx=node(chart,C,'c:tx'),titleRich=node(chart,C,'c:rich');titleRich.appendChild(node(chart,A,'a:bodyPr',{rot:0}));titleRich.appendChild(node(chart,A,'a:lstStyle'));titleRich.appendChild(paragraphs(chart,'عدد المشاريع',10,'Dubai',INK,'ctr')[0]);titleTx.appendChild(titleRich);axisTitle.appendChild(titleTx);var axisLayout=node(chart,C,'c:layout'),axisManual=node(chart,C,'c:manualLayout');['xMode','yMode'].forEach(function(k){axisManual.appendChild(node(chart,C,'c:'+k,{val:'factor'}));});axisManual.appendChild(node(chart,C,'c:x',{val:0.23}));axisManual.appendChild(node(chart,C,'c:y',{val:0.95}));axisLayout.appendChild(axisManual);axisTitle.appendChild(axisLayout);axisTitle.appendChild(node(chart,C,'c:overlay',{val:0}));ax.insertBefore(axisTitle,child(ax,C,'numFmt'));
   var tx=first(first(chart,C,'catAx'),C,'txPr').cloneNode(true);all(tx,A,'pPr').forEach(function(pr){pr.setAttribute('rtl','0');});ax.insertBefore(tx,child(ax,C,'crossAx'));
  });
  var totalLabels=first(all(bar,C,'ser')[series.length-1],C,'dLbls');
  all(totalLabels,A,'srgbClr').forEach(function(n){n.setAttribute('val',BODY);});all(totalLabels,A,'defRPr').concat(all(totalLabels,A,'rPr')).forEach(function(n){n.setAttribute('b','0');n.setAttribute('sz','1100');});
  // Office forbids outside-end labels inside stacked-bar series (MS-OI29500 2.1.1456).
  // Keep the custom editable totals and their manual offsets with a supported center anchor.
  first(totalLabels,C,'dLblPos').setAttribute('val','ctr');first(totalLabels,C,'showVal').setAttribute('val','0');
  totals.forEach(function(total,i){var dl=node(chart,C,'c:dLbl');dl.appendChild(node(chart,C,'c:idx',{val:i}));var layout=node(chart,C,'c:layout'),manual=node(chart,C,'c:manualLayout');manual.appendChild(node(chart,C,'c:xMode',{val:'factor'}));manual.appendChild(node(chart,C,'c:yMode',{val:'factor'}));manual.appendChild(node(chart,C,'c:x',{val:-0.04}));manual.appendChild(node(chart,C,'c:y',{val:0}));layout.appendChild(manual);dl.appendChild(layout);var tx=node(chart,C,'c:tx'),rich=node(chart,C,'c:rich');rich.appendChild(node(chart,A,'a:bodyPr'));rich.appendChild(node(chart,A,'a:lstStyle'));var p=paragraphs(chart,'(المجموع '+U.metricText(total)+')',11,'Dubai',BODY,'ctr')[0];first(p,A,'pPr').setAttribute('rtl','1');rich.appendChild(p);tx.appendChild(rich);dl.appendChild(tx);dl.appendChild(node(chart,C,'c:dLblPos',{val:'ctr'}));['showLegendKey','showVal','showCatName','showSerName','showPercent','showBubbleSize'].forEach(function(n){dl.appendChild(node(chart,C,'c:'+n,{val:0}));});totalLabels.insertBefore(dl,totalLabels.firstChild);});
  first(chart,C,'showDLblsOverMax').setAttribute('val','1');
  all(chart,C,'externalData').forEach(function(n){n.remove();});var ed=node(chart,C,'c:externalData');ed.setAttributeNS(R,'r:id','rIdData');ed.appendChild(node(chart,C,'c:autoUpdate',{val:0}));chart.documentElement.appendChild(ed);
  parts.set('ppt/charts/chart'+index+'.xml',serial(chart));parts.set('ppt/charts/_rels/chart'+index+'.xml.rels','<Relationships xmlns="'+PK+'"><Relationship Id="rIdData" Type="'+R+'/package" Target="../embeddings/hh-chart'+index+'.xlsx"/></Relationships>');parts.set('ppt/embeddings/hh-chart'+index+'.xlsx',await workbook(categories,series));
  var id='rIdChart'+index;entry.rels.documentElement.appendChild(node(entry.rels,PK,'Relationship',{Id:id,Type:R+'/chart',Target:'../charts/chart'+index+'.xml'}));
  var doc=entry.doc,tree=first(doc,P,'spTree'),frame=node(doc,P,'p:graphicFrame'),nv=node(doc,P,'p:nvGraphicFramePr');nv.appendChild(node(doc,P,'p:cNvPr',{id:Math.max(100,...all(doc,P,'cNvPr').map(function(n){return Number(n.getAttribute('id'));}))+1,name:'HH editable chart '+index}));nv.appendChild(node(doc,P,'p:cNvGraphicFramePr'));nv.appendChild(node(doc,P,'p:nvPr'));frame.appendChild(nv);var xf=node(doc,P,'p:xfrm');xf.appendChild(node(doc,A,'a:off',{x:Math.round(b[0]*9525),y:Math.round(b[1]*9525)}));xf.appendChild(node(doc,A,'a:ext',{cx:Math.round(b[2]*9525),cy:Math.round(b[3]*9525)}));frame.appendChild(xf);var graphic=node(doc,A,'a:graphic'),gd=node(doc,A,'a:graphicData',{uri:C}),c=node(doc,C,'c:chart',{'xmlns:c':C});c.setAttributeNS(R,'r:id',id);gd.appendChild(c);graphic.appendChild(gd);frame.appendChild(graphic);tree.appendChild(frame);return true;
 }
 // These cards and the shared legend are native editable shapes and text.
 function summaryCard(doc,title,value,b,color){
  var card=addPanel(doc,'',b,PAPER),pr=first(card,P,'spPr'),ln=node(doc,A,'a:ln',{w:6350}),fill=node(doc,A,'a:solidFill');fill.appendChild(node(doc,A,'a:srgbClr',{val:'E7E0D3'}));ln.appendChild(fill);pr.appendChild(ln);
  addPanel(doc,'',[b[0]+b[2]-5,b[1]+14,3,b[3]-28],color);
  addText(doc,title,[b[0]+16,b[1]+10,b[2]-32,28],13,'Dubai',BODY,'r');
  var valueShape=addText(doc,U.metricText(value),[b[0]+16,b[1]+40,b[2]-32,40],28,'Dubai','333333','r');all(valueShape,A,'rPr').forEach(function(pr){pr.setAttribute('b','1');});
 }
 function summaryLegendLayout(names){var right=1208,row=0;return names.map(function(name){var width=Math.max(118,Math.min(340,lines(name,1000,11)[0].length*7+42));if(right-width<52){right=1208;row++;}var out={name:name,right:right,row:row,width:width};right-=width+18;return out;});}
 function summaryLegend(doc,items,y){items.forEach(function(item){addPanel(doc,'',[item.right-10,y+item.row*25+7,9,9],HH_COLORS[item.name]||'756B5F');addText(doc,item.name,[item.right-item.width,y+item.row*25,item.width-20,23],11,'Dubai',BODY,'r');});}

 async function summary(source,state,m,add,parts,chartSource){
  var model=S.views.reports.hhSummary(state,m),pages=Math.max(1,Math.ceil(model.sectors.length/6)),chartCount=0;
  var maximum=Math.max(1,...model.sectors.map(function(g){return g.values.reduce(function(a,b){return a+b;},0);}));
  function percent(n,t){return t?U.displayNumber(n/t*100,1,'%'):MISSING;}
  for(var page=0;page<pages;page++){
   var d=strip(xml(source),[14]);clearLinks(d);label(d,14,'ملخص تقرير المشاريع الاستراتيجية الخاصة'+(pages>1?' ('+(page+1)+' / '+pages+')':''),24,INK,'r');
   addText(d,S.reportDisplay.get(state).period+(scope(state)?'   '+scope(state):''),[52,88,1156,30],S.reportDisplay.get(state).period.length>60?10:12,'Dubai',BODY,'r');
   var active=model.leadOnly?model.leadInProgress:model.inProgress,other=model.leadOnly?model.leadOtherOpen:model.otherOpen;
   var cards=[['إجمالي المشاريع الخاصة',model.total,INK]];if(!model.leadOnly&&model.lead>0)cards.push(['منها مشاريع للقيادة',model.lead,'ABA394']);cards.push(['المشاريع المنجزة',model.done,ACCENT],['المشاريع قيد العمل',active,INK]);if(other>0)cards.push(['حالات أخرى غير منجزة',other,'808080']);
   var cardWidth=(1156-(cards.length-1)*16)/cards.length;cards.forEach(function(c,i){summaryCard(d,c[0],c[1],[1208-cardWidth-(cardWidth+16)*i,132,cardWidth,92],c[2]);});
   var completions=[[model.leadOnly?'نسبة المشاريع المنجزة للقيادة':'نسبة المشاريع المنجزة',model.done,model.total]];if(!model.leadOnly&&model.lead>0)completions.push(['نسبة المشاريع المنجزة للقيادة',model.leadDone,model.lead]);
   completions.forEach(function(c,i){var gap=18,width=(1156-gap*(completions.length-1))/completions.length,x=1208-width-(width+gap)*i,right=x+width-20,textWidth=Math.min(310,width-140);
    named(cardPanel(d,[x,242,width,78],'EFEBE7',null,true),'Summary completion card '+i);
    addText(d,c[0],[right-textWidth,252,textWidth,27],13,'Dubai',BODY,'r');
    addText(d,'عدد المشاريع: '+U.metricText(c[1])+' من أصل '+U.metricText(c[2]),[right-textWidth,286,textWidth,25],11,'Dubai',INK,'r');
    var pct=addText(d,percent(c[1],c[2]),[right-textWidth-120,258,104,42],24,'Dubai',ACCENT,'ctr');
    first(first(pct,P,'txBody'),A,'bodyPr').setAttribute('anchor','ctr');all(pct,A,'rPr').forEach(function(pr){pr.setAttribute('b','1');});
   });
   addText(d,'توزيع المشاريع حسب القطاع',[620,335,588,32],18,'Dubai','333333','r');
   if(!model.leadOnly&&model.leadOtherOpen>0)addText(d,'من الحالات الأخرى غير المنجزة للقيادة: '+model.leadOtherOpen,[52,340,550,24],10,'Dubai',BODY,'r');
   var entry=add(d,'summary'),groups=model.sectors.slice(page*6,(page+1)*6),legend=summaryLegendLayout(model.names),legendY=660-(legend.length?legend[legend.length-1].row:0)*25;
   if(groups.length){
    await nativeChart(parts,entry,++chartCount,groups.map(function(g){return g.name;}),model.names.map(function(n,j){return {name:n,values:groups.map(function(g){return g.values[j];})};}),[108,377,1100,Math.max(130,legendY-390)],chartSource,true,maximum);
    summaryLegend(d,legend,legendY);
   }else addText(d,'لا توجد مشاريع ضمن النطاق المحدد',[92,439,1076,60],18,'Dubai',INK,'ctr');
  }return chartCount;
 }
 function fittedTitle(doc,id,title,max,min){var b=box(shape(doc,id)),size=max;while(size>min&&chunks(title,b[2],b[3],size).length>1)size--;return fitted(doc,id,title,size);}
 // Status text uses its recorded category independently of the numeric percentage.
 function statusHeader(doc,id,it){
  var statusColor=HH_COLORS[status(it)]||INK,textColor=({'ABA394':'6E675B','756B5F':'706659','00ACA0':'00766D','808080':'666666'})[statusColor]||statusColor;
  var sp=label(doc,id,'الحالة: ',12,BODY);first(sp,P,'cNvPr').setAttribute('name','Recorded status header');
  var p=first(first(sp,P,'txBody'),A,'p'),statusParagraph=paragraphs(doc,status(it),12,'Dubai',textColor,'ctr')[0];
  all(statusParagraph,A,'r').forEach(function(run){first(run,A,'rPr').setAttribute('b','1');p.insertBefore(run,child(p,A,'endParaRPr'));});return sp;
 }
 // Native ellipse and arc geometry keep the circular indicator editable.
 // Arc sweep is calculated from the recorded percentage, never rounded to quarters.
 function addProgressRing(doc,b,percent,color){
  var d=72,x=b[0]+(b[2]-d)/2,y=b[1]+(b[3]-d)/2,thickness=Math.max(4,d*0.095);
  function ring(stroke,partial){
   var sp=addText(doc,'',[x,y,d,d],1,'Dubai',stroke,'ctr'),pr=first(sp,P,'spPr');
   first(sp,P,'cNvPr').setAttribute('name',partial?'Progress ring value '+percent:'Progress ring background');
   var geom;
   if(partial&&percent<100){
    geom=node(doc,A,'a:custGeom');geom.appendChild(node(doc,A,'a:avLst'));var paths=node(doc,A,'a:pathLst'),path=node(doc,A,'a:path',{w:100000,h:100000,fill:'none',stroke:1,extrusionOk:0}),move=node(doc,A,'a:moveTo');move.appendChild(node(doc,A,'a:pt',{x:50000,y:0}));path.appendChild(move);path.appendChild(node(doc,A,'a:arcTo',{wR:50000,hR:50000,stAng:16200000,swAng:Math.round(percent*216000)}));paths.appendChild(path);geom.appendChild(paths);
   }else{geom=node(doc,A,'a:prstGeom',{prst:'ellipse'});geom.appendChild(node(doc,A,'a:avLst'));}
   pr.insertBefore(geom,child(pr,A,'noFill'));var ln=node(doc,A,'a:ln',{w:Math.round(thickness*9525),cap:'flat'}),fill=node(doc,A,'a:solidFill');fill.appendChild(node(doc,A,'a:srgbClr',{val:stroke}));ln.appendChild(fill);pr.appendChild(ln);return sp;
  }
  ring('EFEBE7',false);if(percent>0)ring(color||INK,true);return {x:x,y:y,d:d};
 }
 function addStatusProgress(doc,it,b){
  var h=S.views.reports.harvey(it),r=h.valid?addProgressRing(doc,b,it.progress,HH_COLORS[status(it)]||INK):null;
  var label=addText(doc,h.label,r?[r.x-8,r.y+(r.d-30)/2,r.d+16,30]:[b[0]+8,b[1]+(b[3]-32)/2,b[2]-16,32],h.valid?16:12,'Dubai',BODY,'ctr');first(label,P,'cNvPr').setAttribute('name','Recorded progress percentage');var bp=first(first(label,P,'txBody'),A,'bodyPr');bp.setAttribute('wrap','none');bp.setAttribute('anchor','ctr');
 }
 // Unified Option 1: one source project per editable slide, irrespective of status.
 // Fit the complete field set before drawing; optional empty fields have no section.
 function populated(v){return clean(v).replace(/[\u200B\uFEFF]/g,'').trim()!=='';}
 function named(sp,name){first(sp,P,'cNvPr').setAttribute('name',name);return sp;}
 function bold(sp){all(sp,A,'rPr').concat(all(sp,A,'defRPr')).forEach(function(pr){pr.setAttribute('b','1');});return sp;}
 function cardPanel(doc,b,fill,border,radius){
  var sp=addPanel(doc,'',b,fill),pr=first(sp,P,'spPr');named(sp,'Special card panel');
  if(radius){first(pr,A,'prstGeom').setAttribute('prst','roundRect');var av=first(pr,A,'avLst');av.appendChild(node(doc,A,'a:gd',{name:'adj',fmla:'val 5500'}));}
  if(border){var ln=node(doc,A,'a:ln',{w:6350}),solid=node(doc,A,'a:solidFill');solid.appendChild(node(doc,A,'a:srgbClr',{val:border}));ln.appendChild(solid);pr.appendChild(ln);}return sp;
 }
 function cardText(doc,text,b,size,color,name,isBold){text=clean(text).replace(/\r\n?/g,'\n');var sp=addText(doc,text,b,size,/Special (detail heading|field title)/.test(name)?'DIN Next LT Arabic':'Dubai',color||BODY,'r');named(sp,name);if(isBold)bold(sp);return sp;}
 function cardTextHeight(text,width,size,bullet){
  var n=0;clean(text).replace(/\r\n?/g,'\n').split('\n').forEach(function(p){if(populated(p))n+=lines(p,width-(bullet?19:4),size).length;});
  return Math.max(1,n)*size*4/3*1.24+8;
 }
 function cardBody(doc,text,b,size,color,name,bullet){
  var sp=cardText(doc,text,b,size,color,name,false),tb=first(sp,P,'txBody');
  if(bullet){all(tb,A,'p').forEach(function(p){p.remove();});clean(text).replace(/\r\n?/g,'\n').split('\n').filter(populated).forEach(function(line){var p=paragraphs(doc,line,size,'Dubai',color||BODY,'r')[0],pr=first(p,A,'pPr');pr.setAttribute('marL','0');pr.setAttribute('marR','142875');pr.setAttribute('indent','-104775');all(pr,A,'buNone').forEach(function(n){n.remove();});pr.insertBefore(node(doc,A,'a:buFont',{typeface:'Dubai'}),child(pr,A,'defRPr'));pr.insertBefore(node(doc,A,'a:buChar',{char:'•'}),child(pr,A,'defRPr'));tb.appendChild(p);});}
  return sp;
 }
 function unifiedCards(source,it,index,add){
  var d=strip(xml(source),[]);clearLinks(d);var t=it.t||{},done=status(it)==='منجز',W=1132,G=18,CW=(W-G)/2,left=64,right=64+CW+G,bottom=654;
  var narrative=[{field:'achieved',title:'ما تم إنجازه',value:t.achieved,color:ACCENT,fill:'F2F6F6'},{field:'next',title:done?'المتابعة بعد الإنجاز':'المخطط في المرحلة المقبلة',value:t.next,color:INK,fill:PAPER}].filter(function(f){return populated(f.value);});
  var context=[{field:'notes',title:'ملاحظات مدير المشروع',value:t.notes,bullet:true},{field:'entity',title:'الجهة المعنية',value:t.entity},{field:'desc',title:'نبذة حول المشروع',value:t.desc}].filter(function(f){return populated(f.value);});
  var extras=[{field:'entities',title:'الجهات المساهمة',value:t.entities},{field:'unit',title:'الإدارة',value:t.unit},{field:'units',title:'إدارات مساهمة',value:t.units},{field:'budget',title:'الميزانية المخصصة إن وجدت',value:t.budget}].filter(function(f){return populated(f.value);});
  var covered=['lead','pm','title','desc','entity','entities','sector','unit','units','startMonth','startYear','endMonth','endYear','status','progress','budget','achieved','next','notes','recs'];
  (it.all||[]).forEach(function(f,i){if(!covered.includes(f.field)&&populated(f.value))extras.push({field:'extra-'+i,title:f.label,value:f.value});});
  var metadata=[{name:'pm',label:'مدير المشروع',text:value(t.pm||it.coord),x:850,w:338},{name:'start',label:'البدء',text:date(it,'start'),x:465,w:360},{name:'end',label:'الانتهاء',text:date(it,'end'),x:80,w:360}];
  var metaH=Math.max(42,...metadata.map(function(f){return 12+cardTextHeight(f.text,f.w-(f.name==='pm'?108:65)-6,12.5,false);})),top=201+metaH+14,headerY=201,canCompactHeader=!/[\r\n]/.test(it.title)&&clean(it.title).length<45&&cardTextHeight(it.title,700,24,false)<65,hasRecs=populated(t.recs),font=13.5,layout;
  function rowPlan(fields,size,mode,compact){
   if(!fields.length)return [];
   var available=W-G*(fields.length-1),widths=fields.map(function(){return available/fields.length;});
   // Adaptive widths preserve RTL field order and a single shared context row.
   if(fields.length===3&&mode!=='row'){
    var fractions=mode==='notes60'?[.60,.15,.25]:mode==='notes65'?[.65,.12,.23]:mode==='notes70'?[.70,.10,.20]:mode==='notes55'?[.55,.15,.30]:[.45,.15,.40];
    widths=fractions.map(function(v){return available*v;});
   }else if(fields.length===2&&mode!=='row'){
    var a=clean(fields[0].value).length,b=clean(fields[1].value).length,ratio=Math.max(.3,Math.min(.7,a/Math.max(1,a+b)));widths=[available*ratio,available*(1-ratio)];
   }
   return [{fields:fields,widths:widths,w:available/fields.length,h:Math.max(compact?42:53,...fields.map(function(f,i){return (compact?20:27)+cardTextHeight(f.value,widths[i]-8,size,!!f.bullet);} ))}];
  }

  function measure(size,mode,compact){
   var narrativeWidths=narrative.map(function(){return narrative.length===2?CW:W;});
   if(compact&&narrative.length===2){var lengths=narrative.map(function(f){return clean(f.value).length;}),ratio=lengths[0]/Math.max(1,lengths[1]);if(ratio>2.3||ratio<1/2.3){var firstWidth=(W-G)*(ratio>1?.64:.36);narrativeWidths=[firstWidth,W-G-firstWidth];}}
   var narrH=narrative.length?Math.max(compact?65:95,...narrative.map(function(f,i){return (compact?31:43)+cardTextHeight(f.value,narrativeWidths[i]-30,size,true);})):0;
   var recH=hasRecs?(compact?27:36)+cardTextHeight(t.recs,W-30,size,true):0,contextRows=rowPlan(context,size,mode,compact),extraRows=[];
   for(var i=0;i<extras.length;i+=3)extraRows=extraRows.concat(rowPlan(extras.slice(i,i+3),size,'row',compact));
   var contextH=contextRows.reduce(function(n,r){return n+r.h;},0)+Math.max(0,contextRows.length-1)*8,extraH=extraRows.reduce(function(n,r){return n+r.h;},0)+Math.max(0,extraRows.length-1)*8;
   var blocks=[narrH,recH,contextH,extraH].filter(function(h){return h>0;});return {compact:compact,narrativeWidths:narrativeWidths,gap:compact?8:14,narrH:narrH,recH:recH,contextRows:contextRows,extraRows:extraRows,contextH:contextH,extraH:extraH,total:blocks.reduce(function(n,h){return n+h;},0)+Math.max(0,blocks.length-1)*(compact?8:14)};
  }
  // Preserve the screenshot's RTL notes/entity/description row whenever it fits.
  // Dense source records widen cells within that same row before reducing readable body text.
  layout=measure(font,'row');
  while(layout.total>bottom-top&&font>10.5){
   var candidates=['row','notes55','notes60','notes65','notes70','notes45'].map(function(mode){return measure(font,mode,true);}).sort(function(a,b){return a.total-b.total;});
   if(candidates[0].total<=bottom-top+(canCompactHeader?21:0)){layout=candidates[0];if(canCompactHeader){headerY-=21;top-=21;}break;}
   font-=.25;layout=measure(font,'row');
  }
  if(layout.total>bottom-top){layout=['row','notes55','notes60','notes65','notes70','notes45'].map(function(mode){return measure(font,mode,true);}).sort(function(a,b){return a.total-b.total;})[0];}
  if(layout.total>bottom-top&&canCompactHeader&&headerY===201){headerY-=21;top-=21;}if(layout.total>bottom-top)throw new Error('يتجاوز النص الكامل مساحة شريحة واحدة للمشروع «'+it.title+'». يلزم تقليل نطاق النص أو اعتماد أكثر من شريحة.');
  // Spend spare space on breathing room within the actual blocks, not a blank footer.
  var spare=bottom-top-layout.total,blocks=(narrative.length?1:0)+(hasRecs?1:0)+layout.contextRows.length+layout.extraRows.length,extra=blocks?Math.min(36,spare/blocks):0;
  if(narrative.length)layout.narrH+=extra;if(hasRecs)layout.recH+=extra*.5;
  layout.contextRows.forEach(function(r){r.h+=extra;});layout.extraRows.forEach(function(r){r.h+=extra;});
  var detailHeading=done?'المستجدات التفصيلية للمشاريع المنجزة':'المستجدات التفصيلية للمشاريع قيد المتابعة',headingW=850;
  cardText(d,detailHeading,[1202-headingW,43,headingW,37],21,'333333','Special detail heading',false);
  if(U.key(t.lead)===U.key('نعم')){var leadX=1202-headingW-158;named(cardPanel(d,[leadX,47,144,30],'F2F6F6','D9E1E2',true),'Special lead badge panel');var leadBadge=cardText(d,'مشاريع سموه',[leadX+9,51,126,22],11,ACCENT,'Special lead badge',false);first(first(leadBadge,P,'txBody'),A,'p').firstChild.setAttribute('algn','ctr');}
  // Sector stays in the source/filter model but is intentionally absent from cards.
  cardPanel(d,[52,98,1156,574],PAPER,'E7E0D3',true);
  var titleSize=22;while(titleSize>15&&cardTextHeight(it.title,758,titleSize,false)>75)titleSize-=.5;
  cardText(d,it.title,[430,headerY===201?117:112,758,headerY===201?76:61],titleSize,'333333','Special field title',true);
  var statusShape=cardText(d,status(it),[260,headerY===201?141:123,148,28],13,HH_COLORS[status(it)]===ACCENT?ACCENT:BODY,'Special field status',false);first(first(statusShape,P,'txBody'),A,'p').firstChild.setAttribute('algn','ctr');
  addStatusProgress(d,it,[146,headerY===201?112:91,92,85]);cardText(d,'نسبة الإنجاز',[66,headerY===201?144:123,73,24],10,INK,'Special progress label',false);
  cardPanel(d,[53,headerY,1154,metaH],'EFEBE7');
  metadata.forEach(function(f){var labelW=f.name==='pm'?108:65;cardText(d,f.label,[f.x+f.w-labelW,headerY+9,labelW,24],11,BODY,'Special metadata label '+f.name,false);cardText(d,f.text,[f.x,headerY+8,f.w-labelW-6,metaH-12],12.5,'333333','Special field '+f.name,false);});
  var y=top;
  if(narrative.length){narrative.forEach(function(f,i){var w=layout.narrativeWidths[i],x=narrative.length===2?(i===0?left+W-w:left):left;cardPanel(d,[x,y,w,layout.narrH],f.fill,f.field==='achieved'?'D9E1E2':'E7E0D3',true);cardText(d,f.title,[x+13,y+(layout.compact?5:9),w-26,26],layout.compact?11:13,f.color,'Special label '+f.field,true);cardBody(d,f.value,[x+13,y+(layout.compact?27:36),w-26,layout.narrH-(layout.compact?30:39)],font,BODY,'Special field '+f.field,true);});y+=layout.narrH+layout.gap;}
  if(hasRecs){cardPanel(d,[left,y,W,layout.recH],ACCENT,null,true);cardText(d,'توصيات إدارة الأداء والتنفيذ',[left+13,y+(layout.compact?4:8),W-26,23],layout.compact?10:11,'D9E1E2','Special label recs',false);cardBody(d,t.recs,[left+13,y+(layout.compact?24:31),W-26,layout.recH-(layout.compact?27:34)],font,PAPER,'Special field recs',true);y+=layout.recH+layout.gap;}
  function drawRows(rows){rows.forEach(function(row,ri){row.fields.forEach(function(f,i){var w=row.widths[i],x=left+W-row.widths.slice(0,i+1).reduce(function(n,v){return n+v;},0)-G*i;cardText(d,f.title,[x,y,w,25],layout.compact?10.5:12,INK,'Special label '+f.field,false);cardBody(d,f.value,[x,y+(layout.compact?20:27),w,row.h-(layout.compact?20:27)],font,BODY,'Special field '+f.field,!!f.bullet);});y+=row.h+(ri<rows.length-1?8:0);});}
  drawRows(layout.contextRows);
  if(layout.extraRows.length){if(layout.contextRows.length)y+=layout.gap;cardPanel(d,[left,y-7,W,0.7],'E7E0D3');drawRows(layout.extraRows);}
  var entry=add(d,2,it,true);entry.card=true;entry.projectKey=it.key;
 }
 function openCards(source,it,index,add){unifiedCards(source,it,index,add);}
 function doneCards(source,it,index,add){unifiedCards(source,it,index,add);}
 // Every source row appears exactly once in this editable, paginated native table.
 function masterList(source,state,m,add){
  var widths=[139,116,150,185,173,347,46],headers=['تاريخ الانتهاء','نسبة الإنجاز','الحالة','مدير المشروع','الجهة المعنية','المشروع','م'],font=11;
  var rows=m.items.map(function(it,i){var tableValue=function(v){return U.tableCellText(clean(v));},values=[tableValue([it.t.endMonth,it.t.endYear].filter(Boolean).join(' ')),S.views.reports.harvey(it).valid?S.views.reports.harvey(it).label:'',tableValue(it.t.status?status(it):null),tableValue(it.coord||it.t.pm),tableValue(it.entity),it.title,String(i+1)];return {it:it,values:values,h:Math.max(42,...values.map(function(v,j){return lines(v,widths[j]-26,font*(j===5?1.10:1)).length*font*4/3*1.8+18;}))};}),pages=[],current=[],used=0,capacity=466;
  rows.forEach(function(row){if(current.length&&used+row.h>capacity){pages.push(current);current=[];used=0;}current.push(row);used+=row.h;});if(current.length||!pages.length)pages.push(current);
  var entries=[];
  pages.forEach(function(page,pi){
   var d=strip(xml(source),[14]);clearLinks(d);label(d,14,'القائمة الرئيسية للمشاريع'+(pages.length>1?' (الصفحة '+(pi+1)+' من '+pages.length+')':''),24,INK,'r');
   addText(d,S.reportDisplay.get(state).period+(scope(state)?'   '+scope(state):''),[52,88,1156,27],12,'Dubai',BODY,'r');
   addText(d,'عدد المشاريع: '+U.metricText(m.items.length)+(page.length?'، المشاريع من '+page[0].values[6]+' إلى '+page[page.length-1].values[6]:''),[52,121,1156,25],11,'Dubai',BODY,'r');
   var entry=add(d,'summary');entry.masterRows=[];entries.push(entry);
   if(!page.length){addText(d,'لا توجد مشاريع ضمن النطاق المحدد',[52,300,1156,60],20,'Dubai',INK,'ctr');return;}
   var tree=first(d,P,'spTree'),frame=node(d,P,'p:graphicFrame'),nv=node(d,P,'p:nvGraphicFramePr');nv.appendChild(node(d,P,'p:cNvPr',{id:900,name:'Special master project list native table'}));nv.appendChild(node(d,P,'p:cNvGraphicFramePr'));nv.appendChild(node(d,P,'p:nvPr'));frame.appendChild(nv);
   var xf=node(d,P,'p:xfrm');xf.appendChild(node(d,A,'a:off',{x:52*9525,y:158*9525}));xf.appendChild(node(d,A,'a:ext',{cx:1156*9525,cy:Math.round((40+page.reduce(function(n,r){return n+r.h;},0))*9525)}));frame.appendChild(xf);
   var graphic=node(d,A,'a:graphic'),gd=node(d,A,'a:graphicData',{uri:'http://schemas.openxmlformats.org/drawingml/2006/table'}),table=node(d,A,'a:tbl'),tp=node(d,A,'a:tblPr',{firstRow:1,bandRow:0});tp.appendChild(node(d,A,'a:noFill'));table.appendChild(tp);var grid=node(d,A,'a:tblGrid');widths.forEach(function(w){grid.appendChild(node(d,A,'a:gridCol',{w:w*9525}));});table.appendChild(grid);
   function tableRow(values,h,header,item,rowIndex){var tr=node(d,A,'a:tr',{h:Math.round(h*9525)});values.forEach(function(v,j){var tc=node(d,A,'a:tc'),tb=node(d,A,'a:txBody');tb.appendChild(node(d,A,'a:bodyPr',{wrap:'square',rtlCol:1,anchor:'ctr'}));tb.appendChild(node(d,A,'a:lstStyle'));paragraphs(d,lines(v,widths[j]-26,(header?11.5:font)*(header||j===5?1.10:1)).join('\n'),header?11.5:font,'Dubai',header?PAPER:j===2?(HH_COLORS[status(item)]||BODY):BODY,j>=3&&j<=5?'r':'ctr').forEach(function(p){if(header||j===5)all(p,A,'rPr').concat(all(p,A,'defRPr')).forEach(function(pr){pr.setAttribute('b','1');});tb.appendChild(p);});tc.appendChild(tb);var pr=node(d,A,'a:tcPr',{marL:95250,marR:95250,marT:57150,marB:57150,anchor:'ctr'});['lnL','lnR','lnT','lnB'].forEach(function(edge){var ln=node(d,A,'a:'+edge,{w:6350}),f=node(d,A,'a:solidFill');f.appendChild(node(d,A,'a:srgbClr',{val:'E7E0D3'}));ln.appendChild(f);pr.appendChild(ln);});var fill=node(d,A,'a:solidFill');fill.appendChild(node(d,A,'a:srgbClr',{val:header?INK:rowIndex%2?'F4F1EE':PAPER}));pr.appendChild(fill);tc.appendChild(pr);tr.appendChild(tc);if(!header&&j===5)entry.masterRows.push({key:item.key,cell:tc});});table.appendChild(tr);}
   tableRow(headers,40,true);page.forEach(function(row,rowIndex){tableRow(row.values,row.h,false,row.it,rowIndex);});gd.appendChild(table);graphic.appendChild(gd);frame.appendChild(graphic);tree.appendChild(frame);
  });return entries;
 }
 function reportEditorial(source,state,add){
  var o=S.reportEditorial.options(state);
  [['notes','ملاحظات','115E67'],['recommendations','توصيات','651D32']].forEach(function(section){
   var value=o[section[0]].trim();if(!value)return;
   var pages=chunks(value,1156,470,18);
   pages.forEach(function(text,i){var d=strip(xml(source),[14]);clearLinks(d);label(d,14,section[1]+(pages.length>1?' ('+(i+1)+' / '+pages.length+')':''),24,section[2],'r');addText(d,S.reportDisplay.get(state).period,[52,88,1156,30],12,'Dubai',BODY,'r');addText(d,text,[52,148,1156,470],18,'Dubai',BODY,'r');add(d,'summary');});
  });
 }
 async function build(state){
  state={data:state.data,dash:Object.assign({},state.dash),report:Object.assign({},state.report)};var m=S.views.reports.hhModel(state);await loadTemplate();await loadFonts();await document.fonts.ready;
  var raw=atob(S.hhTemplateBase64),bytes=Uint8Array.from(raw,function(c){return c.charCodeAt(0);}),archive=await S.zip.open(bytes.buffer),parts=new Map();await Promise.all(archive.names().map(async function(n){var payload=await archive.read(n);parts.set(n,/^ppt\/.*\.xml$/.test(n)?encoder.encode(brandXml(decoder.decode(payload))):payload);}));
  var sources={},rels={};Object.entries({cover:1,summary:2,1:3,2:4,3:5,4:6}).forEach(function(pair){var key=pair[0],i=pair[1];sources[key]=decoder.decode(parts.get('ppt/slides/slide'+i+'.xml'));rels[key]=decoder.decode(parts.get('ppt/slides/_rels/slide'+i+'.xml.rels'));});var chartSource=decoder.decode(parts.get('ppt/charts/chart1.xml'));
  Array.from(parts.keys()).forEach(function(n){if(/^ppt\/(slides\/(slide\d+\.xml|_rels\/slide\d+\.xml\.rels)|charts\/|embeddings\/|notesSlides\/)/.test(n))parts.delete(n);});
  var slides=[],projectSlides={},contentsEntries=[],targets=[];
  function add(doc,source,it,firstPage){var entry={doc:doc,rels:cleanRels(rels[source])};slides.push(entry);if(it&&firstPage)projectSlides[it.key]=slides.length;return entry;}
  var display=S.reportDisplay.get(state),cv=S.reportDisplay.cover(S.reportDisplay.options(state)),cover=xml(sources.cover);clearLinks(cover);remove(cover,[3]);textShape(cover,4,display.title,{size:cv.titleSize,font:'DIN Next LT Arabic',align:'ctr',box:cv.titleBox});addText(cover,display.period,cv.periodBox,cv.periodSize,'Dubai',BODY,'ctr');add(cover,'cover');
  contentsEntries.push(add(contents(sources[1],0,state,m),1));targets[0]=slides.length+1;var chartCount=await summary(sources.summary,state,m,add,parts,chartSource);reportEditorial(sources.summary,state,add);
  targets[1]=slides.length+1;var masterEntries=masterList(sources.summary,state,m,add);
  targets[2]=slides.length+1;contentsEntries.push(add(contents(sources[1],2,state,m),1));
  if(m.open.length)m.open.forEach(function(it){openCards(sources[2],it,m.items.indexOf(it),add);});else{var d=strip(xml(sources[4]),[6,26]);set(d,26,'المشاريع قيد المتابعة',22);addText(d,'لا توجد مشاريع قيد المتابعة ضمن النطاق المحدد',[110,320,1090,70],20,'Dubai',INK,'ctr');add(d,4);}
  targets[3]=slides.length+1;contentsEntries.push(add(contents(sources[3],3,state,m),3));
  if(m.done.length)m.done.forEach(function(it){doneCards(sources[4],it,m.items.indexOf(it),add);});else{var d=strip(xml(sources[4]),[6,26]);set(d,26,'المشاريع المنجزة',22);addText(d,'لا توجد مشاريع منجزة ضمن النطاق المحدد',[110,320,1090,70],20,'Dubai',INK,'ctr');add(d,4);}
  contentsEntries.forEach(function(entry){all(entry.doc,A,'tr').forEach(function(row,i){all(row,A,'tc').forEach(function(tc,j){link(entry,tc,targets[i],'section_'+i+'_'+j);});});});
  var masterPageByKey={};masterEntries.forEach(function(entry){entry.masterRows.forEach(function(row,i){link(entry,row.cell,projectSlides[row.key],'project_'+i);masterPageByKey[row.key]=slides.indexOf(entry)+1;});});
  slides.forEach(function(entry,i){
   if(i>0)footer(entry,i,!contentsEntries.includes(entry),entry.card?masterPageByKey[entry.projectKey]:null);parts.set('ppt/slides/slide'+(i+1)+'.xml',serial(entry.doc));parts.set('ppt/slides/_rels/slide'+(i+1)+'.xml.rels',serial(entry.rels));});
  var presentation=xml(decoder.decode(parts.get('ppt/presentation.xml'))),ids=first(presentation,P,'sldIdLst'),presRels=xml(decoder.decode(parts.get('ppt/_rels/presentation.xml.rels')));while(ids.firstChild)ids.firstChild.remove();Array.from(presRels.documentElement.children).filter(function(r){return r.getAttribute('Type').endsWith('/slide');}).forEach(function(r){r.remove();});
  slides.forEach(function(s,i){var id=node(presentation,P,'p:sldId',{id:256+i});id.setAttributeNS(R,'r:id','rIdHHSlide'+i);ids.appendChild(id);presRels.documentElement.appendChild(node(presRels,PK,'Relationship',{Id:'rIdHHSlide'+i,Type:R+'/slide',Target:'slides/slide'+(i+1)+'.xml'}));});clearTemplateSlideLists(presentation);embedReportFonts(parts,presentation,presRels);parts.set('ppt/presentation.xml',serial(presentation));parts.set('ppt/_rels/presentation.xml.rels',serial(presRels));
  var types=xml(decoder.decode(parts.get('[Content_Types].xml')));Array.from(types.documentElement.children).filter(function(t){return /^\/ppt\/(slides\/slide\d+\.xml|charts\/|embeddings\/|notesSlides\/)/.test(t.getAttribute('PartName')||'');}).forEach(function(t){t.remove();});slides.forEach(function(s,i){types.documentElement.appendChild(node(types,CT,'Override',{PartName:'/ppt/slides/slide'+(i+1)+'.xml',ContentType:'application/vnd.openxmlformats-officedocument.presentationml.slide+xml'}));});for(var ci=1;ci<=chartCount;ci++)types.documentElement.appendChild(node(types,CT,'Override',{PartName:'/ppt/charts/chart'+ci+'.xml',ContentType:'application/vnd.openxmlformats-officedocument.drawingml.chart+xml'}));if(!Array.from(types.documentElement.children).some(function(n){return n.getAttribute('Extension')==='xlsx';}))types.documentElement.appendChild(node(types,CT,'Default',{Extension:'xlsx',ContentType:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}));if(!Array.from(types.documentElement.children).some(function(n){return n.getAttribute('Extension')==='fntdata';}))types.documentElement.appendChild(node(types,CT,'Default',{Extension:'fntdata',ContentType:S.agendaFonts.contentType}));parts.set('[Content_Types].xml',serial(types));
  var app=xml(decoder.decode(parts.get('docProps/app.xml'))),count=app.getElementsByTagName('Slides')[0];if(count)count.textContent=slides.length;['TitlesOfParts','HeadingPairs'].forEach(function(tag){Array.from(app.getElementsByTagName(tag)).forEach(function(n){n.remove();});});parts.set('docProps/app.xml',serial(app));
  return {blob:zip(parts,'application/vnd.openxmlformats-officedocument.presentationml.presentation'),name:S.reportDisplay.fileTitle(S.reportDisplay.get(state).fileTitle)+'.pptx',model:m,summary:S.views.reports.hhSummary(state,m),chartCount:chartCount,slides:slides.length,projectSlides:projectSlides,sectionTargets:targets,masterPageByKey:masterPageByKey,masterSlides:masterEntries.map(function(e){return slides.indexOf(e)+1;})};
 }
 S.hhReport={build:build};
})(window.Saytara=window.Saytara||{});
