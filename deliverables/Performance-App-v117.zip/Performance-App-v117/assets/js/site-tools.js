/* Optional browser-native tool access. No file contents are transmitted. */
(function () {
  'use strict';
  var context = document.modelContext;
  if (!context || !context.registerTool) return;
  var lifecycle = new AbortController();
  function state() {
    var app = window.Saytara && window.Saytara.app;
    if (!app) throw new Error('Application is not ready');
    return app;
  }
  function empty(input) {
    if (!input || typeof input !== 'object' || Array.isArray(input) || Object.keys(input).length) throw new Error('No input fields are accepted');
  }
  function register(tool) {
    try { Promise.resolve(context.registerTool(tool, {signal: lifecycle.signal})).catch(function () {}); } catch (ignore) {}
  }
  register({
    name: 'read_saytara_status', title: 'Read performance reporting status',
    description: 'Read the active screen and whether current and previous workbooks have been selected locally. Returns no workbook data.',
    inputSchema: {type: 'object', properties: {}, additionalProperties: false},
    annotations: {readOnlyHint: true, untrustedContentHint: false},
    execute: function (input) { empty(input); var s = state().state; return {screen: s.screen, currentWorkbookLoaded: !!s.data, previousWorkbookLoaded: !!s.previous}; }
  });
  register({
    name: 'open_saytara_comparison', title: 'Open monthly comparison',
    description: 'Navigate to the existing monthly comparison screen. Does not select files or confirm dates.',
    inputSchema: {type: 'object', properties: {}, additionalProperties: false},
    annotations: {readOnlyHint: false, untrustedContentHint: false},
    execute: function (input) { empty(input); var app = state(); app.go('comparison'); return {screen: app.state.screen}; }
  });
  window.addEventListener('pagehide', function (event) { if (!event.persisted) lifecycle.abort(); }, {once: true});
})();
