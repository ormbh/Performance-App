/* Source-grounded finish-year coverage for the current monthly report scope.
   Month-only End Dates follow the workbook's reference-year quarter rule;
   missing or invalid dates never inherit a year from a display label. */
(function (S) {
  'use strict';

  var U = S.util;

  function validYear(value) {
    return typeof value === 'number' && Number.isInteger(value) && value >= 1 && value <= 9999;
  }
  function referenceYear(data) {
    if (validYear(data && data.year)) return data.year;
    var date = data && data.today;
    if (U.validDateSerial(date)) {
      var year = U.ymd(date).y;
      if (validYear(year)) return year;
    }
    return null;
  }
  function endYear(it, year) {
    var cell = it.c && it.c.end;
    if (!cell || cell.t === 's' && !String(cell.v).trim()) return { year: null, reason: 'missing' };
    if (cell.t === 'n' && typeof cell.v === 'number' && U.validDateSerial(cell.v)) {
      // Match Excel's YEAR for its 1900 calendar, including serial 60.
      var serial = Math.floor(cell.v);
      var numericYear = serial < 61 ? 1900 : U.ymd(serial).y;
      if (validYear(numericYear)) return { year: numericYear };
    }
    if (cell.t === 's' && U.MONTHS_EN3.indexOf(U.xlTrim(cell.v).toUpperCase()) >= 0 &&
        validYear(year) && /^Q[1-4]$/.test(it.calc && it.calc.quarter || '')) {
      return { year: year };
    }
    return { year: null, reason: 'invalid' };
  }

  function summarize(data, D) {
    var year = referenceYear(data), counts = new Map(), missing = 0, invalid = 0;
    // D.items has already applied the exact monthly report scope. Count at the
    // same titled-row grain as secTotal, without applying another filter.
    var rows = (D && D.items || []).filter(function (it) {
      return it.pf === 'secretariat' && it.c && S.rules.test('secTotal', it);
    });
    rows.forEach(function (it) {
      var result = endYear(it, year);
      if (result.year != null) counts.set(result.year, (counts.get(result.year) || 0) + 1);
      else if (result.reason === 'missing') missing++;
      else invalid++;
    });
    var years = Array.from(counts.keys()).sort(function (a, b) { return a - b; }).map(function (key) {
      return { year: key, count: counts.get(key) };
    });
    var dated = years.reduce(function (sum, group) { return sum + group.count; }, 0);
    return {
      years: years, undated: missing + invalid, total: rows.length,
      missing: missing, invalid: invalid, reportYear: year,
      inReportYear: year == null ? null : counts.get(year) || 0,
      outsideReportYear: year == null ? null : dated - (counts.get(year) || 0),
      reconciled: dated + missing + invalid === rows.length
    };
  }

  function render(state, D, print) {
    var result = summarize(state && state.data, D);
    var parts = result.years.map(function (group) {
      return 'مشاريع <bdi dir="ltr">' + U.esc(group.year) + '</bdi>: <bdi dir="ltr">' + U.esc(U.fmtN(group.count)) + '</bdi>';
    });
    if (result.undated) parts.push('دون تاريخ انتهاء صالح: <bdi dir="ltr">' + U.esc(U.fmtN(result.undated)) + '</bdi>');
    if (!parts.length) return '';
    return '<p class="monthly-year-coverage' + (print ? ' monthly-year-coverage-print' : '') + '" dir="rtl">' +
      '<span class="monthly-year-coverage-label">حسب سنة الانتهاء:</span> ' + parts.join(' <span aria-hidden="true">|</span> ') + '</p>';
  }

  S.monthlyCoverage = { summarize: summarize, render: render };
})(window.Saytara = window.Saytara || {});
