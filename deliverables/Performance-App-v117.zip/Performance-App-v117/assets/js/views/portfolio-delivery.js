/* Source-scoped portfolio charts, visible readings, one hierarchy per population. */
(function(S){
 'use strict';
 var U=S.util;
 function render(state,m,h){
  var E=U.esc;
  if(!m||!m.total)return '<section class="pd-empty"><h2>لا توجد مشاريع ضمن هذا النطاق</h2><button type="button" class="dbtn" data-act="projects-reset">مسح التصفية</button></section>';
  function num(v){return U.metricText(v);}
  function pct(v){return U.displayNumber(v,1,'%');}
  function cash(v){return U.displayNumber(v,2);}
  function finite(v){return typeof v==='number'&&Number.isFinite(v);}
  function value(metric){return metric&&metric.available!==false&&finite(metric.value)?metric.value:null;}
  function semantic(v,kind){return v===0?'صفر':!finite(v)?'غير متاح':kind==='money'?cash(v)+' درهم إماراتي':kind==='percent'?pct(v):num(v);}
  function drill(text,id,label,cls){return id?'<button type="button" class="pd-drill '+(cls||'')+'"'+h.attrs('delivery',id)+' aria-label="'+E(label+' · يعرض المشاريع المطابقة')+'"><bdi dir="auto">'+E(text)+'</bdi></button>':'<span class="'+(cls||'')+'"><bdi dir="auto">'+E(text)+'</bdi></span>';}
  function count(v,id,label,cls){return drill(num(v),v==null?null:id,label+': '+semantic(v),'pd-count '+(cls||''));}
  function delta(d,label,kind){
   if(!d||!d.available||d.delta===0||!finite(d.delta))return '';
   var v=U.displayNumber(Math.abs(d.delta),kind==='money'?2:kind==='percent'?1:0),unit=kind==='money'?' درهم':kind==='percent'?' نقطة مئوية':'';
   return '<span class="pd-delta" data-direction="'+(d.delta>0?'up':'down')+'" aria-label="'+E(label+': '+(d.delta>0?'زيادة ':'انخفاض ')+v+unit)+'"><span aria-hidden="true">'+(d.delta>0?'↑':'↓')+'</span><bdi dir="ltr">'+E((d.delta>0?'+':'−')+v)+'</bdi>'+(unit?'<span>'+E(unit)+'</span>':'')+'</span>';
  }
  function coverage(metric){if(!metric||metric.known==null||metric.total>0&&metric.known===metric.total)return '';return '<small class="pd-coverage">'+E(metric.total===0?'لا توجد قيم حالية':'قيم متاحة: '+num(metric.known)+' من '+num(metric.total))+'</small>';}
  function budgetCell(g){var b=g.budget||{};return drill(cash(b.value),b.value==null?null:b.id,g.name+'، الموازنة المعتمدة: '+semantic(b.value,'money'),'pd-budget-value')+delta(g.changes&&g.changes.budget,g.name+'، الموازنة المعتمدة','money')+coverage(b);}
  function head(title,note,id){return '<header class="pd-section-head"><div><h2'+(id?' id="'+E(id)+'"':'')+'>'+E(title)+'</h2>'+(note?'<p>'+E(note)+'</p>':'')+'</div></header>';}
  function table(rows,labels,cells,title,extra){return '<div class="pd-table-region" role="region" tabindex="0" aria-label="'+E(title)+'"><table class="pd-table '+(extra||'')+'" role="table"><caption class="visually-hidden">'+E(title)+'</caption><thead role="rowgroup"><tr role="row">'+labels.map(function(label){return '<th scope="col" role="columnheader">'+E(label)+'</th>';}).join('')+'</tr></thead><tbody role="rowgroup">'+rows.map(function(row){return '<tr role="row"'+(row.id?' data-group-id="'+E(row.id)+'"':'')+(row.item?' data-project-key="'+E(row.item.key)+'"':'')+(row.depth?' class="pd-child-row"':'')+'>'+cells(row).map(function(v,i){return '<'+(i===0?'th scope="row" role="rowheader"':'td role="cell"')+' data-label="'+E(labels[i])+'">'+v+'</'+(i===0?'th':'td')+'>';}).join('')+'</tr>';}).join('')+'</tbody></table></div>';}
  function nameCell(g){return drill(g.depth&&g.priorityName?g.priorityName:g.name,g.id,g.name,'pd-group-name')+(g.previousOnly?'<small class="pd-source-sector">ورد في اللقطة السابقة فقط</small>':'');}
  function reading(label,v,id,change,kind,tone,note){return '<div class="pd-reading '+(tone||'')+'">'+drill(label,v==null?null:id,label,'pd-reading-label')+drill(kind==='percent'?pct(v):num(v),v==null?null:id,label+': '+semantic(v,kind),'pd-reading-value')+delta(change,label,kind)+(note?'<p>'+E(note)+'</p>':'')+'</div>';}

  /* A single numeric scale per chart. Signed money grows either side of zero. */
  function scale(values,kind){
   var known=values.filter(finite),min=known.length?Math.min.apply(null,[0].concat(known)):0,max=known.length?Math.max.apply(null,[0].concat(known)):0;
   var magnitude=Math.max(Math.abs(min),Math.abs(max)),divisor=kind==='money'?(magnitude>=1000000?1000000:magnitude>=1000?1000:1):1;
   return {min:min,max:max,span:max-min||1,kind:kind,available:known.length>0,zero:(0-min)/(max-min||1)*100,divisor:divisor};
  }
  function axis(s){
   var label=s.kind==='money'?'الموازنة المعتمدة · '+(s.divisor===1000000?'مليون ':s.divisor===1000?'ألف ':'')+'درهم إماراتي':'عدد المشاريع';
   if(!s.available)return '<div class="pd-chart-axis"><span>'+label+'</span><small>لا توجد قيم متاحة للرسم</small></div>';
   return '<div class="pd-chart-axis"><span>'+label+'</span></div>';
  }
  function bar(v,s,id,label,cls,partial){
   if(!finite(v))return '<span class="pd-plot pd-plot-unavailable" role="img" aria-label="'+E(label+': غير متاح')+'"><bdi>—</bdi></span>';
   var end=(v-s.min)/s.span*100,left=Math.min(s.zero,end),width=Math.abs(end-s.zero);
   var plot='<span class="pd-plot" dir="ltr" aria-hidden="true"><span class="pd-zero-line" style="left:'+s.zero+'%"></span><span class="pd-bar-fill '+(cls||'')+(partial?' pd-partial':'')+'" style="left:'+left+'%;width:'+width+'%"></span></span>';
   return id?'<button type="button" class="pd-bar-button"'+h.attrs('delivery',id)+' aria-label="'+E(label+': '+semantic(v,s.kind==='money'?'money':'')+(partial?'؛ مجموع القيم المتاحة فقط':'')+' · يعرض المشاريع المطابقة')+'">'+plot+'</button>':'<span class="pd-bar-static" role="img" aria-label="'+E(label+': '+semantic(v,s.kind==='money'?'money':''))+'">'+plot+'</span>';
  }
  function hierarchyRows(parents){var rows=[];parents.forEach(function(parent){rows.push(parent);(parent.children||[]).forEach(function(child){rows.push(Object.assign({},child,{depth:1}));});});return rows;}
  function hierarchyChart(parents,area,title,label){
   var rows=hierarchyRows(parents),s=scale(rows.map(function(g){return g.total;}),'count');
   return axis(s)+table(rows,[label,'رسم عدد المشاريع','عدد المشاريع','الموازنة المعتمدة'],function(g){return [nameCell(g),bar(g.total,s,g.id,g.name+'، عدد المشاريع',g.depth?'pd-child-fill':''),count(g.total,g.id,g.name+'، عدد المشاريع')+delta(g.changes&&g.changes.total,g.name+'، عدد المشاريع'),budgetCell(g)];},title,'pd-chart-table');
  }
  var o=m.overall||{},groups=m.groups||[],history=m.history||{};
  var hierarchy=m.hierarchy||groups;
  var distribution='<section class="pd-panel pd-organizations" data-pd-chart-area="organizations" aria-labelledby="pd-organizations-title">'+head('التوزيع التنظيمي','قطاع ثم وحداته، ووحدات مستقلة في تسلسل واحد','pd-organizations-title')+'<div class="pd-scope-totals"><div><span>إجمالي المشاريع ضمن النطاق</span>'+count(o.total,o.id||'overview:all','إجمالي المشاريع')+delta(o.changes&&o.changes.total,'إجمالي المشاريع')+'</div><div><span>الموازنة المعتمدة · درهم إماراتي</span>'+budgetCell(Object.assign({name:'المحفظة'},o))+'</div></div>'+hierarchyChart(hierarchy,'organizations','توزيع المشاريع والموازنة حسب التسلسل التنظيمي','القطاع / الوحدة')+'<p class="pd-footnote">الوحدات التابعة تفصّل إجمالي قطاعها؛ لا تُجمع معه مرة ثانية. الأمانة العامة هي الجهة الأم. الموازنات تجمع القيم المسجلة فقط؛ التغطية مبينة مع القراءة.</p></section>';

  var statuses=(m.statuses||[]).filter(function(s){return s.key!=='unknown'||s.available===false||(s.value==null?s.total:s.value)!==0;}),statusScale=scale(statuses.map(function(s){return s.available===false?null:s.value==null?s.total:s.value;}),'count');
  var statusChart=axis(statusScale)+table(statuses,['حالة المصدر','توزيع المشاريع','عدد المشاريع'],function(s){var v=s.available===false?null:s.value==null?s.total:s.value;return [drill(s.label,v==null?null:s.id,s.label,'pd-status-label'),bar(v,statusScale,v==null?null:s.id,s.label,s.key==='completed'?'pd-completed-fill':''),count(v,s.id,s.label,s.key==='completed'?'pd-good':'')+delta(s.change,s.label)];},'توزيع المشاريع حسب حالات المصدر','pd-status-chart');
  var completion=reading('نسبة المشاريع المنجزة',o.completionRate,o.completedId||'overview:completed',o.changes&&o.changes.completionRate,'percent','pd-good','المنجز حسب الحالة ÷ جميع المشاريع');
  var avg=reading('متوسط نسبة الإنجاز المسجلة',o.progress&&o.progress.value,o.progress&&o.progress.id,o.changes&&o.changes.progress,'percent','','متوسط غير موزون للقيم الصالحة')+coverage(o.progress);
  var quarters=m.quarters||[],four=quarters.filter(function(q){return /^Q[1-4]$/.test(q.key)||/^ربع [1-4]$/.test(q.name);}),other=quarters.filter(function(q){return four.indexOf(q)<0;});
  var quarterHtml='<section class="pd-quarter-section" aria-labelledby="pd-quarter-title"><h3 id="pd-quarter-title">حسب ربع موعد الانتهاء المخطط <bdi dir="ltr">'+E(state.data.year||'')+'</bdi></h3><div class="pd-quarter-boxes">'+four.map(function(q){var v=q.available===false?null:q.value==null?q.total:q.value;return '<div class="pd-quarter-box">'+drill(q.name,q.available===false?null:q.id,q.name,'pd-quarter-label')+count(v,q.available===false?null:q.id,q.name,'pd-quarter-count')+delta(q.changes&&q.changes.total,q.name)+'</div>';}).join('')+'</div>'+other.map(function(q){var v=q.available===false?null:q.value==null?q.total:q.value;return '<p class="pd-quarter-other">'+drill(q.name,q.available===false?null:q.id,q.name)+count(v,q.available===false?null:q.id,q.name)+delta(q.changes&&q.changes.total,q.name)+'</p>';}).join('')+'</section>';
  var delivery='<section class="pd-panel pd-delivery" data-pd-chart-area="delivery" aria-labelledby="pd-delivery-title">'+head('الإنجاز والمواعيد','حالات المصدر، نسب الإنجاز وأرباع الانتهاء المخطط','pd-delivery-title')+statusChart+'<div class="pd-performance-readings"><div>'+completion+'</div><div>'+avg+'</div></div>'+quarterHtml+'<p class="pd-footnote">نسبة المنجز تعتمد الحالة المسجلة. متوسط الإنجاز يشمل الصفر المسجل، ويستبعد القيم غير المتاحة وغير الصالحة دون تحويلها إلى صفر.</p></section>';

  var financeFields=(m.finance||[]).filter(function(f){return f.key!=='available';}),paired=m.financeCoverage||{};
  var finance='<section class="pd-panel pd-finance" data-pd-chart-area="finance">'+head('الوضع المالي','مبالغ المصدر · درهم إماراتي')+'<div class="pd-finance-readings">'+financeFields.map(function(f){return '<div class="pd-finance-reading"><span>'+E(f.name||f.label)+'</span>'+drill(cash(f.value),f.value==null?null:f.id,(f.name||f.label)+': '+semantic(f.value,'money'),'pd-money')+delta(f.change,f.name||f.label,'money')+(f.note&&(f.key==='committed'||f.key==='nonCommitted')?'<p>'+E(f.note)+'</p>':'')+'</div>';}).join('')+'</div><div class="pd-spend-ratio"><span>نسبة المنفق للموازنة المعتمدة</span>'+drill(pct(paired.ratio),paired.ratio==null?null:paired.id,'نسبة المنفق للموازنة على المشاريع بقيم مزدوجة صالحة: '+semantic(paired.ratio,'percent'),'pd-money')+delta(paired.change,'نسبة المنفق للموازنة','percent')+(paired.ratio>100?'<p>المنفق المسجل يتجاوز الموازنة المعتمدة ضمن القيم المزدوجة؛ راجع قيم المصدر.</p>':'')+'</div></section>';

  var managerSummary=m.managerSummary||{},managerValue=value(managerSummary);
  var manager='<section class="pd-panel pd-managers pd-manager-summary" data-pd-chart-area="managers" aria-labelledby="pd-manager-summary-title">'+head('مديرو المشاريع','','pd-manager-summary-title')+'<div class="pd-manager-summary-reading"><span>عدد مديري المشاريع المسجلين</span><span class="pd-manager-summary-value" role="img" aria-label="'+E('عدد مديري المشاريع المسجلين: '+semantic(managerValue))+'"><bdi dir="ltr" aria-hidden="true">'+E(num(managerValue))+'</bdi></span>'+delta(managerSummary.change,'عدد مديري المشاريع المسجلين')+'</div>'+(managerSummary.available===false?'<p class="pd-unavailable">حقل مدير المشروع غير متاح في المصدر.</p>':'')+'</section>';

  var classifications=m.classification||[];
  var category='<section class="pd-panel pd-classification" data-pd-chart-area="classification">'+head('نوع المشروع وأولويته','كل نوع يعرض أولوياته داخله؛ نفس نطاق المشاريع')+hierarchyChart(classifications,'classification','توزيع المشاريع والموازنة حسب النوع والأولوية','نوع المشروع / الأولوية')+'<p class="pd-footnote">الأولوية تحت كل نوع هي تقاطع السجلات نفسه، وليست توزيعاً مفترضاً. صفوف الأولوية تفصّل إجمالي نوعها؛ القيم والتصنيفات غير المسجلة تظل ظاهرة.</p></section>';

  function fullNotes(issue){var it=issue.item||{},t=it.t||{},parts=[['ملاحظات مدير المشروع',t.ownerRemarks],['ملاحظات المالية',t.financeRemarks]].filter(function(p){return p[1]!=null&&String(p[1]).trim()!=='';});return parts.map(function(p){return '<p class="pd-source-note"><span>'+E(p[0])+'</span><bdi dir="auto">'+E(String(p[1]))+'</bdi></p>';}).join('');}
  var issues=m.issues||[],issuesHtml='<section class="pd-panel pd-issues" data-pd-chart-area="issues" aria-labelledby="pd-issues-title"><header class="pd-section-head"><h2 id="pd-issues-title">الملاحظات وحالات التأخر</h2><span class="pd-issue-total">'+count(issues.length,'issues:all','الملاحظات وحالات التأخر')+delta(m.issuesChange,'الملاحظات وحالات التأخر')+'</span></header>'+(issues.length?table(issues,['المشروع','القطاع / الوحدة','سبب المتابعة','مدير المشروع','الحالة / الإنجاز / الموعد','الملاحظات'],function(issue){var it=issue.item||{},t=it.t||{};return [h.link(it.title||'غير مسجل','record',it.key,'pd-issue-project'),E(it.sector||'')+'<small>'+E(it.unit||'')+'</small>','<ul class="pd-reasons">'+(issue.reasons||[]).map(function(reason){return '<li>'+E(reason)+'</li>';}).join('')+'</ul>','<bdi dir="auto">'+E(issue.manager||t.pm||'غير مسجل')+'</bdi>',E(it.statusLabel||t.status||'')+'<small>'+E(pct(it.progress))+'</small><small><bdi dir="auto">'+E(it.dateLabel||t.end||'')+'</bdi></small>'+(issue.daysOverdue>0?'<small>'+E('متأخر '+num(issue.daysOverdue)+' يوماً')+'</small>':''),fullNotes(issue)];},'الملاحظات وحالات التأخر وملاحظاتها الكاملة','pd-issues-table'):'<p class="pd-unavailable">لا توجد مشاريع تتطلب متابعة ضمن الفحوص المتاحة لهذا النطاق.</p>')+'</section>';
  var comparisonNote=m.comparisonAvailable?'<p class="pd-comparison-note">'+E(history.points&&history.points.length===2?'المقارنة بين '+history.points[0].date+' و'+history.points[1].date:'المقارنة بين لقطتين مؤكدتين ضمن النطاق')+'</p>':'<p class="pd-comparison-note">'+E(m.comparisonReason||history.reason||'المقارنة غير متاحة لهذا النطاق')+'</p>';
  var coverageLegend='<p class="pd-coverage-note pd-preamble">الأشرطة تعرض أعداد المشاريع. مبالغ التوزيع التنظيمي والتصنيف تجمع القيم المالية المسجلة؛ تُحجب أسهم تغير المبالغ والمتوسطات عند نقص القيم في إحدى اللقطتين.</p>';
  return '<div class="portfolio-delivery pd-design-b" lang="ar" dir="rtl">'+comparisonNote+coverageLegend+'<div class="pd-card-grid pd-main-pair">'+distribution+delivery+'</div><div class="pd-card-grid pd-secondary-pair">'+finance+manager+'</div>'+category+issuesHtml+'</div>';
 }
 S.views.portfolioDelivery={render:render};
})(window.Saytara=window.Saytara||{});
