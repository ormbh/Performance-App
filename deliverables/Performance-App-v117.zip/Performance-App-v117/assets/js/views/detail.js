/*
 * Performance reporting · item detail panel
 * Each source column is assigned once to a type-specific section. Additional
 * source columns stay visible; calculated fields are explicitly distinguished.
 */
(function (S) {
  'use strict';

  var U = S.util, SC = S.schema, UI = S.ui, SR = S.search;

  var GROUPS = {
    agenda: [
      ['identity', 'تعريف الموضوع', ['type']],
      ['delivery', 'الإنجاز والمواعيد', ['status', 'quarter', 'month', 'year', 'newMonth', 'dateSac', 'dateEc']],
      ['responsibility', 'المسؤوليات والجهات', ['coord', 'entity', 'entities', 'sector', 'unit']],
      ['updates', 'الملاحظات والمتابعة', ['notes', 'rapporteur']]
    ],
    council: [
      ['identity', 'تعريف القرار', ['no', 'issuer', 'plan', 'letterRef']],
      ['delivery', 'الإنجاز وتواريخ المتابعة', ['status', 'progress', 'year', 'meetingDate', 'letterDate', 'replyDate']],
      ['responsibility', 'المسؤوليات والجهات', ['coord', 'entity', 'entities', 'sector', 'unit']],
      ['updates', 'القرار الأخير والمتابعة', ['latest', 'followup', 'hasReport', 'notes']]
    ],
    legislation: [
      ['identity', 'تعريف التشريع', ['seq', 'mcms', 'nature', 'stage', 'issuance', 'state']],
      ['delivery', 'تواريخ التشريع', ['received', 'assigned', 'slc', 'ext', 'deptDate', 'actual', 'sent', 'year', 'legislationMonth']],
      ['responsibility', 'الجهة المرسلة والمسؤوليات', ['sender', 'sector', 'unit']],
      ['updates', 'المستجدات والمتابعة', ['updates']],
      ['performance', 'مؤشرات التوقيت', ['kpi', 'late', 'overrun']]
    ],
    special: [
      ['identity', 'تعريف المشروع', ['lead', 'desc']],
      ['delivery', 'الإنجاز والجدول الزمني', ['status', 'progress', 'startMonth', 'startYear', 'endMonth', 'endYear']],
      ['responsibility', 'المسؤوليات والجهات', ['pm', 'entity', 'entities', 'sector', 'unit', 'units']],
      ['updates', 'المستجدات والخطوات المقبلة', ['achieved', 'next', 'notes', 'recs']],
      ['finance', 'الميزانية', ['budget']]
    ],
    secretariat: [
      ['identity', 'تعريف المشروع', ['no', 'desc', 'priority', 'ptype']],
      ['delivery', 'الإنجاز والجدول الزمني', ['status', 'progress', 'start', 'end', 'quarter', 'late']],
      ['responsibility', 'المسؤوليات', ['pm', 'sector', 'unit']],
      ['updates', 'الملاحظات والمتابعة', ['ownerRemarks']],
      ['finance', 'الموازنة والأعمال والفواتير', ['approved', 'revised', 'committed', 'nonCommitted', 'workDone', 'spent', 'financeRemarks']]
    ],
    kpi: [
      ['identity', 'الأهداف المرتبطة بالمؤشر', ['strategic', 'operational']],
      ['responsibility', 'ملاك الهدف والمسؤوليات', ['owners', 'sector', 'unit', 'share']],
      ['measurement', 'القياس والنتيجة السنوية', ['freq', 'formula', 'num', 'den', 'result', 'target', 'objWeight', 'weight']],
      ['quarterly', 'نتائج القياس الربعي', ['q1n', 'q1d', 'q1', 'q2n', 'q2d', 'q2', 'q3n', 'q3d', 'q3', 'q4n', 'q4d', 'q4']],
      ['updates', 'الملاحظات', ['notes']]
    ]
  };
  var OPTIONAL_TEXT = ['desc', 'notes', 'rapporteur', 'updates', 'achieved', 'next', 'recs', 'ownerRemarks', 'financeRemarks'];
  var LABELS = {
    council: { replyDate: 'تاريخ الرد', letterDate: 'تاريخ إصدار خطاب المتابعة' },
    secretariat: { quarter: 'ربع الانتهاء', ownerRemarks: 'ملاحظات مدير المشروع', approved: 'الموازنة الأصلية', revised: 'الموازنة المعتمدة المعدلة', committed: 'المخصص', nonCommitted: 'غير المخصص', workDone: 'قيمة الأعمال المنجزة', spent: 'المنفق الفعلي حسب الفواتير' }
  };

  function hasValue(v) { return v !== null && v !== undefined && String(v).trim() !== ''; }
  function calcValue(it, field) {
    var calc = it.calc || {};
    if (it.pf === 'secretariat' && field === 'quarter') return U.quarterLabel(calc.quarter);
    if (it.pf === 'secretariat' && field === 'late') return calc.late ? 'متأخر' : '';
    if (it.pf === 'legislation' && field === 'legislationMonth') { var month = calc.legislationMonth; return month ? month.label || 'غير متاح · ' + month.reason : ''; }
    if (it.pf === 'legislation' && field === 'late') return calc.late ? 'متأخر' : '';
    if (it.pf === 'legislation' && field === 'overrun') return calc.overrun ? 'تجاوز الموعد وفق التاريخ المسجل' : '';
    return '';
  }
  function valueOf(it, x) {
    if (x.calc) return calcValue(it, x.field);
    if (it.pf === 'secretariat' && ['start', 'end'].indexOf(x.field) >= 0) return U.monthLabel(x.value);
    return SC.value(x.field, x.value);
  }
  function displayMarkup(value) {
    return /^\d{2}\/\d{2}\/\d{4}$/.test(String(value)) ? '<bdi dir="ltr">' + U.esc(value) + '</bdi>' : U.esc(value);
  }
  function fieldLabel(it, x) { return x.field === 'title' ? UI.contentLabel(it) : LABELS[it.pf] && LABELS[it.pf][x.field] || x.label; }

  /* Work from the actual columns, including repeated headers and unmapped extras.
     Do not replace the row with a schema-only subset or duplicate it in a raw dump. */
  function groupsOf(it) {
    var used = {}, all = it.all || [], groups = [];
    (GROUPS[it.pf] || []).forEach(function (def) {
      var fields = [];
      def[2].forEach(function (field) {
        all.forEach(function (x, index) {
          if (x.field !== field || used[index]) return;
          used[index] = true;
          if (OPTIONAL_TEXT.indexOf(field) >= 0 && !hasValue(valueOf(it, x))) return;
          fields.push(x);
        });
      });
      if (fields.length) groups.push({ id: def[0], title: def[1], fields: fields });
    });
    var extra = [];
    all.forEach(function (x, index) {
      // The heading carries the source title; all other mapped columns remain.
      if (used[index] || x.field === 'title') return;
      if (x.field || hasValue(valueOf(it, x))) extra.push(x);
    });
    if (extra.length) groups.push({ id: 'additional', title: 'حقول إضافية من المصدر', fields: extra });
    return groups;
  }

  function fieldMarkup(it, x) {
    var value = valueOf(it, x), label = fieldLabel(it, x);
    return '<div' + (x.field ? ' data-source-field="' + U.esc(x.field) + '"' : '') + ' data-source-label="' + U.esc(x.label) + '">' +
      '<dt dir="auto">' + U.esc(label) + (x.calc ? ' <span class="calc-tag">محسوب</span>' : '') + '</dt>' +
      '<dd dir="auto">' + (hasValue(value) ? displayMarkup(value) : '<span class="muted">' + (x.calc ? '—' : 'غير مسجل') + '</span>') + '</dd></div>';
  }
  function derivedField(label, value) {
    return '<div><dt>' + U.esc(label) + ' <span class="calc-tag">محسوب</span></dt><dd dir="auto">' + displayMarkup(value) + '</dd></div>';
  }

  function sectionNote(it, id) {
    if (id === 'delivery' && it.pf === 'secretariat') return 'اسم الشهر وحده لا يحدد يوماً أو سنة في المصدر؛ حساب الربع والتأخر يستخدم سنة المرجع للتواريخ الشهرية فقط، والتاريخ الكامل يحتفظ بسنته.';
    if (id === 'performance' && it.pf === 'legislation') return 'مؤشرات التوقيت مستقلة عن حالة التشريع. «في الموعد» و«تجاوز الموعد» لا يثبتان الإغلاق؛ تُعرض الحالة المسجلة في قسم تعريف التشريع.';
    if (id === 'delivery' && it.pf === 'council') return 'تاريخ الرد هو تاريخ مسجل للرد، وليس موعد تسليم.';
    if (id === 'finance' && it.pf === 'secretariat') return 'قيمة الأعمال المنجزة والمنفق حسب الفواتير قياسان مستقلان كما وردا في المصدر.';
    if (id === 'measurement') {
      return 'النتيجة والمستهدف قيمتا قياس؛ لا تعبران عن نسبة إنجاز المشروع أو عن اتجاه أداء المؤشر.' +
        (it.c && it.c.result && it.c.result.t === 'n' && it.c.result.v === 0 ?
          it.calc && it.calc.measured ? ' نتيجة العام 0% مقاسة وفق حالة القياس المسجلة.' :
          it.calc && it.calc.measurementStateExplicit ? ' نتيجة العام 0% محفوظة؛ حالة القياس المسجلة تحدد احتسابها، ولا تعني القيمة وحدها أنها مقاسة.' :
          ' نتيجة العام 0% مسجلة في المصدر؛ لا تدخل ضمن النتائج المقاسة وفق القالب القديم لغياب حالة قياس صريحة.' : '');
    }
    if (id === 'updates' && it.pf === 'council' && S.rules && !S.rules.test('councilTotal', it)) return 'هذا القرار لا يدخل في إجمالي قرارات التقرير وفق قواعد متطلبات المتابعة.';
    return '';
  }

  function renderGroup(it, group) {
    var fields = group.fields.map(function (x) { return fieldMarkup(it, x); }).join('');
    if (group.id === 'responsibility' && it.classification) fields += derivedField('القطاع حسب قائمة الوحدات التنظيمية', it.sector);
    if (group.id === 'delivery' && it.pf === 'legislation' && it.calc && it.calc.deadline != null) fields += derivedField('الموعد المستخدم لحساب التأخر', U.fmtDate(it.calc.deadline));
    var note = sectionNote(it, group.id);
    return '<section class="det-sec det-group" data-detail-group="' + group.id + '" aria-labelledby="det-group-' + group.id + '">' +
      '<h3 id="det-group-' + group.id + '">' + U.esc(group.title) + '</h3>' +
      (note ? '<p class="det-src">' + U.esc(note) + '</p>' : '') + '<dl class="det-all">' + fields + '</dl></section>';
  }

  function sourceRows(it, data) {
    var rows = [], meta = data && data.meta && data.meta[it.pf];
    if (data && data.file && data.file.name) rows.push(['ملف المصدر', data.file.name]);
    rows.push(['ورقة المصدر', it.sheet], ['رقم الصف في المصدر', it.row]);
    if (meta && meta.via === 'table' && meta.table) rows.push(['جدول المصدر', meta.table]);
    if (meta && meta.via === 'sheet') rows.push(['طريقة القراءة', 'قراءة الورقة من الصف الأول لعدم وجود جدول Excel المتوقع']);
    if (hasValue(it.recordId)) rows.push(['المعرف الثابت في المصدر', it.recordId]);
    if (!it.hasTitle) rows.push([UI.contentLabel(it) + ' في المصدر', hasValue(it.t && it.t.title) ? it.t.title : 'غير مسجل']);
    var sourceDate = data && (data.sourceValidationDate != null ? data.sourceValidationDate : data.savedReportDate);
    if (data) {
      rows.push([data.sourceDateKind === 'live' ? 'القيمة المحفوظة لصيغة TODAY (ليست تاريخ لقطة)' : 'التاريخ المرجعي المحفوظ في المصدر (ValidationDate)', U.fmtDate(sourceDate) || 'غير متاح في المصدر']);
      if (sourceDate != null) rows.push(['مرجع التاريخ في المصدر', data.cutoffSource || 'Dashboards!B1']);
      var calculationDate = it.pf === 'legislation' ? data.validationDate : data.today;
      rows.push(['التاريخ المرجعي للحسابات في العرض', U.fmtDate(calculationDate) || 'غير متاح']);
      rows.push(['نطاق ' + S.terms.words(it).definitePlural, 'الملف المرفوع وفق عوامل التصفية؛ التاريخ المرجعي لا يستبعد ' + S.terms.words(it).definitePlural + ' تلقائياً']);
    }
    if (it.classification) {
      var source = it.classification.source;
      rows.push(['مصدر استكمال القطاع', source ? 'جدول ' + (source.table || 'Departments') + ' · ورقة ' + source.sheet : 'قائمة الوحدات التنظيمية في المصدر']);
    }
    var month = it.calc && it.calc.legislationMonth;
    if (it.pf === 'legislation' && month && month.source && SC.PF.legislation.fields[month.source]) rows.push(['التاريخ المستخدم لحساب شهر التشريع', SC.label(SC.PF.legislation.fields[month.source].h)]);
    return rows;
  }

  function textOf(it, data) {
    var lines = [UI.pfName(it.pf) + ' · #' + it.ref, it.title];
    groupsOf(it).forEach(function (group) {
      lines.push('', group.title);
      group.fields.forEach(function (x) {
        var value = valueOf(it, x);
        lines.push(fieldLabel(it, x) + (x.calc ? ' (محسوب)' : '') + ': ' + (hasValue(value) ? value : x.calc ? '—' : 'غير مسجل'));
      });
      if (group.id === 'responsibility' && it.classification) lines.push('القطاع حسب قائمة الوحدات التنظيمية (محسوب): ' + it.sector);
      if (group.id === 'delivery' && it.pf === 'legislation' && it.calc && it.calc.deadline != null) lines.push('الموعد المستخدم لحساب التأخر (محسوب): ' + U.fmtDate(it.calc.deadline));
      var note = sectionNote(it, group.id); if (note) lines.push(note);
    });
    lines.push('', 'المصدر وطريقة الحساب');
    sourceRows(it, data).forEach(function (row) { lines.push(row[0] + ': ' + row[1]); });
    return lines.join('\n');
  }

  function render(state) {
    var it = state.data && state.data.byKey[state.openKey];
    if (!it) return '';
    var toks = state.lastRes ? state.lastRes.toks : [];
    var sameTitle = (state.data.byPf[it.pf] || []).filter(function (x) { return x !== it && x.hasTitle && it.hasTitle && U.key(x.title) === U.key(it.title); });
    var source = sourceRows(it, state.data);
    return '' +
      '<div class="det-overlay" data-act="close-detail"></div>' +
      '<aside class="detail" role="dialog" aria-modal="true" aria-labelledby="det-title" lang="ar" dir="rtl">' +
      '<div class="det-scroll">' +
      '<div class="det-top"><div class="det-meta"><b><bdi>#' + U.esc(it.ref) + '</bdi></b><span>·</span><span>' + U.esc(UI.pfName(it.pf)) + '</span></div>' +
      '<button type="button" class="det-close" data-act="close-detail" aria-label="إغلاق التفاصيل">' + U.icon('x', 18) + '</button></div>' +
      '<h2 id="det-title" data-source-field="title" data-content-label="' + U.esc(UI.contentLabel(it)) + '" dir="' + (it.dir === 'ltr' ? 'ltr' : 'rtl') + '">' + SR.highlight(it.title, toks) + '</h2>' +
      '<div class="det-chips">' + UI.chips(it, 'lg') + '</div>' +
      groupsOf(it).map(function (group) { return renderGroup(it, group); }).join('') +
      '<section class="det-sec" data-detail-group="source" aria-labelledby="det-group-source"><h3 id="det-group-source">المصدر وطريقة الحساب</h3><dl class="det-all">' +
      source.map(function (row) { return '<div><dt>' + U.esc(row[0]) + '</dt><dd dir="auto">' + displayMarkup(row[1]) + '</dd></div>'; }).join('') + '</dl></section>' +
      (sameTitle.length ? '<section class="det-sec"><h3>تنبيه تشابه العناوين</h3><p class="det-warn">' + U.icon('warn', 15) + 'العنوان نفسه مستخدم في ' + S.terms.words(it).plural + ' أخرى. تشابه العنوان وحده لا يثبت وجود علاقة بينها.</p>' +
        sameTitle.map(function (x) {
          return '<button type="button" class="rel" data-act="open" data-key="' + U.esc(x.key) + '"><b><bdi>#' + U.esc(x.ref) + '</bdi></b><span dir="' + (x.dir === 'ltr' ? 'ltr' : 'rtl') + '">' + U.esc(x.title) + '</span>' + UI.statusChip(x) + '</button>';
        }).join('') + '</section>' : '') +
      '</div><div class="det-foot"><button type="button" class="btn" data-act="copy-item">' + U.icon('file', 17) + 'نسخ البيانات</button>' +
      '<button type="button" class="btn" data-act="close-detail">إغلاق</button></div></aside>';
  }

  S.views.detail = { render: render, textOf: textOf, calcValue: calcValue };
})(window.Saytara = window.Saytara || {});
