/*
 * Performance reporting · upload screen
 * The first screen: pick or drop the report workbook. The file is read on this
 * device only.
 */
(function (S) {
  'use strict';

  var U = S.util;

  var MESSAGES = {
    BROWSER: 'المتصفح الحالي لا يدعم قراءة ملفات Excel. استخدم أحدث إصدار من Microsoft Edge أو Google Chrome أو Safari.',
    OLE: 'تعذّرت قراءة الملف لأنه محمي بكلمة مرور أو بتصنيف حماية، أو محفوظ بصيغة ‎.xls‎ القديمة. احفظ نسخة بصيغة ‎.xlsx‎ دون حماية ثم ارفعها.',
    NOT_XLSX: 'هذا الملف ليس ملف Excel بصيغة ‎.xlsx‎. اختر ملف التقرير نفسه.',
    DAMAGED_XLSX: 'تعذّرت قراءة بنية ملف Excel، أو تكررت أجزاؤه الداخلية. افتح نسخة سليمة واحفظها بصيغة ‎.xlsx‎ ثم أعد اختيارها. يبقى الملف الحالي دون تغيير.',
    FILE_LIMIT: 'حجم الملف يتجاوز حد القراءة المحلية (25 ميغابايت). اختر نسخة أصغر من ملف التقرير. يبقى الملف الحالي دون تغيير.',
    WORKBOOK_LIMIT: 'الملف يتجاوز حدود القراءة المحلية الآمنة. الحد لكل ورقة 100,000 صف و500,000 خلية، ولجزء XML الواحد 16 ميغابايت. اختر نسخة أصغر؛ لم تُحذف أي بيانات من الملف الحالي.',
    NOT_TEMPLATE: 'لم يُعثر في الملف على جداول التقرير (الأجندة السنوية، القرارات، التشريعات، المشاريع). تأكد من رفع ملف «تقرير الأداء والتنفيذ» بالقالب نفسه.',
    GENERIC: 'تعذّرت قراءة الملف. تأكد من أنه ملف التقرير بصيغة ‎.xlsx‎ ثم حاول مرة أخرى.'
  };

  function message(err) { return MESSAGES[err && err.code] || MESSAGES.GENERIC; }

  function render(state) {
    var u = state.upload, busy = u.status === 'loading';
    var body = '';
    if (busy) {
      body = '<div class="up-status" role="status"><span class="spinner" aria-hidden="true"></span>جارٍ قراءة الملف…</div>';
    } else if (u.status === 'error') {
      body = '<div class="up-error" role="alert">' + U.icon('warn', 20) + '<div><b>تعذّر تحميل الملف</b><p>' + U.esc(u.error) + '</p></div></div>';
    }
    var back = state.data && !busy ?
      '<button class="btn" data-act="go-home">' + U.icon('right', 17) + 'العودة إلى الملف الحالي</button>' : '';

    return '' +
      '<div class="screen upload" data-screen="upload">' +
      '  <div class="mash-bg" aria-hidden="true"></div>' +
      S.ui.appHeader(state, 'upload') + '<main class="up-center">' +
      '    <p class="up-lead">التقرير الشهري للأداء والتنفيذ</p>' +
      '    <div id="dropzone" class="dropzone' + (busy ? ' is-busy' : '') + '" role="button" tabindex="0" data-act="pick-file" aria-label="اختيار ملف Excel للتقرير" aria-describedby="up-hint">' +
      '      <span class="dz-icon">' + U.icon('upload', 28) + '</span>' +
      '      <span class="dz-title">اسحب ملف Excel وأفلته هنا</span>' +
      '      <span class="dz-or">أو</span>' +
      '      <span class="btn btn-primary">' + U.icon('file', 18) + 'اختيار ملف التقرير</span>' +
      '      <span class="dz-hint" id="up-hint">ملف تقرير الأداء والتنفيذ · ‎.xlsx‎</span>' +
      '    </div>' +
      body +
      '    <button class="btn" data-act="go-comparison">المقارنة الشهرية</button>' +
      '    <p class="privacy">' + U.icon('lock', 16) + 'يُقرأ الملف على هذا الجهاز فقط، ولا يُرسل إلى أي جهة.</p>' +
      back +
      '  </main>' +
      '  <input type="file" id="file-input" class="visually-hidden" accept=".xlsx,.xlsm,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" tabindex="-1" aria-hidden="true">' +
      '</div>';
  }

  S.views = S.views || {};
  S.views.upload = { render: render, message: message };
})(window.Saytara = window.Saytara || {});
