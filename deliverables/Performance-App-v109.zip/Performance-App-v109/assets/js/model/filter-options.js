/* Filter presentation only. Source strings, IDs, workbook comparisons and
   snapshot identity retain their original values. One choice can select every
   original token that differs only in invisible/presentation formatting. */
(function(S){
 'use strict';
 var U=S.util;
 function display(value){
  var text=String(value==null?'':value).normalize('NFC');
  // Fold Arabic presentation glyphs only, retaining spelling and diacritics.
  text=text.replace(/[\uFB50-\uFDFF\uFE70-\uFEFC]/g,function(c){return c.normalize('NFKC');});
  return text.replace(/[\u00AD\u061C\u200B-\u200F\u202A-\u202E\u2060\u2066-\u2069\uFEFF]/g,'').replace(/\s+/g,' ').trim();
 }
 function key(value){return display(value).toLowerCase();}
 function unique(values){return Array.from(new Set(values));}
 function sourceAliases(state,id,values){
  var field=id.slice(2),prefix=id[0],mapped={projectType:'ptype',projectStatus:'status',lead:'lead',legislationMonth:'legislationMonth'},sourceField=mapped[field]||field;
  if(prefix==='e'&&['role','areas'].includes(field))return values;
  // Options use readable text; exact workbook scopes sometimes compare the
  // untrimmed cell. Keep both tokens in the same choice. In particular FEFF is
  // removed by String.trim() in displayed text but survives Excel equality.
  var allowed=new Map((values||[]).map(function(o){var v=o!=null&&typeof o==='object'?o.v:o;return [key(v),o!=null&&typeof o==='object'?o.label:String(v==null?'':v)];}));
  var datasets=[state.data];if(prefix==='d'||prefix==='c'||prefix==='e')datasets.push(state.previous);
  var records=datasets.filter(Boolean).flatMap(function(d){return d.items||[];});
  if(prefix==='d'&&state.data&&state.data.snapshot)records=records.concat(state.data.snapshot.rows||[]);
  if(prefix==='p')records=records.filter(function(it){return it.pf==='secretariat';});
  if(prefix==='r'){var pf={projects:'secretariat',hh:'special',agenda:'agenda',council:'council'}[(state.report||{}).kind];if(pf)records=records.filter(function(it){return it.pf===pf;});}
  var aliases=[],seen=new Set();
  function add(value){
   if(value==null||!['string','number'].includes(typeof value))return;
   var token=String(value),k=key(token);if(!allowed.has(k)||seen.has(token))return;
   seen.add(token);aliases.push({v:token,label:allowed.get(k)});
  }
  records.forEach(function(it){
   var actualField=sourceField==='entity'&&it.pf==='legislation'?'sender':sourceField;
   add(it[field]);add(it.t&&it.t[actualField]);add(it.x&&it.x[actualField]);
   var cell=it.c&&it.c[actualField];if(cell&&cell.t!=='e')add(cell.v);
   if(field==='projectStatus'||field==='status')add(it.statusLabel);
   if(field==='quarter')add(it.calc&&it.calc.quarter);
   if(field==='legislationMonth')add(it.calc&&it.calc.legislationMonth&&it.calc.legislationMonth.key);
   if(field==='entity'&&prefix==='d'&&S.rules&&S.schema&&S.schema.PF[it.pf])add(S.rules.concernedEntity(it));
  });
  // Alias metadata has no population count: adding the underlying token must
  // not count a source row twice in the visible option's facet total.
  return (values||[]).concat(aliases);
 }
 function group(values,selected){
  var selection=U.selection(selected),chosen=new Set(selection),map=new Map(),out=[];
  (values||[]).forEach(function(value){
   var opt=value!=null&&typeof value==='object'?value:{v:String(value==null?'':value),label:String(value==null?'':value)||'غير مسجل'};
   var token=String(opt.v==null?'':opt.v),k=key(token),g=map.get(k);
   if(!g){g={v:token,key:k,label:display(opt.label==null?token:opt.label)||'غير مسجل',variants:[],stale:true};map.set(k,g);out.push(g);}
   if(g.variants.indexOf(token)<0){
    g.variants.push(token);
    if(typeof opt.n==='number'&&Number.isFinite(opt.n))g.n=(g.n||0)+opt.n;
   }
   if(!opt.stale)g.stale=false;
  });
  // Keep saved exact tokens even when their spelling is no longer in this
  // scope. They are not silently widened on loading or merely opening a menu.
  selection.forEach(function(token){
   var k=key(token),g=map.get(k);
   if(!g){g={v:token,key:k,label:display(token)||'غير مسجل',variants:[],stale:true};map.set(k,g);out.unshift(g);}
   if(g.variants.indexOf(token)<0)g.variants.push(token);
  });
  var labels=new Map();out.forEach(function(g){var k=key(g.label);if(!labels.has(k))labels.set(k,[]);labels.get(k).push(g);});
  out.forEach(function(g){
   // Equal translated labels can conceal genuinely different source values.
   // Keep separate choices and show the recorded token, rather than merge them.
   if(labels.get(key(g.label)).length>1)g.label+=' ('+(display(g.v)||'قيمة فارغة')+')';
   if(g.stale)g.label+=' (غير موجود ضمن الخيارات الحالية)';
   var n=g.variants.filter(function(v){return chosen.has(v);}).length;
   g.selected=n>0;g.partial=n>0&&n<g.variants.length;
  });
  return out;
 }
 function selectionGroups(values,options){
  var byKey=new Map((options||[]).map(function(o){return [o.key==null?key(o.v):o.key,o];})),seen=new Set();
  return U.selection(values).filter(function(v){var k=key(v);if(seen.has(k))return false;seen.add(k);return true;}).map(function(v){return byKey.get(key(v))||{v:v,key:key(v),label:display(v)||'غير مسجل',variants:[v],selected:true};});
 }
 function count(values,options){return selectionGroups(values,options).length;}
 function single(values){var groups=selectionGroups(values);return groups.length===1?display(groups[0].v):null;}
 function text(values,options,all){var groups=selectionGroups(values,options);return groups.length?groups.map(function(o){return o.label;}).join('، '):all||'';}
 function remove(values,value){var k=key(value);return U.selection(values).filter(function(v){return key(v)!==k;});}
 function toggle(values,option,checked){var tokens=remove(values,option.v);return checked?unique(tokens.concat(option.variants||[option.v])):tokens;}
 function all(options){return unique((options||[]).filter(function(o){return !o.stale;}).flatMap(function(o){return o.variants||[o.v];}));}
 S.filterOptions={display:display,key:key,sourceAliases:sourceAliases,group:group,selectionGroups:selectionGroups,count:count,single:single,text:text,remove:remove,toggle:toggle,all:all};
})(window.Saytara=window.Saytara||{});
