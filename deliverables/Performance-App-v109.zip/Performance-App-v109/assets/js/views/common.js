/*
 * Performance reporting · shared view pieces
 * Status chips, timing badges, progress bars and the tooltip registry.
 */
(function (S) {
  'use strict';

  var U = S.util, SC = S.schema;

  var HEALTH = {
    delayed: { ar: 'متأخر', icon: 'clock-alert' },
    doneOnTime: { ar: 'ضمن الموعد بحسب المؤشر', icon: 'check' },
    doneLate: { ar: 'تجاوز الموعد', icon: 'check-clock' },
    clear: { ar: 'بدون تأخير', icon: 'check-circle' }
  };

  // Generated UI wording only; workbook labels, values and identifiers stay literal.
  function recordWord(pf, form) {
    var words = S.terms.words(pf);
    return words[form || 'definite'] || words.definite;
  }

  // Type belongs to generated field labels, never to the source title value.
  function contentLabel(itemOrPf) {
    var pf = typeof itemOrPf === 'string' ? itemOrPf : itemOrPf && itemOrPf.pf;
    return SC.PF[pf] ? recordWord(pf, 'definite') : 'العنوان';
  }
  function contentHeader(items, fallbackPortfolios) {
    var rows = Array.isArray(items) ? items : [];
    var types = rows.length ? rows : U.selection(fallbackPortfolios);
    var labels = Array.from(new Set(types.map(contentLabel)));
    return labels.length === 1 ? labels[0] : 'العنوان';
  }

  function statusChip(it, size) {
    if (!it.statusLabel) return '<span class="st st-none">—</span>';
    var cat = it.statusCat;
    // Text colors keep the status hue, with readable darker tints for pale chart fills.
    var inks={'قيد المراجعة':'6E675B','لم يبدأ':'6E675B','جاهز للعرض':'00766D','قيد التطوير':'706659','قيد العمل':'706659','جاري العمل':'706659','منجز':'115E67','متأخر':'651D32','ملغى':'651D32','معلق':'666666','حالات أخرى':'666666'};
    var ink=inks[it.statusLabel]||({review:'6E675B',progress:'706659',ready:'00766D',done:'115E67',delayed:'651D32',cancelled:'651D32',hold:'666666',notStarted:'6E675B',transferred:'6E675B'}[cat])||'4F4E4E';
    return '<span class="st st-' + cat + (size ? ' st-' + size : '') + '" style="color:#'+ink+'">' +
      '<span dir="auto">' + U.esc(it.statusLabel) + '</span></span>';
  }

  function healthChip(key, n, size) {
    var h = HEALTH[key];
    if (!h) return '';
    return '<span class="hl hl-' + key + (size ? ' hl-' + size : '') + '">' + U.icon(h.icon, size === 'lg' ? 15 : 14) + h.ar +
      (n != null && n !== '' ? ' <span class="num">' + U.esc(n) + '</span>' : '') + '</span>';
  }

  /* Status plus timing; a status that already says "متأخر" is not repeated. */
  function chips(it, size) {
    var dup = it.statusCat === 'delayed' && it.health === 'delayed';
    return statusChip(it, size) + (it.health && !dup ? healthChip(it.health, null, size) : '');
  }

  /* Progress cell: % complete for projects and decisions, result vs target for KPIs. */
  function progressReading(value) {
    var text=U.displayNumber(value,1,'%');
    return value===0?'<span data-value-state="zero" title="صفر بالمئة" aria-label="صفر بالمئة">-</span>':U.esc(text);
  }
  function progress(it, big) {
    if (it.pf === 'kpi') {
      var r = it.calc.resultRecorded, t = it.calc.targetRecorded;
      if (r == null) return '<span class="prog-none">' + (it.c.result ? 'نتيجة غير رقمية' : 'غير مسجل') + '</span>';
      var rp = Math.round(r * 100), tp = t != null ? Math.round(t * 100) : null;
      var fill = tp == null ? 'var(--info)' : rp >= tp ? 'var(--ok)' : 'var(--warn)';
      return '<div class="prog' + (big ? ' prog-lg' : '') + '"><div class="prog-label">' + progressReading(r*100) + (tp != null ? ' · المستهدف ' + progressReading(t*100) : '') + '</div>' +
        '<div class="prog-bar"><span style="width:' + Math.max(0, Math.min(100, rp)) + '%;background:' + fill + '"></span>' +
        (tp != null ? '<i class="prog-mark" style="inset-inline-start:' + Math.max(0, Math.min(100, tp)) + '%" title="المستهدف"></i>' : '') + '</div></div>';
    }
    if (it.progress == null) {
      var has = it.pf === 'special' || it.pf === 'secretariat' || it.pf === 'council';
      return '<span class="prog-none">' + (has ? 'غير مسجلة' : '—') + '</span>';
    }
    var p = Math.round(it.progress);
    var col = it.statusCat === 'done' ? 'var(--done)' : it.health === 'delayed' || it.statusCat === 'delayed' ? 'var(--bad)' : 'var(--info)';
    return '<div class="prog' + (big ? ' prog-lg' : '') + '"><div class="prog-label">' + progressReading(it.progress) + '</div>' +
      '<div class="prog-bar"><span style="width:' + Math.max(0, Math.min(100, p)) + '%;background:' + col + '"></span></div></div>';
  }

  function pfName(pf) { return SC.PF[pf] ? SC.PF[pf].ar : pf; }

  function drillCue() { return ''; }

  /* File names mix Arabic, digits and ".xlsx"; keep the extension in its own
     left-to-right run so "سبتمبر 2026.xlsx" does not show as "xlsx.2026". */
  function fileName(name) {
    var n = String(name || ''), dot = n.lastIndexOf('.');
    if (U.dirOf(n) === 'ltr' || dot <= 0) return '<bdi dir="' + U.dirOf(n) + '">' + U.esc(n) + '</bdi>';
    return '<bdi dir="rtl">' + U.esc(n.slice(0, dot)) + '</bdi><bdi dir="ltr">' + U.esc(n.slice(dot)) + '</bdi>';
  }

  /* Source identity and calculation context remain available at the footer. */
  function searchSource(state) { return ''; }
  function sourceFooter(state) {
    var data=state.data;if(!data)return '';
    var date=data.referenceDateReady&&U.validDateSerial(data.today)?U.fmtDate(data.today):'لم يُحدَّد';
    var reference=U.validDateSerial(data.sourceValidationDate)?data.sourceValidationDate:data.savedReportDate;
    return '<footer class="app-source-footer" aria-label="مصدر البيانات وتاريخ الحساب"><div class="app-source-footer-in"><span class="source-footer-file"><span class="source-footer-label">ملف البيانات</span><strong>'+fileName(data.file&&data.file.name||'ملف غير مسمى')+'</strong></span><span class="source-footer-date"><span class="source-footer-label">تاريخ الحساب</span><bdi dir="ltr">'+U.esc(date)+'</bdi></span>'+(U.validDateSerial(reference)&&reference!==data.today?'<span class="source-footer-reference"><span class="source-footer-label">مرجع الملف</span><bdi dir="ltr">'+U.esc(U.fmtDate(reference))+'</bdi></span>':'')+'</div></footer>';
  }


  /* Shared navigation keeps the same routes/actions across every working screen.
     Primary destinations stay distinct from file, validation and export utilities. */
  function appHeader(state, current) {
    var hasData = !!state.data, busy = !!state.reporting;
    var nav = '', utilities = '';
    function destination(key, action, text, icon) {
      var screen = key === 'search' ? 'home' : key;
      var href = S.app && S.app.href ? S.app.href(screen) : '#/' + screen;
      return '<a href="' + U.esc(href) + '" data-screen-link="' + screen + '" class="app-nav-item' + (current === key ? ' is-current' : '') + '" data-act="' + action + '"' + (current === key ? ' aria-current="page"' : '') + '>' + (icon ? U.icon(icon, 17) : '') + text + '</a>';
    }
    if (hasData) {
      nav = destination('search', 'go-home', 'البحث', 'search') +
        destination('dashboard', 'go-dash', 'التقرير الشهري', 'grid') +
        destination('projects', 'go-projects', 'محفظة المشاريع', 'rows') +
        destination('entities', 'go-entities', 'تقرير الجهات', 'entities') +
        destination('comparison', 'go-comparison', 'المقارنة الشهرية', 'compare');
      if (S.views.reports && S.views.reports.menu) nav += '<div class="app-report-nav' + (current === 'reports' ? ' is-current' : '') + '">' + S.views.reports.menu(state) + '</div>';
    }
    if (hasData) {
      var n = (state.data.issues||[]).filter(function (x) { return x.sev !== 'info'; }).length;
      utilities += '<button type="button" class="btn app-utility" data-act="go-checks">' + U.icon('warn', 17) + 'ملاحظات البيانات <span class="badge">' + n + '</span></button>' +
        '<button type="button" class="btn app-utility" data-act="change-file">' + U.icon('upload', 17) + 'تغيير الملف</button>';
    }
    if (current === 'reports') {
      var kind = state.report.kind;
      if (kind === 'hh' || kind === 'agenda' || kind === 'council') utilities += '<button type="button" class="btn app-utility" data-act="' + (kind === 'hh' ? 'hh-report' : kind === 'council' ? 'council-report' : 'agenda-report') + '"' + (busy ? ' disabled' : '') + '>' + U.icon('download', 17) + (busy ? 'جارٍ إعداد PowerPoint…' : 'تنزيل PowerPoint') + '</button>';
      utilities += '<button type="button" class="btn app-utility" data-act="print">' + U.icon('print', 17) + 'طباعة / حفظ PDF</button>';
    }
    if (current === 'comparison') utilities += '<button type="button" class="btn app-utility" data-act="reset-comparison">' + U.icon('refresh', 17) + 'مسح المقارنة</button>';
    var brandScreen = hasData ? 'dashboard' : 'upload';
    return '<a class="app-skip-link" href="#app-main" data-act="skip-content">انتقل إلى المحتوى</a><header class="wb-topbar app-header'+(state.navOpen?' is-nav-open':'')+'"><div class="wb-topbar-in app-header-in"><a href="#/'+brandScreen+'" class="wb-brand" data-screen-link="'+brandScreen+'" data-act="' + (hasData ? 'go-dash' : 'change-file') + '" aria-label="'+(hasData?'التقرير الشهري':'رفع الملف')+'"><img class="tec-logo" src="assets/img/tec-red.png" alt="المجلس التنفيذي — The Executive Council"></a>'+(hasData?'<button type="button" class="btn app-menu-toggle" aria-label="أدوات الصفحة" data-act="toggle-nav" aria-controls="app-page-tools" aria-expanded="'+!!state.navOpen+'">'+U.icon('rows',20)+'<span>أدوات الصفحة</span></button>':'')+'<div id="app-navigation" class="app-navigation"><nav class="app-nav" aria-label="التنقل الرئيسي">' + nav + '</nav>' + (utilities ? '<div id="app-page-tools" class="app-utilities" role="group" aria-label="أدوات الصفحة">' + utilities + '</div>' : '') + '</div></div></header>';
  }

  // All report kinds use the same scope controls and reset action. Extra
  // controls are supplied by the owning report; dashboard markup is unchanged.
  function reportFilterControls(state, dashboard, extra) {
    return state.report.kind==='council' ? S.views.dashboard.filterBar(state,dashboard,true,extra) : S.views.dashboard.filterBar(state,dashboard,true)+(extra||'');
  }
  // Both binary leadership values mean an unconstrained report, including
  // records whose source flag is blank. Keep explicit single/blank values.
  function reportLeadSelection(value) {
    var selected=U.selection(value),keys=selected.map(S.filterOptions.key);
    return keys.includes(S.filterOptions.key('نعم'))&&keys.includes(S.filterOptions.key('لا'))?'':U.selectionState(selected);
  }
  // One disclosure pattern across views. Opening is a presentation preference;
  // it never changes selections, result counts, routing, or export scope.
  function filterPanel(state, options) {
    var id=String(options.id||'scope').replace(/[^a-z0-9-]/gi,'-');
    var open=!!(state.filterPanels&&state.filterPanels[id]);
    var heading='filters-'+id+'-title', controls='filters-'+id+'-controls';
    var active=Math.max(0,Number(options.activeCount)||0);
    return '<section class="ui-filter-panel'+(open?' is-open':'')+'" data-filter-panel="'+id+'" aria-labelledby="'+heading+'">'+
      '<div class="ui-filter-header"><div class="ui-filter-title"><h2 id="'+heading+'" class="visually-hidden">'+U.esc(options.title||'عوامل التصفية')+'</h2><span class="ui-scope-label">النطاق</span><p class="ui-filter-summary" role="status" aria-live="polite" aria-atomic="true"><bdi dir="auto">'+U.esc(options.summary||'الكل')+'</bdi></p></div>'+
      '<div class="ui-filter-actions">'+(active&&options.resetAction?'<button type="button" class="dbtn ui-filter-reset" data-act="'+U.esc(options.resetAction)+'"'+(state.reporting?' disabled':'')+'>'+U.esc(options.resetLabel||'مسح التصفية')+'</button>':'')+'<button type="button" class="dbtn ui-filter-toggle" data-act="toggle-filters" data-filter-panel="'+id+'" aria-expanded="'+open+'" aria-controls="'+controls+'"><span class="ui-filter-toggle-label">'+(open?'إغلاق التصفية':'تصفية')+'</span>'+(active?'<span class="ui-filter-count" aria-label="'+U.esc('عدد عوامل التصفية النشطة: '+active)+'">'+U.fmtN(active)+'</span>':'')+U.icon(open?'up':'down',18)+'</button></div></div>'+
      '<div class="ui-filter-body" id="'+controls+'"'+(open?'':' hidden')+'>'+(options.body||'')+'</div></section>';
  }
  function multiSelect(state,id,label,value,values) {
    var F=S.filterOptions,sel=U.selection(id==='r:lead'?reportLeadSelection(value):value),opts=F.group(F.sourceAliases(state,id,values),sel),groups=F.selectionGroups(sel,opts),open=state.menu===id;
    state.multiOptions=state.multiOptions||{};state.multiOptions[id]=opts;
    var ident='multi-'+id.replace(/[^a-z0-9-]/gi,'-'),text=groups.length===1?groups[0].label:groups.length?'القيم المحددة: '+groups.length:'الكل';
    var query=state.multiSearch&&state.multiSearch[id]||'',needle=U.norm(F.display(query)),matching=opts.filter(function(o){return !needle||U.norm(o.label).includes(needle);}).length;
    return '<div class="menu-wrap multi-wrap" data-multi-wrap="'+U.esc(id)+'"><button type="button" class="dbtn multi-trigger'+(groups.length?' is-active':'')+'" data-act="menu" data-menu="'+U.esc(id)+'" aria-expanded="'+open+'"'+(open?' aria-controls="'+ident+'"':'')+' aria-label="'+U.esc(label+': '+(groups.length?F.text(sel,opts):'الكل'))+'"'+(state.reporting?' disabled':'')+'><span class="muted">'+U.esc(label)+'</span><b dir="auto">'+U.esc(text)+'</b>'+U.icon('down',16)+'</button>'+(open?'<div id="'+ident+'" class="menu menu-check multi-menu" role="group" aria-label="'+U.esc(label)+'"><div class="multi-menu-heading"><strong>'+U.esc(label)+'</strong><button type="button" class="multi-close" data-act="close-multi" data-multi="'+U.esc(id)+'" aria-label="إغلاق خيارات '+U.esc(label)+'">'+U.icon('x',18)+'</button></div><label class="multi-search-label"><span class="visually-hidden">البحث في خيارات '+U.esc(label)+'</span><input type="search" data-multi-search="'+U.esc(id)+'" value="'+U.esc(query)+'" placeholder="البحث في الخيارات" aria-controls="'+ident+'-options"></label><div class="multi-actions"><button type="button" data-act="multi-all" data-multi="'+U.esc(id)+'">تحديد الكل</button><button type="button" data-act="multi-clear" data-multi="'+U.esc(id)+'">مسح التحديد</button><span class="multi-selected-count">'+(groups.length?U.fmtN(groups.length)+' محدد':'الكل')+'</span></div><div class="multi-options" id="'+ident+'-options">'+opts.map(function(o){return '<label class="opt'+(o.stale?' is-stale':'')+'"'+(needle&&!U.norm(o.label).includes(needle)?' hidden':'')+'><input type="checkbox" data-change="multi" data-multi="'+U.esc(id)+'" data-v="'+U.esc(o.v)+'"'+(o.selected&&!o.partial?' checked':'')+(o.partial?' data-multi-partial="true" aria-checked="mixed"':'')+'><span class="opt-l" dir="auto">'+U.esc(o.label)+(o.partial?'<small class="multi-partial-note"> · تحديد جزئي محفوظ</small>':'')+'</span>'+(o.n==null?'':'<span class="opt-n">'+U.metricText(o.n)+'</span>')+'</label>';}).join('')+'</div><p class="multi-empty" role="status"'+(matching?' hidden':'')+'>'+(opts.length?'لا توجد خيارات مطابقة للبحث':'لا توجد قيم ضمن النطاق الحالي')+'</p></div>':'')+'</div>';
  }

  /* Tooltips: views register {title, def, now, base} and mark the element with data-tip. */
  var tips = {};
  var tipSeq = 0;
  function tip(t) { var id = 't' + (++tipSeq); tips[id] = t; return ' data-tip="' + id + '"'; }
  function resetTips() { tips = {}; tipSeq = 0; S.ui.tips = tips; }

  S.views = S.views || {};
  S.ui = {
    recordWord:recordWord, contentLabel:contentLabel, contentHeader:contentHeader, drillCue:drillCue, filterPanel:filterPanel, reportFilterControls:reportFilterControls, reportLeadSelection:reportLeadSelection, multiSelect:multiSelect, statusChip: statusChip, healthChip: healthChip, chips: chips, progress: progress,
    pfName: pfName, fileName: fileName, searchSource:searchSource, sourceFooter:sourceFooter, appHeader: appHeader, HEALTH: HEALTH, tip: tip, resetTips: resetTips, tips: tips
  };
})(window.Saytara = window.Saytara || {});
