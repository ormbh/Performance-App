/* Monthly report context and preparation controls. Calculations stay in the
 * existing loader/controller; this view never changes the workbook or scope. */
(function (S) {
  'use strict';
  var U = S.util;

  function layout(state) { return state.monthly && state.monthly.layout === 'a3' ? 'a3' : 'a4'; }

  function iso(serial) {
    if (!U.validDateSerial(serial)) return '';
    var date = U.ymd(serial);
    return String(date.y).padStart(4, '0') + '-' + String(date.m).padStart(2, '0') + '-' + String(date.d).padStart(2, '0');
  }

  function scope(state) {
    var filters = state.dash || {};
    return [
      { key: 'sector', label: 'القطاع', text: U.selectionText(filters.sector, 'جميع القطاعات') },
      { key: 'unit', label: 'الوحدة التنظيمية', text: U.selectionText(filters.unit, 'جميع الوحدات التنظيمية') },
      { key: 'entity', label: 'الجهة المعنية', text: U.selectionText(filters.entity, 'جميع الجهات المعنية') }
    ];
  }

  function printHint(value) {
    return value === 'a3'
      ? 'A3: الملخص وبنود المتابعة في صفحة واحدة عند كفاية المساحة. تُعرض الملاحظات كاملة وقد تمتد التفاصيل إلى صفحات إضافية.'
      : 'A4: ملخص المؤشرات في الصفحة الأولى، وبنود المتابعة والملاحظات كاملة من الصفحة الثانية. قد تمتد التفاصيل إلى صفحات إضافية.';
  }

  function sourceNote(data) {
    var cached = U.validDateSerial(data.sourceValidationDate) ? data.sourceValidationDate : data.savedReportDate;
    if (data.sourceDateKind === 'live') {
      return 'الملف يستخدم TODAY؛ ' + (data.calculationDateKind === 'live' ? 'الحسابات بحسب تاريخ اليوم.' : 'الحسابات بحسب التاريخ المرجعي المحدد.') +
        ' قيمة TODAY المحفوظة في الملف: ' + (U.validDateSerial(cached) ? U.fmtDate(cached) : 'غير متاحة') + '.';
    }
    if (U.validDateSerial(cached)) return 'التاريخ المرجعي المحفوظ في الملف: ' + U.fmtDate(cached) + '.';
    return 'لا يتوفر تاريخ مرجعي محفوظ في الملف؛ يُستخدم تاريخ الحساب المحدد.';
  }

  function render(state, D) {
    var data=state.data;if(!data)return '';
    var filename=data.file&&data.file.name?data.file.name:'ملف غير مسمى';
    var reference=U.validDateSerial(data.sourceValidationDate)?data.sourceValidationDate:data.savedReportDate;
    return '<div class="monthly-tools monthly-source-line" aria-label="مصدر التقرير وتاريخ الحساب"><span>ملف البيانات: <bdi dir="auto">'+U.esc(filename)+'</bdi></span><span>تاريخ الحساب: <bdi dir="ltr">'+U.esc(U.fmtDate(data.today))+'</bdi></span>'+(U.validDateSerial(reference)&&reference!==data.today?'<span>مرجع الملف: <bdi dir="ltr">'+U.esc(U.fmtDate(reference))+'</bdi></span>':'')+'</div>';
  }
  function settings(state,D) {
    var data=state.data;if(!data)return '';
    var selectedLayout=layout(state),disabled=state.reporting?' disabled':'';
    return '<dialog id="monthly-report-settings" class="monthly-tools monthly-print-dialog" aria-labelledby="monthly-settings-title"><div class="monthly-dialog-head"><h2 id="monthly-settings-title">إعدادات التقرير والطباعة</h2><button type="button" class="monthly-dialog-close" data-act="monthly-settings-close" aria-label="إغلاق إعدادات الطباعة">'+U.icon('x',20)+'</button></div><div class="monthly-settings-body"><div class="monthly-controls"><div class="monthly-date-control"><label for="monthly-date">تاريخ الحساب</label><div class="monthly-date-actions"><input id="monthly-date" name="monthly-date" type="date" data-act="monthly-date" value="'+iso(data.today)+'"'+disabled+'><button type="button" class="dbtn monthly-date-reset" data-act="monthly-date-reset"'+disabled+'>استعادة مرجع الملف</button></div></div><div class="monthly-layout-control"><label for="monthly-layout">تخطيط الطباعة</label><select id="monthly-layout" name="monthly-layout" data-act="monthly-layout"'+disabled+'><option value="a4"'+(selectedLayout==='a4'?' selected':'')+'>A4 أفقي</option><option value="a3"'+(selectedLayout==='a3'?' selected':'')+'>A3 أفقي</option></select></div></div><p class="monthly-settings-note">'+U.esc(sourceNote(data))+'</p><p class="monthly-settings-note">'+U.esc(printHint(selectedLayout))+'</p><p class="monthly-settings-note">تُطبّق الإعدادات مباشرة. تغيير تاريخ الحساب يعيد احتساب التأخر؛ لا يعدّل ملف Excel.</p></div><div class="monthly-dialog-actions"><button type="button" class="btn btn-primary" data-act="monthly-settings-save">حفظ الإعدادات</button></div></dialog>';
  }


  S.monthlyTools = { render: render, settings: settings, layout: layout, iso: iso, scope: scope, printHint: printHint, sourceNote: sourceNote };
})(window.Saytara = window.Saytara || {});
