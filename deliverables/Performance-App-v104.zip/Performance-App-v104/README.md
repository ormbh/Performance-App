# Performance App v104

Extract the complete ZIP, then open `index.html` in your browser. All fonts,
images and scripts are local; no server or installation is required by the app.
Imported data is processed on your device.

## Report workspace

Primary navigation is separate from page tools. A compact scope toolbar shows
active selections even when the filters are closed. Open **تصفية** to select
multiple values and search the option list. Values within one filter form a union;
different filters intersect. **مسح التصفية** resets the scope. Empty selection
means all values. Blank source values remain distinct and available for selection.

Monthly report content appears first. **إعداد التقرير والطباعة**, below the
report, contains the calculation date, restore-source-date action, A4/A3 layout
and print/PDF action. A shortcut beside the monthly title opens these controls.
Source reference, selected calculation date and historical
snapshot dates retain their separate meanings. Other report controls use the same
filter pattern. Source diagnostics and metric definitions follow the content.

No demonstration records, demonstration-file fingerprint, data-purpose selector
or automatic sample classification are included. Retired purpose metadata and
explicitly marked sample caches are cleared during upgrade. Files you import
normally retain the existing local-session behavior. The browser can keep the
imported file in session storage for reload/new-tab workflows; nothing is sent to
an external service. Source files and full notes remain unchanged.

## Measurement and comparison definitions

Annual KPI zeros count as measured only with an explicit measurement-state field:
`حالة القياس`, `Measurement State` or `Measurement Status`. Supported values:
`مقاس`/`Measured`, `غير مقاس`/`Unmeasured`, `لا ينطبق`/`Not applicable`.
Absent or blank state retains the existing nonzero measurement rule. Invalid,
missing, not-applicable and conflicting states are distinguished. Incompatible
measurement definitions withhold comparisons and show the reason. Result and
target averages use their separate source populations; thresholds and weighting
are not invented. Recorded zero is displayed as0; unavailable values as an em dash;
unchanged comparison indicators stay blank.

The application reads cached Excel formula results. It does not recalculate all
Excel formulas or refresh Power Query. Named tables and valid renamed sheets are
supported. Ambiguous identifiers are retained for review and excluded from
resolved historical matches rather than merged by title or row number.

## Upgrade and verification

Keep the prior app and browser data until you have checked your notes/settings.
Use the same browser/profile and location where possible. Full note text and
existing storage keys are preserved. File-origin storage behavior varies between
browsers; back up notes before moving folders or changing profiles.

Browser execution over local HTTP, responsive RTL layouts, keyboard interactions,
scoped imports/filters/CSV and generated monthly PDFs were tested in the delivery
review. Default detailed-report titles have no fixed sample year; the displayed period
defaults to the selected calculation cutoff. User-entered titles/periods are preserved.
Native file-opening is blocked by the managed test browser, so Windows
Edge double-click startup, Microsoft PowerPoint interactive editing, physical
printing and full screen-reader certification remain not run. This is not a claim
of unconditional production readiness.

Readable source modules are bundled locally by `python tools/build-bundles.py`.
`python tools/build-bundles.py --check` checks bundle consistency.
