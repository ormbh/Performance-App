/*
 * Performance reporting · shared helpers
 * Text normalisation, Excel date serials, number formatting, small DOM helpers.
 */
(function (S) {
  'use strict';

  var ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return ESC[c]; });
  }

  /* Comparison key. Mirrors Excel's TRIM(SUBSTITUTE(x, CHAR(160), " ")) and its
     case-insensitive "=" so that dropdown values compare the way the workbook does. */
  function key(v) {
    if (v == null) return '';
    return String(v).replace(/ /g, ' ').replace(/\s+/g, ' ').trim().toLowerCase();
  }

  /* Follow-up tables leave missing cells empty without changing their source.
     Match whole placeholders only: recorded zero and descriptive notes remain. */
  function tableCellText(v) {
    var k = key(v);
    return !k || ['غير مسجل', 'قطاع غير مسجل', 'غير متاح'].indexOf(k) >= 0 || /^[-‐‑‒–—−]+$/.test(k) ? '' : String(v);
  }

  /* Excel's "=" on a cell: text compares case-insensitively with spaces kept;
     numbers and booleans never equal text. Used by the report rules. */
  function xl(cell) {
    if (!cell || cell.t === 'e') return '';
    if (cell.t === 's') return String(cell.v).toLowerCase();
    if (cell.t === 'n') return '\u0000n' + cell.v;
    return '\u0000b' + cell.v;
  }

  /* Excel's TRIM (spaces only), optionally after SUBSTITUTE(x, CHAR(160), " "). */
  function xlTrim(v, nbsp) {
    var s = String(v == null ? '' : v);
    if (nbsp) s = s.replace(/ /g, ' ');
    return s.replace(/^ +| +$/g, '').replace(/ {2,}/g, ' ');
  }

  /* Search normalisation (design rule): ignore diacritics and tatweel, treat
     أ إ آ as ا, ة as ه, ى as ي, ؤ as و, ئ as ي, and read Arabic-Indic digits as 0-9. */
  function normChar(c) {
    if (/[ً-ٰٟـ]/.test(c)) return '';
    if (/[أإآٱ]/.test(c)) return 'ا';
    if (c === 'ة') return 'ه';
    if (c === 'ى') return 'ي';
    if (c === 'ؤ') return 'و';
    if (c === 'ئ') return 'ي';
    var code = c.charCodeAt(0);
    if (code >= 0x660 && code <= 0x669) return String(code - 0x660);
    if (code >= 0x6F0 && code <= 0x6F9) return String(code - 0x6F0);
    if (c === ' ' || c === '\n' || c === '\r' || c === '\t') return ' ';
    return c.toLowerCase();
  }

  function norm(v) {
    var s = String(v == null ? '' : v), out = '';
    for (var i = 0; i < s.length; i++) out += normChar(s[i]);
    return out.replace(/\s+/g, ' ');
  }

  /* Normalised text plus a map from each normalised character back to the
     source index, used to highlight matches in the original text. */
  function normMap(v) {
    var s = String(v == null ? '' : v), out = '', map = [];
    for (var i = 0; i < s.length; i++) {
      var n = normChar(s[i]);
      for (var j = 0; j < n.length; j++) { out += n[j]; map.push(i); }
    }
    return { text: out, map: map };
  }

  function dirOf(v) {
    var s = String(v || '');
    var ar = (s.match(/[؀-ۿ]/g) || []).length;
    var la = (s.match(/[A-Za-z]/g) || []).length;
    return la > ar ? 'ltr' : 'rtl';
  }

  /* ---------- numbers ---------- */
  function missingNumber(n) { return n == null || (typeof n === 'string' && n.trim() === '') || !Number.isFinite(Number(n)); }
  function fmtN(n) {
    if (missingNumber(n)) return '—';
    return Math.round(n).toLocaleString('en-US');
  }
  /* A recorded zero is a value. Unavailable values have a separate placeholder. */
  function metricText(n, percent) {
    if (typeof n !== 'number' || !Number.isFinite(n)) return '—';
    var rounded = Math.round(percent ? n * 100 : n);
    return fmtN(rounded) + (percent ? '%' : '');
  }
  function fmtNum(n, maxDec) {
    if (missingNumber(n)) return '';
    return Number(n).toLocaleString('en-US', { maximumFractionDigits: maxDec == null ? 2 : maxDec });
  }
  function fmtM(n) { return missingNumber(n) ? '—' : (Number(n) / 1e6).toFixed(2); }
  function pct(part, whole) { return whole ? Math.round(part / whole * 100) : 0; }

  /* Excel's IFERROR(--x, 0): numbers stay, numeric text is read, anything else is 0. */
  function toNumber(cell) {
    if (!cell) return 0;
    if (cell.t === 'n') return typeof cell.v === 'number' ? cell.v : 0;
    if (cell.t === 's') {
      var t = String(cell.v).replace(/[,\s ]/g, '');
      if (t === '' || isNaN(Number(t))) return 0;
      return Number(t);
    }
    if (cell.t === 'b') return cell.v ? 1 : 0;
    return 0;
  }

  /* ---------- dates as Excel serials (days since 1899-12-30) ---------- */
  var DAY = 86400000;
  var EPOCH = Date.UTC(1899, 11, 30);
  var MONTHS_AR = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
  var MONTHS_EN3 = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

  function serial(y, m, d) { return Math.round((Date.UTC(y, m - 1, d) - EPOCH) / DAY); }
  function ymd(s) {
    var dt = new Date(EPOCH + Math.floor(s) * DAY);
    return { y: dt.getUTCFullYear(), m: dt.getUTCMonth() + 1, d: dt.getUTCDate() };
  }
  function todaySerial() { var n = new Date(); return serial(n.getFullYear(), n.getMonth() + 1, n.getDate()); }
  function eomonth(y, m) { return serial(y, m + 1, 0); }
  function pad2(n) { return String(n).padStart(2, '0'); }
  function validDateSerial(s) { return typeof s === 'number' && Number.isFinite(s) && s > 0 && s < 2958466; }
  function fmtDate(s) {
    if (!validDateSerial(s)) return '';
    var p = ymd(s);
    return pad2(p.d) + '/' + pad2(p.m) + '/' + p.y;
  }
  function fmtMonthYear(s) { if (!validDateSerial(s)) return ''; var p = ymd(s); return MONTHS_AR[p.m - 1] + ' ' + p.y; }
  /* Translate a month token only; never invent the missing day or year. */
  function monthLabel(v) {
    var s = String(v == null ? '' : v).trim(), token = s.toUpperCase(), i = token === 'SEPT' ? 8 : MONTHS_EN3.indexOf(token);
    return i >= 0 ? MONTHS_AR[i] : s;
  }
  function quarterLabel(v) {
    var s = String(v == null ? '' : v).trim(), m = /^(?:(\d{4})\s+)?Q([1-4])$/i.exec(s);
    return m ? ['الربع الأول', 'الربع الثاني', 'الربع الثالث', 'الربع الرابع'][Number(m[2]) - 1] + (m[1] ? ' ' + m[1] : '') : s;
  }
  function fmtDateTime(d) {
    if (!(d instanceof Date) || isNaN(d)) return '';
    return pad2(d.getDate()) + '/' + pad2(d.getMonth() + 1) + '/' + d.getFullYear() + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
  }
  function monthIndexAr(v) {
    var k = key(v);
    for (var i = 0; i < 12; i++) if (key(MONTHS_AR[i]) === k) return i + 1;
    return 0;
  }
  /* Share of the calendar year that has passed on day s (1 Jan counts as day 1). */
  function yearElapsed(s) {
    var y = ymd(s).y, a = serial(y, 1, 1), b = serial(y + 1, 1, 1);
    return (s - a + 1) / (b - a);
  }

  /* ---------- DOM / files ---------- */
  function icon(name, size, cls) {
    size = size || 18;
    return '<svg class="ic' + (cls ? ' ' + cls : '') + '" width="' + size + '" height="' + size +
      '" aria-hidden="true" focusable="false"><use href="#i-' + name + '"></use></svg>';
  }

  function download(name, content, type) {
    var blob = content instanceof Blob ? content : new Blob([content], { type: type || 'text/plain;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = name; a.style.display = 'none';
    document.body.appendChild(a); a.click(); a.remove();
    // Released late: a busy browser may start the save after a few seconds
    setTimeout(function () { URL.revokeObjectURL(url); }, 40000);
  }

  /* CSV that Excel opens as UTF-8 (byte order mark + CRLF). */
  function csv(rows) {
    return '﻿' + rows.map(function (r) {
      return r.map(function (v) {
        var text = String(v == null ? '' : v);
        // Quoting alone does not stop Excel from evaluating imported text as a
        // formula. Numeric values (including negative amounts) stay numeric.
        if (typeof v !== 'number' && /^[\s\uFEFF]*[=+@-]/.test(text) && !/^[+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?%?$/.test(text)) text = "'" + text;
        return '"' + text.replace(/"/g, '""') + '"';
      }).join(',');
    }).join('\r\n');
  }

  var store = {
    get: function (area, k) { try { return window[area].getItem(k); } catch (e) { return null; } },
    set: function (area, k, v) { try { window[area].setItem(k, v); return true; } catch (e) { return false; } },
    del: function (area, k) { try { window[area].removeItem(k); } catch (e) { /* storage unavailable */ } }
  };
  // Storage can fail in private/file browsing or when a browser quota is full.
  // Keep edits in memory and expose the failure without changing report output.
  function persistence(state,key,message){
    state.persistenceWarnings=state.persistenceWarnings||{};
    if(message)state.persistenceWarnings[key]=message;else delete state.persistenceWarnings[key];
    if(S.app&&S.app.refreshPersistenceNotice)S.app.refreshPersistenceNotice();
  }

  /* Scalar values from older links remain valid. Empty lists remove a filter.
     An explicit [""] selects blank source values, and is distinct from no filter. */
  function selection(v) { return Array.from(new Set((Array.isArray(v) ? v : v == null || v === '' ? [] : [v]).filter(function(x){return typeof x === 'string' || typeof x === 'number';}).map(String))); }
  function hasSelection(v) { return selection(v).length > 0; }
  function selected(value, v, normalize) { var a=selection(v), norm=normalize||key; return !a.length || a.some(function(x){return norm(value)==norm(x);}); }
  function selectionText(v, all) { var a=selection(v); return a.length ? a.map(function(x){return x || 'غير مسجل';}).join('، ') : all || ''; }
  function singleSelection(v) { var a=selection(v); return a.length===1 ? a[0] : null; }
  function selectionState(v) { var a=selection(v); return a.length===1 && a[0]!=='' ? a[0] : a.length ? a : ''; }
  function selectionParam(p,k,v) { var a=selection(v); if(a.length)p.set(k, a.length===1 && a[0]!=='' && a[0][0]!=='[' ? a[0] : JSON.stringify(a)); }
  function selectionFromParam(p,k) { var v=p.get(k)||''; if(v[0]==='['){try{var a=JSON.parse(v);if(Array.isArray(a))return selectionState(a);}catch(ignore){}}return v; }

  S.util = {
    selection:selection, hasSelection:hasSelection, selected:selected, selectionText:selectionText, singleSelection:singleSelection, selectionState:selectionState, selectionParam:selectionParam, selectionFromParam:selectionFromParam,
    esc: esc, key: key, tableCellText: tableCellText, xl: xl, xlTrim: xlTrim, norm: norm, normMap: normMap, dirOf: dirOf,
    fmtN: fmtN, metricText: metricText, fmtNum: fmtNum, fmtM: fmtM, pct: pct, toNumber: toNumber,
    DAY: DAY, EPOCH: EPOCH, MONTHS_AR: MONTHS_AR, MONTHS_EN3: MONTHS_EN3,
    serial: serial, ymd: ymd, todaySerial: todaySerial, eomonth: eomonth,
    validDateSerial: validDateSerial, fmtDate: fmtDate, fmtMonthYear: fmtMonthYear, fmtDateTime: fmtDateTime, monthLabel: monthLabel, quarterLabel: quarterLabel,
    monthIndexAr: monthIndexAr, yearElapsed: yearElapsed,
    icon: icon, download: download, csv: csv, store: store, persistence:persistence
  };
})(window.Saytara = window.Saytara || {});
/* Per-report display metadata. It never changes workbook dates, filters or calculations. */
(function(S){
 'use strict';var U=S.util,KEY='saytara.report-display.v1',NAV={agenda:'تقرير الأجندة السنوية',hh:'تقرير المشاريع الخاصة',council:'تقرير قرارات المجالس',projects:'تقرير المشاريع'},DEFAULT={agenda:'مستجدات الأجندة السنوية',hh:'تقرير المشاريع الخاصة',council:'تقرير قرارات المجالس',projects:'تقرير المشاريع'};
 function kind(state){return ['hh','council','projects'].includes(state.report.kind)?state.report.kind:'agenda';}
 function clean(v,max){return typeof v==='string'?Array.from(v.replace(/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g,' ').replace(/\s+/g,' ').trim()).filter(function(ch){var c=ch.codePointAt(0);return c<55296||c>57343;}).slice(0,max).join(''):'';}
 function normalized(v){v=v&&typeof v==='object'?v:{};return {title:clean(v.title,140),period:clean(v.period,100)};}
 // The previous council heading implied a current-year-only scope, while the
 // report contains historical decisions. Correct only the exact old pair the
 // user asked to replace; either field changed by the user remains untouched.
 function legacyCouncil(v){v=normalized(v);return v.title==='مستجدات قرارات المجالس 2026' && /^يناير\s*[-\u2010-\u2015\u2212]\s*سبتمبر\s+2026$/.test(v.period);}
 function all(state){state.report=state.report||{};if(!state.report.displayMeta){var saved;try{saved=JSON.parse(U.store.get('localStorage',KEY)||'{}');}catch(ignore){}var x={};Object.keys(NAV).forEach(function(k){x[k]=normalized(saved&&saved[k]);});state.report.displayMeta=x;}if(legacyCouncil(state.report.displayMeta.council)){state.report.displayMeta.council={title:'',period:''};U.store.set('localStorage',KEY,JSON.stringify(state.report.displayMeta));}return state.report.displayMeta;}
 function raw(state){return normalized(all(state)[kind(state)]);}
 function get(state){var v=raw(state);return {title:v.title||DEFAULT[kind(state)],period:v.period||(state.data&&U.validDateSerial(state.data.today)?'حتى تاريخ '+U.fmtDate(state.data.today):''),fileTitle:v.title||NAV[kind(state)]};}
 function save(state,v){var k=kind(state),value=normalized(v);all(state)[k]=k==='council'&&legacyCouncil(value)?{title:'',period:''}:value;var ok=U.store.set('localStorage',KEY,JSON.stringify(all(state)));U.persistence(state,'report-display',ok?'':'تعذّر حفظ عنوان التقرير وفترته في المتصفح؛ تبقى التعديلات متاحة الآن فقط.');return get(state);}
 function set(state,field,value){var v=raw(state);if(['title','period'].includes(field))v[field]=value;return save(state,v);}
 function text(options,data){return clean(options&&options.reportPeriodText,100)||(data&&U.validDateSerial(data.today)?'حتى تاريخ '+U.fmtDate(data.today):'');}
 function fileTitle(v){var s=clean(v,140).replace(/[<>:"/\\|?*]/g,' ').replace(/[. ]+$/g,'').replace(/\s+/g,' ').trim()||'تقرير';if(/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(s))s='تقرير - '+s;return Array.from(s).slice(0,60).join('');}
 function params(state,p){var v=raw(state);p.set('reportTitle',v.title);p.set('reportPeriod',v.period);}
 function restore(state,p){if(p.has('reportTitle')||p.has('reportPeriod')){var v={title:p.get('reportTitle')||'',period:p.get('reportPeriod')||''},migrate=kind(state)==='council'&&legacyCouncil(v),result=save(state,v);if(migrate&&typeof location!=='undefined'&&typeof history!=='undefined'){var match=/^#\/reports\?(.*)$/.exec(location.hash),live=match&&new URLSearchParams(match[1]);if(live&&live.get('kind')==='council'&&legacyCouncil({title:live.get('reportTitle'),period:live.get('reportPeriod')})){live.set('reportTitle','');live.set('reportPeriod','');try{history.replaceState(null,'','#/reports?'+live.toString());}catch(ignore){}}}return result;}return get(state);}
 function options(state){var v=get(state);return {reportTitle:v.title,reportPeriodText:v.period,reportFileTitle:fileTitle(v.fileTitle)};}
 function controls(state){var v=get(state),disabled=state.reporting?' disabled':'';return '<section class="report-display-controls" aria-label="عنوان وفترة التقرير"><div class="report-display-fields"><label>عنوان التقرير<input type="text" data-report-display="title" maxlength="140" value="'+U.esc(v.title)+'"'+disabled+'></label><label>الفترة المعروضة<input type="text" data-report-display="period" maxlength="100" value="'+U.esc(v.period)+'"'+disabled+'></label><button type="button" class="btn" data-act="reset-report-display"'+disabled+'>إعادة الافتراضي</button></div></section>';}
 function long(state){var v=get(state);return v.title.length>55||v.period.length>45;}
 function updateVisible(state){var v=get(state);if(typeof document!=='undefined'&&document.querySelectorAll){document.querySelectorAll('[data-report-title]').forEach(function(el){el.textContent=v.title;});document.querySelectorAll('[data-report-period-label]').forEach(function(el){el.textContent=v.period;});document.querySelectorAll('.ag-cover').forEach(function(el){el.setAttribute('data-report-long',long(state)?'true':'false');});}}
 function cover(options){var title=clean(options&&options.reportTitle,140),period=text(options);return {titleSize:title.length>80?22:title.length>55?25:28,titleBox:title.length>55?[180,282,920,112]:[180,318,920,76],periodSize:period.length>65?15:18,periodBox:[200,410,880,86]};}
 S.reportDisplay={get:get,raw:raw,set:set,save:save,text:text,clean:clean,fileTitle:fileTitle,options:options,cover:cover,params:params,restore:restore,controls:controls,long:long,updateVisible:updateVisible,reset:function(state){return save(state,{});}};
})(window.Saytara=window.Saytara||{});

/* Report notes are local to the workbook, report and selected scope. */
(function(S){
 'use strict';var U=S.util,sourceIds=new WeakMap(),sourceSeq=0;
 function sourceKey(data){if(data.fingerprint)return data.fingerprint;if(!sourceIds.has(data))sourceIds.set(data,'session-'+Date.now()+'-'+(++sourceSeq));return sourceIds.get(data);}
 function key(state){return JSON.stringify(['saytara.report-editorial.v1',state.report.kind,sourceKey(state.data),state.data.file.name,state.data.file.size||'',state.data.year,U.selection(state.dash.sector).sort(),U.selection(state.dash.unit).sort(),...(U.hasSelection(state.dash.entity)?[['concernedEntity',U.selection(state.dash.entity).sort()]]:[]),state.report.kind==='hh'?U.selection(state.report.lead).sort():[],...(state.report.kind==='council'&&U.hasSelection(state.report.followup)?[['followup',U.selection(state.report.followup).sort()]]:[])]);}
 function options(state){var k=key(state);state.report.editorialOptions=state.report.editorialOptions||{};if(!state.report.editorialOptions[k]){var saved={};try{saved=JSON.parse(U.store.get('sessionStorage',k)||'{}');}catch(ignore){}state.report.editorialOptions[k]={notes:saved&&typeof saved.notes==='string'?saved.notes:'',recommendations:saved&&typeof saved.recommendations==='string'?saved.recommendations:''};}return state.report.editorialOptions[k];}
 function set(state,field,value){if(!['notes','recommendations'].includes(field))return;options(state)[field]=String(value==null?'':value);var ok=U.store.set('sessionStorage',key(state),JSON.stringify(options(state)));U.persistence(state,'report-notes',ok?'':'تعذّر حفظ نصوص التقرير للجلسة؛ تبقى التعديلات متاحة الآن. انسخ النصوص قبل تحديث الصفحة.');}
 function content(state){var o=options(state);return [['notes','ملاحظات'],['recommendations','توصيات']].filter(function(x){return o[x[0]].trim();}).map(function(x){return '<section class="ag-editorial-section ag-'+x[0]+'"><h3>'+x[1]+'</h3><p>'+U.esc(o[x[0]].trim())+'</p></section>';}).join('');}
 function output(state){var html=content(state);return '<aside id="report-editorial" class="rpt-editorial" aria-label="ملاحظات وتوصيات التقرير"'+(!html?' hidden':'')+'>'+html+'</aside>';}
 function update(state){var el=document.getElementById('report-editorial');if(el){var html=content(state);el.innerHTML=html;el.hidden=!html;}}
 function editor(state){var o=options(state),disabled=state.reporting?' disabled':'';return '<details class="ag-editor rpt-editor"><summary>إعداد محتوى التقرير</summary><div class="ag-editor-fields">'+[['notes','ملاحظات'],['recommendations','توصيات']].map(function(x){return '<label class="ag-editor-text">'+x[1]+'<textarea data-report-text="'+x[0]+'" rows="4" placeholder="أضف '+(x[0]==='notes'?'الملاحظات':'التوصيات')+' لعرضها في التقرير"'+disabled+'>'+U.esc(o[x[0]])+'</textarea></label>';}).join('')+'</div></details>';}
 S.reportEditorial={options:options,set:set,editor:editor,output:output,update:update,sourceKey:sourceKey};
})(window.Saytara=window.Saytara||{});
